package processing.core;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.util.Arrays;

public class PGraphicsJava2D extends PGraphics {
  public Graphics2D g2;
  
  protected BufferedImage offscreen;
  
  GeneralPath gpath;
  
  boolean breakShape;
  
  float[] curveCoordX;
  
  float[] curveCoordY;
  
  float[] curveDrawX;
  
  float[] curveDrawY;
  
  int transformCount;
  
  AffineTransform[] transformStack = new AffineTransform[32];
  
  double[] transform = new double[6];
  
  Line2D.Float line = new Line2D.Float();
  
  Ellipse2D.Float ellipse = new Ellipse2D.Float();
  
  Rectangle2D.Float rect = new Rectangle2D.Float();
  
  Arc2D.Float arc = new Arc2D.Float();
  
  protected Color tintColorObject;
  
  protected Color fillColorObject;
  
  public boolean fillGradient;
  
  public Paint fillGradientObject;
  
  protected Color strokeColorObject;
  
  public boolean strokeGradient;
  
  public Paint strokeGradientObject;
  
  int[] clearPixels;
  
  static int[] getset = new int[1];
  
  public void setSize(int paramInt1, int paramInt2) {
    this.width = paramInt1;
    this.height = paramInt2;
    this.width1 = this.width - 1;
    this.height1 = this.height - 1;
    allocate();
    reapplySettings();
  }
  
  protected void allocate() {
    this.image = new BufferedImage(this.width, this.height, 2);
    if (this.primarySurface) {
      this.offscreen = new BufferedImage(this.width, this.height, 2);
      this.g2 = (Graphics2D)this.offscreen.getGraphics();
    } else {
      this.g2 = (Graphics2D)this.image.getGraphics();
    } 
  }
  
  public boolean canDraw() {
    return true;
  }
  
  public void beginDraw() {
    checkSettings();
    resetMatrix();
    this.vertexCount = 0;
  }
  
  public void endDraw() {
    if (this.primarySurface) {
      synchronized (this.image) {
        this.image.getGraphics().drawImage(this.offscreen, 0, 0, null);
      } 
    } else {
      loadPixels();
    } 
    this.modified = true;
  }
  
  public void beginShape(int paramInt) {
    this.shape = paramInt;
    this.vertexCount = 0;
    this.curveVertexCount = 0;
    this.gpath = null;
  }
  
  public void texture(PImage paramPImage) {
    showMethodWarning("texture");
  }
  
  public void vertex(float paramFloat1, float paramFloat2) {
    this.curveVertexCount = 0;
    if (this.vertexCount == this.vertices.length) {
      float[][] arrayOfFloat = new float[this.vertexCount << 1][37];
      System.arraycopy(this.vertices, 0, arrayOfFloat, 0, this.vertexCount);
      this.vertices = arrayOfFloat;
    } 
    this.vertices[this.vertexCount][0] = paramFloat1;
    this.vertices[this.vertexCount][1] = paramFloat2;
    this.vertexCount++;
    switch (this.shape) {
      case 2:
        point(paramFloat1, paramFloat2);
        break;
      case 4:
        if (this.vertexCount % 2 == 0)
          line(this.vertices[this.vertexCount - 2][0], this.vertices[this.vertexCount - 2][1], paramFloat1, paramFloat2); 
        break;
      case 9:
        if (this.vertexCount % 3 == 0)
          triangle(this.vertices[this.vertexCount - 3][0], this.vertices[this.vertexCount - 3][1], this.vertices[this.vertexCount - 2][0], this.vertices[this.vertexCount - 2][1], paramFloat1, paramFloat2); 
        break;
      case 10:
        if (this.vertexCount >= 3)
          triangle(this.vertices[this.vertexCount - 2][0], this.vertices[this.vertexCount - 2][1], this.vertices[this.vertexCount - 1][0], this.vertices[this.vertexCount - 1][1], this.vertices[this.vertexCount - 3][0], this.vertices[this.vertexCount - 3][1]); 
        break;
      case 11:
        if (this.vertexCount == 3) {
          triangle(this.vertices[0][0], this.vertices[0][1], this.vertices[1][0], this.vertices[1][1], paramFloat1, paramFloat2);
          break;
        } 
        if (this.vertexCount > 3) {
          this.gpath = new GeneralPath();
          this.gpath.moveTo(this.vertices[0][0], this.vertices[0][1]);
          this.gpath.lineTo(this.vertices[this.vertexCount - 2][0], this.vertices[this.vertexCount - 2][1]);
          this.gpath.lineTo(paramFloat1, paramFloat2);
          drawShape(this.gpath);
        } 
        break;
      case 16:
        if (this.vertexCount % 4 == 0)
          quad(this.vertices[this.vertexCount - 4][0], this.vertices[this.vertexCount - 4][1], this.vertices[this.vertexCount - 3][0], this.vertices[this.vertexCount - 3][1], this.vertices[this.vertexCount - 2][0], this.vertices[this.vertexCount - 2][1], paramFloat1, paramFloat2); 
        break;
      case 17:
        if (this.vertexCount >= 4 && this.vertexCount % 2 == 0)
          quad(this.vertices[this.vertexCount - 4][0], this.vertices[this.vertexCount - 4][1], this.vertices[this.vertexCount - 2][0], this.vertices[this.vertexCount - 2][1], paramFloat1, paramFloat2, this.vertices[this.vertexCount - 3][0], this.vertices[this.vertexCount - 3][1]); 
        break;
      case 20:
        if (this.gpath == null) {
          this.gpath = new GeneralPath();
          this.gpath.moveTo(paramFloat1, paramFloat2);
          break;
        } 
        if (this.breakShape) {
          this.gpath.moveTo(paramFloat1, paramFloat2);
          this.breakShape = false;
          break;
        } 
        this.gpath.lineTo(paramFloat1, paramFloat2);
        break;
    } 
  }
  
  public void vertex(float paramFloat1, float paramFloat2, float paramFloat3) {
    showDepthWarningXYZ("vertex");
  }
  
  public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    showVariationWarning("vertex(x, y, u, v)");
  }
  
  public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    showDepthWarningXYZ("vertex");
  }
  
  public void breakShape() {
    this.breakShape = true;
  }
  
  public void endShape(int paramInt) {
    if (this.gpath != null && this.shape == 20) {
      if (paramInt == 2)
        this.gpath.closePath(); 
      drawShape(this.gpath);
    } 
    this.shape = 0;
  }
  
  public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    bezierVertexCheck();
    this.gpath.curveTo(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9) {
    showDepthWarningXYZ("bezierVertex");
  }
  
  public void quadVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    bezierVertexCheck();
    Point2D point2D = this.gpath.getCurrentPoint();
    float f1 = (float)point2D.getX();
    float f2 = (float)point2D.getY();
    bezierVertex(f1 + (paramFloat1 - f1) * 2.0F / 3.0F, f2 + (paramFloat2 - f2) * 2.0F / 3.0F, paramFloat3 + (paramFloat1 - paramFloat3) * 2.0F / 3.0F, paramFloat4 + (paramFloat2 - paramFloat4) * 2.0F / 3.0F, paramFloat3, paramFloat4);
  }
  
  public void quadVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    showDepthWarningXYZ("quadVertex");
  }
  
  protected void curveVertexCheck() {
    super.curveVertexCheck();
    if (this.curveCoordX == null) {
      this.curveCoordX = new float[4];
      this.curveCoordY = new float[4];
      this.curveDrawX = new float[4];
      this.curveDrawY = new float[4];
    } 
  }
  
  protected void curveVertexSegment(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    this.curveCoordX[0] = paramFloat1;
    this.curveCoordY[0] = paramFloat2;
    this.curveCoordX[1] = paramFloat3;
    this.curveCoordY[1] = paramFloat4;
    this.curveCoordX[2] = paramFloat5;
    this.curveCoordY[2] = paramFloat6;
    this.curveCoordX[3] = paramFloat7;
    this.curveCoordY[3] = paramFloat8;
    this.curveToBezierMatrix.mult(this.curveCoordX, this.curveDrawX);
    this.curveToBezierMatrix.mult(this.curveCoordY, this.curveDrawY);
    if (this.gpath == null) {
      this.gpath = new GeneralPath();
      this.gpath.moveTo(this.curveDrawX[0], this.curveDrawY[0]);
    } 
    this.gpath.curveTo(this.curveDrawX[1], this.curveDrawY[1], this.curveDrawX[2], this.curveDrawY[2], this.curveDrawX[3], this.curveDrawY[3]);
  }
  
  public void curveVertex(float paramFloat1, float paramFloat2, float paramFloat3) {
    showDepthWarningXYZ("curveVertex");
  }
  
  public void point(float paramFloat1, float paramFloat2) {
    if (this.stroke)
      line(paramFloat1, paramFloat2, paramFloat1 + 1.0E-4F, paramFloat2 + 1.0E-4F); 
  }
  
  public void line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.line.setLine(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    strokeShape(this.line);
  }
  
  public void triangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    this.gpath = new GeneralPath();
    this.gpath.moveTo(paramFloat1, paramFloat2);
    this.gpath.lineTo(paramFloat3, paramFloat4);
    this.gpath.lineTo(paramFloat5, paramFloat6);
    this.gpath.closePath();
    drawShape(this.gpath);
  }
  
  public void quad(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    GeneralPath generalPath = new GeneralPath();
    generalPath.moveTo(paramFloat1, paramFloat2);
    generalPath.lineTo(paramFloat3, paramFloat4);
    generalPath.lineTo(paramFloat5, paramFloat6);
    generalPath.lineTo(paramFloat7, paramFloat8);
    generalPath.closePath();
    drawShape(generalPath);
  }
  
  protected void rectImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.rect.setFrame(paramFloat1, paramFloat2, (paramFloat3 - paramFloat1), (paramFloat4 - paramFloat2));
    drawShape(this.rect);
  }
  
  protected void ellipseImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.ellipse.setFrame(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    drawShape(this.ellipse);
  }
  
  protected void arcImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    paramFloat5 = -paramFloat5 * 57.295776F;
    paramFloat6 = -paramFloat6 * 57.295776F;
    float f = paramFloat6 - paramFloat5;
    if (this.fill) {
      this.arc.setArc(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, f, 2);
      fillShape(this.arc);
    } 
    if (this.stroke) {
      this.arc.setArc(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, f, 0);
      strokeShape(this.arc);
    } 
  }
  
  protected void fillShape(Shape paramShape) {
    if (this.fillGradient) {
      this.g2.setPaint(this.fillGradientObject);
      this.g2.fill(paramShape);
    } else if (this.fill) {
      this.g2.setColor(this.fillColorObject);
      this.g2.fill(paramShape);
    } 
  }
  
  protected void strokeShape(Shape paramShape) {
    if (this.strokeGradient) {
      this.g2.setPaint(this.strokeGradientObject);
      this.g2.draw(paramShape);
    } else if (this.stroke) {
      this.g2.setColor(this.strokeColorObject);
      this.g2.draw(paramShape);
    } 
  }
  
  protected void drawShape(Shape paramShape) {
    if (this.fillGradient) {
      this.g2.setPaint(this.fillGradientObject);
      this.g2.fill(paramShape);
    } else if (this.fill) {
      this.g2.setColor(this.fillColorObject);
      this.g2.fill(paramShape);
    } 
    if (this.strokeGradient) {
      this.g2.setPaint(this.strokeGradientObject);
      this.g2.draw(paramShape);
    } else if (this.stroke) {
      this.g2.setColor(this.strokeColorObject);
      this.g2.draw(paramShape);
    } 
  }
  
  public void box(float paramFloat1, float paramFloat2, float paramFloat3) {
    showMethodWarning("box");
  }
  
  public void sphere(float paramFloat) {
    showMethodWarning("sphere");
  }
  
  public void bezierDetail(int paramInt) {}
  
  public void curveDetail(int paramInt) {}
  
  public void smooth() {
    this.smooth = true;
    this.g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    this.g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
  }
  
  public void noSmooth() {
    this.smooth = false;
    this.g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
    this.g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
  }
  
  protected void imageImpl(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramPImage.width <= 0 || paramPImage.height <= 0)
      return; 
    if (paramPImage.getCache(this) == null) {
      paramPImage.setCache(this, new ImageCache(paramPImage));
      paramPImage.updatePixels();
      paramPImage.modified = true;
    } 
    ImageCache imageCache = (ImageCache)paramPImage.getCache(this);
    if ((this.tint && !imageCache.tinted) || (this.tint && imageCache.tintedColor != this.tintColor) || (!this.tint && imageCache.tinted))
      paramPImage.updatePixels(); 
    if (paramPImage.modified) {
      imageCache.update(this.tint, this.tintColor);
      paramPImage.modified = false;
    } 
    this.g2.drawImage(((ImageCache)paramPImage.getCache(this)).image, (int)paramFloat1, (int)paramFloat2, (int)paramFloat3, (int)paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4, null);
  }
  
  public float textAscent() {
    if (this.textFont == null)
      defaultFontOrDeath("textAscent"); 
    Font font = this.textFont.getFont();
    if (font != null) {
      FontMetrics fontMetrics = this.parent.getFontMetrics(font);
      return fontMetrics.getAscent();
    } 
    return super.textAscent();
  }
  
  public float textDescent() {
    if (this.textFont == null)
      defaultFontOrDeath("textAscent"); 
    Font font = this.textFont.getFont();
    if (font != null) {
      FontMetrics fontMetrics = this.parent.getFontMetrics(font);
      return fontMetrics.getDescent();
    } 
    return super.textDescent();
  }
  
  protected boolean textModeCheck(int paramInt) {
    return (paramInt == 4 || paramInt == 256);
  }
  
  public void textSize(float paramFloat) {
    if (this.textFont == null)
      defaultFontOrDeath("textAscent", paramFloat); 
    Font font = this.textFont.getFont();
    if (font != null) {
      Font font1 = font.deriveFont(paramFloat);
      this.g2.setFont(font1);
      this.textFont.setFont(font1);
    } 
    super.textSize(paramFloat);
  }
  
  protected float textWidthImpl(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    Font font = this.textFont.getFont();
    if (font != null) {
      int i = paramInt2 - paramInt1;
      FontMetrics fontMetrics = this.g2.getFontMetrics(font);
      return fontMetrics.charsWidth(paramArrayOfchar, paramInt1, i);
    } 
    return super.textWidthImpl(paramArrayOfchar, paramInt1, paramInt2);
  }
  
  protected void textLineImpl(char[] paramArrayOfchar, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
    Font font = this.textFont.getFont();
    if (font != null) {
      Object object = this.g2.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
      if (object == null)
        object = RenderingHints.VALUE_ANTIALIAS_DEFAULT; 
      this.g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, this.textFont.smooth ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
      this.g2.setColor(this.fillColorObject);
      int i = paramInt2 - paramInt1;
      this.g2.drawChars(paramArrayOfchar, paramInt1, i, (int)(paramFloat1 + 0.5F), (int)(paramFloat2 + 0.5F));
      this.g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, object);
      this.textX = paramFloat1 + textWidthImpl(paramArrayOfchar, paramInt1, paramInt2);
      this.textY = paramFloat2;
      this.textZ = 0.0F;
    } else {
      super.textLineImpl(paramArrayOfchar, paramInt1, paramInt2, paramFloat1, paramFloat2);
    } 
  }
  
  public void pushMatrix() {
    if (this.transformCount == this.transformStack.length)
      throw new RuntimeException("pushMatrix() cannot use push more than " + this.transformStack.length + " times"); 
    this.transformStack[this.transformCount] = this.g2.getTransform();
    this.transformCount++;
  }
  
  public void popMatrix() {
    if (this.transformCount == 0)
      throw new RuntimeException("missing a popMatrix() to go with that pushMatrix()"); 
    this.transformCount--;
    this.g2.setTransform(this.transformStack[this.transformCount]);
  }
  
  public void translate(float paramFloat1, float paramFloat2) {
    this.g2.translate(paramFloat1, paramFloat2);
  }
  
  public void rotate(float paramFloat) {
    this.g2.rotate(paramFloat);
  }
  
  public void rotateX(float paramFloat) {
    showDepthWarning("rotateX");
  }
  
  public void rotateY(float paramFloat) {
    showDepthWarning("rotateY");
  }
  
  public void rotateZ(float paramFloat) {
    showDepthWarning("rotateZ");
  }
  
  public void rotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    showVariationWarning("rotate");
  }
  
  public void scale(float paramFloat) {
    this.g2.scale(paramFloat, paramFloat);
  }
  
  public void scale(float paramFloat1, float paramFloat2) {
    this.g2.scale(paramFloat1, paramFloat2);
  }
  
  public void scale(float paramFloat1, float paramFloat2, float paramFloat3) {
    showDepthWarningXYZ("scale");
  }
  
  public void skewX(float paramFloat) {
    this.g2.shear(Math.tan(paramFloat), 0.0D);
  }
  
  public void skewY(float paramFloat) {
    this.g2.shear(0.0D, Math.tan(paramFloat));
  }
  
  public void resetMatrix() {
    this.g2.setTransform(new AffineTransform());
  }
  
  public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    this.g2.transform(new AffineTransform(paramFloat1, paramFloat4, paramFloat2, paramFloat5, paramFloat3, paramFloat6));
  }
  
  public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16) {
    showVariationWarning("applyMatrix");
  }
  
  public PMatrix getMatrix() {
    return getMatrix((PMatrix2D)null);
  }
  
  public PMatrix2D getMatrix(PMatrix2D paramPMatrix2D) {
    if (paramPMatrix2D == null)
      paramPMatrix2D = new PMatrix2D(); 
    this.g2.getTransform().getMatrix(this.transform);
    paramPMatrix2D.set((float)this.transform[0], (float)this.transform[2], (float)this.transform[4], (float)this.transform[1], (float)this.transform[3], (float)this.transform[5]);
    return paramPMatrix2D;
  }
  
  public PMatrix3D getMatrix(PMatrix3D paramPMatrix3D) {
    showVariationWarning("getMatrix");
    return paramPMatrix3D;
  }
  
  public void setMatrix(PMatrix2D paramPMatrix2D) {
    this.g2.setTransform(new AffineTransform(paramPMatrix2D.m00, paramPMatrix2D.m10, paramPMatrix2D.m01, paramPMatrix2D.m11, paramPMatrix2D.m02, paramPMatrix2D.m12));
  }
  
  public void setMatrix(PMatrix3D paramPMatrix3D) {
    showVariationWarning("setMatrix");
  }
  
  public void printMatrix() {
    getMatrix((PMatrix2D)null).print();
  }
  
  public float screenX(float paramFloat1, float paramFloat2) {
    this.g2.getTransform().getMatrix(this.transform);
    return (float)this.transform[0] * paramFloat1 + (float)this.transform[2] * paramFloat2 + (float)this.transform[4];
  }
  
  public float screenY(float paramFloat1, float paramFloat2) {
    this.g2.getTransform().getMatrix(this.transform);
    return (float)this.transform[1] * paramFloat1 + (float)this.transform[3] * paramFloat2 + (float)this.transform[5];
  }
  
  public float screenX(float paramFloat1, float paramFloat2, float paramFloat3) {
    showDepthWarningXYZ("screenX");
    return 0.0F;
  }
  
  public float screenY(float paramFloat1, float paramFloat2, float paramFloat3) {
    showDepthWarningXYZ("screenY");
    return 0.0F;
  }
  
  public float screenZ(float paramFloat1, float paramFloat2, float paramFloat3) {
    showDepthWarningXYZ("screenZ");
    return 0.0F;
  }
  
  public void strokeCap(int paramInt) {
    super.strokeCap(paramInt);
    strokeImpl();
  }
  
  public void strokeJoin(int paramInt) {
    super.strokeJoin(paramInt);
    strokeImpl();
  }
  
  public void strokeWeight(float paramFloat) {
    super.strokeWeight(paramFloat);
    strokeImpl();
  }
  
  protected void strokeImpl() {
    byte b1 = 0;
    if (this.strokeCap == 2) {
      b1 = 1;
    } else if (this.strokeCap == 4) {
      b1 = 2;
    } 
    byte b2 = 2;
    if (this.strokeJoin == 8) {
      b2 = 0;
    } else if (this.strokeJoin == 2) {
      b2 = 1;
    } 
    this.g2.setStroke(new BasicStroke(this.strokeWeight, b1, b2));
  }
  
  protected void strokeFromCalc() {
    super.strokeFromCalc();
    this.strokeColorObject = new Color(this.strokeColor, true);
    this.strokeGradient = false;
  }
  
  protected void tintFromCalc() {
    super.tintFromCalc();
    this.tintColorObject = new Color(this.tintColor, true);
  }
  
  protected void fillFromCalc() {
    super.fillFromCalc();
    this.fillColorObject = new Color(this.fillColor, true);
    this.fillGradient = false;
  }
  
  public void backgroundImpl() {
    if (this.backgroundAlpha) {
      WritableRaster writableRaster = ((BufferedImage)this.image).getRaster();
      if (this.clearPixels == null || this.clearPixels.length < this.width)
        this.clearPixels = new int[this.width]; 
      Arrays.fill(this.clearPixels, this.backgroundColor);
      for (byte b = 0; b < this.height; b++)
        writableRaster.setDataElements(0, b, this.width, 1, this.clearPixels); 
    } else {
      pushMatrix();
      resetMatrix();
      this.g2.setColor(new Color(this.backgroundColor));
      this.g2.fillRect(0, 0, this.width, this.height);
      popMatrix();
    } 
  }
  
  public void beginRaw(PGraphics paramPGraphics) {
    showMethodWarning("beginRaw");
  }
  
  public void endRaw() {
    showMethodWarning("endRaw");
  }
  
  public void loadPixels() {
    if (this.pixels == null || this.pixels.length != this.width * this.height)
      this.pixels = new int[this.width * this.height]; 
    WritableRaster writableRaster = ((BufferedImage)(this.primarySurface ? this.offscreen : (BufferedImage)this.image)).getRaster();
    writableRaster.getDataElements(0, 0, this.width, this.height, this.pixels);
  }
  
  public void updatePixels() {
    WritableRaster writableRaster = ((BufferedImage)(this.primarySurface ? this.offscreen : (BufferedImage)this.image)).getRaster();
    writableRaster.setDataElements(0, 0, this.width, this.height, this.pixels);
  }
  
  public void updatePixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt1 != 0 || paramInt2 != 0 || paramInt3 != this.width || paramInt4 != this.height)
      showVariationWarning("updatePixels(x, y, w, h)"); 
    updatePixels();
  }
  
  public int get(int paramInt1, int paramInt2) {
    if (paramInt1 < 0 || paramInt2 < 0 || paramInt1 >= this.width || paramInt2 >= this.height)
      return 0; 
    WritableRaster writableRaster = ((BufferedImage)(this.primarySurface ? this.offscreen : (BufferedImage)this.image)).getRaster();
    writableRaster.getDataElements(paramInt1, paramInt2, getset);
    return getset[0];
  }
  
  public PImage getImpl(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    PImage pImage = new PImage(paramInt3, paramInt4);
    pImage.parent = this.parent;
    WritableRaster writableRaster = ((BufferedImage)(this.primarySurface ? this.offscreen : (BufferedImage)this.image)).getRaster();
    writableRaster.getDataElements(paramInt1, paramInt2, paramInt3, paramInt4, pImage.pixels);
    return pImage;
  }
  
  public PImage get() {
    return get(0, 0, this.width, this.height);
  }
  
  public void set(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 < 0 || paramInt2 < 0 || paramInt1 >= this.width || paramInt2 >= this.height)
      return; 
    getset[0] = paramInt3;
    WritableRaster writableRaster = ((BufferedImage)(this.primarySurface ? this.offscreen : (BufferedImage)this.image)).getRaster();
    writableRaster.setDataElements(paramInt1, paramInt2, getset);
  }
  
  protected void setImpl(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, PImage paramPImage) {
    WritableRaster writableRaster = ((BufferedImage)(this.primarySurface ? this.offscreen : (BufferedImage)this.image)).getRaster();
    if (paramInt3 == 0 && paramInt4 == 0 && paramInt5 == paramPImage.width && paramInt6 == paramPImage.height) {
      writableRaster.setDataElements(paramInt1, paramInt2, paramPImage.width, paramPImage.height, paramPImage.pixels);
    } else {
      PImage pImage = paramPImage.get(paramInt3, paramInt4, paramInt5, paramInt6);
      writableRaster.setDataElements(paramInt1, paramInt2, pImage.width, pImage.height, pImage.pixels);
    } 
  }
  
  public void mask(int[] paramArrayOfint) {
    showMethodWarning("mask");
  }
  
  public void mask(PImage paramPImage) {
    showMethodWarning("mask");
  }
  
  public void copy(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
    if (paramInt3 != paramInt7 || paramInt4 != paramInt8) {
      copy(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
    } else {
      paramInt5 -= paramInt1;
      paramInt6 -= paramInt2;
      this.g2.copyArea(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
    } 
  }
  
  class ImageCache {
    PImage source;
    
    boolean tinted;
    
    int tintedColor;
    
    int[] tintedPixels;
    
    BufferedImage image;
    
    public ImageCache(PImage param1PImage) {
      this.source = param1PImage;
    }
    
    public void delete() {}
    
    public void update(boolean param1Boolean, int param1Int) {
      byte b = 2;
      boolean bool1 = ((param1Int & 0xFF000000) == -16777216) ? true : false;
      if (this.source.format == 1 && (!param1Boolean || (param1Boolean && bool1)))
        b = 1; 
      boolean bool2 = (this.image != null && this.image.getType() != b) ? true : false;
      if (this.image == null || bool2)
        this.image = new BufferedImage(this.source.width, this.source.height, b); 
      WritableRaster writableRaster = this.image.getRaster();
      if (param1Boolean) {
        if (this.tintedPixels == null || this.tintedPixels.length != this.source.width)
          this.tintedPixels = new int[this.source.width]; 
        int i = param1Int >> 24 & 0xFF;
        int j = param1Int >> 16 & 0xFF;
        int k = param1Int >> 8 & 0xFF;
        int m = param1Int & 0xFF;
        if (b == 1) {
          byte b1 = 0;
          for (byte b2 = 0; b2 < this.source.height; b2++) {
            for (byte b3 = 0; b3 < this.source.width; b3++) {
              int n = this.source.pixels[b1++];
              int i1 = n >> 16 & 0xFF;
              int i2 = n >> 8 & 0xFF;
              int i3 = n & 0xFF;
              this.tintedPixels[b3] = (j * i1 & 0xFF00) << 8 | k * i2 & 0xFF00 | (m * i3 & 0xFF00) >> 8;
            } 
            writableRaster.setDataElements(0, b2, this.source.width, 1, this.tintedPixels);
          } 
        } else if (b == 2) {
          byte b1 = 0;
          for (byte b2 = 0; b2 < this.source.height; b2++) {
            if (this.source.format == 1) {
              int n = param1Int & 0xFF000000;
              for (byte b3 = 0; b3 < this.source.width; b3++) {
                int i1 = this.source.pixels[b1++];
                int i2 = i1 >> 16 & 0xFF;
                int i3 = i1 >> 8 & 0xFF;
                int i4 = i1 & 0xFF;
                this.tintedPixels[b3] = n | (j * i2 & 0xFF00) << 8 | k * i3 & 0xFF00 | (m * i4 & 0xFF00) >> 8;
              } 
            } else if (this.source.format == 2) {
              for (byte b3 = 0; b3 < this.source.width; b3++) {
                int n = this.source.pixels[b1++];
                int i1 = n >> 24 & 0xFF;
                int i2 = n >> 16 & 0xFF;
                int i3 = n >> 8 & 0xFF;
                int i4 = n & 0xFF;
                this.tintedPixels[b3] = (i * i1 & 0xFF00) << 16 | (j * i2 & 0xFF00) << 8 | k * i3 & 0xFF00 | (m * i4 & 0xFF00) >> 8;
              } 
            } else if (this.source.format == 4) {
              int n = param1Int & 0xFFFFFF;
              for (byte b3 = 0; b3 < this.source.width; b3++) {
                int i1 = this.source.pixels[b1++];
                this.tintedPixels[b3] = (i * i1 & 0xFF00) << 16 | n;
              } 
            } 
            writableRaster.setDataElements(0, b2, this.source.width, 1, this.tintedPixels);
          } 
        } 
      } else {
        writableRaster.setDataElements(0, 0, this.source.width, this.source.height, this.source.pixels);
      } 
      this.tinted = param1Boolean;
      this.tintedColor = param1Int;
    }
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PGraphicsJava2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */