package processing.core;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;

public class PFont implements PConstants {
  protected int glyphCount;
  
  protected Glyph[] glyphs;
  
  protected String name;
  
  protected String psname;
  
  protected int size;
  
  protected boolean smooth;
  
  protected int ascent;
  
  protected int descent;
  
  protected int[] ascii;
  
  protected boolean lazy;
  
  protected Font font;
  
  protected boolean stream;
  
  protected boolean subsetting;
  
  protected boolean fontSearched;
  
  protected static Font[] fonts;
  
  protected static HashMap<String, Font> fontDifferent;
  
  protected BufferedImage lazyImage;
  
  protected Graphics2D lazyGraphics;
  
  protected FontMetrics lazyMetrics;
  
  protected int[] lazySamples;
  
  protected HashMap<PGraphics, Object> cacheMap;
  
  static final char[] EXTRA_CHARS = new char[] { 
      '', '', '', '', '', '', '', '', '', '', 
      '', '', '', '', '', '', '', '', '', '', 
      '', '', '', '', '', '', '', '', '', '', 
      '', '', ' ', '¡', '¢', '£', '¤', '¥', '¦', '§', 
      '¨', '©', 'ª', '«', '¬', '­', '®', '¯', '°', '±', 
      '´', 'µ', '¶', '·', '¸', 'º', '»', '¿', 'À', 'Á', 
      'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 
      'Ì', 'Í', 'Î', 'Ï', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 
      '×', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 
      'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 
      'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 
      '÷', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'Ă', 'ă', 
      'Ą', 'ą', 'Ć', 'ć', 'Č', 'č', 'Ď', 'ď', 'Đ', 'đ', 
      'Ę', 'ę', 'Ě', 'ě', 'ı', 'Ĺ', 'ĺ', 'Ľ', 'ľ', 'Ł', 
      'ł', 'Ń', 'ń', 'Ň', 'ň', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 
      'ŕ', 'Ř', 'ř', 'Ś', 'ś', 'Ş', 'ş', 'Š', 'š', 'Ţ', 
      'ţ', 'Ť', 'ť', 'Ů', 'ů', 'Ű', 'ű', 'Ÿ', 'Ź', 'ź', 
      'Ż', 'ż', 'Ž', 'ž', 'ƒ', 'ˆ', 'ˇ', '˘', '˙', '˚', 
      '˛', '˜', '˝', 'Ω', 'π', '–', '—', '‘', '’', '‚', 
      '“', '”', '„', '†', '‡', '•', '…', '‰', '‹', '›', 
      '⁄', '€', '™', '∂', '∆', '∏', '∑', '√', '∞', '∫', 
      '≈', '≠', '≤', '≥', '◊', '', 'ﬁ', 'ﬂ' };
  
  public static char[] CHARSET = new char[94 + EXTRA_CHARS.length];
  
  public PFont() {}
  
  public PFont(Font paramFont, boolean paramBoolean) {
    this(paramFont, paramBoolean, null);
  }
  
  public PFont(Font paramFont, boolean paramBoolean, char[] paramArrayOfchar) {
    this.font = paramFont;
    this.smooth = paramBoolean;
    this.name = paramFont.getName();
    this.psname = paramFont.getPSName();
    this.size = paramFont.getSize();
    byte b = 10;
    this.glyphs = new Glyph[b];
    this.ascii = new int[128];
    Arrays.fill(this.ascii, -1);
    int i = this.size * 3;
    this.lazyImage = new BufferedImage(i, i, 1);
    this.lazyGraphics = (Graphics2D)this.lazyImage.getGraphics();
    this.lazyGraphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, paramBoolean ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
    this.lazyGraphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, paramBoolean ? RenderingHints.VALUE_TEXT_ANTIALIAS_ON : RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
    this.lazyGraphics.setFont(paramFont);
    this.lazyMetrics = this.lazyGraphics.getFontMetrics();
    this.lazySamples = new int[i * i];
    if (paramArrayOfchar == null) {
      this.lazy = true;
    } else {
      Arrays.sort(paramArrayOfchar);
      this.glyphs = new Glyph[paramArrayOfchar.length];
      this.glyphCount = 0;
      for (char c : paramArrayOfchar) {
        if (paramFont.canDisplay(c)) {
          Glyph glyph = new Glyph(c);
          if (glyph.value < 128)
            this.ascii[glyph.value] = this.glyphCount; 
          glyph.index = this.glyphCount;
          this.glyphs[this.glyphCount++] = glyph;
        } 
      } 
      if (this.glyphCount != paramArrayOfchar.length)
        this.glyphs = (Glyph[])PApplet.subset(this.glyphs, 0, this.glyphCount); 
    } 
    if (this.ascent == 0)
      if (paramFont.canDisplay('d')) {
        new Glyph('d');
      } else {
        this.ascent = this.lazyMetrics.getAscent();
      }  
    if (this.descent == 0)
      if (paramFont.canDisplay('p')) {
        new Glyph('p');
      } else {
        this.descent = this.lazyMetrics.getDescent();
      }  
  }
  
  public PFont(Font paramFont, boolean paramBoolean1, char[] paramArrayOfchar, boolean paramBoolean2) {
    this(paramFont, paramBoolean1, paramArrayOfchar);
    this.stream = paramBoolean2;
  }
  
  public PFont(InputStream paramInputStream) throws IOException {
    DataInputStream dataInputStream = new DataInputStream(paramInputStream);
    this.glyphCount = dataInputStream.readInt();
    int i = dataInputStream.readInt();
    this.size = dataInputStream.readInt();
    dataInputStream.readInt();
    this.ascent = dataInputStream.readInt();
    this.descent = dataInputStream.readInt();
    this.glyphs = new Glyph[this.glyphCount];
    this.ascii = new int[128];
    Arrays.fill(this.ascii, -1);
    for (byte b = 0; b < this.glyphCount; b++) {
      Glyph glyph = new Glyph(dataInputStream);
      if (glyph.value < 128)
        this.ascii[glyph.value] = b; 
      glyph.index = b;
      this.glyphs[b] = glyph;
    } 
    if (this.ascent == 0 && this.descent == 0)
      throw new RuntimeException("Please use \"Create Font\" to re-create this font."); 
    for (Glyph glyph : this.glyphs)
      glyph.readBitmap(dataInputStream); 
    if (i >= 10) {
      this.name = dataInputStream.readUTF();
      this.psname = dataInputStream.readUTF();
    } 
    if (i == 11)
      this.smooth = dataInputStream.readBoolean(); 
    findFont();
  }
  
  void delete() {
    if (this.cacheMap != null) {
      Set<PGraphics> set = this.cacheMap.keySet();
      if (!set.isEmpty()) {
        Object[] arrayOfObject = set.toArray();
        for (byte b = 0; b < arrayOfObject.length; b++) {
          Object object = getCache((PGraphics)arrayOfObject[b]);
          Method method = null;
          try {
            Class<?> clazz = object.getClass();
            method = clazz.getMethod("delete", new Class[0]);
          } catch (Exception exception) {}
          if (method != null)
            try {
              method.invoke(object, new Object[0]);
            } catch (Exception exception) {} 
        } 
      } 
    } 
  }
  
  public void save(OutputStream paramOutputStream) throws IOException {
    DataOutputStream dataOutputStream = new DataOutputStream(paramOutputStream);
    dataOutputStream.writeInt(this.glyphCount);
    if (this.name == null || this.psname == null) {
      this.name = "";
      this.psname = "";
    } 
    dataOutputStream.writeInt(11);
    dataOutputStream.writeInt(this.size);
    dataOutputStream.writeInt(0);
    dataOutputStream.writeInt(this.ascent);
    dataOutputStream.writeInt(this.descent);
    byte b;
    for (b = 0; b < this.glyphCount; b++)
      this.glyphs[b].writeHeader(dataOutputStream); 
    for (b = 0; b < this.glyphCount; b++)
      this.glyphs[b].writeBitmap(dataOutputStream); 
    dataOutputStream.writeUTF(this.name);
    dataOutputStream.writeUTF(this.psname);
    dataOutputStream.writeBoolean(this.smooth);
    dataOutputStream.flush();
  }
  
  protected void addGlyph(char paramChar) {
    Glyph glyph = new Glyph(paramChar);
    if (this.glyphCount == this.glyphs.length)
      this.glyphs = (Glyph[])PApplet.expand(this.glyphs); 
    if (this.glyphCount == 0) {
      glyph.index = 0;
      this.glyphs[this.glyphCount] = glyph;
      if (glyph.value < 128)
        this.ascii[glyph.value] = 0; 
    } else if ((this.glyphs[this.glyphCount - 1]).value < glyph.value) {
      this.glyphs[this.glyphCount] = glyph;
      if (glyph.value < 128)
        this.ascii[glyph.value] = this.glyphCount; 
    } else {
      for (byte b = 0; b < this.glyphCount; b++) {
        if ((this.glyphs[b]).value > paramChar) {
          for (int i = this.glyphCount; i > b; i--) {
            this.glyphs[i] = this.glyphs[i - 1];
            if ((this.glyphs[i]).value < 128)
              this.ascii[(this.glyphs[i]).value] = i; 
          } 
          glyph.index = b;
          this.glyphs[b] = glyph;
          if (paramChar < '')
            this.ascii[paramChar] = b; 
          break;
        } 
      } 
    } 
    this.glyphCount++;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getPostScriptName() {
    return this.psname;
  }
  
  public void setFont(Font paramFont) {
    this.font = paramFont;
  }
  
  public Font getFont() {
    return this.subsetting ? null : this.font;
  }
  
  public int getSize() {
    return this.size;
  }
  
  public boolean isStream() {
    return this.stream;
  }
  
  public void setSubsetting() {
    this.subsetting = true;
  }
  
  public Font findFont() {
    if (this.font == null && !this.fontSearched) {
      this.font = new Font(this.name, 0, this.size);
      if (!this.font.getPSName().equals(this.psname))
        this.font = new Font(this.psname, 0, this.size); 
      if (!this.font.getPSName().equals(this.psname))
        this.font = null; 
      this.fontSearched = true;
    } 
    return this.font;
  }
  
  public Glyph getGlyph(char paramChar) {
    int i = index(paramChar);
    return (i == -1) ? null : this.glyphs[i];
  }
  
  protected int index(char paramChar) {
    if (this.lazy) {
      int i = indexActual(paramChar);
      if (i != -1)
        return i; 
      if (this.font != null && this.font.canDisplay(paramChar)) {
        addGlyph(paramChar);
        return indexActual(paramChar);
      } 
      return -1;
    } 
    return indexActual(paramChar);
  }
  
  protected int indexActual(char paramChar) {
    return (this.glyphCount == 0) ? -1 : ((paramChar < '') ? this.ascii[paramChar] : indexHunt(paramChar, 0, this.glyphCount - 1));
  }
  
  protected int indexHunt(int paramInt1, int paramInt2, int paramInt3) {
    int i = (paramInt2 + paramInt3) / 2;
    return (paramInt1 == (this.glyphs[i]).value) ? i : ((paramInt2 >= paramInt3) ? -1 : ((paramInt1 < (this.glyphs[i]).value) ? indexHunt(paramInt1, paramInt2, i - 1) : indexHunt(paramInt1, i + 1, paramInt3)));
  }
  
  public float kern(char paramChar1, char paramChar2) {
    return 0.0F;
  }
  
  public float ascent() {
    return this.ascent / this.size;
  }
  
  public float descent() {
    return this.descent / this.size;
  }
  
  public float width(char paramChar) {
    if (paramChar == ' ')
      return width('i'); 
    int i = index(paramChar);
    return (i == -1) ? 0.0F : ((this.glyphs[i]).setWidth / this.size);
  }
  
  public void setCache(PGraphics paramPGraphics, Object paramObject) {
    if (this.cacheMap == null)
      this.cacheMap = new HashMap<PGraphics, Object>(); 
    this.cacheMap.put(paramPGraphics, paramObject);
  }
  
  public Object getCache(PGraphics paramPGraphics) {
    return (this.cacheMap == null) ? null : this.cacheMap.get(paramPGraphics);
  }
  
  public void removeCache(PGraphics paramPGraphics) {
    if (this.cacheMap != null)
      this.cacheMap.remove(paramPGraphics); 
  }
  
  public int getGlyphCount() {
    return this.glyphCount;
  }
  
  public Glyph getGlyph(int paramInt) {
    return this.glyphs[paramInt];
  }
  
  public static String[] list() {
    loadFonts();
    String[] arrayOfString = new String[fonts.length];
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = fonts[b].getName(); 
    return arrayOfString;
  }
  
  public static void loadFonts() {
    if (fonts == null) {
      GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
      fonts = graphicsEnvironment.getAllFonts();
      if (PApplet.platform == 2) {
        fontDifferent = new HashMap<String, Font>();
        for (Font font : fonts)
          fontDifferent.put(font.getName(), font); 
      } 
    } 
  }
  
  public static Font findFont(String paramString) {
    loadFonts();
    if (PApplet.platform == 2) {
      Font font = fontDifferent.get(paramString);
      if (font != null)
        return font; 
    } 
    return new Font(paramString, 0, 1);
  }
  
  static {
    byte b1 = 0;
    byte b2;
    for (b2 = 33; b2 <= 126; b2++)
      CHARSET[b1++] = (char)b2; 
    for (b2 = 0; b2 < EXTRA_CHARS.length; b2++)
      CHARSET[b1++] = EXTRA_CHARS[b2]; 
  }
  
  public class Glyph {
    public PImage image;
    
    public int value;
    
    public int height;
    
    public int width;
    
    public int index;
    
    public int setWidth;
    
    public int topExtent;
    
    public int leftExtent;
    
    public Glyph() {
      this.index = -1;
    }
    
    public Glyph(DataInputStream param1DataInputStream) throws IOException {
      this.index = -1;
      readHeader(param1DataInputStream);
    }
    
    protected void readHeader(DataInputStream param1DataInputStream) throws IOException {
      this.value = param1DataInputStream.readInt();
      this.height = param1DataInputStream.readInt();
      this.width = param1DataInputStream.readInt();
      this.setWidth = param1DataInputStream.readInt();
      this.topExtent = param1DataInputStream.readInt();
      this.leftExtent = param1DataInputStream.readInt();
      param1DataInputStream.readInt();
      if (this.value == 100 && PFont.this.ascent == 0)
        PFont.this.ascent = this.topExtent; 
      if (this.value == 112 && PFont.this.descent == 0)
        PFont.this.descent = -this.topExtent + this.height; 
    }
    
    protected void writeHeader(DataOutputStream param1DataOutputStream) throws IOException {
      param1DataOutputStream.writeInt(this.value);
      param1DataOutputStream.writeInt(this.height);
      param1DataOutputStream.writeInt(this.width);
      param1DataOutputStream.writeInt(this.setWidth);
      param1DataOutputStream.writeInt(this.topExtent);
      param1DataOutputStream.writeInt(this.leftExtent);
      param1DataOutputStream.writeInt(0);
    }
    
    protected void readBitmap(DataInputStream param1DataInputStream) throws IOException {
      this.image = new PImage(this.width, this.height, 4);
      int i = this.width * this.height;
      byte[] arrayOfByte = new byte[i];
      param1DataInputStream.readFully(arrayOfByte);
      int j = this.width;
      int k = this.height;
      int[] arrayOfInt = this.image.pixels;
      for (byte b = 0; b < k; b++) {
        for (byte b1 = 0; b1 < j; b1++)
          arrayOfInt[b * this.width + b1] = arrayOfByte[b * j + b1] & 0xFF; 
      } 
    }
    
    protected void writeBitmap(DataOutputStream param1DataOutputStream) throws IOException {
      int[] arrayOfInt = this.image.pixels;
      for (byte b = 0; b < this.height; b++) {
        for (byte b1 = 0; b1 < this.width; b1++)
          param1DataOutputStream.write(arrayOfInt[b * this.width + b1] & 0xFF); 
      } 
    }
    
    protected Glyph(char param1Char) {
      int i = PFont.this.size * 3;
      PFont.this.lazyGraphics.setColor(Color.white);
      PFont.this.lazyGraphics.fillRect(0, 0, i, i);
      PFont.this.lazyGraphics.setColor(Color.black);
      PFont.this.lazyGraphics.drawString(String.valueOf(param1Char), PFont.this.size, PFont.this.size * 2);
      WritableRaster writableRaster = PFont.this.lazyImage.getRaster();
      writableRaster.getDataElements(0, 0, i, i, PFont.this.lazySamples);
      char c1 = 'Ϩ';
      byte b1 = 0;
      char c2 = 'Ϩ';
      byte b2 = 0;
      boolean bool = false;
      for (byte b3 = 0; b3 < i; b3++) {
        for (byte b = 0; b < i; b++) {
          int j = PFont.this.lazySamples[b3 * i + b] & 0xFF;
          if (j != 255) {
            if (b < c1)
              c1 = b; 
            if (b3 < c2)
              c2 = b3; 
            if (b > b1)
              b1 = b; 
            if (b3 > b2)
              b2 = b3; 
            bool = true;
          } 
        } 
      } 
      if (!bool) {
        c1 = c2 = Character.MIN_VALUE;
        b1 = b2 = 0;
      } 
      this.value = param1Char;
      this.height = b2 - c2 + 1;
      this.width = b1 - c1 + 1;
      this.setWidth = PFont.this.lazyMetrics.charWidth(param1Char);
      this.topExtent = PFont.this.size * 2 - c2;
      this.leftExtent = c1 - PFont.this.size;
      this.image = new PImage(this.width, this.height, 4);
      int[] arrayOfInt = this.image.pixels;
      for (char c3 = c2; c3 <= b2; c3++) {
        for (char c = c1; c <= b1; c++) {
          int j = 255 - (PFont.this.lazySamples[c3 * i + c] & 0xFF);
          int k = (c3 - c2) * this.width + c - c1;
          arrayOfInt[k] = j;
        } 
      } 
      if (this.value == 100 && PFont.this.ascent == 0)
        PFont.this.ascent = this.topExtent; 
      if (this.value == 112 && PFont.this.descent == 0)
        PFont.this.descent = -this.topExtent + this.height; 
    }
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PFont.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */