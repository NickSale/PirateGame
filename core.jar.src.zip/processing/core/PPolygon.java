package processing.core;

public class PPolygon implements PConstants {
  static final int DEFAULT_SIZE = 64;
  
  float[][] vertices = new float[64][36];
  
  int vertexCount;
  
  float[] r = new float[64];
  
  float[] dr = new float[64];
  
  float[] l = new float[64];
  
  float[] dl = new float[64];
  
  float[] sp = new float[64];
  
  float[] sdp = new float[64];
  
  protected boolean interpX;
  
  protected boolean interpUV;
  
  protected boolean interpARGB;
  
  private int rgba;
  
  private int r2;
  
  private int g2;
  
  private int b2;
  
  private int a2;
  
  private int a2orig;
  
  PGraphics parent;
  
  int[] pixels;
  
  int width;
  
  int height;
  
  int width1;
  
  int height1;
  
  PImage timage;
  
  int[] tpixels;
  
  int theight;
  
  int twidth;
  
  int theight1;
  
  int twidth1;
  
  int tformat;
  
  static final int SUBXRES = 8;
  
  static final int SUBXRES1 = 7;
  
  static final int SUBYRES = 8;
  
  static final int SUBYRES1 = 7;
  
  static final int MAX_COVERAGE = 64;
  
  boolean smooth;
  
  int firstModY;
  
  int lastModY;
  
  int lastY;
  
  int[] aaleft = new int[8];
  
  int[] aaright = new int[8];
  
  int aaleftmin;
  
  int aarightmin;
  
  int aaleftmax;
  
  int aarightmax;
  
  int aaleftfull;
  
  int aarightfull;
  
  private final int MODYRES(int paramInt) {
    return paramInt & 0x7;
  }
  
  public PPolygon(PGraphics paramPGraphics) {
    this.parent = paramPGraphics;
    reset(0);
  }
  
  protected void reset(int paramInt) {
    this.vertexCount = paramInt;
    this.interpX = true;
    this.interpUV = false;
    this.interpARGB = true;
    this.timage = null;
  }
  
  protected float[] nextVertex() {
    if (this.vertexCount == this.vertices.length) {
      float[][] arrayOfFloat = new float[this.vertexCount << 1][36];
      System.arraycopy(this.vertices, 0, arrayOfFloat, 0, this.vertexCount);
      this.vertices = arrayOfFloat;
      this.r = new float[this.vertices.length];
      this.dr = new float[this.vertices.length];
      this.l = new float[this.vertices.length];
      this.dl = new float[this.vertices.length];
      this.sp = new float[this.vertices.length];
      this.sdp = new float[this.vertices.length];
    } 
    return this.vertices[this.vertexCount++];
  }
  
  protected void texture(PImage paramPImage) {
    this.timage = paramPImage;
    if (paramPImage != null) {
      this.tpixels = paramPImage.pixels;
      this.twidth = paramPImage.width;
      this.theight = paramPImage.height;
      this.tformat = paramPImage.format;
      this.twidth1 = this.twidth - 1;
      this.theight1 = this.theight - 1;
      this.interpUV = true;
    } else {
      this.interpUV = false;
    } 
  }
  
  protected void renderPolygon(float[][] paramArrayOffloat, int paramInt) {
    this.vertices = paramArrayOffloat;
    this.vertexCount = paramInt;
    if (this.r.length < this.vertexCount) {
      this.r = new float[this.vertexCount];
      this.dr = new float[this.vertexCount];
      this.l = new float[this.vertexCount];
      this.dl = new float[this.vertexCount];
      this.sp = new float[this.vertexCount];
      this.sdp = new float[this.vertexCount];
    } 
    render();
    checkExpand();
  }
  
  protected void renderTriangle(float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3) {
    this.vertices[0] = paramArrayOffloat1;
    this.vertices[1] = paramArrayOffloat2;
    this.vertices[2] = paramArrayOffloat3;
    render();
    checkExpand();
  }
  
  protected void checkExpand() {
    if (this.smooth)
      for (byte b = 0; b < this.vertexCount; b++) {
        this.vertices[b][18] = this.vertices[b][18] / 8.0F;
        this.vertices[b][19] = this.vertices[b][19] / 8.0F;
      }  
  }
  
  protected void render() {
    if (this.vertexCount < 3)
      return; 
    this.pixels = this.parent.pixels;
    this.smooth = this.parent.smooth;
    this.width = this.smooth ? (this.parent.width * 8) : this.parent.width;
    this.height = this.smooth ? (this.parent.height * 8) : this.parent.height;
    this.width1 = this.width - 1;
    this.height1 = this.height - 1;
    if (!this.interpARGB) {
      this.r2 = (int)(this.vertices[0][3] * 255.0F);
      this.g2 = (int)(this.vertices[0][4] * 255.0F);
      this.b2 = (int)(this.vertices[0][5] * 255.0F);
      this.a2 = (int)(this.vertices[0][6] * 255.0F);
      this.a2orig = this.a2;
      this.rgba = 0xFF000000 | this.r2 << 16 | this.g2 << 8 | this.b2;
    } 
    int i;
    for (i = 0; i < this.vertexCount; i++) {
      this.r[i] = 0.0F;
      this.dr[i] = 0.0F;
      this.l[i] = 0.0F;
      this.dl[i] = 0.0F;
    } 
    if (this.smooth) {
      for (i = 0; i < this.vertexCount; i++) {
        this.vertices[i][18] = this.vertices[i][18] * 8.0F;
        this.vertices[i][19] = this.vertices[i][19] * 8.0F;
      } 
      this.firstModY = -1;
    } 
    i = 0;
    float f1 = this.vertices[0][19];
    float f2 = this.vertices[0][19];
    int j;
    for (j = 1; j < this.vertexCount; j++) {
      if (this.vertices[j][19] < f1) {
        f1 = this.vertices[j][19];
        i = j;
      } 
      if (this.vertices[j][19] > f2)
        f2 = this.vertices[j][19]; 
    } 
    this.lastY = (int)(f2 - 0.5F);
    j = i;
    int k = i;
    int m = (int)(f1 + 0.5F);
    int n = m - 1;
    int i1 = m - 1;
    this.interpX = true;
    int i2 = this.vertexCount;
    while (i2 > 0) {
      while (n <= m && i2 > 0) {
        i2--;
        int i3 = (j != 0) ? (j - 1) : (this.vertexCount - 1);
        incrementalizeY(this.vertices[j], this.vertices[i3], this.l, this.dl, m);
        n = (int)(this.vertices[i3][19] + 0.5F);
        j = i3;
      } 
      while (i1 <= m && i2 > 0) {
        i2--;
        boolean bool = (k != this.vertexCount - 1) ? (k + 1) : false;
        incrementalizeY(this.vertices[k], this.vertices[bool], this.r, this.dr, m);
        i1 = (int)(this.vertices[bool][19] + 0.5F);
        k = bool;
      } 
      while (m < n && m < i1) {
        if (m >= 0 && m < this.height)
          if (this.l[18] <= this.r[18]) {
            scanline(m, this.l, this.r);
          } else {
            scanline(m, this.r, this.l);
          }  
        m++;
        increment(this.l, this.dl);
        increment(this.r, this.dr);
      } 
    } 
  }
  
  private void scanline(int paramInt, float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
    int i;
    for (i = 0; i < this.vertexCount; i++) {
      this.sp[i] = 0.0F;
      this.sdp[i] = 0.0F;
    } 
    i = (int)(paramArrayOffloat1[18] + 0.49999F);
    if (i < 0)
      i = 0; 
    int j = (int)(paramArrayOffloat2[18] - 0.5F);
    if (j > this.width1)
      j = this.width1; 
    if (i > j)
      return; 
    if (this.smooth) {
      int i2 = MODYRES(paramInt);
      this.aaleft[i2] = i;
      this.aaright[i2] = j;
      if (this.firstModY == -1) {
        this.firstModY = i2;
        this.aaleftmin = i;
        this.aaleftmax = i;
        this.aarightmin = j;
        this.aarightmax = j;
      } else {
        if (this.aaleftmin > this.aaleft[i2])
          this.aaleftmin = this.aaleft[i2]; 
        if (this.aaleftmax < this.aaleft[i2])
          this.aaleftmax = this.aaleft[i2]; 
        if (this.aarightmin > this.aaright[i2])
          this.aarightmin = this.aaright[i2]; 
        if (this.aarightmax < this.aaright[i2])
          this.aarightmax = this.aaright[i2]; 
      } 
      this.lastModY = i2;
      if (i2 != 7 && paramInt != this.lastY)
        return; 
      this.aaleftfull = this.aaleftmax / 8 + 1;
      this.aarightfull = this.aarightmin / 8 - 1;
    } 
    incrementalizeX(paramArrayOffloat1, paramArrayOffloat2, this.sp, this.sdp, i);
    int k = this.smooth ? (this.parent.width * paramInt / 8) : (this.parent.width * paramInt);
    int m = 0;
    int n = 0;
    if (this.smooth) {
      m = i / 8;
      n = (j + 7) / 8;
      i = this.aaleftmin / 8;
      j = (this.aarightmax + 7) / 8;
      if (i < 0)
        i = 0; 
      if (j > this.parent.width1)
        j = this.parent.width1; 
    } 
    this.interpX = false;
    for (int i1 = i; i1 <= j; i1++) {
      if (this.interpUV) {
        int i2;
        int i3;
        int i4;
        int i5;
        int i6 = (int)(this.sp[7] * this.twidth);
        int i7 = (int)(this.sp[8] * this.theight);
        if (i6 > this.twidth1)
          i6 = this.twidth1; 
        if (i7 > this.theight1)
          i7 = this.theight1; 
        if (i6 < 0)
          i6 = 0; 
        if (i7 < 0)
          i7 = 0; 
        int i8 = i7 * this.twidth + i6;
        int i9 = (int)(255.0F * (this.sp[7] * this.twidth - i6));
        int i10 = (int)(255.0F * (this.sp[8] * this.theight - i7));
        int i11 = 255 - i9;
        int i12 = 255 - i10;
        int i13 = this.tpixels[i8];
        int i14 = (i7 < this.theight1) ? this.tpixels[i8 + this.twidth] : this.tpixels[i8];
        int i15 = (i6 < this.twidth1) ? this.tpixels[i8 + 1] : this.tpixels[i8];
        int i16 = (i7 < this.theight1 && i6 < this.twidth1) ? this.tpixels[i8 + this.twidth + 1] : this.tpixels[i8];
        if (this.tformat == 4) {
          int i17 = i13 * i11 + i15 * i9 >> 8;
          int i18 = i14 * i11 + i16 * i9 >> 8;
          i5 = (i17 * i12 + i18 * i10 >> 8) * (this.interpARGB ? (int)(this.sp[6] * 255.0F) : this.a2orig) >> 8;
        } else if (this.tformat == 2) {
          int i17 = i13 >> 24 & 0xFF;
          int i18 = i14 >> 24 & 0xFF;
          int i19 = i15 >> 24 & 0xFF;
          int i20 = i16 >> 24 & 0xFF;
          int i21 = i17 * i11 + i19 * i9 >> 8;
          int i22 = i18 * i11 + i20 * i9 >> 8;
          i5 = (i21 * i12 + i22 * i10 >> 8) * (this.interpARGB ? (int)(this.sp[6] * 255.0F) : this.a2orig) >> 8;
        } else {
          i5 = this.interpARGB ? (int)(this.sp[6] * 255.0F) : this.a2orig;
        } 
        if (this.tformat == 1 || this.tformat == 2) {
          int i17 = i13 >> 16 & 0xFF;
          int i18 = i14 >> 16 & 0xFF;
          int i19 = i15 >> 16 & 0xFF;
          int i20 = i16 >> 16 & 0xFF;
          int i21 = i17 * i11 + i19 * i9 >> 8;
          int i22 = i18 * i11 + i20 * i9 >> 8;
          i2 = (i21 * i12 + i22 * i10 >> 8) * (this.interpARGB ? (int)(this.sp[3] * 255.0F) : this.r2) >> 8;
          i17 = i13 >> 8 & 0xFF;
          i18 = i14 >> 8 & 0xFF;
          i19 = i15 >> 8 & 0xFF;
          i20 = i16 >> 8 & 0xFF;
          i21 = i17 * i11 + i19 * i9 >> 8;
          i22 = i18 * i11 + i20 * i9 >> 8;
          i3 = (i21 * i12 + i22 * i10 >> 8) * (this.interpARGB ? (int)(this.sp[4] * 255.0F) : this.g2) >> 8;
          i17 = i13 & 0xFF;
          i18 = i14 & 0xFF;
          i19 = i15 & 0xFF;
          i20 = i16 & 0xFF;
          i21 = i17 * i11 + i19 * i9 >> 8;
          i22 = i18 * i11 + i20 * i9 >> 8;
          i4 = (i21 * i12 + i22 * i10 >> 8) * (this.interpARGB ? (int)(this.sp[5] * 255.0F) : this.b2) >> 8;
        } else if (this.interpARGB) {
          i2 = (int)(this.sp[3] * 255.0F);
          i3 = (int)(this.sp[4] * 255.0F);
          i4 = (int)(this.sp[5] * 255.0F);
        } else {
          i2 = this.r2;
          i3 = this.g2;
          i4 = this.b2;
        } 
        byte b = this.smooth ? coverage(i1) : 255;
        if (b != 'ÿ')
          i5 = i5 * b >> 8; 
        if (i5 == 254 || i5 == 255) {
          this.pixels[k + i1] = 0xFF000000 | i2 << 16 | i3 << 8 | i4;
        } else {
          int i17 = 255 - i5;
          int i18 = this.pixels[k + i1] >> 16 & 0xFF;
          int i19 = this.pixels[k + i1] >> 8 & 0xFF;
          int i20 = this.pixels[k + i1] & 0xFF;
          this.pixels[k + i1] = 0xFF000000 | i2 * i5 + i18 * i17 >> 8 << 16 | i3 * i5 + i19 * i17 & 0xFF00 | i4 * i5 + i20 * i17 >> 8;
        } 
      } else {
        int i2 = this.smooth ? coverage(i1) : 255;
        if (this.interpARGB) {
          this.r2 = (int)(this.sp[3] * 255.0F);
          this.g2 = (int)(this.sp[4] * 255.0F);
          this.b2 = (int)(this.sp[5] * 255.0F);
          if (this.sp[6] != 1.0F)
            i2 = i2 * (int)(this.sp[6] * 255.0F) >> 8; 
          if (i2 == 255)
            this.rgba = 0xFF000000 | this.r2 << 16 | this.g2 << 8 | this.b2; 
        } else if (this.a2orig != 255) {
          i2 = i2 * this.a2orig >> 8;
        } 
        if (i2 == 255) {
          this.pixels[k + i1] = this.rgba;
        } else {
          int i3 = this.pixels[k + i1] >> 16 & 0xFF;
          int i4 = this.pixels[k + i1] >> 8 & 0xFF;
          int i5 = this.pixels[k + i1] & 0xFF;
          this.a2 = i2;
          int i6 = 255 - this.a2;
          this.pixels[k + i1] = 0xFF000000 | i3 * i6 + this.r2 * this.a2 >> 8 << 16 | i4 * i6 + this.g2 * this.a2 >> 8 << 8 | i5 * i6 + this.b2 * this.a2 >> 8;
        } 
      } 
      if (!this.smooth || (i1 >= m && i1 <= n))
        increment(this.sp, this.sdp); 
    } 
    this.firstModY = -1;
    this.interpX = true;
  }
  
  private int coverage(int paramInt) {
    if (paramInt >= this.aaleftfull && paramInt <= this.aarightfull && this.firstModY == 0 && this.lastModY == 7)
      return 255; 
    int i = paramInt * 8;
    int j = i + 8;
    int k = 0;
    for (int m = this.firstModY; m <= this.lastModY; m++) {
      if (this.aaleft[m] <= j && this.aaright[m] >= i)
        k += ((this.aaright[m] < j) ? this.aaright[m] : j) - ((this.aaleft[m] > i) ? this.aaleft[m] : i); 
    } 
    k <<= 2;
    return (k == 256) ? 255 : k;
  }
  
  private void incrementalizeY(float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, float[] paramArrayOffloat4, int paramInt) {
    float f1 = paramArrayOffloat2[19] - paramArrayOffloat1[19];
    if (f1 == 0.0F)
      f1 = 1.0F; 
    float f2 = paramInt + 0.5F - paramArrayOffloat1[19];
    if (this.interpX) {
      paramArrayOffloat4[18] = (paramArrayOffloat2[18] - paramArrayOffloat1[18]) / f1;
      paramArrayOffloat3[18] = paramArrayOffloat1[18] + paramArrayOffloat4[18] * f2;
    } 
    if (this.interpARGB) {
      paramArrayOffloat4[3] = (paramArrayOffloat2[3] - paramArrayOffloat1[3]) / f1;
      paramArrayOffloat4[4] = (paramArrayOffloat2[4] - paramArrayOffloat1[4]) / f1;
      paramArrayOffloat4[5] = (paramArrayOffloat2[5] - paramArrayOffloat1[5]) / f1;
      paramArrayOffloat4[6] = (paramArrayOffloat2[6] - paramArrayOffloat1[6]) / f1;
      paramArrayOffloat3[3] = paramArrayOffloat1[3] + paramArrayOffloat4[3] * f2;
      paramArrayOffloat3[4] = paramArrayOffloat1[4] + paramArrayOffloat4[4] * f2;
      paramArrayOffloat3[5] = paramArrayOffloat1[5] + paramArrayOffloat4[5] * f2;
      paramArrayOffloat3[6] = paramArrayOffloat1[6] + paramArrayOffloat4[6] * f2;
    } 
    if (this.interpUV) {
      paramArrayOffloat4[7] = (paramArrayOffloat2[7] - paramArrayOffloat1[7]) / f1;
      paramArrayOffloat4[8] = (paramArrayOffloat2[8] - paramArrayOffloat1[8]) / f1;
      paramArrayOffloat3[7] = paramArrayOffloat1[7] + paramArrayOffloat4[7] * f2;
      paramArrayOffloat3[8] = paramArrayOffloat1[8] + paramArrayOffloat4[8] * f2;
    } 
  }
  
  private void incrementalizeX(float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, float[] paramArrayOffloat4, int paramInt) {
    float f1 = paramArrayOffloat2[18] - paramArrayOffloat1[18];
    if (f1 == 0.0F)
      f1 = 1.0F; 
    float f2 = paramInt + 0.5F - paramArrayOffloat1[18];
    if (this.smooth) {
      f1 /= 8.0F;
      f2 /= 8.0F;
    } 
    if (this.interpX) {
      paramArrayOffloat4[18] = (paramArrayOffloat2[18] - paramArrayOffloat1[18]) / f1;
      paramArrayOffloat3[18] = paramArrayOffloat1[18] + paramArrayOffloat4[18] * f2;
    } 
    if (this.interpARGB) {
      paramArrayOffloat4[3] = (paramArrayOffloat2[3] - paramArrayOffloat1[3]) / f1;
      paramArrayOffloat4[4] = (paramArrayOffloat2[4] - paramArrayOffloat1[4]) / f1;
      paramArrayOffloat4[5] = (paramArrayOffloat2[5] - paramArrayOffloat1[5]) / f1;
      paramArrayOffloat4[6] = (paramArrayOffloat2[6] - paramArrayOffloat1[6]) / f1;
      paramArrayOffloat3[3] = paramArrayOffloat1[3] + paramArrayOffloat4[3] * f2;
      paramArrayOffloat3[4] = paramArrayOffloat1[4] + paramArrayOffloat4[4] * f2;
      paramArrayOffloat3[5] = paramArrayOffloat1[5] + paramArrayOffloat4[5] * f2;
      paramArrayOffloat3[6] = paramArrayOffloat1[6] + paramArrayOffloat4[6] * f2;
    } 
    if (this.interpUV) {
      paramArrayOffloat4[7] = (paramArrayOffloat2[7] - paramArrayOffloat1[7]) / f1;
      paramArrayOffloat4[8] = (paramArrayOffloat2[8] - paramArrayOffloat1[8]) / f1;
      paramArrayOffloat3[7] = paramArrayOffloat1[7] + paramArrayOffloat4[7] * f2;
      paramArrayOffloat3[8] = paramArrayOffloat1[8] + paramArrayOffloat4[8] * f2;
    } 
  }
  
  private void increment(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
    if (this.interpX)
      paramArrayOffloat1[18] = paramArrayOffloat1[18] + paramArrayOffloat2[18]; 
    if (this.interpARGB) {
      paramArrayOffloat1[3] = paramArrayOffloat1[3] + paramArrayOffloat2[3];
      paramArrayOffloat1[4] = paramArrayOffloat1[4] + paramArrayOffloat2[4];
      paramArrayOffloat1[5] = paramArrayOffloat1[5] + paramArrayOffloat2[5];
      paramArrayOffloat1[6] = paramArrayOffloat1[6] + paramArrayOffloat2[6];
    } 
    if (this.interpUV) {
      paramArrayOffloat1[7] = paramArrayOffloat1[7] + paramArrayOffloat2[7];
      paramArrayOffloat1[8] = paramArrayOffloat1[8] + paramArrayOffloat2[8];
    } 
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PPolygon.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */