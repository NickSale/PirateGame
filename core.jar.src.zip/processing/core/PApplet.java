package processing.core;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.MediaTracker;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.awt.image.MemoryImageSource;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import processing.xml.XMLElement;

public class PApplet extends Applet implements PConstants, Runnable, MouseListener, MouseMotionListener, KeyListener, FocusListener {
  public static final String javaVersionName = System.getProperty("java.version");
  
  public static final float javaVersion = (new Float(javaVersionName.substring(0, 3))).floatValue();
  
  public static int platform;
  
  public static boolean useQuartz = true;
  
  public static final int MENU_SHORTCUT = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
  
  public PGraphics g;
  
  public Frame frame;
  
  public int screenWidth;
  
  public int screenHeight;
  
  public Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
  
  public PGraphics recorder;
  
  public String[] args;
  
  public String sketchPath;
  
  static final boolean THREAD_DEBUG = false;
  
  public static final int DEFAULT_WIDTH = 100;
  
  public static final int DEFAULT_HEIGHT = 100;
  
  public static final int MIN_WINDOW_WIDTH = 128;
  
  public static final int MIN_WINDOW_HEIGHT = 128;
  
  public boolean defaultSize;
  
  volatile boolean resizeRequest;
  
  volatile int resizeWidth;
  
  volatile int resizeHeight;
  
  public int[] pixels;
  
  public int width;
  
  public int height;
  
  public int mouseX;
  
  public int mouseY;
  
  public int pmouseX;
  
  public int pmouseY;
  
  protected int dmouseX;
  
  protected int dmouseY;
  
  protected int emouseX;
  
  protected int emouseY;
  
  public boolean firstMouse;
  
  public int mouseButton;
  
  public boolean mousePressed;
  
  public MouseEvent mouseEvent;
  
  public char key;
  
  public int keyCode;
  
  public boolean keyPressed;
  
  public KeyEvent keyEvent;
  
  public boolean focused = false;
  
  public boolean online = false;
  
  long millisOffset = System.currentTimeMillis();
  
  public float frameRate = 10.0F;
  
  protected long frameRateLastNanos = 0L;
  
  protected float frameRateTarget = 60.0F;
  
  protected long frameRatePeriod = 16666666L;
  
  protected boolean looping;
  
  protected boolean redraw;
  
  public int frameCount;
  
  public volatile boolean finished;
  
  public volatile boolean paused;
  
  protected boolean exitCalled;
  
  Thread thread;
  
  protected RegisteredMethods sizeMethods;
  
  protected RegisteredMethods preMethods;
  
  protected RegisteredMethods drawMethods;
  
  protected RegisteredMethods postMethods;
  
  protected RegisteredMethods mouseEventMethods;
  
  protected RegisteredMethods keyEventMethods;
  
  protected RegisteredMethods disposeMethods;
  
  public static final String ARGS_EDITOR_LOCATION = "--editor-location";
  
  public static final String ARGS_EXTERNAL = "--external";
  
  public static final String ARGS_LOCATION = "--location";
  
  public static final String ARGS_DISPLAY = "--display";
  
  public static final String ARGS_BGCOLOR = "--bgcolor";
  
  public static final String ARGS_PRESENT = "--present";
  
  public static final String ARGS_EXCLUSIVE = "--exclusive";
  
  public static final String ARGS_STOP_COLOR = "--stop-color";
  
  public static final String ARGS_HIDE_STOP = "--hide-stop";
  
  public static final String ARGS_SKETCH_FOLDER = "--sketch-path";
  
  public static final String EXTERNAL_STOP = "__STOP__";
  
  public static final String EXTERNAL_MOVE = "__MOVE__";
  
  boolean external = false;
  
  static final String ERROR_MIN_MAX = "Cannot use min() or max() on an empty array.";
  
  MouseEvent[] mouseEventQueue = new MouseEvent[10];
  
  int mouseEventCount;
  
  KeyEvent[] keyEventQueue = new KeyEvent[10];
  
  int keyEventCount;
  
  static String openLauncher;
  
  int cursorType = 0;
  
  boolean cursorVisible = true;
  
  PImage invisibleCursor;
  
  Random internalRandom;
  
  static final int PERLIN_YWRAPB = 4;
  
  static final int PERLIN_YWRAP = 16;
  
  static final int PERLIN_ZWRAPB = 8;
  
  static final int PERLIN_ZWRAP = 256;
  
  static final int PERLIN_SIZE = 4095;
  
  int perlin_octaves = 4;
  
  float perlin_amp_falloff = 0.5F;
  
  int perlin_TWOPI;
  
  int perlin_PI;
  
  float[] perlin_cosTable;
  
  float[] perlin;
  
  Random perlinRandom;
  
  protected String[] loadImageFormats;
  
  public int requestImageMax = 4;
  
  volatile int requestImageCount;
  
  protected String[] loadShapeFormats;
  
  public File selectedFile;
  
  protected Frame parentFrame;
  
  protected static HashMap<String, Pattern> matchPatterns;
  
  private static NumberFormat int_nf;
  
  private static int int_nf_digits;
  
  private static boolean int_nf_commas;
  
  private static NumberFormat float_nf;
  
  private static int float_nf_left;
  
  private static int float_nf_right;
  
  private static boolean float_nf_commas;
  
  public static final byte[] ICON_IMAGE = new byte[] { 
      71, 73, 70, 56, 57, 97, 16, 0, 16, 0, 
      -77, 0, 0, 0, 0, 0, -1, -1, -1, 12, 
      12, 13, -15, -15, -14, 45, 57, 74, 54, 80, 
      111, 47, 71, 97, 62, 88, 117, 1, 14, 27, 
      7, 41, 73, 15, 52, 85, 2, 31, 55, 4, 
      54, 94, 18, 69, 109, 37, 87, 126, -1, -1, 
      -1, 33, -7, 4, 1, 0, 0, 15, 0, 44, 
      0, 0, 0, 0, 16, 0, 16, 0, 0, 4, 
      122, -16, -107, 114, -86, -67, 83, 30, -42, 26, 
      -17, -100, -45, 56, -57, -108, 48, 40, 122, -90, 
      104, 67, -91, -51, 32, -53, 77, -78, -100, 47, 
      -86, 12, 76, -110, -20, -74, -101, 97, -93, 27, 
      40, 20, -65, 65, 48, -111, 99, -20, -112, -117, 
      -123, -47, -105, 24, 114, -112, 74, 69, 84, 25, 
      93, 88, -75, 9, 46, 2, 49, 88, -116, -67, 
      7, -19, -83, 60, 38, 3, -34, 2, 66, -95, 
      27, -98, 13, 4, -17, 55, 33, 109, 11, 11, 
      -2, Byte.MIN_VALUE, 121, 123, 62, 91, 120, Byte.MIN_VALUE, Byte.MAX_VALUE, 122, 
      115, 102, 2, 119, 0, -116, -113, -119, 6, 102, 
      121, -108, -126, 5, 18, 6, 4, -102, -101, -100, 
      114, 15, 17, 0, 59 };
  
  public void init() {
    Dimension dimension1 = Toolkit.getDefaultToolkit().getScreenSize();
    this.screenWidth = dimension1.width;
    this.screenHeight = dimension1.height;
    setFocusTraversalKeysEnabled(false);
    this.finished = false;
    this.looping = true;
    this.redraw = true;
    this.firstMouse = true;
    this.sizeMethods = new RegisteredMethods();
    this.preMethods = new RegisteredMethods();
    this.drawMethods = new RegisteredMethods();
    this.postMethods = new RegisteredMethods();
    this.mouseEventMethods = new RegisteredMethods();
    this.keyEventMethods = new RegisteredMethods();
    this.disposeMethods = new RegisteredMethods();
    try {
      getAppletContext();
      this.online = true;
    } catch (NullPointerException nullPointerException) {
      this.online = false;
    } 
    try {
      if (this.sketchPath == null)
        this.sketchPath = System.getProperty("user.dir"); 
    } catch (Exception exception) {}
    Dimension dimension2 = getSize();
    if (dimension2.width != 0 && dimension2.height != 0) {
      this.g = makeGraphics(dimension2.width, dimension2.height, sketchRenderer(), (String)null, true);
    } else {
      this.defaultSize = true;
      int i = sketchWidth();
      int j = sketchHeight();
      this.g = makeGraphics(i, j, sketchRenderer(), (String)null, true);
      setSize(i, j);
      setPreferredSize(new Dimension(i, j));
    } 
    this.width = this.g.width;
    this.height = this.g.height;
    addListeners();
    start();
  }
  
  public int sketchWidth() {
    return 100;
  }
  
  public int sketchHeight() {
    return 100;
  }
  
  public String sketchRenderer() {
    return "processing.core.PGraphicsJava2D";
  }
  
  public void start() {
    this.finished = false;
    this.paused = false;
    if (this.thread == null) {
      this.thread = new Thread(this, "Animation Thread");
      this.thread.start();
    } 
  }
  
  public void stop() {
    this.paused = true;
  }
  
  public void destroy() {
    exit();
  }
  
  public void registerSize(Object paramObject) {
    Class[] arrayOfClass = { int.class, int.class };
    registerWithArgs(this.sizeMethods, "size", paramObject, arrayOfClass);
  }
  
  public void registerPre(Object paramObject) {
    registerNoArgs(this.preMethods, "pre", paramObject);
  }
  
  public void registerDraw(Object paramObject) {
    registerNoArgs(this.drawMethods, "draw", paramObject);
  }
  
  public void registerPost(Object paramObject) {
    registerNoArgs(this.postMethods, "post", paramObject);
  }
  
  public void registerMouseEvent(Object paramObject) {
    Class[] arrayOfClass = { MouseEvent.class };
    registerWithArgs(this.mouseEventMethods, "mouseEvent", paramObject, arrayOfClass);
  }
  
  public void registerKeyEvent(Object paramObject) {
    Class[] arrayOfClass = { KeyEvent.class };
    registerWithArgs(this.keyEventMethods, "keyEvent", paramObject, arrayOfClass);
  }
  
  public void registerDispose(Object paramObject) {
    registerNoArgs(this.disposeMethods, "dispose", paramObject);
  }
  
  protected void registerNoArgs(RegisteredMethods paramRegisteredMethods, String paramString, Object paramObject) {
    Class<?> clazz = paramObject.getClass();
    try {
      Method method = clazz.getMethod(paramString, new Class[0]);
      paramRegisteredMethods.add(paramObject, method);
    } catch (NoSuchMethodException noSuchMethodException) {
      die("There is no public " + paramString + "() method in the class " + paramObject.getClass().getName());
    } catch (Exception exception) {
      die("Could not register " + paramString + " + () for " + paramObject, exception);
    } 
  }
  
  protected void registerWithArgs(RegisteredMethods paramRegisteredMethods, String paramString, Object paramObject, Class<?>[] paramArrayOfClass) {
    Class<?> clazz = paramObject.getClass();
    try {
      Method method = clazz.getMethod(paramString, paramArrayOfClass);
      paramRegisteredMethods.add(paramObject, method);
    } catch (NoSuchMethodException noSuchMethodException) {
      die("There is no public " + paramString + "() method in the class " + paramObject.getClass().getName());
    } catch (Exception exception) {
      die("Could not register " + paramString + " + () for " + paramObject, exception);
    } 
  }
  
  public void unregisterSize(Object paramObject) {
    Class[] arrayOfClass = { int.class, int.class };
    unregisterWithArgs(this.sizeMethods, "size", paramObject, arrayOfClass);
  }
  
  public void unregisterPre(Object paramObject) {
    unregisterNoArgs(this.preMethods, "pre", paramObject);
  }
  
  public void unregisterDraw(Object paramObject) {
    unregisterNoArgs(this.drawMethods, "draw", paramObject);
  }
  
  public void unregisterPost(Object paramObject) {
    unregisterNoArgs(this.postMethods, "post", paramObject);
  }
  
  public void unregisterMouseEvent(Object paramObject) {
    Class[] arrayOfClass = { MouseEvent.class };
    unregisterWithArgs(this.mouseEventMethods, "mouseEvent", paramObject, arrayOfClass);
  }
  
  public void unregisterKeyEvent(Object paramObject) {
    Class[] arrayOfClass = { KeyEvent.class };
    unregisterWithArgs(this.keyEventMethods, "keyEvent", paramObject, arrayOfClass);
  }
  
  public void unregisterDispose(Object paramObject) {
    unregisterNoArgs(this.disposeMethods, "dispose", paramObject);
  }
  
  protected void unregisterNoArgs(RegisteredMethods paramRegisteredMethods, String paramString, Object paramObject) {
    Class<?> clazz = paramObject.getClass();
    try {
      Method method = clazz.getMethod(paramString, new Class[0]);
      paramRegisteredMethods.remove(paramObject, method);
    } catch (Exception exception) {
      die("Could not unregister " + paramString + "() for " + paramObject, exception);
    } 
  }
  
  protected void unregisterWithArgs(RegisteredMethods paramRegisteredMethods, String paramString, Object paramObject, Class<?>[] paramArrayOfClass) {
    Class<?> clazz = paramObject.getClass();
    try {
      Method method = clazz.getMethod(paramString, paramArrayOfClass);
      paramRegisteredMethods.remove(paramObject, method);
    } catch (Exception exception) {
      die("Could not unregister " + paramString + "() for " + paramObject, exception);
    } 
  }
  
  public void setup() {}
  
  public void draw() {
    this.finished = true;
  }
  
  protected void resizeRenderer(int paramInt1, int paramInt2) {
    if (this.width != paramInt1 || this.height != paramInt2) {
      this.g.setSize(paramInt1, paramInt2);
      this.width = paramInt1;
      this.height = paramInt2;
    } 
  }
  
  public void size(int paramInt1, int paramInt2) {
    size(paramInt1, paramInt2, "processing.core.PGraphicsJava2D", (String)null);
  }
  
  public void size(int paramInt1, int paramInt2, String paramString) {
    size(paramInt1, paramInt2, paramString, (String)null);
  }
  
  public void size(final int iwidth, final int iheight, String paramString1, String paramString2) {
    SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            PApplet.this.setPreferredSize(new Dimension(iwidth, iheight));
            PApplet.this.setSize(iwidth, iheight);
          }
        });
    if (paramString2 != null)
      paramString2 = savePath(paramString2); 
    String str = this.g.getClass().getName();
    if (str.equals(paramString1)) {
      resizeRenderer(iwidth, iheight);
    } else {
      this.g = makeGraphics(iwidth, iheight, paramString1, paramString2, true);
      this.width = iwidth;
      this.height = iheight;
      this.defaultSize = false;
      throw new RendererChangeException();
    } 
  }
  
  public PGraphics createGraphics(int paramInt1, int paramInt2, String paramString) {
    return makeGraphics(paramInt1, paramInt2, paramString, (String)null, false);
  }
  
  public PGraphics createGraphics(int paramInt1, int paramInt2, String paramString1, String paramString2) {
    if (paramString2 != null)
      paramString2 = savePath(paramString2); 
    PGraphics pGraphics = makeGraphics(paramInt1, paramInt2, paramString1, paramString2, false);
    pGraphics.parent = this;
    return pGraphics;
  }
  
  protected PGraphics makeGraphics(int paramInt1, int paramInt2, String paramString1, String paramString2, boolean paramBoolean) {
    if (paramString1.equals("processing.opengl.PGraphicsOpenGL") && platform == 1) {
      String str1 = System.getProperty("java.version");
      if (str1 != null && str1.equals("1.5.0_10")) {
        System.err.println("OpenGL support is broken with Java 1.5.0_10");
        System.err.println("See http://dev.processing.org/bugs/show_bug.cgi?id=513 for more info.");
        throw new RuntimeException("Please update your Java installation (see bug #513)");
      } 
    } 
    String str = "Before using OpenGL, first select Import Library > opengl from the Sketch menu.";
    try {
      Class<?> clazz = Thread.currentThread().getContextClassLoader().loadClass(paramString1);
      Constructor<?> constructor = clazz.getConstructor(new Class[0]);
      PGraphics pGraphics = (PGraphics)constructor.newInstance(new Object[0]);
      pGraphics.setParent(this);
      pGraphics.setPrimary(paramBoolean);
      if (paramString2 != null)
        pGraphics.setPath(paramString2); 
      pGraphics.setSize(paramInt1, paramInt2);
      return pGraphics;
    } catch (InvocationTargetException invocationTargetException) {
      String str1 = invocationTargetException.getTargetException().getMessage();
      if (str1 != null && str1.indexOf("no jogl in java.library.path") != -1)
        throw new RuntimeException(str + " (The native library is missing.)"); 
      invocationTargetException.getTargetException().printStackTrace();
      Throwable throwable = invocationTargetException.getTargetException();
      if (platform == 2)
        throwable.printStackTrace(System.out); 
      throw new RuntimeException(throwable.getMessage());
    } catch (ClassNotFoundException classNotFoundException) {
      if (classNotFoundException.getMessage().indexOf("processing.opengl.PGraphicsGL") != -1)
        throw new RuntimeException(str + " (The library .jar file is missing.)"); 
      throw new RuntimeException("You need to use \"Import Library\" to add " + paramString1 + " to your sketch.");
    } catch (Exception exception) {
      if (exception instanceof IllegalArgumentException || exception instanceof NoSuchMethodException || exception instanceof IllegalAccessException) {
        exception.printStackTrace();
        String str1 = paramString1 + " needs to be updated " + "for the current release of Processing.";
        throw new RuntimeException(str1);
      } 
      if (platform == 2)
        exception.printStackTrace(System.out); 
      throw new RuntimeException(exception.getMessage());
    } 
  }
  
  public PImage createImage(int paramInt1, int paramInt2, int paramInt3) {
    return createImage(paramInt1, paramInt2, paramInt3, (Object)null);
  }
  
  public PImage createImage(int paramInt1, int paramInt2, int paramInt3, Object paramObject) {
    PImage pImage = new PImage(paramInt1, paramInt2, paramInt3);
    if (paramObject != null)
      pImage.setParams(this.g, paramObject); 
    pImage.parent = this;
    return pImage;
  }
  
  public void update(Graphics paramGraphics) {
    paint(paramGraphics);
  }
  
  public void paint(Graphics paramGraphics) {
    if (this.frameCount == 0)
      return; 
    if (this.g != null && this.g.image != null)
      synchronized (this.g.image) {
        paramGraphics.drawImage(this.g.image, 0, 0, null);
      }  
  }
  
  public void run() {
    long l1 = System.nanoTime();
    long l2 = 0L;
    byte b = 0;
    while (Thread.currentThread() == this.thread && !this.finished) {
      while (this.paused) {
        try {
          Thread.sleep(100L);
        } catch (InterruptedException interruptedException) {}
      } 
      if (this.resizeRequest) {
        resizeRenderer(this.resizeWidth, this.resizeHeight);
        this.resizeRequest = false;
      } 
      handleDraw();
      if (this.frameCount == 1)
        requestFocusInWindow(); 
      long l3 = System.nanoTime();
      long l4 = l3 - l1;
      long l5 = this.frameRatePeriod - l4 - l2;
      if (l5 > 0L) {
        try {
          Thread.sleep(l5 / 1000000L, (int)(l5 % 1000000L));
          b = 0;
        } catch (InterruptedException interruptedException) {}
        l2 = System.nanoTime() - l3 - l5;
      } else {
        l2 = 0L;
        if (b > 15) {
          Thread.yield();
          b = 0;
        } 
      } 
      l1 = System.nanoTime();
    } 
    dispose();
    if (this.exitCalled)
      exit2(); 
  }
  
  public void handleDraw() {
    if (this.g != null && (this.looping || this.redraw)) {
      if (!this.g.canDraw())
        return; 
      this.g.beginDraw();
      if (this.recorder != null)
        this.recorder.beginDraw(); 
      long l = System.nanoTime();
      if (this.frameCount == 0) {
        try {
          setup();
        } catch (RendererChangeException rendererChangeException) {
          return;
        } 
        this.defaultSize = false;
      } else {
        double d = 1000000.0D / (l - this.frameRateLastNanos) / 1000000.0D;
        float f = (float)d / 1000.0F;
        this.frameRate = this.frameRate * 0.9F + f * 0.1F;
        this.preMethods.handle();
        this.pmouseX = this.dmouseX;
        this.pmouseY = this.dmouseY;
        draw();
        this.dmouseX = this.mouseX;
        this.dmouseY = this.mouseY;
        dequeueMouseEvents();
        dequeueKeyEvents();
        this.drawMethods.handle();
        this.redraw = false;
      } 
      this.g.endDraw();
      if (this.recorder != null)
        this.recorder.endDraw(); 
      this.frameRateLastNanos = l;
      this.frameCount++;
      repaint();
      getToolkit().sync();
      this.postMethods.handle();
    } 
  }
  
  public synchronized void redraw() {
    if (!this.looping)
      this.redraw = true; 
  }
  
  public synchronized void loop() {
    if (!this.looping)
      this.looping = true; 
  }
  
  public synchronized void noLoop() {
    if (this.looping)
      this.looping = false; 
  }
  
  public void addListeners() {
    addMouseListener(this);
    addMouseMotionListener(this);
    addKeyListener(this);
    addFocusListener(this);
    addComponentListener(new ComponentAdapter() {
          public void componentResized(ComponentEvent param1ComponentEvent) {
            Component component = param1ComponentEvent.getComponent();
            Rectangle rectangle = component.getBounds();
            PApplet.this.resizeRequest = true;
            PApplet.this.resizeWidth = rectangle.width;
            PApplet.this.resizeHeight = rectangle.height;
          }
        });
  }
  
  protected void enqueueMouseEvent(MouseEvent paramMouseEvent) {
    synchronized (this.mouseEventQueue) {
      if (this.mouseEventCount == this.mouseEventQueue.length) {
        MouseEvent[] arrayOfMouseEvent = new MouseEvent[this.mouseEventCount << 1];
        System.arraycopy(this.mouseEventQueue, 0, arrayOfMouseEvent, 0, this.mouseEventCount);
        this.mouseEventQueue = arrayOfMouseEvent;
      } 
      this.mouseEventQueue[this.mouseEventCount++] = paramMouseEvent;
    } 
  }
  
  protected void dequeueMouseEvents() {
    synchronized (this.mouseEventQueue) {
      for (byte b = 0; b < this.mouseEventCount; b++) {
        this.mouseEvent = this.mouseEventQueue[b];
        handleMouseEvent(this.mouseEvent);
      } 
      this.mouseEventCount = 0;
    } 
  }
  
  protected void handleMouseEvent(MouseEvent paramMouseEvent) {
    int i = paramMouseEvent.getID();
    if (i == 506 || i == 503) {
      this.pmouseX = this.emouseX;
      this.pmouseY = this.emouseY;
      this.mouseX = paramMouseEvent.getX();
      this.mouseY = paramMouseEvent.getY();
    } 
    this.mouseEvent = paramMouseEvent;
    int j = paramMouseEvent.getModifiers();
    if ((j & 0x10) != 0) {
      this.mouseButton = 37;
    } else if ((j & 0x8) != 0) {
      this.mouseButton = 3;
    } else if ((j & 0x4) != 0) {
      this.mouseButton = 39;
    } 
    if (platform == 2 && this.mouseEvent.isPopupTrigger())
      this.mouseButton = 39; 
    this.mouseEventMethods.handle(new Object[] { paramMouseEvent });
    if (this.firstMouse) {
      this.pmouseX = this.mouseX;
      this.pmouseY = this.mouseY;
      this.dmouseX = this.mouseX;
      this.dmouseY = this.mouseY;
      this.firstMouse = false;
    } 
    switch (i) {
      case 501:
        this.mousePressed = true;
        mousePressed();
        break;
      case 502:
        this.mousePressed = false;
        mouseReleased();
        break;
      case 500:
        mouseClicked();
        break;
      case 506:
        mouseDragged();
        break;
      case 503:
        mouseMoved();
        break;
    } 
    if (i == 506 || i == 503) {
      this.emouseX = this.mouseX;
      this.emouseY = this.mouseY;
    } 
  }
  
  protected void checkMouseEvent(MouseEvent paramMouseEvent) {
    if (this.looping) {
      enqueueMouseEvent(paramMouseEvent);
    } else {
      handleMouseEvent(paramMouseEvent);
    } 
  }
  
  public void mousePressed(MouseEvent paramMouseEvent) {
    checkMouseEvent(paramMouseEvent);
  }
  
  public void mouseReleased(MouseEvent paramMouseEvent) {
    checkMouseEvent(paramMouseEvent);
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent) {
    checkMouseEvent(paramMouseEvent);
  }
  
  public void mouseEntered(MouseEvent paramMouseEvent) {
    checkMouseEvent(paramMouseEvent);
  }
  
  public void mouseExited(MouseEvent paramMouseEvent) {
    checkMouseEvent(paramMouseEvent);
  }
  
  public void mouseDragged(MouseEvent paramMouseEvent) {
    checkMouseEvent(paramMouseEvent);
  }
  
  public void mouseMoved(MouseEvent paramMouseEvent) {
    checkMouseEvent(paramMouseEvent);
  }
  
  public void mousePressed() {}
  
  public void mouseReleased() {}
  
  public void mouseClicked() {}
  
  public void mouseDragged() {}
  
  public void mouseMoved() {}
  
  protected void enqueueKeyEvent(KeyEvent paramKeyEvent) {
    synchronized (this.keyEventQueue) {
      if (this.keyEventCount == this.keyEventQueue.length) {
        KeyEvent[] arrayOfKeyEvent = new KeyEvent[this.keyEventCount << 1];
        System.arraycopy(this.keyEventQueue, 0, arrayOfKeyEvent, 0, this.keyEventCount);
        this.keyEventQueue = arrayOfKeyEvent;
      } 
      this.keyEventQueue[this.keyEventCount++] = paramKeyEvent;
    } 
  }
  
  protected void dequeueKeyEvents() {
    synchronized (this.keyEventQueue) {
      for (byte b = 0; b < this.keyEventCount; b++) {
        this.keyEvent = this.keyEventQueue[b];
        handleKeyEvent(this.keyEvent);
      } 
      this.keyEventCount = 0;
    } 
  }
  
  protected void handleKeyEvent(KeyEvent paramKeyEvent) {
    this.keyEvent = paramKeyEvent;
    this.key = paramKeyEvent.getKeyChar();
    this.keyCode = paramKeyEvent.getKeyCode();
    this.keyEventMethods.handle(new Object[] { paramKeyEvent });
    switch (paramKeyEvent.getID()) {
      case 401:
        this.keyPressed = true;
        keyPressed();
        break;
      case 402:
        this.keyPressed = false;
        keyReleased();
        break;
      case 400:
        keyTyped();
        break;
    } 
    if (paramKeyEvent.getID() == 401) {
      if (this.key == '\033')
        exit(); 
      if (this.external && paramKeyEvent.getModifiers() == MENU_SHORTCUT && paramKeyEvent.getKeyCode() == 87)
        exit(); 
    } 
  }
  
  protected void checkKeyEvent(KeyEvent paramKeyEvent) {
    if (this.looping) {
      enqueueKeyEvent(paramKeyEvent);
    } else {
      handleKeyEvent(paramKeyEvent);
    } 
  }
  
  public void keyPressed(KeyEvent paramKeyEvent) {
    checkKeyEvent(paramKeyEvent);
  }
  
  public void keyReleased(KeyEvent paramKeyEvent) {
    checkKeyEvent(paramKeyEvent);
  }
  
  public void keyTyped(KeyEvent paramKeyEvent) {
    checkKeyEvent(paramKeyEvent);
  }
  
  public void keyPressed() {}
  
  public void keyReleased() {}
  
  public void keyTyped() {}
  
  public void focusGained() {}
  
  public void focusGained(FocusEvent paramFocusEvent) {
    this.focused = true;
    focusGained();
  }
  
  public void focusLost() {}
  
  public void focusLost(FocusEvent paramFocusEvent) {
    this.focused = false;
    focusLost();
  }
  
  public int millis() {
    return (int)(System.currentTimeMillis() - this.millisOffset);
  }
  
  public static int second() {
    return Calendar.getInstance().get(13);
  }
  
  public static int minute() {
    return Calendar.getInstance().get(12);
  }
  
  public static int hour() {
    return Calendar.getInstance().get(11);
  }
  
  public static int day() {
    return Calendar.getInstance().get(5);
  }
  
  public static int month() {
    return Calendar.getInstance().get(2) + 1;
  }
  
  public static int year() {
    return Calendar.getInstance().get(1);
  }
  
  public void delay(int paramInt) {
    if (this.frameCount != 0 && paramInt > 0)
      try {
        Thread.sleep(paramInt);
      } catch (InterruptedException interruptedException) {} 
  }
  
  public void frameRate(float paramFloat) {
    this.frameRateTarget = paramFloat;
    this.frameRatePeriod = (long)(1.0E9D / this.frameRateTarget);
  }
  
  public String param(String paramString) {
    if (this.online)
      return getParameter(paramString); 
    System.err.println("param() only works inside a web browser");
    return null;
  }
  
  public void status(String paramString) {
    if (this.online) {
      showStatus(paramString);
    } else {
      System.out.println(paramString);
    } 
  }
  
  public void link(String paramString) {
    link(paramString, (String)null);
  }
  
  public void link(String paramString1, String paramString2) {
    if (this.online) {
      try {
        if (paramString2 == null) {
          getAppletContext().showDocument(new URL(paramString1));
        } else {
          getAppletContext().showDocument(new URL(paramString1), paramString2);
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
        throw new RuntimeException("Could not open " + paramString1);
      } 
    } else {
      try {
        if (platform == 1) {
          paramString1 = paramString1.replaceAll("&", "^&");
          Runtime.getRuntime().exec("cmd /c start " + paramString1);
        } else if (platform == 2) {
          try {
            Class<?> clazz = Class.forName("com.apple.eio.FileManager");
            Method method = clazz.getMethod("openURL", new Class[] { String.class });
            method.invoke(null, new Object[] { paramString1 });
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
        } else {
          open(paramString1);
        } 
      } catch (IOException iOException) {
        iOException.printStackTrace();
        throw new RuntimeException("Could not open " + paramString1);
      } 
    } 
  }
  
  public static void open(String paramString) {
    open(new String[] { paramString });
  }
  
  public static Process open(String[] paramArrayOfString) {
    String[] arrayOfString = null;
    if (platform == 1) {
      arrayOfString = new String[] { "cmd", "/c" };
    } else if (platform == 2) {
      arrayOfString = new String[] { "open" };
    } else if (platform == 3) {
      if (openLauncher == null)
        try {
          Process process = Runtime.getRuntime().exec(new String[] { "gnome-open" });
          process.waitFor();
          openLauncher = "gnome-open";
        } catch (Exception exception) {} 
      if (openLauncher == null)
        try {
          Process process = Runtime.getRuntime().exec(new String[] { "kde-open" });
          process.waitFor();
          openLauncher = "kde-open";
        } catch (Exception exception) {} 
      if (openLauncher == null)
        System.err.println("Could not find gnome-open or kde-open, the open() command may not work."); 
      if (openLauncher != null)
        arrayOfString = new String[] { openLauncher }; 
    } 
    if (arrayOfString != null) {
      if (arrayOfString[0].equals(paramArrayOfString[0]))
        return exec(paramArrayOfString); 
      arrayOfString = concat(arrayOfString, paramArrayOfString);
      return exec(arrayOfString);
    } 
    return exec(paramArrayOfString);
  }
  
  public static Process exec(String[] paramArrayOfString) {
    try {
      return Runtime.getRuntime().exec(paramArrayOfString);
    } catch (Exception exception) {
      exception.printStackTrace();
      throw new RuntimeException("Could not open " + join(paramArrayOfString, ' '));
    } 
  }
  
  public void die(String paramString) {
    dispose();
    throw new RuntimeException(paramString);
  }
  
  public void die(String paramString, Exception paramException) {
    if (paramException != null)
      paramException.printStackTrace(); 
    die(paramString);
  }
  
  public void exit() {
    if (this.thread == null) {
      exit2();
    } else if (this.looping) {
      this.finished = true;
      this.exitCalled = true;
    } else if (!this.looping) {
      dispose();
      exit2();
    } 
  }
  
  void exit2() {
    try {
      System.exit(0);
    } catch (SecurityException securityException) {}
  }
  
  public void dispose() {
    this.finished = true;
    if (this.thread == null)
      return; 
    this.thread = null;
    if (this.g != null)
      this.g.dispose(); 
    this.disposeMethods.handle();
  }
  
  public void method(String paramString) {
    try {
      Method method = getClass().getMethod(paramString, new Class[0]);
      method.invoke(this, new Object[0]);
    } catch (IllegalArgumentException illegalArgumentException) {
      illegalArgumentException.printStackTrace();
    } catch (IllegalAccessException illegalAccessException) {
      illegalAccessException.printStackTrace();
    } catch (InvocationTargetException invocationTargetException) {
      invocationTargetException.getTargetException().printStackTrace();
    } catch (NoSuchMethodException noSuchMethodException) {
      System.err.println("There is no public " + paramString + "() method " + "in the class " + getClass().getName());
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public void thread(final String name) {
    Thread thread = new Thread() {
        public void run() {
          PApplet.this.method(name);
        }
      };
    thread.start();
  }
  
  public void save(String paramString) {
    this.g.save(savePath(paramString));
  }
  
  public void saveFrame() {
    try {
      this.g.save(savePath("screen-" + nf(this.frameCount, 4) + ".tif"));
    } catch (SecurityException securityException) {
      System.err.println("Can't use saveFrame() when running in a browser, unless using a signed applet.");
    } 
  }
  
  public void saveFrame(String paramString) {
    try {
      this.g.save(savePath(insertFrame(paramString)));
    } catch (SecurityException securityException) {
      System.err.println("Can't use saveFrame() when running in a browser, unless using a signed applet.");
    } 
  }
  
  protected String insertFrame(String paramString) {
    int i = paramString.indexOf('#');
    int j = paramString.lastIndexOf('#');
    if (i != -1 && j - i > 0) {
      String str1 = paramString.substring(0, i);
      int k = j - i + 1;
      String str2 = paramString.substring(j + 1);
      return str1 + nf(this.frameCount, k) + str2;
    } 
    return paramString;
  }
  
  public void cursor(int paramInt) {
    setCursor(Cursor.getPredefinedCursor(paramInt));
    this.cursorVisible = true;
    this.cursorType = paramInt;
  }
  
  public void cursor(PImage paramPImage) {
    cursor(paramPImage, paramPImage.width / 2, paramPImage.height / 2);
  }
  
  public void cursor(PImage paramPImage, int paramInt1, int paramInt2) {
    Image image = createImage(new MemoryImageSource(paramPImage.width, paramPImage.height, paramPImage.pixels, 0, paramPImage.width));
    Point point = new Point(paramInt1, paramInt2);
    Toolkit toolkit = Toolkit.getDefaultToolkit();
    Cursor cursor = toolkit.createCustomCursor(image, point, "Custom Cursor");
    setCursor(cursor);
    this.cursorVisible = true;
  }
  
  public void cursor() {
    if (!this.cursorVisible) {
      this.cursorVisible = true;
      setCursor(Cursor.getPredefinedCursor(this.cursorType));
    } 
  }
  
  public void noCursor() {
    if (!this.cursorVisible)
      return; 
    if (this.invisibleCursor == null)
      this.invisibleCursor = new PImage(16, 16, 2); 
    cursor(this.invisibleCursor, 8, 8);
    this.cursorVisible = false;
  }
  
  public static void print(byte paramByte) {
    System.out.print(paramByte);
    System.out.flush();
  }
  
  public static void print(boolean paramBoolean) {
    System.out.print(paramBoolean);
    System.out.flush();
  }
  
  public static void print(char paramChar) {
    System.out.print(paramChar);
    System.out.flush();
  }
  
  public static void print(int paramInt) {
    System.out.print(paramInt);
    System.out.flush();
  }
  
  public static void print(float paramFloat) {
    System.out.print(paramFloat);
    System.out.flush();
  }
  
  public static void print(String paramString) {
    System.out.print(paramString);
    System.out.flush();
  }
  
  public static void print(Object paramObject) {
    if (paramObject == null) {
      System.out.print("null");
    } else {
      System.out.println(paramObject.toString());
    } 
  }
  
  public static void println() {
    System.out.println();
  }
  
  public static void println(byte paramByte) {
    print(paramByte);
    System.out.println();
  }
  
  public static void println(boolean paramBoolean) {
    print(paramBoolean);
    System.out.println();
  }
  
  public static void println(char paramChar) {
    print(paramChar);
    System.out.println();
  }
  
  public static void println(int paramInt) {
    print(paramInt);
    System.out.println();
  }
  
  public static void println(float paramFloat) {
    print(paramFloat);
    System.out.println();
  }
  
  public static void println(String paramString) {
    print(paramString);
    System.out.println();
  }
  
  public static void println(Object paramObject) {
    if (paramObject == null) {
      System.out.println("null");
    } else {
      String str = paramObject.getClass().getName();
      if (str.charAt(0) == '[') {
        Object[] arrayOfObject;
        byte b1;
        boolean[] arrayOfBoolean;
        byte b2;
        byte[] arrayOfByte;
        byte b3;
        char[] arrayOfChar;
        byte b4;
        int[] arrayOfInt;
        byte b5;
        float[] arrayOfFloat;
        byte b6;
        double[] arrayOfDouble;
        byte b7;
        switch (str.charAt(1)) {
          case '[':
            System.out.println(paramObject);
            return;
          case 'L':
            arrayOfObject = (Object[])paramObject;
            for (b1 = 0; b1 < arrayOfObject.length; b1++) {
              if (arrayOfObject[b1] instanceof String) {
                System.out.println("[" + b1 + "] \"" + arrayOfObject[b1] + "\"");
              } else {
                System.out.println("[" + b1 + "] " + arrayOfObject[b1]);
              } 
            } 
            return;
          case 'Z':
            arrayOfBoolean = (boolean[])paramObject;
            for (b2 = 0; b2 < arrayOfBoolean.length; b2++)
              System.out.println("[" + b2 + "] " + arrayOfBoolean[b2]); 
            return;
          case 'B':
            arrayOfByte = (byte[])paramObject;
            for (b3 = 0; b3 < arrayOfByte.length; b3++)
              System.out.println("[" + b3 + "] " + arrayOfByte[b3]); 
            return;
          case 'C':
            arrayOfChar = (char[])paramObject;
            for (b4 = 0; b4 < arrayOfChar.length; b4++)
              System.out.println("[" + b4 + "] '" + arrayOfChar[b4] + "'"); 
            return;
          case 'I':
            arrayOfInt = (int[])paramObject;
            for (b5 = 0; b5 < arrayOfInt.length; b5++)
              System.out.println("[" + b5 + "] " + arrayOfInt[b5]); 
            return;
          case 'F':
            arrayOfFloat = (float[])paramObject;
            for (b6 = 0; b6 < arrayOfFloat.length; b6++)
              System.out.println("[" + b6 + "] " + arrayOfFloat[b6]); 
            return;
          case 'D':
            arrayOfDouble = (double[])paramObject;
            for (b7 = 0; b7 < arrayOfDouble.length; b7++)
              System.out.println("[" + b7 + "] " + arrayOfDouble[b7]); 
            return;
        } 
        System.out.println(paramObject);
      } else {
        System.out.println(paramObject);
      } 
    } 
  }
  
  public static final float abs(float paramFloat) {
    return (paramFloat < 0.0F) ? -paramFloat : paramFloat;
  }
  
  public static final int abs(int paramInt) {
    return (paramInt < 0) ? -paramInt : paramInt;
  }
  
  public static final float sq(float paramFloat) {
    return paramFloat * paramFloat;
  }
  
  public static final float sqrt(float paramFloat) {
    return (float)Math.sqrt(paramFloat);
  }
  
  public static final float log(float paramFloat) {
    return (float)Math.log(paramFloat);
  }
  
  public static final float exp(float paramFloat) {
    return (float)Math.exp(paramFloat);
  }
  
  public static final float pow(float paramFloat1, float paramFloat2) {
    return (float)Math.pow(paramFloat1, paramFloat2);
  }
  
  public static final int max(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2) ? paramInt1 : paramInt2;
  }
  
  public static final float max(float paramFloat1, float paramFloat2) {
    return (paramFloat1 > paramFloat2) ? paramFloat1 : paramFloat2;
  }
  
  public static final int max(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 > paramInt2) ? ((paramInt1 > paramInt3) ? paramInt1 : paramInt3) : ((paramInt2 > paramInt3) ? paramInt2 : paramInt3);
  }
  
  public static final float max(float paramFloat1, float paramFloat2, float paramFloat3) {
    return (paramFloat1 > paramFloat2) ? ((paramFloat1 > paramFloat3) ? paramFloat1 : paramFloat3) : ((paramFloat2 > paramFloat3) ? paramFloat2 : paramFloat3);
  }
  
  public static final int max(int[] paramArrayOfint) {
    if (paramArrayOfint.length == 0)
      throw new ArrayIndexOutOfBoundsException("Cannot use min() or max() on an empty array."); 
    int i = paramArrayOfint[0];
    for (byte b = 1; b < paramArrayOfint.length; b++) {
      if (paramArrayOfint[b] > i)
        i = paramArrayOfint[b]; 
    } 
    return i;
  }
  
  public static final float max(float[] paramArrayOffloat) {
    if (paramArrayOffloat.length == 0)
      throw new ArrayIndexOutOfBoundsException("Cannot use min() or max() on an empty array."); 
    float f = paramArrayOffloat[0];
    for (byte b = 1; b < paramArrayOffloat.length; b++) {
      if (paramArrayOffloat[b] > f)
        f = paramArrayOffloat[b]; 
    } 
    return f;
  }
  
  public static final int min(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2) ? paramInt1 : paramInt2;
  }
  
  public static final float min(float paramFloat1, float paramFloat2) {
    return (paramFloat1 < paramFloat2) ? paramFloat1 : paramFloat2;
  }
  
  public static final int min(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 < paramInt2) ? ((paramInt1 < paramInt3) ? paramInt1 : paramInt3) : ((paramInt2 < paramInt3) ? paramInt2 : paramInt3);
  }
  
  public static final float min(float paramFloat1, float paramFloat2, float paramFloat3) {
    return (paramFloat1 < paramFloat2) ? ((paramFloat1 < paramFloat3) ? paramFloat1 : paramFloat3) : ((paramFloat2 < paramFloat3) ? paramFloat2 : paramFloat3);
  }
  
  public static final int min(int[] paramArrayOfint) {
    if (paramArrayOfint.length == 0)
      throw new ArrayIndexOutOfBoundsException("Cannot use min() or max() on an empty array."); 
    int i = paramArrayOfint[0];
    for (byte b = 1; b < paramArrayOfint.length; b++) {
      if (paramArrayOfint[b] < i)
        i = paramArrayOfint[b]; 
    } 
    return i;
  }
  
  public static final float min(float[] paramArrayOffloat) {
    if (paramArrayOffloat.length == 0)
      throw new ArrayIndexOutOfBoundsException("Cannot use min() or max() on an empty array."); 
    float f = paramArrayOffloat[0];
    for (byte b = 1; b < paramArrayOffloat.length; b++) {
      if (paramArrayOffloat[b] < f)
        f = paramArrayOffloat[b]; 
    } 
    return f;
  }
  
  public static final int constrain(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 < paramInt2) ? paramInt2 : ((paramInt1 > paramInt3) ? paramInt3 : paramInt1);
  }
  
  public static final float constrain(float paramFloat1, float paramFloat2, float paramFloat3) {
    return (paramFloat1 < paramFloat2) ? paramFloat2 : ((paramFloat1 > paramFloat3) ? paramFloat3 : paramFloat1);
  }
  
  public static final float sin(float paramFloat) {
    return (float)Math.sin(paramFloat);
  }
  
  public static final float cos(float paramFloat) {
    return (float)Math.cos(paramFloat);
  }
  
  public static final float tan(float paramFloat) {
    return (float)Math.tan(paramFloat);
  }
  
  public static final float asin(float paramFloat) {
    return (float)Math.asin(paramFloat);
  }
  
  public static final float acos(float paramFloat) {
    return (float)Math.acos(paramFloat);
  }
  
  public static final float atan(float paramFloat) {
    return (float)Math.atan(paramFloat);
  }
  
  public static final float atan2(float paramFloat1, float paramFloat2) {
    return (float)Math.atan2(paramFloat1, paramFloat2);
  }
  
  public static final float degrees(float paramFloat) {
    return paramFloat * 57.295776F;
  }
  
  public static final float radians(float paramFloat) {
    return paramFloat * 0.017453292F;
  }
  
  public static final int ceil(float paramFloat) {
    return (int)Math.ceil(paramFloat);
  }
  
  public static final int floor(float paramFloat) {
    return (int)Math.floor(paramFloat);
  }
  
  public static final int round(float paramFloat) {
    return Math.round(paramFloat);
  }
  
  public static final float mag(float paramFloat1, float paramFloat2) {
    return (float)Math.sqrt((paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2));
  }
  
  public static final float mag(float paramFloat1, float paramFloat2, float paramFloat3) {
    return (float)Math.sqrt((paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2 + paramFloat3 * paramFloat3));
  }
  
  public static final float dist(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    return sqrt(sq(paramFloat3 - paramFloat1) + sq(paramFloat4 - paramFloat2));
  }
  
  public static final float dist(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    return sqrt(sq(paramFloat4 - paramFloat1) + sq(paramFloat5 - paramFloat2) + sq(paramFloat6 - paramFloat3));
  }
  
  public static final float lerp(float paramFloat1, float paramFloat2, float paramFloat3) {
    return paramFloat1 + (paramFloat2 - paramFloat1) * paramFloat3;
  }
  
  public static final float norm(float paramFloat1, float paramFloat2, float paramFloat3) {
    return (paramFloat1 - paramFloat2) / (paramFloat3 - paramFloat2);
  }
  
  public static final float map(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    return paramFloat4 + (paramFloat5 - paramFloat4) * (paramFloat1 - paramFloat2) / (paramFloat3 - paramFloat2);
  }
  
  public final float random(float paramFloat) {
    if (paramFloat == 0.0F)
      return 0.0F; 
    if (this.internalRandom == null)
      this.internalRandom = new Random(); 
    float f = 0.0F;
    while (true) {
      f = this.internalRandom.nextFloat() * paramFloat;
      if (f != paramFloat)
        return f; 
    } 
  }
  
  public final float random(float paramFloat1, float paramFloat2) {
    if (paramFloat1 >= paramFloat2)
      return paramFloat1; 
    float f = paramFloat2 - paramFloat1;
    return random(f) + paramFloat1;
  }
  
  public final void randomSeed(long paramLong) {
    if (this.internalRandom == null)
      this.internalRandom = new Random(); 
    this.internalRandom.setSeed(paramLong);
  }
  
  public float noise(float paramFloat) {
    return noise(paramFloat, 0.0F, 0.0F);
  }
  
  public float noise(float paramFloat1, float paramFloat2) {
    return noise(paramFloat1, paramFloat2, 0.0F);
  }
  
  public float noise(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.perlin == null) {
      if (this.perlinRandom == null)
        this.perlinRandom = new Random(); 
      this.perlin = new float[4096];
      for (byte b1 = 0; b1 < 'က'; b1++)
        this.perlin[b1] = this.perlinRandom.nextFloat(); 
      this.perlin_cosTable = PGraphics.cosLUT;
      this.perlin_TWOPI = this.perlin_PI = 720;
      this.perlin_PI >>= 1;
    } 
    if (paramFloat1 < 0.0F)
      paramFloat1 = -paramFloat1; 
    if (paramFloat2 < 0.0F)
      paramFloat2 = -paramFloat2; 
    if (paramFloat3 < 0.0F)
      paramFloat3 = -paramFloat3; 
    int i = (int)paramFloat1;
    int j = (int)paramFloat2;
    int k = (int)paramFloat3;
    float f1 = paramFloat1 - i;
    float f2 = paramFloat2 - j;
    float f3 = paramFloat3 - k;
    float f4 = 0.0F;
    float f5 = 0.5F;
    for (byte b = 0; b < this.perlin_octaves; b++) {
      int m = i + (j << 4) + (k << 8);
      float f6 = noise_fsc(f1);
      float f7 = noise_fsc(f2);
      float f8 = this.perlin[m & 0xFFF];
      f8 += f6 * (this.perlin[m + 1 & 0xFFF] - f8);
      float f9 = this.perlin[m + 16 & 0xFFF];
      f9 += f6 * (this.perlin[m + 16 + 1 & 0xFFF] - f9);
      f8 += f7 * (f9 - f8);
      m += 256;
      f9 = this.perlin[m & 0xFFF];
      f9 += f6 * (this.perlin[m + 1 & 0xFFF] - f9);
      float f10 = this.perlin[m + 16 & 0xFFF];
      f10 += f6 * (this.perlin[m + 16 + 1 & 0xFFF] - f10);
      f9 += f7 * (f10 - f9);
      f8 += noise_fsc(f3) * (f9 - f8);
      f4 += f8 * f5;
      f5 *= this.perlin_amp_falloff;
      i <<= 1;
      f1 *= 2.0F;
      j <<= 1;
      f2 *= 2.0F;
      k <<= 1;
      f3 *= 2.0F;
      if (f1 >= 1.0F) {
        i++;
        f1--;
      } 
      if (f2 >= 1.0F) {
        j++;
        f2--;
      } 
      if (f3 >= 1.0F) {
        k++;
        f3--;
      } 
    } 
    return f4;
  }
  
  private float noise_fsc(float paramFloat) {
    return 0.5F * (1.0F - this.perlin_cosTable[(int)(paramFloat * this.perlin_PI) % this.perlin_TWOPI]);
  }
  
  public void noiseDetail(int paramInt) {
    if (paramInt > 0)
      this.perlin_octaves = paramInt; 
  }
  
  public void noiseDetail(int paramInt, float paramFloat) {
    if (paramInt > 0)
      this.perlin_octaves = paramInt; 
    if (paramFloat > 0.0F)
      this.perlin_amp_falloff = paramFloat; 
  }
  
  public void noiseSeed(long paramLong) {
    if (this.perlinRandom == null)
      this.perlinRandom = new Random(); 
    this.perlinRandom.setSeed(paramLong);
    this.perlin = null;
  }
  
  public PImage loadImage(String paramString) {
    return loadImage(paramString, (String)null, (Object)null);
  }
  
  public PImage loadImage(String paramString1, String paramString2) {
    return loadImage(paramString1, paramString2, (Object)null);
  }
  
  public PImage loadImage(String paramString, Object paramObject) {
    return loadImage(paramString, (String)null, paramObject);
  }
  
  public PImage loadImage(String paramString1, String paramString2, Object paramObject) {
    if (paramString2 == null) {
      String str = paramString1.toLowerCase();
      int i = paramString1.lastIndexOf('.');
      if (i == -1)
        paramString2 = "unknown"; 
      paramString2 = str.substring(i + 1);
      int j = paramString2.indexOf('?');
      if (j != -1)
        paramString2 = paramString2.substring(0, j); 
    } 
    paramString2 = paramString2.toLowerCase();
    if (paramString2.equals("tga"))
      try {
        PImage pImage = loadImageTGA(paramString1);
        if (paramObject != null)
          pImage.setParams(this.g, paramObject); 
        return pImage;
      } catch (IOException iOException) {
        iOException.printStackTrace();
        return null;
      }  
    if (paramString2.equals("tif") || paramString2.equals("tiff")) {
      byte[] arrayOfByte = loadBytes(paramString1);
      PImage pImage = (arrayOfByte == null) ? null : PImage.loadTIFF(arrayOfByte);
      if (paramObject != null)
        pImage.setParams(this.g, paramObject); 
      return pImage;
    } 
    try {
      if (paramString2.equals("jpg") || paramString2.equals("jpeg") || paramString2.equals("gif") || paramString2.equals("png") || paramString2.equals("unknown")) {
        byte[] arrayOfByte = loadBytes(paramString1);
        if (arrayOfByte == null)
          return null; 
        Image image = Toolkit.getDefaultToolkit().createImage(arrayOfByte);
        PImage pImage = loadImageMT(image);
        if (pImage.width == -1)
          System.err.println("The file " + paramString1 + " contains bad image data, or may not be an image."); 
        if (paramString2.equals("gif") || paramString2.equals("png"))
          pImage.checkAlpha(); 
        if (paramObject != null)
          pImage.setParams(this.g, paramObject); 
        return pImage;
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    if (this.loadImageFormats == null)
      this.loadImageFormats = ImageIO.getReaderFormatNames(); 
    if (this.loadImageFormats != null)
      for (byte b = 0; b < this.loadImageFormats.length; b++) {
        if (paramString2.equals(this.loadImageFormats[b])) {
          PImage pImage = loadImageIO(paramString1);
          if (paramObject != null)
            pImage.setParams(this.g, paramObject); 
          return pImage;
        } 
      }  
    System.err.println("Could not find a method to load " + paramString1);
    return null;
  }
  
  public PImage requestImage(String paramString) {
    return requestImage(paramString, (String)null, (Object)null);
  }
  
  public PImage requestImage(String paramString1, String paramString2) {
    return requestImage(paramString1, paramString2, (Object)null);
  }
  
  public PImage requestImage(String paramString1, String paramString2, Object paramObject) {
    PImage pImage = createImage(0, 0, 2, paramObject);
    AsyncImageLoader asyncImageLoader = new AsyncImageLoader(paramString1, paramString2, pImage);
    asyncImageLoader.start();
    return pImage;
  }
  
  protected PImage loadImageMT(Image paramImage) {
    MediaTracker mediaTracker = new MediaTracker(this);
    mediaTracker.addImage(paramImage, 0);
    try {
      mediaTracker.waitForAll();
    } catch (InterruptedException interruptedException) {}
    PImage pImage = new PImage(paramImage);
    pImage.parent = this;
    return pImage;
  }
  
  protected PImage loadImageIO(String paramString) {
    InputStream inputStream = createInput(paramString);
    if (inputStream == null) {
      System.err.println("The image " + paramString + " could not be found.");
      return null;
    } 
    try {
      BufferedImage bufferedImage = ImageIO.read(inputStream);
      PImage pImage = new PImage(bufferedImage.getWidth(), bufferedImage.getHeight());
      pImage.parent = this;
      bufferedImage.getRGB(0, 0, pImage.width, pImage.height, pImage.pixels, 0, pImage.width);
      pImage.checkAlpha();
      return pImage;
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  protected PImage loadImageTGA(String paramString) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual createInput : (Ljava/lang/String;)Ljava/io/InputStream;
    //   5: astore_2
    //   6: aload_2
    //   7: ifnonnull -> 12
    //   10: aconst_null
    //   11: areturn
    //   12: bipush #18
    //   14: newarray byte
    //   16: astore_3
    //   17: iconst_0
    //   18: istore #4
    //   20: aload_2
    //   21: aload_3
    //   22: iload #4
    //   24: aload_3
    //   25: arraylength
    //   26: iload #4
    //   28: isub
    //   29: invokevirtual read : ([BII)I
    //   32: istore #5
    //   34: iload #5
    //   36: iconst_m1
    //   37: if_icmpne -> 42
    //   40: aconst_null
    //   41: areturn
    //   42: iload #4
    //   44: iload #5
    //   46: iadd
    //   47: istore #4
    //   49: iload #4
    //   51: bipush #18
    //   53: if_icmplt -> 20
    //   56: iconst_0
    //   57: istore #5
    //   59: aload_3
    //   60: iconst_2
    //   61: baload
    //   62: iconst_3
    //   63: if_icmpeq -> 74
    //   66: aload_3
    //   67: iconst_2
    //   68: baload
    //   69: bipush #11
    //   71: if_icmpne -> 107
    //   74: aload_3
    //   75: bipush #16
    //   77: baload
    //   78: bipush #8
    //   80: if_icmpne -> 107
    //   83: aload_3
    //   84: bipush #17
    //   86: baload
    //   87: bipush #8
    //   89: if_icmpeq -> 101
    //   92: aload_3
    //   93: bipush #17
    //   95: baload
    //   96: bipush #40
    //   98: if_icmpne -> 107
    //   101: iconst_4
    //   102: istore #5
    //   104: goto -> 198
    //   107: aload_3
    //   108: iconst_2
    //   109: baload
    //   110: iconst_2
    //   111: if_icmpeq -> 122
    //   114: aload_3
    //   115: iconst_2
    //   116: baload
    //   117: bipush #10
    //   119: if_icmpne -> 153
    //   122: aload_3
    //   123: bipush #16
    //   125: baload
    //   126: bipush #24
    //   128: if_icmpne -> 153
    //   131: aload_3
    //   132: bipush #17
    //   134: baload
    //   135: bipush #32
    //   137: if_icmpeq -> 147
    //   140: aload_3
    //   141: bipush #17
    //   143: baload
    //   144: ifne -> 153
    //   147: iconst_1
    //   148: istore #5
    //   150: goto -> 198
    //   153: aload_3
    //   154: iconst_2
    //   155: baload
    //   156: iconst_2
    //   157: if_icmpeq -> 168
    //   160: aload_3
    //   161: iconst_2
    //   162: baload
    //   163: bipush #10
    //   165: if_icmpne -> 198
    //   168: aload_3
    //   169: bipush #16
    //   171: baload
    //   172: bipush #32
    //   174: if_icmpne -> 198
    //   177: aload_3
    //   178: bipush #17
    //   180: baload
    //   181: bipush #8
    //   183: if_icmpeq -> 195
    //   186: aload_3
    //   187: bipush #17
    //   189: baload
    //   190: bipush #40
    //   192: if_icmpne -> 198
    //   195: iconst_2
    //   196: istore #5
    //   198: iload #5
    //   200: ifne -> 231
    //   203: getstatic java/lang/System.err : Ljava/io/PrintStream;
    //   206: new java/lang/StringBuilder
    //   209: dup
    //   210: invokespecial <init> : ()V
    //   213: ldc_w 'Unknown .tga file format for '
    //   216: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   219: aload_1
    //   220: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   223: invokevirtual toString : ()Ljava/lang/String;
    //   226: invokevirtual println : (Ljava/lang/String;)V
    //   229: aconst_null
    //   230: areturn
    //   231: aload_3
    //   232: bipush #13
    //   234: baload
    //   235: sipush #255
    //   238: iand
    //   239: bipush #8
    //   241: ishl
    //   242: aload_3
    //   243: bipush #12
    //   245: baload
    //   246: sipush #255
    //   249: iand
    //   250: iadd
    //   251: istore #6
    //   253: aload_3
    //   254: bipush #15
    //   256: baload
    //   257: sipush #255
    //   260: iand
    //   261: bipush #8
    //   263: ishl
    //   264: aload_3
    //   265: bipush #14
    //   267: baload
    //   268: sipush #255
    //   271: iand
    //   272: iadd
    //   273: istore #7
    //   275: aload_0
    //   276: iload #6
    //   278: iload #7
    //   280: iload #5
    //   282: invokevirtual createImage : (III)Lprocessing/core/PImage;
    //   285: astore #8
    //   287: aload_3
    //   288: bipush #17
    //   290: baload
    //   291: bipush #32
    //   293: iand
    //   294: ifeq -> 301
    //   297: iconst_1
    //   298: goto -> 302
    //   301: iconst_0
    //   302: istore #9
    //   304: aload_3
    //   305: iconst_2
    //   306: baload
    //   307: iconst_2
    //   308: if_icmpeq -> 318
    //   311: aload_3
    //   312: iconst_2
    //   313: baload
    //   314: iconst_3
    //   315: if_icmpne -> 757
    //   318: iload #9
    //   320: ifeq -> 582
    //   323: iload #7
    //   325: iconst_1
    //   326: isub
    //   327: iload #6
    //   329: imul
    //   330: istore #10
    //   332: iload #5
    //   334: tableswitch default -> 579, 1 -> 422, 2 -> 500, 3 -> 579, 4 -> 364
    //   364: iload #7
    //   366: iconst_1
    //   367: isub
    //   368: istore #11
    //   370: iload #11
    //   372: iflt -> 419
    //   375: iconst_0
    //   376: istore #12
    //   378: iload #12
    //   380: iload #6
    //   382: if_icmpge -> 406
    //   385: aload #8
    //   387: getfield pixels : [I
    //   390: iload #10
    //   392: iload #12
    //   394: iadd
    //   395: aload_2
    //   396: invokevirtual read : ()I
    //   399: iastore
    //   400: iinc #12, 1
    //   403: goto -> 378
    //   406: iload #10
    //   408: iload #6
    //   410: isub
    //   411: istore #10
    //   413: iinc #11, -1
    //   416: goto -> 370
    //   419: goto -> 579
    //   422: iload #7
    //   424: iconst_1
    //   425: isub
    //   426: istore #11
    //   428: iload #11
    //   430: iflt -> 497
    //   433: iconst_0
    //   434: istore #12
    //   436: iload #12
    //   438: iload #6
    //   440: if_icmpge -> 484
    //   443: aload #8
    //   445: getfield pixels : [I
    //   448: iload #10
    //   450: iload #12
    //   452: iadd
    //   453: aload_2
    //   454: invokevirtual read : ()I
    //   457: aload_2
    //   458: invokevirtual read : ()I
    //   461: bipush #8
    //   463: ishl
    //   464: ior
    //   465: aload_2
    //   466: invokevirtual read : ()I
    //   469: bipush #16
    //   471: ishl
    //   472: ior
    //   473: ldc_w -16777216
    //   476: ior
    //   477: iastore
    //   478: iinc #12, 1
    //   481: goto -> 436
    //   484: iload #10
    //   486: iload #6
    //   488: isub
    //   489: istore #10
    //   491: iinc #11, -1
    //   494: goto -> 428
    //   497: goto -> 579
    //   500: iload #7
    //   502: iconst_1
    //   503: isub
    //   504: istore #11
    //   506: iload #11
    //   508: iflt -> 579
    //   511: iconst_0
    //   512: istore #12
    //   514: iload #12
    //   516: iload #6
    //   518: if_icmpge -> 566
    //   521: aload #8
    //   523: getfield pixels : [I
    //   526: iload #10
    //   528: iload #12
    //   530: iadd
    //   531: aload_2
    //   532: invokevirtual read : ()I
    //   535: aload_2
    //   536: invokevirtual read : ()I
    //   539: bipush #8
    //   541: ishl
    //   542: ior
    //   543: aload_2
    //   544: invokevirtual read : ()I
    //   547: bipush #16
    //   549: ishl
    //   550: ior
    //   551: aload_2
    //   552: invokevirtual read : ()I
    //   555: bipush #24
    //   557: ishl
    //   558: ior
    //   559: iastore
    //   560: iinc #12, 1
    //   563: goto -> 514
    //   566: iload #10
    //   568: iload #6
    //   570: isub
    //   571: istore #10
    //   573: iinc #11, -1
    //   576: goto -> 506
    //   579: goto -> 1208
    //   582: iload #6
    //   584: iload #7
    //   586: imul
    //   587: istore #10
    //   589: iload #5
    //   591: tableswitch default -> 754, 1 -> 651, 2 -> 702, 3 -> 754, 4 -> 620
    //   620: iconst_0
    //   621: istore #11
    //   623: iload #11
    //   625: iload #10
    //   627: if_icmpge -> 648
    //   630: aload #8
    //   632: getfield pixels : [I
    //   635: iload #11
    //   637: aload_2
    //   638: invokevirtual read : ()I
    //   641: iastore
    //   642: iinc #11, 1
    //   645: goto -> 623
    //   648: goto -> 754
    //   651: iconst_0
    //   652: istore #11
    //   654: iload #11
    //   656: iload #10
    //   658: if_icmpge -> 699
    //   661: aload #8
    //   663: getfield pixels : [I
    //   666: iload #11
    //   668: aload_2
    //   669: invokevirtual read : ()I
    //   672: aload_2
    //   673: invokevirtual read : ()I
    //   676: bipush #8
    //   678: ishl
    //   679: ior
    //   680: aload_2
    //   681: invokevirtual read : ()I
    //   684: bipush #16
    //   686: ishl
    //   687: ior
    //   688: ldc_w -16777216
    //   691: ior
    //   692: iastore
    //   693: iinc #11, 1
    //   696: goto -> 654
    //   699: goto -> 754
    //   702: iconst_0
    //   703: istore #11
    //   705: iload #11
    //   707: iload #10
    //   709: if_icmpge -> 754
    //   712: aload #8
    //   714: getfield pixels : [I
    //   717: iload #11
    //   719: aload_2
    //   720: invokevirtual read : ()I
    //   723: aload_2
    //   724: invokevirtual read : ()I
    //   727: bipush #8
    //   729: ishl
    //   730: ior
    //   731: aload_2
    //   732: invokevirtual read : ()I
    //   735: bipush #16
    //   737: ishl
    //   738: ior
    //   739: aload_2
    //   740: invokevirtual read : ()I
    //   743: bipush #24
    //   745: ishl
    //   746: ior
    //   747: iastore
    //   748: iinc #11, 1
    //   751: goto -> 705
    //   754: goto -> 1208
    //   757: iconst_0
    //   758: istore #10
    //   760: aload #8
    //   762: getfield pixels : [I
    //   765: astore #11
    //   767: iload #10
    //   769: aload #11
    //   771: arraylength
    //   772: if_icmpge -> 1121
    //   775: aload_2
    //   776: invokevirtual read : ()I
    //   779: istore #12
    //   781: iload #12
    //   783: sipush #128
    //   786: iand
    //   787: ifeq -> 794
    //   790: iconst_1
    //   791: goto -> 795
    //   794: iconst_0
    //   795: istore #13
    //   797: iload #13
    //   799: ifeq -> 948
    //   802: iinc #12, -127
    //   805: iconst_0
    //   806: istore #14
    //   808: iload #5
    //   810: tableswitch default -> 908, 1 -> 849, 2 -> 878, 3 -> 908, 4 -> 840
    //   840: aload_2
    //   841: invokevirtual read : ()I
    //   844: istore #14
    //   846: goto -> 908
    //   849: ldc_w -16777216
    //   852: aload_2
    //   853: invokevirtual read : ()I
    //   856: ior
    //   857: aload_2
    //   858: invokevirtual read : ()I
    //   861: bipush #8
    //   863: ishl
    //   864: ior
    //   865: aload_2
    //   866: invokevirtual read : ()I
    //   869: bipush #16
    //   871: ishl
    //   872: ior
    //   873: istore #14
    //   875: goto -> 908
    //   878: aload_2
    //   879: invokevirtual read : ()I
    //   882: aload_2
    //   883: invokevirtual read : ()I
    //   886: bipush #8
    //   888: ishl
    //   889: ior
    //   890: aload_2
    //   891: invokevirtual read : ()I
    //   894: bipush #16
    //   896: ishl
    //   897: ior
    //   898: aload_2
    //   899: invokevirtual read : ()I
    //   902: bipush #24
    //   904: ishl
    //   905: ior
    //   906: istore #14
    //   908: iconst_0
    //   909: istore #15
    //   911: iload #15
    //   913: iload #12
    //   915: if_icmpge -> 945
    //   918: aload #11
    //   920: iload #10
    //   922: iinc #10, 1
    //   925: iload #14
    //   927: iastore
    //   928: iload #10
    //   930: aload #11
    //   932: arraylength
    //   933: if_icmpne -> 939
    //   936: goto -> 945
    //   939: iinc #15, 1
    //   942: goto -> 911
    //   945: goto -> 1118
    //   948: iinc #12, 1
    //   951: iload #5
    //   953: tableswitch default -> 1118, 1 -> 1015, 2 -> 1066, 3 -> 1118, 4 -> 984
    //   984: iconst_0
    //   985: istore #14
    //   987: iload #14
    //   989: iload #12
    //   991: if_icmpge -> 1012
    //   994: aload #11
    //   996: iload #10
    //   998: iinc #10, 1
    //   1001: aload_2
    //   1002: invokevirtual read : ()I
    //   1005: iastore
    //   1006: iinc #14, 1
    //   1009: goto -> 987
    //   1012: goto -> 1118
    //   1015: iconst_0
    //   1016: istore #14
    //   1018: iload #14
    //   1020: iload #12
    //   1022: if_icmpge -> 1063
    //   1025: aload #11
    //   1027: iload #10
    //   1029: iinc #10, 1
    //   1032: ldc_w -16777216
    //   1035: aload_2
    //   1036: invokevirtual read : ()I
    //   1039: ior
    //   1040: aload_2
    //   1041: invokevirtual read : ()I
    //   1044: bipush #8
    //   1046: ishl
    //   1047: ior
    //   1048: aload_2
    //   1049: invokevirtual read : ()I
    //   1052: bipush #16
    //   1054: ishl
    //   1055: ior
    //   1056: iastore
    //   1057: iinc #14, 1
    //   1060: goto -> 1018
    //   1063: goto -> 1118
    //   1066: iconst_0
    //   1067: istore #14
    //   1069: iload #14
    //   1071: iload #12
    //   1073: if_icmpge -> 1118
    //   1076: aload #11
    //   1078: iload #10
    //   1080: iinc #10, 1
    //   1083: aload_2
    //   1084: invokevirtual read : ()I
    //   1087: aload_2
    //   1088: invokevirtual read : ()I
    //   1091: bipush #8
    //   1093: ishl
    //   1094: ior
    //   1095: aload_2
    //   1096: invokevirtual read : ()I
    //   1099: bipush #16
    //   1101: ishl
    //   1102: ior
    //   1103: aload_2
    //   1104: invokevirtual read : ()I
    //   1107: bipush #24
    //   1109: ishl
    //   1110: ior
    //   1111: iastore
    //   1112: iinc #14, 1
    //   1115: goto -> 1069
    //   1118: goto -> 767
    //   1121: iload #9
    //   1123: ifne -> 1208
    //   1126: iload #6
    //   1128: newarray int
    //   1130: astore #12
    //   1132: iconst_0
    //   1133: istore #13
    //   1135: iload #13
    //   1137: iload #7
    //   1139: iconst_2
    //   1140: idiv
    //   1141: if_icmpge -> 1208
    //   1144: iload #7
    //   1146: iconst_1
    //   1147: isub
    //   1148: iload #13
    //   1150: isub
    //   1151: istore #14
    //   1153: aload #11
    //   1155: iload #13
    //   1157: iload #6
    //   1159: imul
    //   1160: aload #12
    //   1162: iconst_0
    //   1163: iload #6
    //   1165: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   1168: aload #11
    //   1170: iload #14
    //   1172: iload #6
    //   1174: imul
    //   1175: aload #11
    //   1177: iload #13
    //   1179: iload #6
    //   1181: imul
    //   1182: iload #6
    //   1184: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   1187: aload #12
    //   1189: iconst_0
    //   1190: aload #11
    //   1192: iload #14
    //   1194: iload #6
    //   1196: imul
    //   1197: iload #6
    //   1199: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   1202: iinc #13, 1
    //   1205: goto -> 1135
    //   1208: aload #8
    //   1210: areturn
  }
  
  public PShape loadShape(String paramString) {
    return loadShape(paramString, (Object)null);
  }
  
  public PShape loadShape(String paramString, Object paramObject) {
    String str2 = paramString.toLowerCase();
    int i = paramString.lastIndexOf('.');
    if (i == -1)
      String str = "unknown"; 
    String str1 = str2.substring(i + 1);
    int j = str1.indexOf('?');
    if (j != -1)
      str1 = str1.substring(0, j); 
    if (str1.equals("svg"))
      return new PShapeSVG(this, paramString); 
    if (str1.equals("svgz")) {
      try {
        GZIPInputStream gZIPInputStream = new GZIPInputStream(createInput(paramString));
        XMLElement xMLElement = new XMLElement(createReader(gZIPInputStream));
        return new PShapeSVG(xMLElement);
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
    } else {
      this.loadShapeFormats = this.g.getSupportedShapeFormats();
      if (this.loadShapeFormats != null)
        for (byte b = 0; b < this.loadShapeFormats.length; b++) {
          if (str1.equals(this.loadShapeFormats[b]))
            return this.g.loadShape(paramString, paramObject); 
        }  
    } 
    return null;
  }
  
  public PShape createShape(int paramInt, Object paramObject) {
    return this.g.createShape(paramInt, paramObject);
  }
  
  public PFont loadFont(String paramString) {
    try {
      InputStream inputStream = createInput(paramString);
      return new PFont(inputStream);
    } catch (Exception exception) {
      die("Could not load font " + paramString + ". " + "Make sure that the font has been copied " + "to the data folder of your sketch.", exception);
      return null;
    } 
  }
  
  protected PFont createDefaultFont(float paramFloat) {
    return createFont("Lucida Sans", paramFloat, true, (char[])null);
  }
  
  public PFont createFont(String paramString, float paramFloat) {
    return createFont(paramString, paramFloat, true, (char[])null);
  }
  
  public PFont createFont(String paramString, float paramFloat, boolean paramBoolean) {
    return createFont(paramString, paramFloat, paramBoolean, (char[])null);
  }
  
  public PFont createFont(String paramString, float paramFloat, boolean paramBoolean, char[] paramArrayOfchar) {
    String str = paramString.toLowerCase();
    Font font = null;
    try {
      InputStream inputStream = null;
      if (str.endsWith(".otf") || str.endsWith(".ttf")) {
        inputStream = createInput(paramString);
        if (inputStream == null) {
          System.err.println("The font \"" + paramString + "\" " + "is missing or inaccessible, make sure " + "the URL is valid or that the file has been " + "added to your sketch and is readable.");
          return null;
        } 
        font = Font.createFont(0, createInput(paramString));
      } else {
        font = PFont.findFont(paramString);
      } 
      return new PFont(font.deriveFont(paramFloat), paramBoolean, paramArrayOfchar, (inputStream != null));
    } catch (Exception exception) {
      System.err.println("Problem createFont(" + paramString + ")");
      exception.printStackTrace();
      return null;
    } 
  }
  
  protected void checkParentFrame() {
    if (this.parentFrame == null) {
      for (Container container = getParent(); container != null; container = container.getParent()) {
        if (container instanceof Frame) {
          this.parentFrame = (Frame)container;
          break;
        } 
      } 
      if (this.parentFrame == null)
        this.parentFrame = new Frame(); 
    } 
  }
  
  public String selectInput() {
    return selectInput("Select a file...");
  }
  
  public String selectInput(String paramString) {
    return selectFileImpl(paramString, 0);
  }
  
  public String selectOutput() {
    return selectOutput("Save as...");
  }
  
  public String selectOutput(String paramString) {
    return selectFileImpl(paramString, 1);
  }
  
  protected String selectFileImpl(final String prompt, final int mode) {
    checkParentFrame();
    try {
      SwingUtilities.invokeAndWait(new Runnable() {
            public void run() {
              FileDialog fileDialog = new FileDialog(PApplet.this.parentFrame, prompt, mode);
              fileDialog.setVisible(true);
              String str1 = fileDialog.getDirectory();
              String str2 = fileDialog.getFile();
              PApplet.this.selectedFile = (str2 == null) ? null : new File(str1, str2);
            }
          });
      return (this.selectedFile == null) ? null : this.selectedFile.getAbsolutePath();
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public String selectFolder() {
    return selectFolder("Select a folder...");
  }
  
  public String selectFolder(final String prompt) {
    checkParentFrame();
    try {
      SwingUtilities.invokeAndWait(new Runnable() {
            public void run() {
              if (PApplet.platform == 2) {
                FileDialog fileDialog = new FileDialog(PApplet.this.parentFrame, prompt, 0);
                System.setProperty("apple.awt.fileDialogForDirectories", "true");
                fileDialog.setVisible(true);
                System.setProperty("apple.awt.fileDialogForDirectories", "false");
                String str = fileDialog.getFile();
                PApplet.this.selectedFile = (str == null) ? null : new File(fileDialog.getDirectory(), fileDialog.getFile());
              } else {
                JFileChooser jFileChooser = new JFileChooser();
                jFileChooser.setDialogTitle(prompt);
                jFileChooser.setFileSelectionMode(1);
                int i = jFileChooser.showOpenDialog(PApplet.this.parentFrame);
                System.out.println(i);
                if (i == 1) {
                  PApplet.this.selectedFile = null;
                } else {
                  PApplet.this.selectedFile = jFileChooser.getSelectedFile();
                } 
              } 
            }
          });
      return (this.selectedFile == null) ? null : this.selectedFile.getAbsolutePath();
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public BufferedReader createReader(String paramString) {
    try {
      InputStream inputStream = createInput(paramString);
      if (inputStream == null) {
        System.err.println(paramString + " does not exist or could not be read");
        return null;
      } 
      return createReader(inputStream);
    } catch (Exception exception) {
      if (paramString == null) {
        System.err.println("Filename passed to reader() was null");
      } else {
        System.err.println("Couldn't create a reader for " + paramString);
      } 
      return null;
    } 
  }
  
  public static BufferedReader createReader(File paramFile) {
    try {
      GZIPInputStream gZIPInputStream;
      FileInputStream fileInputStream = new FileInputStream(paramFile);
      if (paramFile.getName().toLowerCase().endsWith(".gz"))
        gZIPInputStream = new GZIPInputStream(fileInputStream); 
      return createReader(gZIPInputStream);
    } catch (Exception exception) {
      if (paramFile == null)
        throw new RuntimeException("File passed to createReader() was null"); 
      exception.printStackTrace();
      throw new RuntimeException("Couldn't create a reader for " + paramFile.getAbsolutePath());
    } 
  }
  
  public static BufferedReader createReader(InputStream paramInputStream) {
    InputStreamReader inputStreamReader = null;
    try {
      inputStreamReader = new InputStreamReader(paramInputStream, "UTF-8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {}
    return new BufferedReader(inputStreamReader);
  }
  
  public PrintWriter createWriter(String paramString) {
    return createWriter(saveFile(paramString));
  }
  
  public static PrintWriter createWriter(File paramFile) {
    try {
      GZIPOutputStream gZIPOutputStream;
      createPath(paramFile);
      FileOutputStream fileOutputStream = new FileOutputStream(paramFile);
      if (paramFile.getName().toLowerCase().endsWith(".gz"))
        gZIPOutputStream = new GZIPOutputStream(fileOutputStream); 
      return createWriter(gZIPOutputStream);
    } catch (Exception exception) {
      if (paramFile == null)
        throw new RuntimeException("File passed to createWriter() was null"); 
      exception.printStackTrace();
      throw new RuntimeException("Couldn't create a writer for " + paramFile.getAbsolutePath());
    } 
  }
  
  public static PrintWriter createWriter(OutputStream paramOutputStream) {
    try {
      BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(paramOutputStream, 8192);
      OutputStreamWriter outputStreamWriter = new OutputStreamWriter(bufferedOutputStream, "UTF-8");
      return new PrintWriter(outputStreamWriter);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      return null;
    } 
  }
  
  public InputStream openStream(String paramString) {
    return createInput(paramString);
  }
  
  public InputStream createInput(String paramString) {
    InputStream inputStream = createInputRaw(paramString);
    if (inputStream != null && paramString.toLowerCase().endsWith(".gz"))
      try {
        return new GZIPInputStream(inputStream);
      } catch (IOException iOException) {
        iOException.printStackTrace();
        return null;
      }  
    return inputStream;
  }
  
  public InputStream createInputRaw(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_1
    //   3: ifnonnull -> 8
    //   6: aconst_null
    //   7: areturn
    //   8: aload_1
    //   9: invokevirtual length : ()I
    //   12: ifne -> 17
    //   15: aconst_null
    //   16: areturn
    //   17: aload_1
    //   18: ldc_w ':'
    //   21: invokevirtual indexOf : (Ljava/lang/String;)I
    //   24: iconst_m1
    //   25: if_icmpeq -> 59
    //   28: new java/net/URL
    //   31: dup
    //   32: aload_1
    //   33: invokespecial <init> : (Ljava/lang/String;)V
    //   36: astore_3
    //   37: aload_3
    //   38: invokevirtual openStream : ()Ljava/io/InputStream;
    //   41: astore_2
    //   42: aload_2
    //   43: areturn
    //   44: astore_3
    //   45: goto -> 59
    //   48: astore_3
    //   49: goto -> 59
    //   52: astore_3
    //   53: aload_3
    //   54: invokevirtual printStackTrace : ()V
    //   57: aconst_null
    //   58: areturn
    //   59: new java/io/File
    //   62: dup
    //   63: aload_0
    //   64: aload_1
    //   65: invokevirtual dataPath : (Ljava/lang/String;)Ljava/lang/String;
    //   68: invokespecial <init> : (Ljava/lang/String;)V
    //   71: astore_3
    //   72: aload_3
    //   73: invokevirtual exists : ()Z
    //   76: ifne -> 92
    //   79: new java/io/File
    //   82: dup
    //   83: aload_0
    //   84: getfield sketchPath : Ljava/lang/String;
    //   87: aload_1
    //   88: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   91: astore_3
    //   92: aload_3
    //   93: invokevirtual isDirectory : ()Z
    //   96: ifeq -> 101
    //   99: aconst_null
    //   100: areturn
    //   101: aload_3
    //   102: invokevirtual exists : ()Z
    //   105: ifeq -> 207
    //   108: aload_3
    //   109: invokevirtual getCanonicalPath : ()Ljava/lang/String;
    //   112: astore #4
    //   114: new java/io/File
    //   117: dup
    //   118: aload #4
    //   120: invokespecial <init> : (Ljava/lang/String;)V
    //   123: invokevirtual getName : ()Ljava/lang/String;
    //   126: astore #5
    //   128: new java/io/File
    //   131: dup
    //   132: aload_1
    //   133: invokespecial <init> : (Ljava/lang/String;)V
    //   136: invokevirtual getName : ()Ljava/lang/String;
    //   139: astore #6
    //   141: aload #5
    //   143: aload #6
    //   145: invokevirtual equals : (Ljava/lang/Object;)Z
    //   148: ifne -> 202
    //   151: new java/lang/RuntimeException
    //   154: dup
    //   155: new java/lang/StringBuilder
    //   158: dup
    //   159: invokespecial <init> : ()V
    //   162: ldc_w 'This file is named '
    //   165: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   168: aload #5
    //   170: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   173: ldc_w ' not '
    //   176: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   179: aload_1
    //   180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: ldc_w '. Rename the file '
    //   186: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   189: ldc_w 'or change your code.'
    //   192: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   195: invokevirtual toString : ()Ljava/lang/String;
    //   198: invokespecial <init> : (Ljava/lang/String;)V
    //   201: athrow
    //   202: goto -> 207
    //   205: astore #4
    //   207: new java/io/FileInputStream
    //   210: dup
    //   211: aload_3
    //   212: invokespecial <init> : (Ljava/io/File;)V
    //   215: astore_2
    //   216: aload_2
    //   217: ifnull -> 222
    //   220: aload_2
    //   221: areturn
    //   222: goto -> 230
    //   225: astore_3
    //   226: goto -> 230
    //   229: astore_3
    //   230: aload_0
    //   231: invokevirtual getClass : ()Ljava/lang/Class;
    //   234: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   237: astore_3
    //   238: aload_3
    //   239: new java/lang/StringBuilder
    //   242: dup
    //   243: invokespecial <init> : ()V
    //   246: ldc_w 'data/'
    //   249: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   252: aload_1
    //   253: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   256: invokevirtual toString : ()Ljava/lang/String;
    //   259: invokevirtual getResourceAsStream : (Ljava/lang/String;)Ljava/io/InputStream;
    //   262: astore_2
    //   263: aload_2
    //   264: ifnull -> 289
    //   267: aload_2
    //   268: invokevirtual getClass : ()Ljava/lang/Class;
    //   271: invokevirtual getName : ()Ljava/lang/String;
    //   274: astore #4
    //   276: aload #4
    //   278: ldc_w 'sun.plugin.cache.EmptyInputStream'
    //   281: invokevirtual equals : (Ljava/lang/Object;)Z
    //   284: ifne -> 289
    //   287: aload_2
    //   288: areturn
    //   289: aload_3
    //   290: aload_1
    //   291: invokevirtual getResourceAsStream : (Ljava/lang/String;)Ljava/io/InputStream;
    //   294: astore_2
    //   295: aload_2
    //   296: ifnull -> 321
    //   299: aload_2
    //   300: invokevirtual getClass : ()Ljava/lang/Class;
    //   303: invokevirtual getName : ()Ljava/lang/String;
    //   306: astore #4
    //   308: aload #4
    //   310: ldc_w 'sun.plugin.cache.EmptyInputStream'
    //   313: invokevirtual equals : (Ljava/lang/Object;)Z
    //   316: ifne -> 321
    //   319: aload_2
    //   320: areturn
    //   321: aload_0
    //   322: invokevirtual getDocumentBase : ()Ljava/net/URL;
    //   325: astore #4
    //   327: aload #4
    //   329: ifnull -> 357
    //   332: new java/net/URL
    //   335: dup
    //   336: aload #4
    //   338: aload_1
    //   339: invokespecial <init> : (Ljava/net/URL;Ljava/lang/String;)V
    //   342: astore #5
    //   344: aload #5
    //   346: invokevirtual openConnection : ()Ljava/net/URLConnection;
    //   349: astore #6
    //   351: aload #6
    //   353: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   356: areturn
    //   357: goto -> 362
    //   360: astore #4
    //   362: aload_0
    //   363: invokevirtual getDocumentBase : ()Ljava/net/URL;
    //   366: astore #4
    //   368: aload #4
    //   370: ifnull -> 417
    //   373: new java/net/URL
    //   376: dup
    //   377: aload #4
    //   379: new java/lang/StringBuilder
    //   382: dup
    //   383: invokespecial <init> : ()V
    //   386: ldc_w 'data/'
    //   389: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   392: aload_1
    //   393: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   396: invokevirtual toString : ()Ljava/lang/String;
    //   399: invokespecial <init> : (Ljava/net/URL;Ljava/lang/String;)V
    //   402: astore #5
    //   404: aload #5
    //   406: invokevirtual openConnection : ()Ljava/net/URLConnection;
    //   409: astore #6
    //   411: aload #6
    //   413: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   416: areturn
    //   417: goto -> 422
    //   420: astore #4
    //   422: new java/io/FileInputStream
    //   425: dup
    //   426: aload_0
    //   427: aload_1
    //   428: invokevirtual dataPath : (Ljava/lang/String;)Ljava/lang/String;
    //   431: invokespecial <init> : (Ljava/lang/String;)V
    //   434: astore_2
    //   435: aload_2
    //   436: ifnull -> 441
    //   439: aload_2
    //   440: areturn
    //   441: goto -> 446
    //   444: astore #4
    //   446: new java/io/FileInputStream
    //   449: dup
    //   450: aload_0
    //   451: aload_1
    //   452: invokevirtual sketchPath : (Ljava/lang/String;)Ljava/lang/String;
    //   455: invokespecial <init> : (Ljava/lang/String;)V
    //   458: astore_2
    //   459: aload_2
    //   460: ifnull -> 465
    //   463: aload_2
    //   464: areturn
    //   465: goto -> 470
    //   468: astore #4
    //   470: new java/io/FileInputStream
    //   473: dup
    //   474: aload_1
    //   475: invokespecial <init> : (Ljava/lang/String;)V
    //   478: astore_2
    //   479: aload_2
    //   480: ifnull -> 485
    //   483: aload_2
    //   484: areturn
    //   485: goto -> 490
    //   488: astore #4
    //   490: goto -> 495
    //   493: astore #4
    //   495: goto -> 505
    //   498: astore #4
    //   500: aload #4
    //   502: invokevirtual printStackTrace : ()V
    //   505: aconst_null
    //   506: areturn
    // Exception table:
    //   from	to	target	type
    //   28	43	44	java/net/MalformedURLException
    //   28	43	48	java/io/FileNotFoundException
    //   28	43	52	java/io/IOException
    //   59	100	225	java/io/IOException
    //   59	100	229	java/lang/SecurityException
    //   101	221	225	java/io/IOException
    //   101	221	229	java/lang/SecurityException
    //   108	202	205	java/io/IOException
    //   321	356	360	java/lang/Exception
    //   362	416	420	java/lang/Exception
    //   422	440	444	java/io/IOException
    //   422	440	493	java/lang/SecurityException
    //   422	440	498	java/lang/Exception
    //   441	464	493	java/lang/SecurityException
    //   441	464	498	java/lang/Exception
    //   446	464	468	java/lang/Exception
    //   465	484	493	java/lang/SecurityException
    //   465	484	498	java/lang/Exception
    //   470	484	488	java/io/IOException
    //   485	490	493	java/lang/SecurityException
    //   485	495	498	java/lang/Exception
  }
  
  public static InputStream createInput(File paramFile) {
    if (paramFile == null)
      throw new IllegalArgumentException("File passed to createInput() was null"); 
    try {
      FileInputStream fileInputStream = new FileInputStream(paramFile);
      return (InputStream)(paramFile.getName().toLowerCase().endsWith(".gz") ? new GZIPInputStream(fileInputStream) : fileInputStream);
    } catch (IOException iOException) {
      System.err.println("Could not createInput() for " + paramFile);
      iOException.printStackTrace();
      return null;
    } 
  }
  
  public byte[] loadBytes(String paramString) {
    InputStream inputStream = createInput(paramString);
    if (inputStream != null)
      return loadBytes(inputStream); 
    System.err.println("The file \"" + paramString + "\" " + "is missing or inaccessible, make sure " + "the URL is valid or that the file has been " + "added to your sketch and is readable.");
    return null;
  }
  
  public static byte[] loadBytes(InputStream paramInputStream) {
    try {
      BufferedInputStream bufferedInputStream = new BufferedInputStream(paramInputStream);
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      for (int i = bufferedInputStream.read(); i != -1; i = bufferedInputStream.read())
        byteArrayOutputStream.write(i); 
      return byteArrayOutputStream.toByteArray();
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return null;
    } 
  }
  
  public static byte[] loadBytes(File paramFile) {
    InputStream inputStream = createInput(paramFile);
    return loadBytes(inputStream);
  }
  
  public static String[] loadStrings(File paramFile) {
    InputStream inputStream = createInput(paramFile);
    return (inputStream != null) ? loadStrings(inputStream) : null;
  }
  
  public String[] loadStrings(String paramString) {
    InputStream inputStream = createInput(paramString);
    if (inputStream != null)
      return loadStrings(inputStream); 
    System.err.println("The file \"" + paramString + "\" " + "is missing or inaccessible, make sure " + "the URL is valid or that the file has been " + "added to your sketch and is readable.");
    return null;
  }
  
  public static String[] loadStrings(InputStream paramInputStream) {
    try {
      BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream, "UTF-8"));
      String[] arrayOfString1 = new String[100];
      byte b = 0;
      String str = null;
      while ((str = bufferedReader.readLine()) != null) {
        if (b == arrayOfString1.length) {
          String[] arrayOfString = new String[b << 1];
          System.arraycopy(arrayOfString1, 0, arrayOfString, 0, b);
          arrayOfString1 = arrayOfString;
        } 
        arrayOfString1[b++] = str;
      } 
      bufferedReader.close();
      if (b == arrayOfString1.length)
        return arrayOfString1; 
      String[] arrayOfString2 = new String[b];
      System.arraycopy(arrayOfString1, 0, arrayOfString2, 0, b);
      return arrayOfString2;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return null;
    } 
  }
  
  public OutputStream createOutput(String paramString) {
    return createOutput(saveFile(paramString));
  }
  
  public static OutputStream createOutput(File paramFile) {
    try {
      createPath(paramFile);
      FileOutputStream fileOutputStream = new FileOutputStream(paramFile);
      return (OutputStream)(paramFile.getName().toLowerCase().endsWith(".gz") ? new GZIPOutputStream(fileOutputStream) : fileOutputStream);
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return null;
    } 
  }
  
  public boolean saveStream(String paramString1, String paramString2) {
    return saveStream(saveFile(paramString1), paramString2);
  }
  
  public boolean saveStream(File paramFile, String paramString) {
    return saveStream(paramFile, createInputRaw(paramString));
  }
  
  public boolean saveStream(String paramString, InputStream paramInputStream) {
    return saveStream(saveFile(paramString), paramInputStream);
  }
  
  public static boolean saveStream(File paramFile, InputStream paramInputStream) {
    File file = null;
    try {
      File file1 = paramFile.getParentFile();
      createPath(paramFile);
      file = File.createTempFile(paramFile.getName(), null, file1);
      BufferedInputStream bufferedInputStream = new BufferedInputStream(paramInputStream, 16384);
      FileOutputStream fileOutputStream = new FileOutputStream(file);
      BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
      byte[] arrayOfByte = new byte[8192];
      int i;
      while ((i = bufferedInputStream.read(arrayOfByte)) != -1)
        bufferedOutputStream.write(arrayOfByte, 0, i); 
      bufferedOutputStream.flush();
      bufferedOutputStream.close();
      bufferedOutputStream = null;
      if (!file.renameTo(paramFile)) {
        System.err.println("Could not rename temporary file " + file.getAbsolutePath());
        return false;
      } 
      return true;
    } catch (IOException iOException) {
      if (file != null)
        file.delete(); 
      iOException.printStackTrace();
      return false;
    } 
  }
  
  public void saveBytes(String paramString, byte[] paramArrayOfbyte) {
    saveBytes(saveFile(paramString), paramArrayOfbyte);
  }
  
  public static void saveBytes(File paramFile, byte[] paramArrayOfbyte) {
    File file = null;
    try {
      File file1 = paramFile.getParentFile();
      file = File.createTempFile(paramFile.getName(), null, file1);
      OutputStream outputStream = createOutput(file);
      saveBytes(outputStream, paramArrayOfbyte);
      outputStream.close();
      outputStream = null;
      if (!file.renameTo(paramFile))
        System.err.println("Could not rename temporary file " + file.getAbsolutePath()); 
    } catch (IOException iOException) {
      System.err.println("error saving bytes to " + paramFile);
      if (file != null)
        file.delete(); 
      iOException.printStackTrace();
    } 
  }
  
  public static void saveBytes(OutputStream paramOutputStream, byte[] paramArrayOfbyte) {
    try {
      paramOutputStream.write(paramArrayOfbyte);
      paramOutputStream.flush();
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
  }
  
  public void saveStrings(String paramString, String[] paramArrayOfString) {
    saveStrings(saveFile(paramString), paramArrayOfString);
  }
  
  public static void saveStrings(File paramFile, String[] paramArrayOfString) {
    saveStrings(createOutput(paramFile), paramArrayOfString);
  }
  
  public static void saveStrings(OutputStream paramOutputStream, String[] paramArrayOfString) {
    PrintWriter printWriter = createWriter(paramOutputStream);
    for (byte b = 0; b < paramArrayOfString.length; b++)
      printWriter.println(paramArrayOfString[b]); 
    printWriter.flush();
    printWriter.close();
  }
  
  public String sketchPath(String paramString) {
    if (this.sketchPath == null)
      return paramString; 
    try {
      if ((new File(paramString)).isAbsolute())
        return paramString; 
    } catch (Exception exception) {}
    return this.sketchPath + File.separator + paramString;
  }
  
  public File sketchFile(String paramString) {
    return new File(sketchPath(paramString));
  }
  
  public String savePath(String paramString) {
    if (paramString == null)
      return null; 
    String str = sketchPath(paramString);
    createPath(str);
    return str;
  }
  
  public File saveFile(String paramString) {
    return new File(savePath(paramString));
  }
  
  public String dataPath(String paramString) {
    return (new File(paramString)).isAbsolute() ? paramString : (this.sketchPath + File.separator + "data" + File.separator + paramString);
  }
  
  public File dataFile(String paramString) {
    return new File(dataPath(paramString));
  }
  
  public static void createPath(String paramString) {
    createPath(new File(paramString));
  }
  
  public static void createPath(File paramFile) {
    try {
      String str = paramFile.getParent();
      if (str != null) {
        File file = new File(str);
        if (!file.exists())
          file.mkdirs(); 
      } 
    } catch (SecurityException securityException) {
      System.err.println("You don't have permissions to create " + paramFile.getAbsolutePath());
    } 
  }
  
  public static byte[] sort(byte[] paramArrayOfbyte) {
    return sort(paramArrayOfbyte, paramArrayOfbyte.length);
  }
  
  public static byte[] sort(byte[] paramArrayOfbyte, int paramInt) {
    byte[] arrayOfByte = new byte[paramArrayOfbyte.length];
    System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, paramArrayOfbyte.length);
    Arrays.sort(arrayOfByte, 0, paramInt);
    return arrayOfByte;
  }
  
  public static char[] sort(char[] paramArrayOfchar) {
    return sort(paramArrayOfchar, paramArrayOfchar.length);
  }
  
  public static char[] sort(char[] paramArrayOfchar, int paramInt) {
    char[] arrayOfChar = new char[paramArrayOfchar.length];
    System.arraycopy(paramArrayOfchar, 0, arrayOfChar, 0, paramArrayOfchar.length);
    Arrays.sort(arrayOfChar, 0, paramInt);
    return arrayOfChar;
  }
  
  public static int[] sort(int[] paramArrayOfint) {
    return sort(paramArrayOfint, paramArrayOfint.length);
  }
  
  public static int[] sort(int[] paramArrayOfint, int paramInt) {
    int[] arrayOfInt = new int[paramArrayOfint.length];
    System.arraycopy(paramArrayOfint, 0, arrayOfInt, 0, paramArrayOfint.length);
    Arrays.sort(arrayOfInt, 0, paramInt);
    return arrayOfInt;
  }
  
  public static float[] sort(float[] paramArrayOffloat) {
    return sort(paramArrayOffloat, paramArrayOffloat.length);
  }
  
  public static float[] sort(float[] paramArrayOffloat, int paramInt) {
    float[] arrayOfFloat = new float[paramArrayOffloat.length];
    System.arraycopy(paramArrayOffloat, 0, arrayOfFloat, 0, paramArrayOffloat.length);
    Arrays.sort(arrayOfFloat, 0, paramInt);
    return arrayOfFloat;
  }
  
  public static String[] sort(String[] paramArrayOfString) {
    return sort(paramArrayOfString, paramArrayOfString.length);
  }
  
  public static String[] sort(String[] paramArrayOfString, int paramInt) {
    String[] arrayOfString = new String[paramArrayOfString.length];
    System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramArrayOfString.length);
    Arrays.sort((Object[])arrayOfString, 0, paramInt);
    return arrayOfString;
  }
  
  public static void arrayCopy(Object paramObject1, int paramInt1, Object paramObject2, int paramInt2, int paramInt3) {
    System.arraycopy(paramObject1, paramInt1, paramObject2, paramInt2, paramInt3);
  }
  
  public static void arrayCopy(Object paramObject1, Object paramObject2, int paramInt) {
    System.arraycopy(paramObject1, 0, paramObject2, 0, paramInt);
  }
  
  public static void arrayCopy(Object paramObject1, Object paramObject2) {
    System.arraycopy(paramObject1, 0, paramObject2, 0, Array.getLength(paramObject1));
  }
  
  public static void arraycopy(Object paramObject1, int paramInt1, Object paramObject2, int paramInt2, int paramInt3) {
    System.arraycopy(paramObject1, paramInt1, paramObject2, paramInt2, paramInt3);
  }
  
  public static void arraycopy(Object paramObject1, Object paramObject2, int paramInt) {
    System.arraycopy(paramObject1, 0, paramObject2, 0, paramInt);
  }
  
  public static void arraycopy(Object paramObject1, Object paramObject2) {
    System.arraycopy(paramObject1, 0, paramObject2, 0, Array.getLength(paramObject1));
  }
  
  public static boolean[] expand(boolean[] paramArrayOfboolean) {
    return expand(paramArrayOfboolean, paramArrayOfboolean.length << 1);
  }
  
  public static boolean[] expand(boolean[] paramArrayOfboolean, int paramInt) {
    boolean[] arrayOfBoolean = new boolean[paramInt];
    System.arraycopy(paramArrayOfboolean, 0, arrayOfBoolean, 0, Math.min(paramInt, paramArrayOfboolean.length));
    return arrayOfBoolean;
  }
  
  public static byte[] expand(byte[] paramArrayOfbyte) {
    return expand(paramArrayOfbyte, paramArrayOfbyte.length << 1);
  }
  
  public static byte[] expand(byte[] paramArrayOfbyte, int paramInt) {
    byte[] arrayOfByte = new byte[paramInt];
    System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, Math.min(paramInt, paramArrayOfbyte.length));
    return arrayOfByte;
  }
  
  public static char[] expand(char[] paramArrayOfchar) {
    return expand(paramArrayOfchar, paramArrayOfchar.length << 1);
  }
  
  public static char[] expand(char[] paramArrayOfchar, int paramInt) {
    char[] arrayOfChar = new char[paramInt];
    System.arraycopy(paramArrayOfchar, 0, arrayOfChar, 0, Math.min(paramInt, paramArrayOfchar.length));
    return arrayOfChar;
  }
  
  public static int[] expand(int[] paramArrayOfint) {
    return expand(paramArrayOfint, paramArrayOfint.length << 1);
  }
  
  public static int[] expand(int[] paramArrayOfint, int paramInt) {
    int[] arrayOfInt = new int[paramInt];
    System.arraycopy(paramArrayOfint, 0, arrayOfInt, 0, Math.min(paramInt, paramArrayOfint.length));
    return arrayOfInt;
  }
  
  public static float[] expand(float[] paramArrayOffloat) {
    return expand(paramArrayOffloat, paramArrayOffloat.length << 1);
  }
  
  public static float[] expand(float[] paramArrayOffloat, int paramInt) {
    float[] arrayOfFloat = new float[paramInt];
    System.arraycopy(paramArrayOffloat, 0, arrayOfFloat, 0, Math.min(paramInt, paramArrayOffloat.length));
    return arrayOfFloat;
  }
  
  public static String[] expand(String[] paramArrayOfString) {
    return expand(paramArrayOfString, paramArrayOfString.length << 1);
  }
  
  public static String[] expand(String[] paramArrayOfString, int paramInt) {
    String[] arrayOfString = new String[paramInt];
    System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, Math.min(paramInt, paramArrayOfString.length));
    return arrayOfString;
  }
  
  public static Object expand(Object paramObject) {
    return expand(paramObject, Array.getLength(paramObject) << 1);
  }
  
  public static Object expand(Object paramObject, int paramInt) {
    Class<?> clazz = paramObject.getClass().getComponentType();
    Object object = Array.newInstance(clazz, paramInt);
    System.arraycopy(paramObject, 0, object, 0, Math.min(Array.getLength(paramObject), paramInt));
    return object;
  }
  
  public static byte[] append(byte[] paramArrayOfbyte, byte paramByte) {
    paramArrayOfbyte = expand(paramArrayOfbyte, paramArrayOfbyte.length + 1);
    paramArrayOfbyte[paramArrayOfbyte.length - 1] = paramByte;
    return paramArrayOfbyte;
  }
  
  public static char[] append(char[] paramArrayOfchar, char paramChar) {
    paramArrayOfchar = expand(paramArrayOfchar, paramArrayOfchar.length + 1);
    paramArrayOfchar[paramArrayOfchar.length - 1] = paramChar;
    return paramArrayOfchar;
  }
  
  public static int[] append(int[] paramArrayOfint, int paramInt) {
    paramArrayOfint = expand(paramArrayOfint, paramArrayOfint.length + 1);
    paramArrayOfint[paramArrayOfint.length - 1] = paramInt;
    return paramArrayOfint;
  }
  
  public static float[] append(float[] paramArrayOffloat, float paramFloat) {
    paramArrayOffloat = expand(paramArrayOffloat, paramArrayOffloat.length + 1);
    paramArrayOffloat[paramArrayOffloat.length - 1] = paramFloat;
    return paramArrayOffloat;
  }
  
  public static String[] append(String[] paramArrayOfString, String paramString) {
    paramArrayOfString = expand(paramArrayOfString, paramArrayOfString.length + 1);
    paramArrayOfString[paramArrayOfString.length - 1] = paramString;
    return paramArrayOfString;
  }
  
  public static Object append(Object paramObject1, Object paramObject2) {
    int i = Array.getLength(paramObject1);
    paramObject1 = expand(paramObject1, i + 1);
    Array.set(paramObject1, i, paramObject2);
    return paramObject1;
  }
  
  public static boolean[] shorten(boolean[] paramArrayOfboolean) {
    return subset(paramArrayOfboolean, 0, paramArrayOfboolean.length - 1);
  }
  
  public static byte[] shorten(byte[] paramArrayOfbyte) {
    return subset(paramArrayOfbyte, 0, paramArrayOfbyte.length - 1);
  }
  
  public static char[] shorten(char[] paramArrayOfchar) {
    return subset(paramArrayOfchar, 0, paramArrayOfchar.length - 1);
  }
  
  public static int[] shorten(int[] paramArrayOfint) {
    return subset(paramArrayOfint, 0, paramArrayOfint.length - 1);
  }
  
  public static float[] shorten(float[] paramArrayOffloat) {
    return subset(paramArrayOffloat, 0, paramArrayOffloat.length - 1);
  }
  
  public static String[] shorten(String[] paramArrayOfString) {
    return subset(paramArrayOfString, 0, paramArrayOfString.length - 1);
  }
  
  public static Object shorten(Object paramObject) {
    int i = Array.getLength(paramObject);
    return subset(paramObject, 0, i - 1);
  }
  
  public static final boolean[] splice(boolean[] paramArrayOfboolean, boolean paramBoolean, int paramInt) {
    boolean[] arrayOfBoolean = new boolean[paramArrayOfboolean.length + 1];
    System.arraycopy(paramArrayOfboolean, 0, arrayOfBoolean, 0, paramInt);
    arrayOfBoolean[paramInt] = paramBoolean;
    System.arraycopy(paramArrayOfboolean, paramInt, arrayOfBoolean, paramInt + 1, paramArrayOfboolean.length - paramInt);
    return arrayOfBoolean;
  }
  
  public static final boolean[] splice(boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2, int paramInt) {
    boolean[] arrayOfBoolean = new boolean[paramArrayOfboolean1.length + paramArrayOfboolean2.length];
    System.arraycopy(paramArrayOfboolean1, 0, arrayOfBoolean, 0, paramInt);
    System.arraycopy(paramArrayOfboolean2, 0, arrayOfBoolean, paramInt, paramArrayOfboolean2.length);
    System.arraycopy(paramArrayOfboolean1, paramInt, arrayOfBoolean, paramInt + paramArrayOfboolean2.length, paramArrayOfboolean1.length - paramInt);
    return arrayOfBoolean;
  }
  
  public static final byte[] splice(byte[] paramArrayOfbyte, byte paramByte, int paramInt) {
    byte[] arrayOfByte = new byte[paramArrayOfbyte.length + 1];
    System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, paramInt);
    arrayOfByte[paramInt] = paramByte;
    System.arraycopy(paramArrayOfbyte, paramInt, arrayOfByte, paramInt + 1, paramArrayOfbyte.length - paramInt);
    return arrayOfByte;
  }
  
  public static final byte[] splice(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt) {
    byte[] arrayOfByte = new byte[paramArrayOfbyte1.length + paramArrayOfbyte2.length];
    System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte, 0, paramInt);
    System.arraycopy(paramArrayOfbyte2, 0, arrayOfByte, paramInt, paramArrayOfbyte2.length);
    System.arraycopy(paramArrayOfbyte1, paramInt, arrayOfByte, paramInt + paramArrayOfbyte2.length, paramArrayOfbyte1.length - paramInt);
    return arrayOfByte;
  }
  
  public static final char[] splice(char[] paramArrayOfchar, char paramChar, int paramInt) {
    char[] arrayOfChar = new char[paramArrayOfchar.length + 1];
    System.arraycopy(paramArrayOfchar, 0, arrayOfChar, 0, paramInt);
    arrayOfChar[paramInt] = paramChar;
    System.arraycopy(paramArrayOfchar, paramInt, arrayOfChar, paramInt + 1, paramArrayOfchar.length - paramInt);
    return arrayOfChar;
  }
  
  public static final char[] splice(char[] paramArrayOfchar1, char[] paramArrayOfchar2, int paramInt) {
    char[] arrayOfChar = new char[paramArrayOfchar1.length + paramArrayOfchar2.length];
    System.arraycopy(paramArrayOfchar1, 0, arrayOfChar, 0, paramInt);
    System.arraycopy(paramArrayOfchar2, 0, arrayOfChar, paramInt, paramArrayOfchar2.length);
    System.arraycopy(paramArrayOfchar1, paramInt, arrayOfChar, paramInt + paramArrayOfchar2.length, paramArrayOfchar1.length - paramInt);
    return arrayOfChar;
  }
  
  public static final int[] splice(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    int[] arrayOfInt = new int[paramArrayOfint.length + 1];
    System.arraycopy(paramArrayOfint, 0, arrayOfInt, 0, paramInt2);
    arrayOfInt[paramInt2] = paramInt1;
    System.arraycopy(paramArrayOfint, paramInt2, arrayOfInt, paramInt2 + 1, paramArrayOfint.length - paramInt2);
    return arrayOfInt;
  }
  
  public static final int[] splice(int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt) {
    int[] arrayOfInt = new int[paramArrayOfint1.length + paramArrayOfint2.length];
    System.arraycopy(paramArrayOfint1, 0, arrayOfInt, 0, paramInt);
    System.arraycopy(paramArrayOfint2, 0, arrayOfInt, paramInt, paramArrayOfint2.length);
    System.arraycopy(paramArrayOfint1, paramInt, arrayOfInt, paramInt + paramArrayOfint2.length, paramArrayOfint1.length - paramInt);
    return arrayOfInt;
  }
  
  public static final float[] splice(float[] paramArrayOffloat, float paramFloat, int paramInt) {
    float[] arrayOfFloat = new float[paramArrayOffloat.length + 1];
    System.arraycopy(paramArrayOffloat, 0, arrayOfFloat, 0, paramInt);
    arrayOfFloat[paramInt] = paramFloat;
    System.arraycopy(paramArrayOffloat, paramInt, arrayOfFloat, paramInt + 1, paramArrayOffloat.length - paramInt);
    return arrayOfFloat;
  }
  
  public static final float[] splice(float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt) {
    float[] arrayOfFloat = new float[paramArrayOffloat1.length + paramArrayOffloat2.length];
    System.arraycopy(paramArrayOffloat1, 0, arrayOfFloat, 0, paramInt);
    System.arraycopy(paramArrayOffloat2, 0, arrayOfFloat, paramInt, paramArrayOffloat2.length);
    System.arraycopy(paramArrayOffloat1, paramInt, arrayOfFloat, paramInt + paramArrayOffloat2.length, paramArrayOffloat1.length - paramInt);
    return arrayOfFloat;
  }
  
  public static final String[] splice(String[] paramArrayOfString, String paramString, int paramInt) {
    String[] arrayOfString = new String[paramArrayOfString.length + 1];
    System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramInt);
    arrayOfString[paramInt] = paramString;
    System.arraycopy(paramArrayOfString, paramInt, arrayOfString, paramInt + 1, paramArrayOfString.length - paramInt);
    return arrayOfString;
  }
  
  public static final String[] splice(String[] paramArrayOfString1, String[] paramArrayOfString2, int paramInt) {
    String[] arrayOfString = new String[paramArrayOfString1.length + paramArrayOfString2.length];
    System.arraycopy(paramArrayOfString1, 0, arrayOfString, 0, paramInt);
    System.arraycopy(paramArrayOfString2, 0, arrayOfString, paramInt, paramArrayOfString2.length);
    System.arraycopy(paramArrayOfString1, paramInt, arrayOfString, paramInt + paramArrayOfString2.length, paramArrayOfString1.length - paramInt);
    return arrayOfString;
  }
  
  public static final Object splice(Object paramObject1, Object paramObject2, int paramInt) {
    Object[] arrayOfObject = null;
    int i = Array.getLength(paramObject1);
    if (paramObject2.getClass().getName().charAt(0) == '[') {
      int j = Array.getLength(paramObject2);
      arrayOfObject = new Object[i + j];
      System.arraycopy(paramObject1, 0, arrayOfObject, 0, paramInt);
      System.arraycopy(paramObject2, 0, arrayOfObject, paramInt, j);
      System.arraycopy(paramObject1, paramInt, arrayOfObject, paramInt + j, i - paramInt);
    } else {
      arrayOfObject = new Object[i + 1];
      System.arraycopy(paramObject1, 0, arrayOfObject, 0, paramInt);
      Array.set(arrayOfObject, paramInt, paramObject2);
      System.arraycopy(paramObject1, paramInt, arrayOfObject, paramInt + 1, i - paramInt);
    } 
    return arrayOfObject;
  }
  
  public static boolean[] subset(boolean[] paramArrayOfboolean, int paramInt) {
    return subset(paramArrayOfboolean, paramInt, paramArrayOfboolean.length - paramInt);
  }
  
  public static boolean[] subset(boolean[] paramArrayOfboolean, int paramInt1, int paramInt2) {
    boolean[] arrayOfBoolean = new boolean[paramInt2];
    System.arraycopy(paramArrayOfboolean, paramInt1, arrayOfBoolean, 0, paramInt2);
    return arrayOfBoolean;
  }
  
  public static byte[] subset(byte[] paramArrayOfbyte, int paramInt) {
    return subset(paramArrayOfbyte, paramInt, paramArrayOfbyte.length - paramInt);
  }
  
  public static byte[] subset(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    byte[] arrayOfByte = new byte[paramInt2];
    System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
    return arrayOfByte;
  }
  
  public static char[] subset(char[] paramArrayOfchar, int paramInt) {
    return subset(paramArrayOfchar, paramInt, paramArrayOfchar.length - paramInt);
  }
  
  public static char[] subset(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    char[] arrayOfChar = new char[paramInt2];
    System.arraycopy(paramArrayOfchar, paramInt1, arrayOfChar, 0, paramInt2);
    return arrayOfChar;
  }
  
  public static int[] subset(int[] paramArrayOfint, int paramInt) {
    return subset(paramArrayOfint, paramInt, paramArrayOfint.length - paramInt);
  }
  
  public static int[] subset(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    int[] arrayOfInt = new int[paramInt2];
    System.arraycopy(paramArrayOfint, paramInt1, arrayOfInt, 0, paramInt2);
    return arrayOfInt;
  }
  
  public static float[] subset(float[] paramArrayOffloat, int paramInt) {
    return subset(paramArrayOffloat, paramInt, paramArrayOffloat.length - paramInt);
  }
  
  public static float[] subset(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    float[] arrayOfFloat = new float[paramInt2];
    System.arraycopy(paramArrayOffloat, paramInt1, arrayOfFloat, 0, paramInt2);
    return arrayOfFloat;
  }
  
  public static String[] subset(String[] paramArrayOfString, int paramInt) {
    return subset(paramArrayOfString, paramInt, paramArrayOfString.length - paramInt);
  }
  
  public static String[] subset(String[] paramArrayOfString, int paramInt1, int paramInt2) {
    String[] arrayOfString = new String[paramInt2];
    System.arraycopy(paramArrayOfString, paramInt1, arrayOfString, 0, paramInt2);
    return arrayOfString;
  }
  
  public static Object subset(Object paramObject, int paramInt) {
    int i = Array.getLength(paramObject);
    return subset(paramObject, paramInt, i - paramInt);
  }
  
  public static Object subset(Object paramObject, int paramInt1, int paramInt2) {
    Class<?> clazz = paramObject.getClass().getComponentType();
    Object object = Array.newInstance(clazz, paramInt2);
    System.arraycopy(paramObject, paramInt1, object, 0, paramInt2);
    return object;
  }
  
  public static boolean[] concat(boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2) {
    boolean[] arrayOfBoolean = new boolean[paramArrayOfboolean1.length + paramArrayOfboolean2.length];
    System.arraycopy(paramArrayOfboolean1, 0, arrayOfBoolean, 0, paramArrayOfboolean1.length);
    System.arraycopy(paramArrayOfboolean2, 0, arrayOfBoolean, paramArrayOfboolean1.length, paramArrayOfboolean2.length);
    return arrayOfBoolean;
  }
  
  public static byte[] concat(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    byte[] arrayOfByte = new byte[paramArrayOfbyte1.length + paramArrayOfbyte2.length];
    System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte, 0, paramArrayOfbyte1.length);
    System.arraycopy(paramArrayOfbyte2, 0, arrayOfByte, paramArrayOfbyte1.length, paramArrayOfbyte2.length);
    return arrayOfByte;
  }
  
  public static char[] concat(char[] paramArrayOfchar1, char[] paramArrayOfchar2) {
    char[] arrayOfChar = new char[paramArrayOfchar1.length + paramArrayOfchar2.length];
    System.arraycopy(paramArrayOfchar1, 0, arrayOfChar, 0, paramArrayOfchar1.length);
    System.arraycopy(paramArrayOfchar2, 0, arrayOfChar, paramArrayOfchar1.length, paramArrayOfchar2.length);
    return arrayOfChar;
  }
  
  public static int[] concat(int[] paramArrayOfint1, int[] paramArrayOfint2) {
    int[] arrayOfInt = new int[paramArrayOfint1.length + paramArrayOfint2.length];
    System.arraycopy(paramArrayOfint1, 0, arrayOfInt, 0, paramArrayOfint1.length);
    System.arraycopy(paramArrayOfint2, 0, arrayOfInt, paramArrayOfint1.length, paramArrayOfint2.length);
    return arrayOfInt;
  }
  
  public static float[] concat(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
    float[] arrayOfFloat = new float[paramArrayOffloat1.length + paramArrayOffloat2.length];
    System.arraycopy(paramArrayOffloat1, 0, arrayOfFloat, 0, paramArrayOffloat1.length);
    System.arraycopy(paramArrayOffloat2, 0, arrayOfFloat, paramArrayOffloat1.length, paramArrayOffloat2.length);
    return arrayOfFloat;
  }
  
  public static String[] concat(String[] paramArrayOfString1, String[] paramArrayOfString2) {
    String[] arrayOfString = new String[paramArrayOfString1.length + paramArrayOfString2.length];
    System.arraycopy(paramArrayOfString1, 0, arrayOfString, 0, paramArrayOfString1.length);
    System.arraycopy(paramArrayOfString2, 0, arrayOfString, paramArrayOfString1.length, paramArrayOfString2.length);
    return arrayOfString;
  }
  
  public static Object concat(Object paramObject1, Object paramObject2) {
    Class<?> clazz = paramObject1.getClass().getComponentType();
    int i = Array.getLength(paramObject1);
    int j = Array.getLength(paramObject2);
    Object object = Array.newInstance(clazz, i + j);
    System.arraycopy(paramObject1, 0, object, 0, i);
    System.arraycopy(paramObject2, 0, object, i, j);
    return object;
  }
  
  public static boolean[] reverse(boolean[] paramArrayOfboolean) {
    boolean[] arrayOfBoolean = new boolean[paramArrayOfboolean.length];
    int i = paramArrayOfboolean.length - 1;
    for (byte b = 0; b < paramArrayOfboolean.length; b++)
      arrayOfBoolean[b] = paramArrayOfboolean[i - b]; 
    return arrayOfBoolean;
  }
  
  public static byte[] reverse(byte[] paramArrayOfbyte) {
    byte[] arrayOfByte = new byte[paramArrayOfbyte.length];
    int i = paramArrayOfbyte.length - 1;
    for (byte b = 0; b < paramArrayOfbyte.length; b++)
      arrayOfByte[b] = paramArrayOfbyte[i - b]; 
    return arrayOfByte;
  }
  
  public static char[] reverse(char[] paramArrayOfchar) {
    char[] arrayOfChar = new char[paramArrayOfchar.length];
    int i = paramArrayOfchar.length - 1;
    for (byte b = 0; b < paramArrayOfchar.length; b++)
      arrayOfChar[b] = paramArrayOfchar[i - b]; 
    return arrayOfChar;
  }
  
  public static int[] reverse(int[] paramArrayOfint) {
    int[] arrayOfInt = new int[paramArrayOfint.length];
    int i = paramArrayOfint.length - 1;
    for (byte b = 0; b < paramArrayOfint.length; b++)
      arrayOfInt[b] = paramArrayOfint[i - b]; 
    return arrayOfInt;
  }
  
  public static float[] reverse(float[] paramArrayOffloat) {
    float[] arrayOfFloat = new float[paramArrayOffloat.length];
    int i = paramArrayOffloat.length - 1;
    for (byte b = 0; b < paramArrayOffloat.length; b++)
      arrayOfFloat[b] = paramArrayOffloat[i - b]; 
    return arrayOfFloat;
  }
  
  public static String[] reverse(String[] paramArrayOfString) {
    String[] arrayOfString = new String[paramArrayOfString.length];
    int i = paramArrayOfString.length - 1;
    for (byte b = 0; b < paramArrayOfString.length; b++)
      arrayOfString[b] = paramArrayOfString[i - b]; 
    return arrayOfString;
  }
  
  public static Object reverse(Object paramObject) {
    Class<?> clazz = paramObject.getClass().getComponentType();
    int i = Array.getLength(paramObject);
    Object object = Array.newInstance(clazz, i);
    for (byte b = 0; b < i; b++)
      Array.set(object, b, Array.get(paramObject, i - 1 - b)); 
    return object;
  }
  
  public static String trim(String paramString) {
    return paramString.replace(' ', ' ').trim();
  }
  
  public static String[] trim(String[] paramArrayOfString) {
    String[] arrayOfString = new String[paramArrayOfString.length];
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      if (paramArrayOfString[b] != null)
        arrayOfString[b] = paramArrayOfString[b].replace(' ', ' ').trim(); 
    } 
    return arrayOfString;
  }
  
  public static String join(String[] paramArrayOfString, char paramChar) {
    return join(paramArrayOfString, String.valueOf(paramChar));
  }
  
  public static String join(String[] paramArrayOfString, String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      if (b != 0)
        stringBuffer.append(paramString); 
      stringBuffer.append(paramArrayOfString[b]);
    } 
    return stringBuffer.toString();
  }
  
  public static String[] splitTokens(String paramString) {
    return splitTokens(paramString, " \t\n\r\f ");
  }
  
  public static String[] splitTokens(String paramString1, String paramString2) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString1, paramString2);
    String[] arrayOfString = new String[stringTokenizer.countTokens()];
    byte b = 0;
    while (stringTokenizer.hasMoreTokens())
      arrayOfString[b++] = stringTokenizer.nextToken(); 
    return arrayOfString;
  }
  
  public static String[] split(String paramString, char paramChar) {
    if (paramString == null)
      return null; 
    char[] arrayOfChar = paramString.toCharArray();
    byte b1 = 0;
    for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
      if (arrayOfChar[b2] == paramChar)
        b1++; 
    } 
    if (b1 == 0) {
      String[] arrayOfString1 = new String[1];
      arrayOfString1[0] = new String(paramString);
      return arrayOfString1;
    } 
    String[] arrayOfString = new String[b1 + 1];
    byte b3 = 0;
    int i = 0;
    for (byte b4 = 0; b4 < arrayOfChar.length; b4++) {
      if (arrayOfChar[b4] == paramChar) {
        arrayOfString[b3++] = new String(arrayOfChar, i, b4 - i);
        i = b4 + 1;
      } 
    } 
    arrayOfString[b3] = new String(arrayOfChar, i, arrayOfChar.length - i);
    return arrayOfString;
  }
  
  public static String[] split(String paramString1, String paramString2) {
    ArrayList<String> arrayList = new ArrayList();
    int i;
    int j;
    for (j = 0; (i = paramString1.indexOf(paramString2, j)) != -1; j = i + paramString2.length())
      arrayList.add(paramString1.substring(j, i)); 
    arrayList.add(paramString1.substring(j));
    String[] arrayOfString = new String[arrayList.size()];
    arrayList.toArray(arrayOfString);
    return arrayOfString;
  }
  
  static Pattern matchPattern(String paramString) {
    Pattern pattern = null;
    if (matchPatterns == null) {
      matchPatterns = new HashMap<String, Pattern>();
    } else {
      pattern = matchPatterns.get(paramString);
    } 
    if (pattern == null) {
      if (matchPatterns.size() == 10)
        matchPatterns.clear(); 
      pattern = Pattern.compile(paramString, 40);
      matchPatterns.put(paramString, pattern);
    } 
    return pattern;
  }
  
  public static String[] match(String paramString1, String paramString2) {
    Pattern pattern = matchPattern(paramString2);
    Matcher matcher = pattern.matcher(paramString1);
    if (matcher.find()) {
      int i = matcher.groupCount() + 1;
      String[] arrayOfString = new String[i];
      for (byte b = 0; b < i; b++)
        arrayOfString[b] = matcher.group(b); 
      return arrayOfString;
    } 
    return null;
  }
  
  public static String[][] matchAll(String paramString1, String paramString2) {
    Pattern pattern = matchPattern(paramString2);
    Matcher matcher = pattern.matcher(paramString1);
    ArrayList<String[]> arrayList = new ArrayList();
    int i = matcher.groupCount() + 1;
    while (matcher.find()) {
      String[] arrayOfString1 = new String[i];
      for (byte b1 = 0; b1 < i; b1++)
        arrayOfString1[b1] = matcher.group(b1); 
      arrayList.add(arrayOfString1);
    } 
    if (arrayList.isEmpty())
      return (String[][])null; 
    String[][] arrayOfString = new String[arrayList.size()][i];
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = arrayList.get(b); 
    return arrayOfString;
  }
  
  public static final boolean parseBoolean(int paramInt) {
    return (paramInt != 0);
  }
  
  public static final boolean parseBoolean(String paramString) {
    return (new Boolean(paramString)).booleanValue();
  }
  
  public static final boolean[] parseBoolean(int[] paramArrayOfint) {
    boolean[] arrayOfBoolean = new boolean[paramArrayOfint.length];
    for (byte b = 0; b < paramArrayOfint.length; b++)
      arrayOfBoolean[b] = (paramArrayOfint[b] != 0); 
    return arrayOfBoolean;
  }
  
  public static final boolean[] parseBoolean(String[] paramArrayOfString) {
    boolean[] arrayOfBoolean = new boolean[paramArrayOfString.length];
    for (byte b = 0; b < paramArrayOfString.length; b++)
      arrayOfBoolean[b] = (new Boolean(paramArrayOfString[b])).booleanValue(); 
    return arrayOfBoolean;
  }
  
  public static final byte parseByte(boolean paramBoolean) {
    return paramBoolean ? 1 : 0;
  }
  
  public static final byte parseByte(char paramChar) {
    return (byte)paramChar;
  }
  
  public static final byte parseByte(int paramInt) {
    return (byte)paramInt;
  }
  
  public static final byte parseByte(float paramFloat) {
    return (byte)(int)paramFloat;
  }
  
  public static final byte[] parseByte(boolean[] paramArrayOfboolean) {
    byte[] arrayOfByte = new byte[paramArrayOfboolean.length];
    for (byte b = 0; b < paramArrayOfboolean.length; b++)
      arrayOfByte[b] = paramArrayOfboolean[b] ? 1 : 0; 
    return arrayOfByte;
  }
  
  public static final byte[] parseByte(char[] paramArrayOfchar) {
    byte[] arrayOfByte = new byte[paramArrayOfchar.length];
    for (byte b = 0; b < paramArrayOfchar.length; b++)
      arrayOfByte[b] = (byte)paramArrayOfchar[b]; 
    return arrayOfByte;
  }
  
  public static final byte[] parseByte(int[] paramArrayOfint) {
    byte[] arrayOfByte = new byte[paramArrayOfint.length];
    for (byte b = 0; b < paramArrayOfint.length; b++)
      arrayOfByte[b] = (byte)paramArrayOfint[b]; 
    return arrayOfByte;
  }
  
  public static final byte[] parseByte(float[] paramArrayOffloat) {
    byte[] arrayOfByte = new byte[paramArrayOffloat.length];
    for (byte b = 0; b < paramArrayOffloat.length; b++)
      arrayOfByte[b] = (byte)(int)paramArrayOffloat[b]; 
    return arrayOfByte;
  }
  
  public static final char parseChar(byte paramByte) {
    return (char)(paramByte & 0xFF);
  }
  
  public static final char parseChar(int paramInt) {
    return (char)paramInt;
  }
  
  public static final char[] parseChar(byte[] paramArrayOfbyte) {
    char[] arrayOfChar = new char[paramArrayOfbyte.length];
    for (byte b = 0; b < paramArrayOfbyte.length; b++)
      arrayOfChar[b] = (char)(paramArrayOfbyte[b] & 0xFF); 
    return arrayOfChar;
  }
  
  public static final char[] parseChar(int[] paramArrayOfint) {
    char[] arrayOfChar = new char[paramArrayOfint.length];
    for (byte b = 0; b < paramArrayOfint.length; b++)
      arrayOfChar[b] = (char)paramArrayOfint[b]; 
    return arrayOfChar;
  }
  
  public static final int parseInt(boolean paramBoolean) {
    return paramBoolean ? 1 : 0;
  }
  
  public static final int parseInt(byte paramByte) {
    return paramByte & 0xFF;
  }
  
  public static final int parseInt(char paramChar) {
    return paramChar;
  }
  
  public static final int parseInt(float paramFloat) {
    return (int)paramFloat;
  }
  
  public static final int parseInt(String paramString) {
    return parseInt(paramString, 0);
  }
  
  public static final int parseInt(String paramString, int paramInt) {
    try {
      int i = paramString.indexOf('.');
      return (i == -1) ? Integer.parseInt(paramString) : Integer.parseInt(paramString.substring(0, i));
    } catch (NumberFormatException numberFormatException) {
      return paramInt;
    } 
  }
  
  public static final int[] parseInt(boolean[] paramArrayOfboolean) {
    int[] arrayOfInt = new int[paramArrayOfboolean.length];
    for (byte b = 0; b < paramArrayOfboolean.length; b++)
      arrayOfInt[b] = paramArrayOfboolean[b] ? 1 : 0; 
    return arrayOfInt;
  }
  
  public static final int[] parseInt(byte[] paramArrayOfbyte) {
    int[] arrayOfInt = new int[paramArrayOfbyte.length];
    for (byte b = 0; b < paramArrayOfbyte.length; b++)
      arrayOfInt[b] = paramArrayOfbyte[b] & 0xFF; 
    return arrayOfInt;
  }
  
  public static final int[] parseInt(char[] paramArrayOfchar) {
    int[] arrayOfInt = new int[paramArrayOfchar.length];
    for (byte b = 0; b < paramArrayOfchar.length; b++)
      arrayOfInt[b] = paramArrayOfchar[b]; 
    return arrayOfInt;
  }
  
  public static int[] parseInt(float[] paramArrayOffloat) {
    int[] arrayOfInt = new int[paramArrayOffloat.length];
    for (byte b = 0; b < paramArrayOffloat.length; b++)
      arrayOfInt[b] = (int)paramArrayOffloat[b]; 
    return arrayOfInt;
  }
  
  public static int[] parseInt(String[] paramArrayOfString) {
    return parseInt(paramArrayOfString, 0);
  }
  
  public static int[] parseInt(String[] paramArrayOfString, int paramInt) {
    int[] arrayOfInt = new int[paramArrayOfString.length];
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      try {
        arrayOfInt[b] = Integer.parseInt(paramArrayOfString[b]);
      } catch (NumberFormatException numberFormatException) {
        arrayOfInt[b] = paramInt;
      } 
    } 
    return arrayOfInt;
  }
  
  public static final float parseFloat(int paramInt) {
    return paramInt;
  }
  
  public static final float parseFloat(String paramString) {
    return parseFloat(paramString, Float.NaN);
  }
  
  public static final float parseFloat(String paramString, float paramFloat) {
    try {
      return (new Float(paramString)).floatValue();
    } catch (NumberFormatException numberFormatException) {
      return paramFloat;
    } 
  }
  
  public static final float[] parseByte(byte[] paramArrayOfbyte) {
    float[] arrayOfFloat = new float[paramArrayOfbyte.length];
    for (byte b = 0; b < paramArrayOfbyte.length; b++)
      arrayOfFloat[b] = paramArrayOfbyte[b]; 
    return arrayOfFloat;
  }
  
  public static final float[] parseFloat(int[] paramArrayOfint) {
    float[] arrayOfFloat = new float[paramArrayOfint.length];
    for (byte b = 0; b < paramArrayOfint.length; b++)
      arrayOfFloat[b] = paramArrayOfint[b]; 
    return arrayOfFloat;
  }
  
  public static final float[] parseFloat(String[] paramArrayOfString) {
    return parseFloat(paramArrayOfString, Float.NaN);
  }
  
  public static final float[] parseFloat(String[] paramArrayOfString, float paramFloat) {
    float[] arrayOfFloat = new float[paramArrayOfString.length];
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      try {
        arrayOfFloat[b] = (new Float(paramArrayOfString[b])).floatValue();
      } catch (NumberFormatException numberFormatException) {
        arrayOfFloat[b] = paramFloat;
      } 
    } 
    return arrayOfFloat;
  }
  
  public static final String str(boolean paramBoolean) {
    return String.valueOf(paramBoolean);
  }
  
  public static final String str(byte paramByte) {
    return String.valueOf(paramByte);
  }
  
  public static final String str(char paramChar) {
    return String.valueOf(paramChar);
  }
  
  public static final String str(int paramInt) {
    return String.valueOf(paramInt);
  }
  
  public static final String str(float paramFloat) {
    return String.valueOf(paramFloat);
  }
  
  public static final String[] str(boolean[] paramArrayOfboolean) {
    String[] arrayOfString = new String[paramArrayOfboolean.length];
    for (byte b = 0; b < paramArrayOfboolean.length; b++)
      arrayOfString[b] = String.valueOf(paramArrayOfboolean[b]); 
    return arrayOfString;
  }
  
  public static final String[] str(byte[] paramArrayOfbyte) {
    String[] arrayOfString = new String[paramArrayOfbyte.length];
    for (byte b = 0; b < paramArrayOfbyte.length; b++)
      arrayOfString[b] = String.valueOf(paramArrayOfbyte[b]); 
    return arrayOfString;
  }
  
  public static final String[] str(char[] paramArrayOfchar) {
    String[] arrayOfString = new String[paramArrayOfchar.length];
    for (byte b = 0; b < paramArrayOfchar.length; b++)
      arrayOfString[b] = String.valueOf(paramArrayOfchar[b]); 
    return arrayOfString;
  }
  
  public static final String[] str(int[] paramArrayOfint) {
    String[] arrayOfString = new String[paramArrayOfint.length];
    for (byte b = 0; b < paramArrayOfint.length; b++)
      arrayOfString[b] = String.valueOf(paramArrayOfint[b]); 
    return arrayOfString;
  }
  
  public static final String[] str(float[] paramArrayOffloat) {
    String[] arrayOfString = new String[paramArrayOffloat.length];
    for (byte b = 0; b < paramArrayOffloat.length; b++)
      arrayOfString[b] = String.valueOf(paramArrayOffloat[b]); 
    return arrayOfString;
  }
  
  public static String[] nf(int[] paramArrayOfint, int paramInt) {
    String[] arrayOfString = new String[paramArrayOfint.length];
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = nf(paramArrayOfint[b], paramInt); 
    return arrayOfString;
  }
  
  public static String nf(int paramInt1, int paramInt2) {
    if (int_nf != null && int_nf_digits == paramInt2 && !int_nf_commas)
      return int_nf.format(paramInt1); 
    int_nf = NumberFormat.getInstance();
    int_nf.setGroupingUsed(false);
    int_nf_commas = false;
    int_nf.setMinimumIntegerDigits(paramInt2);
    int_nf_digits = paramInt2;
    return int_nf.format(paramInt1);
  }
  
  public static String[] nfc(int[] paramArrayOfint) {
    String[] arrayOfString = new String[paramArrayOfint.length];
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = nfc(paramArrayOfint[b]); 
    return arrayOfString;
  }
  
  public static String nfc(int paramInt) {
    if (int_nf != null && int_nf_digits == 0 && int_nf_commas)
      return int_nf.format(paramInt); 
    int_nf = NumberFormat.getInstance();
    int_nf.setGroupingUsed(true);
    int_nf_commas = true;
    int_nf.setMinimumIntegerDigits(0);
    int_nf_digits = 0;
    return int_nf.format(paramInt);
  }
  
  public static String nfs(int paramInt1, int paramInt2) {
    return (paramInt1 < 0) ? nf(paramInt1, paramInt2) : (' ' + nf(paramInt1, paramInt2));
  }
  
  public static String[] nfs(int[] paramArrayOfint, int paramInt) {
    String[] arrayOfString = new String[paramArrayOfint.length];
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = nfs(paramArrayOfint[b], paramInt); 
    return arrayOfString;
  }
  
  public static String nfp(int paramInt1, int paramInt2) {
    return (paramInt1 < 0) ? nf(paramInt1, paramInt2) : ('+' + nf(paramInt1, paramInt2));
  }
  
  public static String[] nfp(int[] paramArrayOfint, int paramInt) {
    String[] arrayOfString = new String[paramArrayOfint.length];
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = nfp(paramArrayOfint[b], paramInt); 
    return arrayOfString;
  }
  
  public static String[] nf(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    String[] arrayOfString = new String[paramArrayOffloat.length];
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = nf(paramArrayOffloat[b], paramInt1, paramInt2); 
    return arrayOfString;
  }
  
  public static String nf(float paramFloat, int paramInt1, int paramInt2) {
    if (float_nf != null && float_nf_left == paramInt1 && float_nf_right == paramInt2 && !float_nf_commas)
      return float_nf.format(paramFloat); 
    float_nf = NumberFormat.getInstance();
    float_nf.setGroupingUsed(false);
    float_nf_commas = false;
    if (paramInt1 != 0)
      float_nf.setMinimumIntegerDigits(paramInt1); 
    if (paramInt2 != 0) {
      float_nf.setMinimumFractionDigits(paramInt2);
      float_nf.setMaximumFractionDigits(paramInt2);
    } 
    float_nf_left = paramInt1;
    float_nf_right = paramInt2;
    return float_nf.format(paramFloat);
  }
  
  public static String[] nfc(float[] paramArrayOffloat, int paramInt) {
    String[] arrayOfString = new String[paramArrayOffloat.length];
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = nfc(paramArrayOffloat[b], paramInt); 
    return arrayOfString;
  }
  
  public static String nfc(float paramFloat, int paramInt) {
    if (float_nf != null && float_nf_left == 0 && float_nf_right == paramInt && float_nf_commas)
      return float_nf.format(paramFloat); 
    float_nf = NumberFormat.getInstance();
    float_nf.setGroupingUsed(true);
    float_nf_commas = true;
    if (paramInt != 0) {
      float_nf.setMinimumFractionDigits(paramInt);
      float_nf.setMaximumFractionDigits(paramInt);
    } 
    float_nf_left = 0;
    float_nf_right = paramInt;
    return float_nf.format(paramFloat);
  }
  
  public static String[] nfs(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    String[] arrayOfString = new String[paramArrayOffloat.length];
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = nfs(paramArrayOffloat[b], paramInt1, paramInt2); 
    return arrayOfString;
  }
  
  public static String nfs(float paramFloat, int paramInt1, int paramInt2) {
    return (paramFloat < 0.0F) ? nf(paramFloat, paramInt1, paramInt2) : (' ' + nf(paramFloat, paramInt1, paramInt2));
  }
  
  public static String[] nfp(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    String[] arrayOfString = new String[paramArrayOffloat.length];
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = nfp(paramArrayOffloat[b], paramInt1, paramInt2); 
    return arrayOfString;
  }
  
  public static String nfp(float paramFloat, int paramInt1, int paramInt2) {
    return (paramFloat < 0.0F) ? nf(paramFloat, paramInt1, paramInt2) : ('+' + nf(paramFloat, paramInt1, paramInt2));
  }
  
  public static final String hex(byte paramByte) {
    return hex(paramByte, 2);
  }
  
  public static final String hex(char paramChar) {
    return hex(paramChar, 4);
  }
  
  public static final String hex(int paramInt) {
    return hex(paramInt, 8);
  }
  
  public static final String hex(int paramInt1, int paramInt2) {
    String str = Integer.toHexString(paramInt1).toUpperCase();
    int i = str.length();
    return (i > paramInt2) ? str.substring(i - paramInt2) : ((i < paramInt2) ? ("00000000".substring(8 - paramInt2 - i) + str) : str);
  }
  
  public static final int unhex(String paramString) {
    return (int)Long.parseLong(paramString, 16);
  }
  
  public static final String binary(byte paramByte) {
    return binary(paramByte, 8);
  }
  
  public static final String binary(char paramChar) {
    return binary(paramChar, 16);
  }
  
  public static final String binary(int paramInt) {
    return Integer.toBinaryString(paramInt);
  }
  
  public static final String binary(int paramInt1, int paramInt2) {
    String str = Integer.toBinaryString(paramInt1);
    int i = str.length();
    if (i > paramInt2)
      return str.substring(i - paramInt2); 
    if (i < paramInt2) {
      int j = 32 - paramInt2 - i;
      return "00000000000000000000000000000000".substring(j) + str;
    } 
    return str;
  }
  
  public static final int unbinary(String paramString) {
    return Integer.parseInt(paramString, 2);
  }
  
  public final int color(int paramInt) {
    if (this.g == null) {
      if (paramInt > 255) {
        paramInt = 255;
      } else if (paramInt < 0) {
        paramInt = 0;
      } 
      return 0xFF000000 | paramInt << 16 | paramInt << 8 | paramInt;
    } 
    return this.g.color(paramInt);
  }
  
  public final int color(float paramFloat) {
    if (this.g == null) {
      int i = (int)paramFloat;
      if (i > 255) {
        i = 255;
      } else if (i < 0) {
        i = 0;
      } 
      return 0xFF000000 | i << 16 | i << 8 | i;
    } 
    return this.g.color(paramFloat);
  }
  
  public final int color(int paramInt1, int paramInt2) {
    if (this.g == null) {
      if (paramInt2 > 255) {
        paramInt2 = 255;
      } else if (paramInt2 < 0) {
        paramInt2 = 0;
      } 
      return (paramInt1 > 255) ? (paramInt2 << 24 | paramInt1 & 0xFFFFFF) : (paramInt2 << 24 | paramInt1 << 16 | paramInt1 << 8 | paramInt1);
    } 
    return this.g.color(paramInt1, paramInt2);
  }
  
  public final int color(float paramFloat1, float paramFloat2) {
    if (this.g == null) {
      int i = (int)paramFloat1;
      int j = (int)paramFloat2;
      if (i > 255) {
        i = 255;
      } else if (i < 0) {
        i = 0;
      } 
      if (j > 255) {
        j = 255;
      } else if (j < 0) {
        j = 0;
      } 
      return 0xFF000000 | i << 16 | i << 8 | i;
    } 
    return this.g.color(paramFloat1, paramFloat2);
  }
  
  public final int color(int paramInt1, int paramInt2, int paramInt3) {
    if (this.g == null) {
      if (paramInt1 > 255) {
        paramInt1 = 255;
      } else if (paramInt1 < 0) {
        paramInt1 = 0;
      } 
      if (paramInt2 > 255) {
        paramInt2 = 255;
      } else if (paramInt2 < 0) {
        paramInt2 = 0;
      } 
      if (paramInt3 > 255) {
        paramInt3 = 255;
      } else if (paramInt3 < 0) {
        paramInt3 = 0;
      } 
      return 0xFF000000 | paramInt1 << 16 | paramInt2 << 8 | paramInt3;
    } 
    return this.g.color(paramInt1, paramInt2, paramInt3);
  }
  
  public final int color(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.g == null) {
      if (paramFloat1 > 255.0F) {
        paramFloat1 = 255.0F;
      } else if (paramFloat1 < 0.0F) {
        paramFloat1 = 0.0F;
      } 
      if (paramFloat2 > 255.0F) {
        paramFloat2 = 255.0F;
      } else if (paramFloat2 < 0.0F) {
        paramFloat2 = 0.0F;
      } 
      if (paramFloat3 > 255.0F) {
        paramFloat3 = 255.0F;
      } else if (paramFloat3 < 0.0F) {
        paramFloat3 = 0.0F;
      } 
      return 0xFF000000 | (int)paramFloat1 << 16 | (int)paramFloat2 << 8 | (int)paramFloat3;
    } 
    return this.g.color(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public final int color(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.g == null) {
      if (paramInt4 > 255) {
        paramInt4 = 255;
      } else if (paramInt4 < 0) {
        paramInt4 = 0;
      } 
      if (paramInt1 > 255) {
        paramInt1 = 255;
      } else if (paramInt1 < 0) {
        paramInt1 = 0;
      } 
      if (paramInt2 > 255) {
        paramInt2 = 255;
      } else if (paramInt2 < 0) {
        paramInt2 = 0;
      } 
      if (paramInt3 > 255) {
        paramInt3 = 255;
      } else if (paramInt3 < 0) {
        paramInt3 = 0;
      } 
      return paramInt4 << 24 | paramInt1 << 16 | paramInt2 << 8 | paramInt3;
    } 
    return this.g.color(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public final int color(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.g == null) {
      if (paramFloat4 > 255.0F) {
        paramFloat4 = 255.0F;
      } else if (paramFloat4 < 0.0F) {
        paramFloat4 = 0.0F;
      } 
      if (paramFloat1 > 255.0F) {
        paramFloat1 = 255.0F;
      } else if (paramFloat1 < 0.0F) {
        paramFloat1 = 0.0F;
      } 
      if (paramFloat2 > 255.0F) {
        paramFloat2 = 255.0F;
      } else if (paramFloat2 < 0.0F) {
        paramFloat2 = 0.0F;
      } 
      if (paramFloat3 > 255.0F) {
        paramFloat3 = 255.0F;
      } else if (paramFloat3 < 0.0F) {
        paramFloat3 = 0.0F;
      } 
      return (int)paramFloat4 << 24 | (int)paramFloat1 << 16 | (int)paramFloat2 << 8 | (int)paramFloat3;
    } 
    return this.g.color(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void setupExternalMessages() {
    this.frame.addComponentListener(new ComponentAdapter() {
          public void componentMoved(ComponentEvent param1ComponentEvent) {
            Point point = ((Frame)param1ComponentEvent.getSource()).getLocation();
            System.err.println("__MOVE__ " + point.x + " " + point.y);
            System.err.flush();
          }
        });
    this.frame.addWindowListener(new WindowAdapter() {
          public void windowClosing(WindowEvent param1WindowEvent) {
            PApplet.this.exit();
          }
        });
  }
  
  public void setupFrameResizeListener() {
    this.frame.addComponentListener(new ComponentAdapter() {
          public void componentResized(ComponentEvent param1ComponentEvent) {
            if (PApplet.this.frame.isResizable()) {
              Frame frame = (Frame)param1ComponentEvent.getComponent();
              if (frame.isVisible()) {
                Insets insets = frame.getInsets();
                Dimension dimension = frame.getSize();
                int i = dimension.width - insets.left - insets.right;
                int j = dimension.height - insets.top - insets.bottom;
                PApplet.this.setBounds(insets.left, insets.top, i, j);
              } 
            } 
          }
        });
  }
  
  public static void runSketch(String[] paramArrayOfString, PApplet paramPApplet) {
    PApplet pApplet;
    if (platform == 2)
      System.setProperty("apple.awt.graphics.UseQuartz", String.valueOf(useQuartz)); 
    if (paramArrayOfString.length < 1) {
      System.err.println("Usage: PApplet <appletname>");
      System.err.println("For additional options, see the Javadoc for PApplet");
      System.exit(1);
    } 
    boolean bool1 = false;
    int[] arrayOfInt1 = null;
    int[] arrayOfInt2 = null;
    String str1 = null;
    boolean bool2 = false;
    boolean bool3 = false;
    Color color1 = Color.BLACK;
    Color color2 = Color.GRAY;
    GraphicsDevice graphicsDevice = null;
    boolean bool4 = false;
    String str2 = null;
    String str3 = null;
    String str4 = null;
    try {
      str4 = System.getProperty("user.dir");
    } catch (Exception exception) {}
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      int i = paramArrayOfString[b].indexOf('=');
      if (i != -1) {
        str2 = paramArrayOfString[b].substring(0, i);
        str3 = paramArrayOfString[b].substring(i + 1);
        if (str2.equals("--editor-location")) {
          bool1 = true;
          arrayOfInt2 = parseInt(split(str3, ','));
        } else if (str2.equals("--display")) {
          int j = Integer.parseInt(str3) - 1;
          GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
          GraphicsDevice[] arrayOfGraphicsDevice = graphicsEnvironment.getScreenDevices();
          if (j >= 0 && j < arrayOfGraphicsDevice.length) {
            graphicsDevice = arrayOfGraphicsDevice[j];
          } else {
            System.err.println("Display " + str3 + " does not exist, " + "using the default display instead.");
          } 
        } else if (str2.equals("--bgcolor")) {
          if (str3.charAt(0) == '#')
            str3 = str3.substring(1); 
          color1 = new Color(Integer.parseInt(str3, 16));
        } else if (str2.equals("--stop-color")) {
          if (str3.charAt(0) == '#')
            str3 = str3.substring(1); 
          color2 = new Color(Integer.parseInt(str3, 16));
        } else if (str2.equals("--sketch-path")) {
          str4 = str3;
        } else if (str2.equals("--location")) {
          arrayOfInt1 = parseInt(split(str3, ','));
        } 
      } else if (paramArrayOfString[b].equals("--present")) {
        bool2 = true;
      } else if (paramArrayOfString[b].equals("--exclusive")) {
        bool3 = true;
      } else if (paramArrayOfString[b].equals("--hide-stop")) {
        bool4 = true;
      } else if (paramArrayOfString[b].equals("--external")) {
        bool1 = true;
      } else {
        str1 = paramArrayOfString[b];
        break;
      } 
    } 
    if (graphicsDevice == null) {
      GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
      graphicsDevice = graphicsEnvironment.getDefaultScreenDevice();
    } 
    Frame frame = new Frame(graphicsDevice.getDefaultConfiguration());
    Image image = Toolkit.getDefaultToolkit().createImage(ICON_IMAGE);
    frame.setIconImage(image);
    frame.setTitle(str1);
    if (paramPApplet != null) {
      pApplet = paramPApplet;
    } else {
      try {
        Class<?> clazz = Thread.currentThread().getContextClassLoader().loadClass(str1);
        pApplet = (PApplet)clazz.newInstance();
      } catch (Exception exception) {
        throw new RuntimeException(exception);
      } 
    } 
    pApplet.frame = frame;
    pApplet.sketchPath = str4;
    pApplet.args = subset(paramArrayOfString, 1);
    pApplet.external = bool1;
    Rectangle rectangle = null;
    if (bool2) {
      frame.setUndecorated(true);
      frame.setBackground(color1);
      if (bool3) {
        graphicsDevice.setFullScreenWindow(frame);
        rectangle = frame.getBounds();
      } else {
        DisplayMode displayMode = graphicsDevice.getDisplayMode();
        rectangle = new Rectangle(0, 0, displayMode.getWidth(), displayMode.getHeight());
        frame.setBounds(rectangle);
        frame.setVisible(true);
      } 
    } 
    frame.setLayout((LayoutManager)null);
    frame.add(pApplet);
    if (bool2) {
      frame.invalidate();
    } else {
      frame.pack();
    } 
    frame.setResizable(false);
    pApplet.init();
    while (pApplet.defaultSize && !pApplet.finished) {
      try {
        Thread.sleep(5L);
      } catch (InterruptedException interruptedException) {}
    } 
    if (bool2) {
      frame.setBounds(rectangle);
      pApplet.setBounds((rectangle.width - pApplet.width) / 2, (rectangle.height - pApplet.height) / 2, pApplet.width, pApplet.height);
      if (!bool4) {
        Label label = new Label("stop");
        label.setForeground(color2);
        label.addMouseListener(new MouseAdapter() {
              public void mousePressed(MouseEvent param1MouseEvent) {
                System.exit(0);
              }
            });
        frame.add(label);
        Dimension dimension = label.getPreferredSize();
        dimension = new Dimension(100, dimension.height);
        label.setSize(dimension);
        label.setLocation(20, rectangle.height - dimension.height - 20);
      } 
      if (bool1)
        pApplet.setupExternalMessages(); 
    } else {
      Insets insets = frame.getInsets();
      int i = Math.max(pApplet.width, 128) + insets.left + insets.right;
      int j = Math.max(pApplet.height, 128) + insets.top + insets.bottom;
      frame.setSize(i, j);
      if (arrayOfInt1 != null) {
        frame.setLocation(arrayOfInt1[0], arrayOfInt1[1]);
      } else if (bool1) {
        int m = arrayOfInt2[0] - 20;
        int n = arrayOfInt2[1];
        if (m - i > 10) {
          frame.setLocation(m - i, n);
        } else {
          m = arrayOfInt2[0] + 66;
          n = arrayOfInt2[1] + 66;
          if (m + i > pApplet.screenWidth - 33 || n + j > pApplet.screenHeight - 33) {
            m = (pApplet.screenWidth - i) / 2;
            n = (pApplet.screenHeight - j) / 2;
          } 
          frame.setLocation(m, n);
        } 
      } else {
        frame.setLocation((pApplet.screenWidth - pApplet.width) / 2, (pApplet.screenHeight - pApplet.height) / 2);
      } 
      Point point = frame.getLocation();
      if (point.y < 0)
        frame.setLocation(point.x, 30); 
      if (color1 == Color.black)
        color1 = SystemColor.control; 
      frame.setBackground(color1);
      int k = j - insets.top - insets.bottom;
      pApplet.setBounds((i - pApplet.width) / 2, insets.top + (k - pApplet.height) / 2, pApplet.width, pApplet.height);
      if (bool1) {
        pApplet.setupExternalMessages();
      } else {
        frame.addWindowListener(new WindowAdapter() {
              public void windowClosing(WindowEvent param1WindowEvent) {
                System.exit(0);
              }
            });
      } 
      pApplet.setupFrameResizeListener();
      if (pApplet.displayable())
        frame.setVisible(true); 
    } 
  }
  
  public static void main(String[] paramArrayOfString) {
    runSketch(paramArrayOfString, (PApplet)null);
  }
  
  protected void runSketch(String[] paramArrayOfString) {
    String[] arrayOfString = new String[paramArrayOfString.length + 1];
    System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramArrayOfString.length);
    String str1 = getClass().getSimpleName();
    String str2 = str1.replaceAll("__[^_]+__\\$", "").replaceAll("\\$\\d+", "");
    arrayOfString[paramArrayOfString.length] = str2;
    runSketch(arrayOfString, this);
  }
  
  protected void runSketch() {
    runSketch(new String[0]);
  }
  
  public PGraphics beginRecord(String paramString1, String paramString2) {
    paramString2 = insertFrame(paramString2);
    PGraphics pGraphics = createGraphics(this.width, this.height, paramString1, paramString2);
    beginRecord(pGraphics);
    return pGraphics;
  }
  
  public void beginRecord(PGraphics paramPGraphics) {
    this.recorder = paramPGraphics;
    paramPGraphics.beginDraw();
  }
  
  public void endRecord() {
    if (this.recorder != null) {
      this.recorder.endDraw();
      this.recorder.dispose();
      this.recorder = null;
    } 
    if (this.g.isRecording())
      this.g.endRecord(); 
  }
  
  public PGraphics beginRaw(String paramString1, String paramString2) {
    paramString2 = insertFrame(paramString2);
    PGraphics pGraphics = createGraphics(this.width, this.height, paramString1, paramString2);
    this.g.beginRaw(pGraphics);
    return pGraphics;
  }
  
  public void beginRaw(PGraphics paramPGraphics) {
    this.g.beginRaw(paramPGraphics);
  }
  
  public void endRaw() {
    this.g.endRaw();
  }
  
  public PShape beginRecord() {
    return this.g.beginRecord();
  }
  
  public void loadPixels() {
    this.g.loadPixels();
    this.pixels = this.g.pixels;
  }
  
  public void updatePixels() {
    this.g.updatePixels();
  }
  
  public void updatePixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.g.updatePixels(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void flush() {
    if (this.recorder != null)
      this.recorder.flush(); 
    this.g.flush();
  }
  
  public void hint(int paramInt) {
    if (this.recorder != null)
      this.recorder.hint(paramInt); 
    this.g.hint(paramInt);
  }
  
  public boolean hintEnabled(int paramInt) {
    return this.g.hintEnabled(paramInt);
  }
  
  public void beginShape() {
    if (this.recorder != null)
      this.recorder.beginShape(); 
    this.g.beginShape();
  }
  
  public void beginShape(int paramInt) {
    if (this.recorder != null)
      this.recorder.beginShape(paramInt); 
    this.g.beginShape(paramInt);
  }
  
  public void edge(boolean paramBoolean) {
    if (this.recorder != null)
      this.recorder.edge(paramBoolean); 
    this.g.edge(paramBoolean);
  }
  
  public void normal(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.normal(paramFloat1, paramFloat2, paramFloat3); 
    this.g.normal(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void textureMode(int paramInt) {
    if (this.recorder != null)
      this.recorder.textureMode(paramInt); 
    this.g.textureMode(paramInt);
  }
  
  public void texture(PImage paramPImage) {
    if (this.recorder != null)
      this.recorder.texture(paramPImage); 
    this.g.texture(paramPImage);
  }
  
  public void noTexture() {
    if (this.recorder != null)
      this.recorder.noTexture(); 
    this.g.noTexture();
  }
  
  public void vertex(float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.vertex(paramFloat1, paramFloat2); 
    this.g.vertex(paramFloat1, paramFloat2);
  }
  
  public void vertex(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.vertex(paramFloat1, paramFloat2, paramFloat3); 
    this.g.vertex(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void vertexFields(float[] paramArrayOffloat) {
    if (this.recorder != null)
      this.recorder.vertexFields(paramArrayOffloat); 
    this.g.vertexFields(paramArrayOffloat);
  }
  
  public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.vertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.vertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    if (this.recorder != null)
      this.recorder.vertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5); 
    this.g.vertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
  }
  
  public void breakShape() {
    if (this.recorder != null)
      this.recorder.breakShape(); 
    this.g.breakShape();
  }
  
  public void endShape() {
    if (this.recorder != null)
      this.recorder.endShape(); 
    this.g.endShape();
  }
  
  public void endShape(int paramInt) {
    if (this.recorder != null)
      this.recorder.endShape(paramInt); 
    this.g.endShape(paramInt);
  }
  
  public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.recorder != null)
      this.recorder.bezierVertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6); 
    this.g.bezierVertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9) {
    if (this.recorder != null)
      this.recorder.bezierVertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9); 
    this.g.bezierVertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9);
  }
  
  public void quadVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.quadVertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.quadVertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void quadVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.recorder != null)
      this.recorder.quadVertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6); 
    this.g.quadVertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void curveVertex(float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.curveVertex(paramFloat1, paramFloat2); 
    this.g.curveVertex(paramFloat1, paramFloat2);
  }
  
  public void curveVertex(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.curveVertex(paramFloat1, paramFloat2, paramFloat3); 
    this.g.curveVertex(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void point(float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.point(paramFloat1, paramFloat2); 
    this.g.point(paramFloat1, paramFloat2);
  }
  
  public void point(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.point(paramFloat1, paramFloat2, paramFloat3); 
    this.g.point(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.line(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.line(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.recorder != null)
      this.recorder.line(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6); 
    this.g.line(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void triangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.recorder != null)
      this.recorder.triangle(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6); 
    this.g.triangle(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void quad(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    if (this.recorder != null)
      this.recorder.quad(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8); 
    this.g.quad(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
  }
  
  public void rectMode(int paramInt) {
    if (this.recorder != null)
      this.recorder.rectMode(paramInt); 
    this.g.rectMode(paramInt);
  }
  
  public void rect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.rect(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.rect(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void rect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.recorder != null)
      this.recorder.rect(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6); 
    this.g.rect(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void rect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    if (this.recorder != null)
      this.recorder.rect(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8); 
    this.g.rect(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
  }
  
  public void ellipseMode(int paramInt) {
    if (this.recorder != null)
      this.recorder.ellipseMode(paramInt); 
    this.g.ellipseMode(paramInt);
  }
  
  public void ellipse(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.ellipse(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.ellipse(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void arc(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.recorder != null)
      this.recorder.arc(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6); 
    this.g.arc(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void box(float paramFloat) {
    if (this.recorder != null)
      this.recorder.box(paramFloat); 
    this.g.box(paramFloat);
  }
  
  public void box(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.box(paramFloat1, paramFloat2, paramFloat3); 
    this.g.box(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void sphereDetail(int paramInt) {
    if (this.recorder != null)
      this.recorder.sphereDetail(paramInt); 
    this.g.sphereDetail(paramInt);
  }
  
  public void sphereDetail(int paramInt1, int paramInt2) {
    if (this.recorder != null)
      this.recorder.sphereDetail(paramInt1, paramInt2); 
    this.g.sphereDetail(paramInt1, paramInt2);
  }
  
  public void sphere(float paramFloat) {
    if (this.recorder != null)
      this.recorder.sphere(paramFloat); 
    this.g.sphere(paramFloat);
  }
  
  public float bezierPoint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    return this.g.bezierPoint(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
  }
  
  public float bezierTangent(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    return this.g.bezierTangent(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
  }
  
  public void bezierDetail(int paramInt) {
    if (this.recorder != null)
      this.recorder.bezierDetail(paramInt); 
    this.g.bezierDetail(paramInt);
  }
  
  public void bezier(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    if (this.recorder != null)
      this.recorder.bezier(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8); 
    this.g.bezier(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
  }
  
  public void bezier(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12) {
    if (this.recorder != null)
      this.recorder.bezier(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12); 
    this.g.bezier(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12);
  }
  
  public float curvePoint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    return this.g.curvePoint(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
  }
  
  public float curveTangent(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    return this.g.curveTangent(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
  }
  
  public void curveDetail(int paramInt) {
    if (this.recorder != null)
      this.recorder.curveDetail(paramInt); 
    this.g.curveDetail(paramInt);
  }
  
  public void curveTightness(float paramFloat) {
    if (this.recorder != null)
      this.recorder.curveTightness(paramFloat); 
    this.g.curveTightness(paramFloat);
  }
  
  public void curve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    if (this.recorder != null)
      this.recorder.curve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8); 
    this.g.curve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
  }
  
  public void curve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12) {
    if (this.recorder != null)
      this.recorder.curve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12); 
    this.g.curve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12);
  }
  
  public void smooth() {
    if (this.recorder != null)
      this.recorder.smooth(); 
    this.g.smooth();
  }
  
  public void noSmooth() {
    if (this.recorder != null)
      this.recorder.noSmooth(); 
    this.g.noSmooth();
  }
  
  public void imageMode(int paramInt) {
    if (this.recorder != null)
      this.recorder.imageMode(paramInt); 
    this.g.imageMode(paramInt);
  }
  
  public void image(PImage paramPImage, float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.image(paramPImage, paramFloat1, paramFloat2); 
    this.g.image(paramPImage, paramFloat1, paramFloat2);
  }
  
  public void image(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.image(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.image(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void image(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.recorder != null)
      this.recorder.image(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4); 
    this.g.image(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void shapeMode(int paramInt) {
    if (this.recorder != null)
      this.recorder.shapeMode(paramInt); 
    this.g.shapeMode(paramInt);
  }
  
  public void shape(PShape paramPShape) {
    if (this.recorder != null)
      this.recorder.shape(paramPShape); 
    this.g.shape(paramPShape);
  }
  
  public void shape(PShape paramPShape, float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.shape(paramPShape, paramFloat1, paramFloat2); 
    this.g.shape(paramPShape, paramFloat1, paramFloat2);
  }
  
  public void shape(PShape paramPShape, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.shape(paramPShape, paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.shape(paramPShape, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void textAlign(int paramInt) {
    if (this.recorder != null)
      this.recorder.textAlign(paramInt); 
    this.g.textAlign(paramInt);
  }
  
  public void textAlign(int paramInt1, int paramInt2) {
    if (this.recorder != null)
      this.recorder.textAlign(paramInt1, paramInt2); 
    this.g.textAlign(paramInt1, paramInt2);
  }
  
  public float textAscent() {
    return this.g.textAscent();
  }
  
  public float textDescent() {
    return this.g.textDescent();
  }
  
  public void textFont(PFont paramPFont) {
    if (this.recorder != null)
      this.recorder.textFont(paramPFont); 
    this.g.textFont(paramPFont);
  }
  
  public void textFont(PFont paramPFont, float paramFloat) {
    if (this.recorder != null)
      this.recorder.textFont(paramPFont, paramFloat); 
    this.g.textFont(paramPFont, paramFloat);
  }
  
  public void textLeading(float paramFloat) {
    if (this.recorder != null)
      this.recorder.textLeading(paramFloat); 
    this.g.textLeading(paramFloat);
  }
  
  public void textMode(int paramInt) {
    if (this.recorder != null)
      this.recorder.textMode(paramInt); 
    this.g.textMode(paramInt);
  }
  
  public void textSize(float paramFloat) {
    if (this.recorder != null)
      this.recorder.textSize(paramFloat); 
    this.g.textSize(paramFloat);
  }
  
  public float textWidth(char paramChar) {
    return this.g.textWidth(paramChar);
  }
  
  public float textWidth(String paramString) {
    return this.g.textWidth(paramString);
  }
  
  public float textWidth(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    return this.g.textWidth(paramArrayOfchar, paramInt1, paramInt2);
  }
  
  public void text(char paramChar) {
    if (this.recorder != null)
      this.recorder.text(paramChar); 
    this.g.text(paramChar);
  }
  
  public void text(char paramChar, float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.text(paramChar, paramFloat1, paramFloat2); 
    this.g.text(paramChar, paramFloat1, paramFloat2);
  }
  
  public void text(char paramChar, float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.text(paramChar, paramFloat1, paramFloat2, paramFloat3); 
    this.g.text(paramChar, paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void text(String paramString) {
    if (this.recorder != null)
      this.recorder.text(paramString); 
    this.g.text(paramString);
  }
  
  public void text(String paramString, float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.text(paramString, paramFloat1, paramFloat2); 
    this.g.text(paramString, paramFloat1, paramFloat2);
  }
  
  public void text(char[] paramArrayOfchar, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.text(paramArrayOfchar, paramInt1, paramInt2, paramFloat1, paramFloat2); 
    this.g.text(paramArrayOfchar, paramInt1, paramInt2, paramFloat1, paramFloat2);
  }
  
  public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.text(paramString, paramFloat1, paramFloat2, paramFloat3); 
    this.g.text(paramString, paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void text(char[] paramArrayOfchar, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.text(paramArrayOfchar, paramInt1, paramInt2, paramFloat1, paramFloat2, paramFloat3); 
    this.g.text(paramArrayOfchar, paramInt1, paramInt2, paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.text(paramString, paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.text(paramString, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    if (this.recorder != null)
      this.recorder.text(paramString, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5); 
    this.g.text(paramString, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
  }
  
  public void text(int paramInt, float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.text(paramInt, paramFloat1, paramFloat2); 
    this.g.text(paramInt, paramFloat1, paramFloat2);
  }
  
  public void text(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.text(paramInt, paramFloat1, paramFloat2, paramFloat3); 
    this.g.text(paramInt, paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void text(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.text(paramFloat1, paramFloat2, paramFloat3); 
    this.g.text(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void text(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.text(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.text(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void pushMatrix() {
    if (this.recorder != null)
      this.recorder.pushMatrix(); 
    this.g.pushMatrix();
  }
  
  public void popMatrix() {
    if (this.recorder != null)
      this.recorder.popMatrix(); 
    this.g.popMatrix();
  }
  
  public void translate(float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.translate(paramFloat1, paramFloat2); 
    this.g.translate(paramFloat1, paramFloat2);
  }
  
  public void translate(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.translate(paramFloat1, paramFloat2, paramFloat3); 
    this.g.translate(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void rotate(float paramFloat) {
    if (this.recorder != null)
      this.recorder.rotate(paramFloat); 
    this.g.rotate(paramFloat);
  }
  
  public void rotateX(float paramFloat) {
    if (this.recorder != null)
      this.recorder.rotateX(paramFloat); 
    this.g.rotateX(paramFloat);
  }
  
  public void rotateY(float paramFloat) {
    if (this.recorder != null)
      this.recorder.rotateY(paramFloat); 
    this.g.rotateY(paramFloat);
  }
  
  public void rotateZ(float paramFloat) {
    if (this.recorder != null)
      this.recorder.rotateZ(paramFloat); 
    this.g.rotateZ(paramFloat);
  }
  
  public void rotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.rotate(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.rotate(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void scale(float paramFloat) {
    if (this.recorder != null)
      this.recorder.scale(paramFloat); 
    this.g.scale(paramFloat);
  }
  
  public void scale(float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.scale(paramFloat1, paramFloat2); 
    this.g.scale(paramFloat1, paramFloat2);
  }
  
  public void scale(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.scale(paramFloat1, paramFloat2, paramFloat3); 
    this.g.scale(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void shearX(float paramFloat) {
    if (this.recorder != null)
      this.recorder.shearX(paramFloat); 
    this.g.shearX(paramFloat);
  }
  
  public void shearY(float paramFloat) {
    if (this.recorder != null)
      this.recorder.shearY(paramFloat); 
    this.g.shearY(paramFloat);
  }
  
  public void resetMatrix() {
    if (this.recorder != null)
      this.recorder.resetMatrix(); 
    this.g.resetMatrix();
  }
  
  public void applyMatrix(PMatrix paramPMatrix) {
    if (this.recorder != null)
      this.recorder.applyMatrix(paramPMatrix); 
    this.g.applyMatrix(paramPMatrix);
  }
  
  public void applyMatrix(PMatrix2D paramPMatrix2D) {
    if (this.recorder != null)
      this.recorder.applyMatrix(paramPMatrix2D); 
    this.g.applyMatrix(paramPMatrix2D);
  }
  
  public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.recorder != null)
      this.recorder.applyMatrix(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6); 
    this.g.applyMatrix(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void applyMatrix(PMatrix3D paramPMatrix3D) {
    if (this.recorder != null)
      this.recorder.applyMatrix(paramPMatrix3D); 
    this.g.applyMatrix(paramPMatrix3D);
  }
  
  public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16) {
    if (this.recorder != null)
      this.recorder.applyMatrix(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16); 
    this.g.applyMatrix(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
  }
  
  public PMatrix getMatrix() {
    return this.g.getMatrix();
  }
  
  public PMatrix2D getMatrix(PMatrix2D paramPMatrix2D) {
    return this.g.getMatrix(paramPMatrix2D);
  }
  
  public PMatrix3D getMatrix(PMatrix3D paramPMatrix3D) {
    return this.g.getMatrix(paramPMatrix3D);
  }
  
  public void setMatrix(PMatrix paramPMatrix) {
    if (this.recorder != null)
      this.recorder.setMatrix(paramPMatrix); 
    this.g.setMatrix(paramPMatrix);
  }
  
  public void setMatrix(PMatrix2D paramPMatrix2D) {
    if (this.recorder != null)
      this.recorder.setMatrix(paramPMatrix2D); 
    this.g.setMatrix(paramPMatrix2D);
  }
  
  public void setMatrix(PMatrix3D paramPMatrix3D) {
    if (this.recorder != null)
      this.recorder.setMatrix(paramPMatrix3D); 
    this.g.setMatrix(paramPMatrix3D);
  }
  
  public void printMatrix() {
    if (this.recorder != null)
      this.recorder.printMatrix(); 
    this.g.printMatrix();
  }
  
  public void beginCamera() {
    if (this.recorder != null)
      this.recorder.beginCamera(); 
    this.g.beginCamera();
  }
  
  public void endCamera() {
    if (this.recorder != null)
      this.recorder.endCamera(); 
    this.g.endCamera();
  }
  
  public void camera() {
    if (this.recorder != null)
      this.recorder.camera(); 
    this.g.camera();
  }
  
  public void camera(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9) {
    if (this.recorder != null)
      this.recorder.camera(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9); 
    this.g.camera(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9);
  }
  
  public void printCamera() {
    if (this.recorder != null)
      this.recorder.printCamera(); 
    this.g.printCamera();
  }
  
  public void ortho() {
    if (this.recorder != null)
      this.recorder.ortho(); 
    this.g.ortho();
  }
  
  public void ortho(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.ortho(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.ortho(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void ortho(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.recorder != null)
      this.recorder.ortho(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6); 
    this.g.ortho(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void perspective() {
    if (this.recorder != null)
      this.recorder.perspective(); 
    this.g.perspective();
  }
  
  public void perspective(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.perspective(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.perspective(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void frustum(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.recorder != null)
      this.recorder.frustum(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6); 
    this.g.frustum(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void printProjection() {
    if (this.recorder != null)
      this.recorder.printProjection(); 
    this.g.printProjection();
  }
  
  public float screenX(float paramFloat1, float paramFloat2) {
    return this.g.screenX(paramFloat1, paramFloat2);
  }
  
  public float screenY(float paramFloat1, float paramFloat2) {
    return this.g.screenY(paramFloat1, paramFloat2);
  }
  
  public float screenX(float paramFloat1, float paramFloat2, float paramFloat3) {
    return this.g.screenX(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public float screenY(float paramFloat1, float paramFloat2, float paramFloat3) {
    return this.g.screenY(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public float screenZ(float paramFloat1, float paramFloat2, float paramFloat3) {
    return this.g.screenZ(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public float modelX(float paramFloat1, float paramFloat2, float paramFloat3) {
    return this.g.modelX(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public float modelY(float paramFloat1, float paramFloat2, float paramFloat3) {
    return this.g.modelY(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public float modelZ(float paramFloat1, float paramFloat2, float paramFloat3) {
    return this.g.modelZ(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void pushStyle() {
    if (this.recorder != null)
      this.recorder.pushStyle(); 
    this.g.pushStyle();
  }
  
  public void popStyle() {
    if (this.recorder != null)
      this.recorder.popStyle(); 
    this.g.popStyle();
  }
  
  public void style(PStyle paramPStyle) {
    if (this.recorder != null)
      this.recorder.style(paramPStyle); 
    this.g.style(paramPStyle);
  }
  
  public void strokeWeight(float paramFloat) {
    if (this.recorder != null)
      this.recorder.strokeWeight(paramFloat); 
    this.g.strokeWeight(paramFloat);
  }
  
  public void strokeJoin(int paramInt) {
    if (this.recorder != null)
      this.recorder.strokeJoin(paramInt); 
    this.g.strokeJoin(paramInt);
  }
  
  public void strokeCap(int paramInt) {
    if (this.recorder != null)
      this.recorder.strokeCap(paramInt); 
    this.g.strokeCap(paramInt);
  }
  
  public void noStroke() {
    if (this.recorder != null)
      this.recorder.noStroke(); 
    this.g.noStroke();
  }
  
  public void stroke(int paramInt) {
    if (this.recorder != null)
      this.recorder.stroke(paramInt); 
    this.g.stroke(paramInt);
  }
  
  public void stroke(int paramInt, float paramFloat) {
    if (this.recorder != null)
      this.recorder.stroke(paramInt, paramFloat); 
    this.g.stroke(paramInt, paramFloat);
  }
  
  public void stroke(float paramFloat) {
    if (this.recorder != null)
      this.recorder.stroke(paramFloat); 
    this.g.stroke(paramFloat);
  }
  
  public void stroke(float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.stroke(paramFloat1, paramFloat2); 
    this.g.stroke(paramFloat1, paramFloat2);
  }
  
  public void stroke(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.stroke(paramFloat1, paramFloat2, paramFloat3); 
    this.g.stroke(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void stroke(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.stroke(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.stroke(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void noTint() {
    if (this.recorder != null)
      this.recorder.noTint(); 
    this.g.noTint();
  }
  
  public void tint(int paramInt) {
    if (this.recorder != null)
      this.recorder.tint(paramInt); 
    this.g.tint(paramInt);
  }
  
  public void tint(int paramInt, float paramFloat) {
    if (this.recorder != null)
      this.recorder.tint(paramInt, paramFloat); 
    this.g.tint(paramInt, paramFloat);
  }
  
  public void tint(float paramFloat) {
    if (this.recorder != null)
      this.recorder.tint(paramFloat); 
    this.g.tint(paramFloat);
  }
  
  public void tint(float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.tint(paramFloat1, paramFloat2); 
    this.g.tint(paramFloat1, paramFloat2);
  }
  
  public void tint(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.tint(paramFloat1, paramFloat2, paramFloat3); 
    this.g.tint(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void tint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.tint(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.tint(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void noFill() {
    if (this.recorder != null)
      this.recorder.noFill(); 
    this.g.noFill();
  }
  
  public void fill(int paramInt) {
    if (this.recorder != null)
      this.recorder.fill(paramInt); 
    this.g.fill(paramInt);
  }
  
  public void fill(int paramInt, float paramFloat) {
    if (this.recorder != null)
      this.recorder.fill(paramInt, paramFloat); 
    this.g.fill(paramInt, paramFloat);
  }
  
  public void fill(float paramFloat) {
    if (this.recorder != null)
      this.recorder.fill(paramFloat); 
    this.g.fill(paramFloat);
  }
  
  public void fill(float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.fill(paramFloat1, paramFloat2); 
    this.g.fill(paramFloat1, paramFloat2);
  }
  
  public void fill(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.fill(paramFloat1, paramFloat2, paramFloat3); 
    this.g.fill(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void fill(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.fill(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.fill(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void ambient(int paramInt) {
    if (this.recorder != null)
      this.recorder.ambient(paramInt); 
    this.g.ambient(paramInt);
  }
  
  public void ambient(float paramFloat) {
    if (this.recorder != null)
      this.recorder.ambient(paramFloat); 
    this.g.ambient(paramFloat);
  }
  
  public void ambient(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.ambient(paramFloat1, paramFloat2, paramFloat3); 
    this.g.ambient(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void specular(int paramInt) {
    if (this.recorder != null)
      this.recorder.specular(paramInt); 
    this.g.specular(paramInt);
  }
  
  public void specular(float paramFloat) {
    if (this.recorder != null)
      this.recorder.specular(paramFloat); 
    this.g.specular(paramFloat);
  }
  
  public void specular(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.specular(paramFloat1, paramFloat2, paramFloat3); 
    this.g.specular(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void shininess(float paramFloat) {
    if (this.recorder != null)
      this.recorder.shininess(paramFloat); 
    this.g.shininess(paramFloat);
  }
  
  public void emissive(int paramInt) {
    if (this.recorder != null)
      this.recorder.emissive(paramInt); 
    this.g.emissive(paramInt);
  }
  
  public void emissive(float paramFloat) {
    if (this.recorder != null)
      this.recorder.emissive(paramFloat); 
    this.g.emissive(paramFloat);
  }
  
  public void emissive(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.emissive(paramFloat1, paramFloat2, paramFloat3); 
    this.g.emissive(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void lights() {
    if (this.recorder != null)
      this.recorder.lights(); 
    this.g.lights();
  }
  
  public void noLights() {
    if (this.recorder != null)
      this.recorder.noLights(); 
    this.g.noLights();
  }
  
  public void ambientLight(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.ambientLight(paramFloat1, paramFloat2, paramFloat3); 
    this.g.ambientLight(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void ambientLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.recorder != null)
      this.recorder.ambientLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6); 
    this.g.ambientLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void directionalLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.recorder != null)
      this.recorder.directionalLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6); 
    this.g.directionalLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void pointLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.recorder != null)
      this.recorder.pointLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6); 
    this.g.pointLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void spotLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11) {
    if (this.recorder != null)
      this.recorder.spotLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11); 
    this.g.spotLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11);
  }
  
  public void lightFalloff(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.lightFalloff(paramFloat1, paramFloat2, paramFloat3); 
    this.g.lightFalloff(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void lightSpecular(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.lightSpecular(paramFloat1, paramFloat2, paramFloat3); 
    this.g.lightSpecular(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void background(int paramInt) {
    if (this.recorder != null)
      this.recorder.background(paramInt); 
    this.g.background(paramInt);
  }
  
  public void background(int paramInt, float paramFloat) {
    if (this.recorder != null)
      this.recorder.background(paramInt, paramFloat); 
    this.g.background(paramInt, paramFloat);
  }
  
  public void background(float paramFloat) {
    if (this.recorder != null)
      this.recorder.background(paramFloat); 
    this.g.background(paramFloat);
  }
  
  public void background(float paramFloat1, float paramFloat2) {
    if (this.recorder != null)
      this.recorder.background(paramFloat1, paramFloat2); 
    this.g.background(paramFloat1, paramFloat2);
  }
  
  public void background(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.background(paramFloat1, paramFloat2, paramFloat3); 
    this.g.background(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void background(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.background(paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.background(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void background(PImage paramPImage) {
    if (this.recorder != null)
      this.recorder.background(paramPImage); 
    this.g.background(paramPImage);
  }
  
  public void colorMode(int paramInt) {
    if (this.recorder != null)
      this.recorder.colorMode(paramInt); 
    this.g.colorMode(paramInt);
  }
  
  public void colorMode(int paramInt, float paramFloat) {
    if (this.recorder != null)
      this.recorder.colorMode(paramInt, paramFloat); 
    this.g.colorMode(paramInt, paramFloat);
  }
  
  public void colorMode(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.recorder != null)
      this.recorder.colorMode(paramInt, paramFloat1, paramFloat2, paramFloat3); 
    this.g.colorMode(paramInt, paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void colorMode(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.recorder != null)
      this.recorder.colorMode(paramInt, paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
    this.g.colorMode(paramInt, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public final float alpha(int paramInt) {
    return this.g.alpha(paramInt);
  }
  
  public final float red(int paramInt) {
    return this.g.red(paramInt);
  }
  
  public final float green(int paramInt) {
    return this.g.green(paramInt);
  }
  
  public final float blue(int paramInt) {
    return this.g.blue(paramInt);
  }
  
  public final float hue(int paramInt) {
    return this.g.hue(paramInt);
  }
  
  public final float saturation(int paramInt) {
    return this.g.saturation(paramInt);
  }
  
  public final float brightness(int paramInt) {
    return this.g.brightness(paramInt);
  }
  
  public int lerpColor(int paramInt1, int paramInt2, float paramFloat) {
    return this.g.lerpColor(paramInt1, paramInt2, paramFloat);
  }
  
  public static int lerpColor(int paramInt1, int paramInt2, float paramFloat, int paramInt3) {
    return PGraphics.lerpColor(paramInt1, paramInt2, paramFloat, paramInt3);
  }
  
  public static void showDepthWarning(String paramString) {
    PGraphics.showDepthWarning(paramString);
  }
  
  public static void showDepthWarningXYZ(String paramString) {
    PGraphics.showDepthWarningXYZ(paramString);
  }
  
  public static void showMethodWarning(String paramString) {
    PGraphics.showMethodWarning(paramString);
  }
  
  public static void showVariationWarning(String paramString) {
    PGraphics.showVariationWarning(paramString);
  }
  
  public static void showMissingWarning(String paramString) {
    PGraphics.showMissingWarning(paramString);
  }
  
  public boolean displayable() {
    return this.g.displayable();
  }
  
  public void screenBlend(int paramInt) {
    if (this.recorder != null)
      this.recorder.screenBlend(paramInt); 
    this.g.screenBlend(paramInt);
  }
  
  public void textureBlend(int paramInt) {
    if (this.recorder != null)
      this.recorder.textureBlend(paramInt); 
    this.g.textureBlend(paramInt);
  }
  
  public boolean isRecording() {
    return this.g.isRecording();
  }
  
  public void mergeShapes(boolean paramBoolean) {
    if (this.recorder != null)
      this.recorder.mergeShapes(paramBoolean); 
    this.g.mergeShapes(paramBoolean);
  }
  
  public void shapeName(String paramString) {
    if (this.recorder != null)
      this.recorder.shapeName(paramString); 
    this.g.shapeName(paramString);
  }
  
  public void autoNormal(boolean paramBoolean) {
    if (this.recorder != null)
      this.recorder.autoNormal(paramBoolean); 
    this.g.autoNormal(paramBoolean);
  }
  
  public void matrixMode(int paramInt) {
    if (this.recorder != null)
      this.recorder.matrixMode(paramInt); 
    this.g.matrixMode(paramInt);
  }
  
  public void beginText() {
    if (this.recorder != null)
      this.recorder.beginText(); 
    this.g.beginText();
  }
  
  public void endText() {
    if (this.recorder != null)
      this.recorder.endText(); 
    this.g.endText();
  }
  
  public void texture(PImage... paramVarArgs) {
    if (this.recorder != null)
      this.recorder.texture(paramVarArgs); 
    this.g.texture(paramVarArgs);
  }
  
  public void vertex(float... paramVarArgs) {
    if (this.recorder != null)
      this.recorder.vertex(paramVarArgs); 
    this.g.vertex(paramVarArgs);
  }
  
  public void delete() {
    if (this.recorder != null)
      this.recorder.delete(); 
    this.g.delete();
  }
  
  public void setCache(PGraphics paramPGraphics, Object paramObject) {
    if (this.recorder != null)
      this.recorder.setCache(paramPGraphics, paramObject); 
    this.g.setCache(paramPGraphics, paramObject);
  }
  
  public Object getCache(PGraphics paramPGraphics) {
    return this.g.getCache(paramPGraphics);
  }
  
  public void removeCache(PGraphics paramPGraphics) {
    if (this.recorder != null)
      this.recorder.removeCache(paramPGraphics); 
    this.g.removeCache(paramPGraphics);
  }
  
  public void setParams(PGraphics paramPGraphics, Object paramObject) {
    if (this.recorder != null)
      this.recorder.setParams(paramPGraphics, paramObject); 
    this.g.setParams(paramPGraphics, paramObject);
  }
  
  public Object getParams(PGraphics paramPGraphics) {
    return this.g.getParams(paramPGraphics);
  }
  
  public void removeParams(PGraphics paramPGraphics) {
    if (this.recorder != null)
      this.recorder.removeParams(paramPGraphics); 
    this.g.removeParams(paramPGraphics);
  }
  
  public int get(int paramInt1, int paramInt2) {
    return this.g.get(paramInt1, paramInt2);
  }
  
  public PImage get(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return this.g.get(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public PImage get() {
    return this.g.get();
  }
  
  public void set(int paramInt1, int paramInt2, int paramInt3) {
    if (this.recorder != null)
      this.recorder.set(paramInt1, paramInt2, paramInt3); 
    this.g.set(paramInt1, paramInt2, paramInt3);
  }
  
  public void set(int paramInt1, int paramInt2, PImage paramPImage) {
    if (this.recorder != null)
      this.recorder.set(paramInt1, paramInt2, paramPImage); 
    this.g.set(paramInt1, paramInt2, paramPImage);
  }
  
  public void mask(int[] paramArrayOfint) {
    if (this.recorder != null)
      this.recorder.mask(paramArrayOfint); 
    this.g.mask(paramArrayOfint);
  }
  
  public void mask(PImage paramPImage) {
    if (this.recorder != null)
      this.recorder.mask(paramPImage); 
    this.g.mask(paramPImage);
  }
  
  public void filter(int paramInt) {
    if (this.recorder != null)
      this.recorder.filter(paramInt); 
    this.g.filter(paramInt);
  }
  
  public void filter(int paramInt, float paramFloat) {
    if (this.recorder != null)
      this.recorder.filter(paramInt, paramFloat); 
    this.g.filter(paramInt, paramFloat);
  }
  
  public void copy(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
    if (this.recorder != null)
      this.recorder.copy(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8); 
    this.g.copy(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
  }
  
  public void copy(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
    if (this.recorder != null)
      this.recorder.copy(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8); 
    this.g.copy(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
  }
  
  public static int blendColor(int paramInt1, int paramInt2, int paramInt3) {
    return PGraphics.blendColor(paramInt1, paramInt2, paramInt3);
  }
  
  public void blend(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    if (this.recorder != null)
      this.recorder.blend(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9); 
    this.g.blend(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
  }
  
  public void blend(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    if (this.recorder != null)
      this.recorder.blend(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9); 
    this.g.blend(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
  }
  
  static {
    String str = System.getProperty("os.name");
    if (str.indexOf("Mac") != -1) {
      platform = 2;
    } else if (str.indexOf("Windows") != -1) {
      platform = 1;
    } else if (str.equals("Linux")) {
      platform = 3;
    } else {
      platform = 0;
    } 
  }
  
  class AsyncImageLoader extends Thread {
    String filename;
    
    String extension;
    
    PImage vessel;
    
    public AsyncImageLoader(String param1String1, String param1String2, PImage param1PImage) {
      this.filename = param1String1;
      this.extension = param1String2;
      this.vessel = param1PImage;
    }
    
    public void run() {
      while (PApplet.this.requestImageCount == PApplet.this.requestImageMax) {
        try {
          Thread.sleep(10L);
        } catch (InterruptedException interruptedException) {}
      } 
      PApplet.this.requestImageCount++;
      PImage pImage = PApplet.this.loadImage(this.filename, this.extension);
      if (pImage == null) {
        this.vessel.width = -1;
        this.vessel.height = -1;
      } else {
        this.vessel.width = pImage.width;
        this.vessel.height = pImage.height;
        this.vessel.format = pImage.format;
        this.vessel.pixels = pImage.pixels;
      } 
      PApplet.this.requestImageCount--;
    }
  }
  
  public class RegisteredMethods {
    int count;
    
    Object[] objects;
    
    Method[] methods;
    
    public void handle() {
      handle(new Object[0]);
    }
    
    public void handle(Object[] param1ArrayOfObject) {
      for (byte b = 0; b < this.count; b++) {
        try {
          this.methods[b].invoke(this.objects[b], param1ArrayOfObject);
        } catch (Exception exception) {
          if (exception instanceof InvocationTargetException) {
            InvocationTargetException invocationTargetException = (InvocationTargetException)exception;
            invocationTargetException.getTargetException().printStackTrace();
          } else {
            exception.printStackTrace();
          } 
        } 
      } 
    }
    
    public void add(Object param1Object, Method param1Method) {
      if (this.objects == null) {
        this.objects = new Object[5];
        this.methods = new Method[5];
      } 
      if (this.count == this.objects.length) {
        this.objects = (Object[])PApplet.expand(this.objects);
        this.methods = (Method[])PApplet.expand(this.methods);
      } 
      this.objects[this.count] = param1Object;
      this.methods[this.count] = param1Method;
      this.count++;
    }
    
    public void remove(Object param1Object, Method param1Method) {
      int i = findIndex(param1Object, param1Method);
      if (i != -1) {
        this.count--;
        for (int j = i; j < this.count; j++) {
          this.objects[j] = this.objects[j + 1];
          this.methods[j] = this.methods[j + 1];
        } 
        this.objects[this.count] = null;
        this.methods[this.count] = null;
      } 
    }
    
    protected int findIndex(Object param1Object, Method param1Method) {
      for (byte b = 0; b < this.count; b++) {
        if (this.objects[b] == param1Object && this.methods[b].equals(param1Method))
          return b; 
      } 
      return -1;
    }
  }
  
  public static class RendererChangeException extends RuntimeException {}
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PApplet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */