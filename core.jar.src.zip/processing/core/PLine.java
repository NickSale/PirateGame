package processing.core;

public class PLine implements PConstants {
  private int[] m_pixels;
  
  private float[] m_zbuffer;
  
  private int m_index;
  
  static final int R_COLOR = 1;
  
  static final int R_ALPHA = 2;
  
  static final int R_SPATIAL = 8;
  
  static final int R_THICK = 4;
  
  static final int R_SMOOTH = 16;
  
  private int SCREEN_WIDTH;
  
  private int SCREEN_HEIGHT;
  
  private int SCREEN_WIDTH1;
  
  private int SCREEN_HEIGHT1;
  
  public boolean INTERPOLATE_RGB;
  
  public boolean INTERPOLATE_ALPHA;
  
  public boolean INTERPOLATE_Z = false;
  
  public boolean INTERPOLATE_THICK;
  
  private boolean SMOOTH;
  
  private int m_stroke;
  
  public int m_drawFlags;
  
  private float[] x_array = new float[2];
  
  private float[] y_array = new float[2];
  
  private float[] z_array = new float[2];
  
  private float[] r_array = new float[2];
  
  private float[] g_array = new float[2];
  
  private float[] b_array = new float[2];
  
  private float[] a_array = new float[2];
  
  private int o0;
  
  private int o1;
  
  private float m_r0;
  
  private float m_g0;
  
  private float m_b0;
  
  private float m_a0;
  
  private float m_z0;
  
  private float dz;
  
  private float dr;
  
  private float dg;
  
  private float db;
  
  private float da;
  
  private PGraphics parent;
  
  public PLine(PGraphics paramPGraphics) {
    this.parent = paramPGraphics;
  }
  
  public void reset() {
    this.SCREEN_WIDTH = this.parent.width;
    this.SCREEN_HEIGHT = this.parent.height;
    this.SCREEN_WIDTH1 = this.SCREEN_WIDTH - 1;
    this.SCREEN_HEIGHT1 = this.SCREEN_HEIGHT - 1;
    this.m_pixels = this.parent.pixels;
    if (this.parent instanceof PGraphics3D)
      this.m_zbuffer = ((PGraphics3D)this.parent).zbuffer; 
    this.INTERPOLATE_RGB = false;
    this.INTERPOLATE_ALPHA = false;
    this.m_drawFlags = 0;
    this.m_index = 0;
  }
  
  public void setVertices(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (paramFloat3 != paramFloat6 || paramFloat3 != 0.0F || paramFloat6 != 0.0F || this.INTERPOLATE_Z) {
      this.INTERPOLATE_Z = true;
      this.m_drawFlags |= 0x8;
    } else {
      this.INTERPOLATE_Z = false;
      this.m_drawFlags &= 0xFFFFFFF7;
    } 
    this.z_array[0] = paramFloat3;
    this.z_array[1] = paramFloat6;
    this.x_array[0] = paramFloat1;
    this.x_array[1] = paramFloat4;
    this.y_array[0] = paramFloat2;
    this.y_array[1] = paramFloat5;
  }
  
  public void setIntensities(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    this.a_array[0] = (paramFloat4 * 253.0F + 1.0F) * 65536.0F;
    this.a_array[1] = (paramFloat8 * 253.0F + 1.0F) * 65536.0F;
    if (paramFloat4 != 1.0F || paramFloat8 != 1.0F) {
      this.INTERPOLATE_ALPHA = true;
      this.m_drawFlags |= 0x2;
    } else {
      this.INTERPOLATE_ALPHA = false;
      this.m_drawFlags &= 0xFFFFFFFD;
    } 
    this.r_array[0] = (paramFloat1 * 253.0F + 1.0F) * 65536.0F;
    this.r_array[1] = (paramFloat5 * 253.0F + 1.0F) * 65536.0F;
    this.g_array[0] = (paramFloat2 * 253.0F + 1.0F) * 65536.0F;
    this.g_array[1] = (paramFloat6 * 253.0F + 1.0F) * 65536.0F;
    this.b_array[0] = (paramFloat3 * 253.0F + 1.0F) * 65536.0F;
    this.b_array[1] = (paramFloat7 * 253.0F + 1.0F) * 65536.0F;
    if (paramFloat1 != paramFloat5) {
      this.INTERPOLATE_RGB = true;
      this.m_drawFlags |= 0x1;
    } else if (paramFloat2 != paramFloat6) {
      this.INTERPOLATE_RGB = true;
      this.m_drawFlags |= 0x1;
    } else if (paramFloat3 != paramFloat7) {
      this.INTERPOLATE_RGB = true;
      this.m_drawFlags |= 0x1;
    } else {
      this.m_stroke = 0xFF000000 | (int)(255.0F * paramFloat1) << 16 | (int)(255.0F * paramFloat2) << 8 | (int)(255.0F * paramFloat3);
      this.INTERPOLATE_RGB = false;
      this.m_drawFlags &= 0xFFFFFFFE;
    } 
  }
  
  public void setIndex(int paramInt) {
    this.m_index = paramInt;
    if (this.m_index == -1)
      this.m_index = 0; 
  }
  
  public void draw() {
    int i;
    int j;
    int k;
    int i1;
    boolean bool = true;
    if (this.parent.smooth) {
      this.SMOOTH = true;
      this.m_drawFlags |= 0x10;
    } else {
      this.SMOOTH = false;
      this.m_drawFlags &= 0xFFFFFFEF;
    } 
    bool = lineClipping();
    if (!bool)
      return; 
    boolean bool1 = false;
    if (this.x_array[1] < this.x_array[0]) {
      float f = this.x_array[1];
      this.x_array[1] = this.x_array[0];
      this.x_array[0] = f;
      f = this.y_array[1];
      this.y_array[1] = this.y_array[0];
      this.y_array[0] = f;
      f = this.z_array[1];
      this.z_array[1] = this.z_array[0];
      this.z_array[0] = f;
      f = this.r_array[1];
      this.r_array[1] = this.r_array[0];
      this.r_array[0] = f;
      f = this.g_array[1];
      this.g_array[1] = this.g_array[0];
      this.g_array[0] = f;
      f = this.b_array[1];
      this.b_array[1] = this.b_array[0];
      this.b_array[0] = f;
      f = this.a_array[1];
      this.a_array[1] = this.a_array[0];
      this.a_array[0] = f;
    } 
    int n = (int)this.x_array[1] - (int)this.x_array[0];
    int m = (int)this.y_array[1] - (int)this.y_array[0];
    if (Math.abs(m) > Math.abs(n)) {
      int i2 = m;
      m = n;
      n = i2;
      bool1 = true;
    } 
    if (n < 0) {
      this.o0 = 1;
      this.o1 = 0;
      i = (int)this.x_array[1];
      j = (int)this.y_array[1];
      k = -n;
    } else {
      this.o0 = 0;
      this.o1 = 1;
      i = (int)this.x_array[0];
      j = (int)this.y_array[0];
      k = n;
    } 
    if (k == 0) {
      i1 = 0;
    } else {
      i1 = (m << 16) / n;
    } 
    this.m_r0 = this.r_array[this.o0];
    this.m_g0 = this.g_array[this.o0];
    this.m_b0 = this.b_array[this.o0];
    if (this.INTERPOLATE_RGB) {
      this.dr = (this.r_array[this.o1] - this.r_array[this.o0]) / k;
      this.dg = (this.g_array[this.o1] - this.g_array[this.o0]) / k;
      this.db = (this.b_array[this.o1] - this.b_array[this.o0]) / k;
    } else {
      this.dr = 0.0F;
      this.dg = 0.0F;
      this.db = 0.0F;
    } 
    this.m_a0 = this.a_array[this.o0];
    if (this.INTERPOLATE_ALPHA) {
      this.da = (this.a_array[this.o1] - this.a_array[this.o0]) / k;
    } else {
      this.da = 0.0F;
    } 
    this.m_z0 = this.z_array[this.o0];
    if (this.INTERPOLATE_Z) {
      this.dz = (this.z_array[this.o1] - this.z_array[this.o0]) / k;
    } else {
      this.dz = 0.0F;
    } 
    if (k == 0) {
      if (this.INTERPOLATE_ALPHA) {
        drawPoint_alpha(i, j);
      } else {
        drawPoint(i, j);
      } 
      return;
    } 
    if (this.SMOOTH) {
      drawLine_smooth(i, j, i1, k, bool1);
    } else if (this.m_drawFlags == 0) {
      drawLine_plain(i, j, i1, k, bool1);
    } else if (this.m_drawFlags == 2) {
      drawLine_plain_alpha(i, j, i1, k, bool1);
    } else if (this.m_drawFlags == 1) {
      drawLine_color(i, j, i1, k, bool1);
    } else if (this.m_drawFlags == 3) {
      drawLine_color_alpha(i, j, i1, k, bool1);
    } else if (this.m_drawFlags == 8) {
      drawLine_plain_spatial(i, j, i1, k, bool1);
    } else if (this.m_drawFlags == 10) {
      drawLine_plain_alpha_spatial(i, j, i1, k, bool1);
    } else if (this.m_drawFlags == 9) {
      drawLine_color_spatial(i, j, i1, k, bool1);
    } else if (this.m_drawFlags == 11) {
      drawLine_color_alpha_spatial(i, j, i1, k, bool1);
    } 
  }
  
  public boolean lineClipping() {
    int i = lineClipCode(this.x_array[0], this.y_array[0]);
    int j = lineClipCode(this.x_array[1], this.y_array[1]);
    int k = i | j;
    if ((i & j) != 0)
      return false; 
    if (k != 0) {
      float f1 = 0.0F;
      float f2 = 1.0F;
      float f3 = 0.0F;
      for (byte b = 0; b < 4; b++) {
        if ((k >> b) % 2 == 1) {
          f3 = lineSlope(this.x_array[0], this.y_array[0], this.x_array[1], this.y_array[1], b + 1);
          if ((i >> b) % 2 == 1) {
            f1 = (f3 > f1) ? f3 : f1;
          } else {
            f2 = (f3 < f2) ? f3 : f2;
          } 
        } 
      } 
      if (f1 > f2)
        return false; 
      float f4 = this.x_array[0];
      float f5 = this.y_array[0];
      this.x_array[0] = f4 + f1 * (this.x_array[1] - f4);
      this.y_array[0] = f5 + f1 * (this.y_array[1] - f5);
      this.x_array[1] = f4 + f2 * (this.x_array[1] - f4);
      this.y_array[1] = f5 + f2 * (this.y_array[1] - f5);
      if (this.INTERPOLATE_RGB) {
        float f = this.r_array[0];
        this.r_array[0] = f + f1 * (this.r_array[1] - f);
        this.r_array[1] = f + f2 * (this.r_array[1] - f);
        f = this.g_array[0];
        this.g_array[0] = f + f1 * (this.g_array[1] - f);
        this.g_array[1] = f + f2 * (this.g_array[1] - f);
        f = this.b_array[0];
        this.b_array[0] = f + f1 * (this.b_array[1] - f);
        this.b_array[1] = f + f2 * (this.b_array[1] - f);
      } 
      if (this.INTERPOLATE_ALPHA) {
        float f = this.a_array[0];
        this.a_array[0] = f + f1 * (this.a_array[1] - f);
        this.a_array[1] = f + f2 * (this.a_array[1] - f);
      } 
    } 
    return true;
  }
  
  private int lineClipCode(float paramFloat1, float paramFloat2) {
    boolean bool1 = false;
    boolean bool2 = false;
    int i = this.SCREEN_WIDTH1;
    int j = this.SCREEN_HEIGHT1;
    return ((paramFloat2 < bool2) ? 8 : 0) | (((int)paramFloat2 > j) ? 4 : 0) | ((paramFloat1 < bool1) ? 2 : 0) | (((int)paramFloat1 > i) ? 1 : 0);
  }
  
  private float lineSlope(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt) {
    boolean bool1 = false;
    boolean bool2 = false;
    int i = this.SCREEN_WIDTH1;
    int j = this.SCREEN_HEIGHT1;
    switch (paramInt) {
      case 4:
        return (bool2 - paramFloat2) / (paramFloat4 - paramFloat2);
      case 3:
        return (j - paramFloat2) / (paramFloat4 - paramFloat2);
      case 2:
        return (bool1 - paramFloat1) / (paramFloat3 - paramFloat1);
      case 1:
        return (i - paramFloat1) / (paramFloat3 - paramFloat1);
    } 
    return -1.0F;
  }
  
  private void drawPoint(int paramInt1, int paramInt2) {
    float f = this.m_z0;
    int i = paramInt2 * this.SCREEN_WIDTH + paramInt1;
    if (this.m_zbuffer == null) {
      this.m_pixels[i] = this.m_stroke;
    } else if (f <= this.m_zbuffer[i]) {
      this.m_pixels[i] = this.m_stroke;
      this.m_zbuffer[i] = f;
    } 
  }
  
  private void drawPoint_alpha(int paramInt1, int paramInt2) {
    int i = (int)this.a_array[0];
    int j = this.m_stroke & 0xFF0000;
    int k = this.m_stroke & 0xFF00;
    int m = this.m_stroke & 0xFF;
    float f = this.m_z0;
    int n = paramInt2 * this.SCREEN_WIDTH + paramInt1;
    if (this.m_zbuffer == null || f <= this.m_zbuffer[n]) {
      int i1 = i >> 16;
      int i2 = this.m_pixels[n];
      int i3 = i2 & 0xFF00;
      int i4 = i2 & 0xFF;
      i2 &= 0xFF0000;
      i2 += (j - i2) * i1 >> 8;
      i3 += (k - i3) * i1 >> 8;
      i4 += (m - i4) * i1 >> 8;
      this.m_pixels[n] = 0xFF000000 | i2 & 0xFF0000 | i3 & 0xFF00 | i4 & 0xFF;
      if (this.m_zbuffer != null)
        this.m_zbuffer[n] = f; 
    } 
  }
  
  private void drawLine_plain(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    int i = 0;
    if (paramBoolean) {
      paramInt4 += paramInt2;
      int j = 32768 + (paramInt1 << 16);
      while (paramInt2 <= paramInt4) {
        i = paramInt2 * this.SCREEN_WIDTH + (j >> 16);
        this.m_pixels[i] = this.m_stroke;
        if (this.m_zbuffer != null)
          this.m_zbuffer[i] = this.m_z0; 
        j += paramInt3;
        paramInt2++;
      } 
    } else {
      paramInt4 += paramInt1;
      int j = 32768 + (paramInt2 << 16);
      while (paramInt1 <= paramInt4) {
        i = (j >> 16) * this.SCREEN_WIDTH + paramInt1;
        this.m_pixels[i] = this.m_stroke;
        if (this.m_zbuffer != null)
          this.m_zbuffer[i] = this.m_z0; 
        j += paramInt3;
        paramInt1++;
      } 
    } 
  }
  
  private void drawLine_plain_alpha(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    int i = 0;
    int j = this.m_stroke & 0xFF0000;
    int k = this.m_stroke & 0xFF00;
    int m = this.m_stroke & 0xFF;
    int n = (int)this.m_a0;
    if (paramBoolean) {
      paramInt4 += paramInt2;
      int i1 = 32768 + (paramInt1 << 16);
      while (paramInt2 <= paramInt4) {
        i = paramInt2 * this.SCREEN_WIDTH + (i1 >> 16);
        int i2 = n >> 16;
        int i3 = this.m_pixels[i];
        int i4 = i3 & 0xFF00;
        int i5 = i3 & 0xFF;
        i3 &= 0xFF0000;
        i3 += (j - i3) * i2 >> 8;
        i4 += (k - i4) * i2 >> 8;
        i5 += (m - i5) * i2 >> 8;
        this.m_pixels[i] = 0xFF000000 | i3 & 0xFF0000 | i4 & 0xFF00 | i5 & 0xFF;
        n = (int)(n + this.da);
        i1 += paramInt3;
        paramInt2++;
      } 
    } else {
      paramInt4 += paramInt1;
      int i1 = 32768 + (paramInt2 << 16);
      while (paramInt1 <= paramInt4) {
        i = (i1 >> 16) * this.SCREEN_WIDTH + paramInt1;
        int i2 = n >> 16;
        int i3 = this.m_pixels[i];
        int i4 = i3 & 0xFF00;
        int i5 = i3 & 0xFF;
        i3 &= 0xFF0000;
        i3 += (j - i3) * i2 >> 8;
        i4 += (k - i4) * i2 >> 8;
        i5 += (m - i5) * i2 >> 8;
        this.m_pixels[i] = 0xFF000000 | i3 & 0xFF0000 | i4 & 0xFF00 | i5 & 0xFF;
        n = (int)(n + this.da);
        i1 += paramInt3;
        paramInt1++;
      } 
    } 
  }
  
  private void drawLine_color(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    int i = 0;
    int j = (int)this.m_r0;
    int k = (int)this.m_g0;
    int m = (int)this.m_b0;
    if (paramBoolean) {
      paramInt4 += paramInt2;
      int n = 32768 + (paramInt1 << 16);
      while (paramInt2 <= paramInt4) {
        i = paramInt2 * this.SCREEN_WIDTH + (n >> 16);
        this.m_pixels[i] = 0xFF000000 | j & 0xFF0000 | k >> 8 & 0xFF00 | m >> 16;
        if (this.m_zbuffer != null)
          this.m_zbuffer[i] = this.m_z0; 
        j = (int)(j + this.dr);
        k = (int)(k + this.dg);
        m = (int)(m + this.db);
        n += paramInt3;
        paramInt2++;
      } 
    } else {
      paramInt4 += paramInt1;
      int n = 32768 + (paramInt2 << 16);
      while (paramInt1 <= paramInt4) {
        i = (n >> 16) * this.SCREEN_WIDTH + paramInt1;
        this.m_pixels[i] = 0xFF000000 | j & 0xFF0000 | k >> 8 & 0xFF00 | m >> 16;
        if (this.m_zbuffer != null)
          this.m_zbuffer[i] = this.m_z0; 
        j = (int)(j + this.dr);
        k = (int)(k + this.dg);
        m = (int)(m + this.db);
        n += paramInt3;
        paramInt1++;
      } 
    } 
  }
  
  private void drawLine_color_alpha(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    int i = 0;
    int j = (int)this.m_r0;
    int k = (int)this.m_g0;
    int m = (int)this.m_b0;
    int n = (int)this.m_a0;
    if (paramBoolean) {
      paramInt4 += paramInt2;
      int i1 = 32768 + (paramInt1 << 16);
      while (paramInt2 <= paramInt4) {
        i = paramInt2 * this.SCREEN_WIDTH + (i1 >> 16);
        int i2 = j & 0xFF0000;
        int i3 = k >> 8 & 0xFF00;
        int i4 = m >> 16;
        int i5 = this.m_pixels[i];
        int i6 = i5 & 0xFF00;
        int i7 = i5 & 0xFF;
        i5 &= 0xFF0000;
        int i8 = n >> 16;
        i5 += (i2 - i5) * i8 >> 8;
        i6 += (i3 - i6) * i8 >> 8;
        i7 += (i4 - i7) * i8 >> 8;
        this.m_pixels[i] = 0xFF000000 | i5 & 0xFF0000 | i6 & 0xFF00 | i7 & 0xFF;
        if (this.m_zbuffer != null)
          this.m_zbuffer[i] = this.m_z0; 
        j = (int)(j + this.dr);
        k = (int)(k + this.dg);
        m = (int)(m + this.db);
        n = (int)(n + this.da);
        i1 += paramInt3;
        paramInt2++;
      } 
    } else {
      paramInt4 += paramInt1;
      int i1 = 32768 + (paramInt2 << 16);
      while (paramInt1 <= paramInt4) {
        i = (i1 >> 16) * this.SCREEN_WIDTH + paramInt1;
        int i2 = j & 0xFF0000;
        int i3 = k >> 8 & 0xFF00;
        int i4 = m >> 16;
        int i5 = this.m_pixels[i];
        int i6 = i5 & 0xFF00;
        int i7 = i5 & 0xFF;
        i5 &= 0xFF0000;
        int i8 = n >> 16;
        i5 += (i2 - i5) * i8 >> 8;
        i6 += (i3 - i6) * i8 >> 8;
        i7 += (i4 - i7) * i8 >> 8;
        this.m_pixels[i] = 0xFF000000 | i5 & 0xFF0000 | i6 & 0xFF00 | i7 & 0xFF;
        if (this.m_zbuffer != null)
          this.m_zbuffer[i] = this.m_z0; 
        j = (int)(j + this.dr);
        k = (int)(k + this.dg);
        m = (int)(m + this.db);
        n = (int)(n + this.da);
        i1 += paramInt3;
        paramInt1++;
      } 
    } 
  }
  
  private void drawLine_plain_spatial(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    int i = 0;
    float f = this.m_z0;
    if (paramBoolean) {
      paramInt4 += paramInt2;
      int j = 32768 + (paramInt1 << 16);
      while (paramInt2 <= paramInt4) {
        i = paramInt2 * this.SCREEN_WIDTH + (j >> 16);
        if (i < this.m_pixels.length && f <= this.m_zbuffer[i]) {
          this.m_pixels[i] = this.m_stroke;
          this.m_zbuffer[i] = f;
        } 
        f += this.dz;
        j += paramInt3;
        paramInt2++;
      } 
    } else {
      paramInt4 += paramInt1;
      int j = 32768 + (paramInt2 << 16);
      while (paramInt1 <= paramInt4) {
        i = (j >> 16) * this.SCREEN_WIDTH + paramInt1;
        if (i < this.m_pixels.length && f <= this.m_zbuffer[i]) {
          this.m_pixels[i] = this.m_stroke;
          this.m_zbuffer[i] = f;
        } 
        f += this.dz;
        j += paramInt3;
        paramInt1++;
      } 
    } 
  }
  
  private void drawLine_plain_alpha_spatial(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    int i = 0;
    float f = this.m_z0;
    int j = this.m_stroke & 0xFF0000;
    int k = this.m_stroke & 0xFF00;
    int m = this.m_stroke & 0xFF;
    int n = (int)this.m_a0;
    if (paramBoolean) {
      paramInt4 += paramInt2;
      int i1 = 32768 + (paramInt1 << 16);
      while (paramInt2 <= paramInt4) {
        i = paramInt2 * this.SCREEN_WIDTH + (i1 >> 16);
        if (i < this.m_pixels.length && f <= this.m_zbuffer[i]) {
          int i2 = n >> 16;
          int i3 = this.m_pixels[i];
          int i4 = i3 & 0xFF00;
          int i5 = i3 & 0xFF;
          i3 &= 0xFF0000;
          i3 += (j - i3) * i2 >> 8;
          i4 += (k - i4) * i2 >> 8;
          i5 += (m - i5) * i2 >> 8;
          this.m_pixels[i] = 0xFF000000 | i3 & 0xFF0000 | i4 & 0xFF00 | i5 & 0xFF;
          this.m_zbuffer[i] = f;
        } 
        f += this.dz;
        n = (int)(n + this.da);
        i1 += paramInt3;
        paramInt2++;
      } 
    } else {
      paramInt4 += paramInt1;
      int i1 = 32768 + (paramInt2 << 16);
      while (paramInt1 <= paramInt4) {
        i = (i1 >> 16) * this.SCREEN_WIDTH + paramInt1;
        if (i < this.m_pixels.length && f <= this.m_zbuffer[i]) {
          int i2 = n >> 16;
          int i3 = this.m_pixels[i];
          int i4 = i3 & 0xFF00;
          int i5 = i3 & 0xFF;
          i3 &= 0xFF0000;
          i3 += (j - i3) * i2 >> 8;
          i4 += (k - i4) * i2 >> 8;
          i5 += (m - i5) * i2 >> 8;
          this.m_pixels[i] = 0xFF000000 | i3 & 0xFF0000 | i4 & 0xFF00 | i5 & 0xFF;
          this.m_zbuffer[i] = f;
        } 
        f += this.dz;
        n = (int)(n + this.da);
        i1 += paramInt3;
        paramInt1++;
      } 
    } 
  }
  
  private void drawLine_color_spatial(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    int i = 0;
    float f = this.m_z0;
    int j = (int)this.m_r0;
    int k = (int)this.m_g0;
    int m = (int)this.m_b0;
    if (paramBoolean) {
      paramInt4 += paramInt2;
      int n = 32768 + (paramInt1 << 16);
      while (paramInt2 <= paramInt4) {
        i = paramInt2 * this.SCREEN_WIDTH + (n >> 16);
        if (f <= this.m_zbuffer[i]) {
          this.m_pixels[i] = 0xFF000000 | j & 0xFF0000 | k >> 8 & 0xFF00 | m >> 16;
          this.m_zbuffer[i] = f;
        } 
        f += this.dz;
        j = (int)(j + this.dr);
        k = (int)(k + this.dg);
        m = (int)(m + this.db);
        n += paramInt3;
        paramInt2++;
      } 
    } else {
      paramInt4 += paramInt1;
      int n = 32768 + (paramInt2 << 16);
      while (paramInt1 <= paramInt4) {
        i = (n >> 16) * this.SCREEN_WIDTH + paramInt1;
        if (f <= this.m_zbuffer[i]) {
          this.m_pixels[i] = 0xFF000000 | j & 0xFF0000 | k >> 8 & 0xFF00 | m >> 16;
          this.m_zbuffer[i] = f;
        } 
        f += this.dz;
        j = (int)(j + this.dr);
        k = (int)(k + this.dg);
        m = (int)(m + this.db);
        n += paramInt3;
        paramInt1++;
      } 
      return;
    } 
  }
  
  private void drawLine_color_alpha_spatial(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    int i = 0;
    float f = this.m_z0;
    int j = (int)this.m_r0;
    int k = (int)this.m_g0;
    int m = (int)this.m_b0;
    int n = (int)this.m_a0;
    if (paramBoolean) {
      paramInt4 += paramInt2;
      int i1 = 32768 + (paramInt1 << 16);
      while (paramInt2 <= paramInt4) {
        i = paramInt2 * this.SCREEN_WIDTH + (i1 >> 16);
        if (f <= this.m_zbuffer[i]) {
          int i2 = j & 0xFF0000;
          int i3 = k >> 8 & 0xFF00;
          int i4 = m >> 16;
          int i5 = this.m_pixels[i];
          int i6 = i5 & 0xFF00;
          int i7 = i5 & 0xFF;
          i5 &= 0xFF0000;
          int i8 = n >> 16;
          i5 += (i2 - i5) * i8 >> 8;
          i6 += (i3 - i6) * i8 >> 8;
          i7 += (i4 - i7) * i8 >> 8;
          this.m_pixels[i] = 0xFF000000 | i5 & 0xFF0000 | i6 & 0xFF00 | i7 & 0xFF;
          this.m_zbuffer[i] = f;
        } 
        f += this.dz;
        j = (int)(j + this.dr);
        k = (int)(k + this.dg);
        m = (int)(m + this.db);
        n = (int)(n + this.da);
        i1 += paramInt3;
        paramInt2++;
      } 
    } else {
      paramInt4 += paramInt1;
      int i1 = 32768 + (paramInt2 << 16);
      while (paramInt1 <= paramInt4) {
        i = (i1 >> 16) * this.SCREEN_WIDTH + paramInt1;
        if (f <= this.m_zbuffer[i]) {
          int i2 = j & 0xFF0000;
          int i3 = k >> 8 & 0xFF00;
          int i4 = m >> 16;
          int i5 = this.m_pixels[i];
          int i6 = i5 & 0xFF00;
          int i7 = i5 & 0xFF;
          i5 &= 0xFF0000;
          int i8 = n >> 16;
          i5 += (i2 - i5) * i8 >> 8;
          i6 += (i3 - i6) * i8 >> 8;
          i7 += (i4 - i7) * i8 >> 8;
          this.m_pixels[i] = 0xFF000000 | i5 & 0xFF0000 | i6 & 0xFF00 | i7 & 0xFF;
          this.m_zbuffer[i] = f;
        } 
        f += this.dz;
        j = (int)(j + this.dr);
        k = (int)(k + this.dg);
        m = (int)(m + this.db);
        n = (int)(n + this.da);
        i1 += paramInt3;
        paramInt1++;
      } 
    } 
  }
  
  private void drawLine_smooth(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    int i = 0;
    float f = this.m_z0;
    int j = (int)this.m_r0;
    int k = (int)this.m_g0;
    int m = (int)this.m_b0;
    int n = (int)this.m_a0;
    if (paramBoolean) {
      int i1 = paramInt1 << 16;
      int i2 = paramInt2 << 16;
      int i3 = paramInt4 + paramInt2;
      while (i2 >> 16 < i3) {
        i = (i2 >> 16) * this.SCREEN_WIDTH + (i1 >> 16);
        int i5 = j & 0xFF0000;
        int i6 = k >> 8 & 0xFF00;
        int i7 = m >> 16;
        if (this.m_zbuffer == null || f <= this.m_zbuffer[i]) {
          int i8 = ((i1 ^ 0xFFFFFFFF) >> 8 & 0xFF) * (n >> 16) >> 8;
          int i9 = this.m_pixels[i];
          int i10 = i9 & 0xFF00;
          int i11 = i9 & 0xFF;
          i9 &= 0xFF0000;
          i9 += (i5 - i9) * i8 >> 8;
          i10 += (i6 - i10) * i8 >> 8;
          i11 += (i7 - i11) * i8 >> 8;
          this.m_pixels[i] = 0xFF000000 | i9 & 0xFF0000 | i10 & 0xFF00 | i11 & 0xFF;
          if (this.m_zbuffer != null)
            this.m_zbuffer[i] = f; 
        } 
        int i4 = (i1 >> 16) + 1;
        if (i4 >= this.SCREEN_WIDTH) {
          i1 += paramInt3;
          i2 += 65536;
          continue;
        } 
        i = (i2 >> 16) * this.SCREEN_WIDTH + i4;
        if (this.m_zbuffer == null || f <= this.m_zbuffer[i]) {
          int i8 = (i1 >> 8 & 0xFF) * (n >> 16) >> 8;
          int i9 = this.m_pixels[i];
          int i10 = i9 & 0xFF00;
          int i11 = i9 & 0xFF;
          i9 &= 0xFF0000;
          i9 += (i5 - i9) * i8 >> 8;
          i10 += (i6 - i10) * i8 >> 8;
          i11 += (i7 - i11) * i8 >> 8;
          this.m_pixels[i] = 0xFF000000 | i9 & 0xFF0000 | i10 & 0xFF00 | i11 & 0xFF;
          if (this.m_zbuffer != null)
            this.m_zbuffer[i] = f; 
        } 
        i1 += paramInt3;
        i2 += 65536;
        f += this.dz;
        j = (int)(j + this.dr);
        k = (int)(k + this.dg);
        m = (int)(m + this.db);
        n = (int)(n + this.da);
      } 
    } else {
      int i1 = paramInt1 << 16;
      int i2 = paramInt2 << 16;
      int i3 = paramInt4 + paramInt1;
      while (i1 >> 16 < i3) {
        i = (i2 >> 16) * this.SCREEN_WIDTH + (i1 >> 16);
        int i5 = j & 0xFF0000;
        int i6 = k >> 8 & 0xFF00;
        int i7 = m >> 16;
        if (this.m_zbuffer == null || f <= this.m_zbuffer[i]) {
          int i8 = ((i2 ^ 0xFFFFFFFF) >> 8 & 0xFF) * (n >> 16) >> 8;
          int i9 = this.m_pixels[i];
          int i10 = i9 & 0xFF00;
          int i11 = i9 & 0xFF;
          i9 &= 0xFF0000;
          i9 += (i5 - i9) * i8 >> 8;
          i10 += (i6 - i10) * i8 >> 8;
          i11 += (i7 - i11) * i8 >> 8;
          this.m_pixels[i] = 0xFF000000 | i9 & 0xFF0000 | i10 & 0xFF00 | i11 & 0xFF;
          if (this.m_zbuffer != null)
            this.m_zbuffer[i] = f; 
        } 
        int i4 = (i2 >> 16) + 1;
        if (i4 >= this.SCREEN_HEIGHT) {
          i1 += 65536;
          i2 += paramInt3;
          continue;
        } 
        i = i4 * this.SCREEN_WIDTH + (i1 >> 16);
        if (this.m_zbuffer == null || f <= this.m_zbuffer[i]) {
          int i8 = (i2 >> 8 & 0xFF) * (n >> 16) >> 8;
          int i9 = this.m_pixels[i];
          int i10 = i9 & 0xFF00;
          int i11 = i9 & 0xFF;
          i9 &= 0xFF0000;
          i9 += (i5 - i9) * i8 >> 8;
          i10 += (i6 - i10) * i8 >> 8;
          i11 += (i7 - i11) * i8 >> 8;
          this.m_pixels[i] = 0xFF000000 | i9 & 0xFF0000 | i10 & 0xFF00 | i11 & 0xFF;
          if (this.m_zbuffer != null)
            this.m_zbuffer[i] = f; 
        } 
        i1 += 65536;
        i2 += paramInt3;
        f += this.dz;
        j = (int)(j + this.dr);
        k = (int)(k + this.dg);
        m = (int)(m + this.db);
        n = (int)(n + this.da);
      } 
    } 
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PLine.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */