package processing.core;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.PixelGrabber;
import java.awt.image.WritableRaster;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Set;
import javax.imageio.ImageIO;

public class PImage implements PConstants, Cloneable {
  public int format;
  
  public int[] pixels;
  
  public int width;
  
  public int height;
  
  public PApplet parent;
  
  protected HashMap<PGraphics, Object> cacheMap;
  
  protected HashMap<PGraphics, Object> paramMap;
  
  protected boolean modified;
  
  protected int mx1;
  
  protected int my1;
  
  protected int mx2;
  
  protected int my2;
  
  private int fracU;
  
  private int ifU;
  
  private int fracV;
  
  private int ifV;
  
  private int u1;
  
  private int u2;
  
  private int v1;
  
  private int v2;
  
  private int sX;
  
  private int sY;
  
  private int iw;
  
  private int iw1;
  
  private int ih1;
  
  private int ul;
  
  private int ll;
  
  private int ur;
  
  private int lr;
  
  private int cUL;
  
  private int cLL;
  
  private int cUR;
  
  private int cLR;
  
  private int srcXOffset;
  
  private int srcYOffset;
  
  private int r;
  
  private int g;
  
  private int b;
  
  private int a;
  
  private int[] srcBuffer;
  
  static final int PRECISIONB = 15;
  
  static final int PRECISIONF = 32768;
  
  static final int PREC_MAXVAL = 32767;
  
  static final int PREC_ALPHA_SHIFT = 9;
  
  static final int PREC_RED_SHIFT = 1;
  
  private int blurRadius;
  
  private int blurKernelSize;
  
  private int[] blurKernel;
  
  private int[][] blurMult;
  
  static byte[] TIFF_HEADER = new byte[] { 
      77, 77, 0, 42, 0, 0, 0, 8, 0, 9, 
      0, -2, 0, 4, 0, 0, 0, 1, 0, 0, 
      0, 0, 1, 0, 0, 3, 0, 0, 0, 1, 
      0, 0, 0, 0, 1, 1, 0, 3, 0, 0, 
      0, 1, 0, 0, 0, 0, 1, 2, 0, 3, 
      0, 0, 0, 3, 0, 0, 0, 122, 1, 6, 
      0, 3, 0, 0, 0, 1, 0, 2, 0, 0, 
      1, 17, 0, 4, 0, 0, 0, 1, 0, 0, 
      3, 0, 1, 21, 0, 3, 0, 0, 0, 1, 
      0, 3, 0, 0, 1, 22, 0, 3, 0, 0, 
      0, 1, 0, 0, 0, 0, 1, 23, 0, 4, 
      0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 8, 0, 8, 0, 8 };
  
  static final String TIFF_ERROR = "Error: Processing can only read its own TIFF files.";
  
  protected String[] saveImageFormats;
  
  public PImage() {
    this.format = 2;
  }
  
  public PImage(int paramInt1, int paramInt2) {
    init(paramInt1, paramInt2, 1);
  }
  
  public PImage(int paramInt1, int paramInt2, int paramInt3) {
    init(paramInt1, paramInt2, paramInt3);
  }
  
  public void init(int paramInt1, int paramInt2, int paramInt3) {
    this.width = paramInt1;
    this.height = paramInt2;
    this.pixels = new int[paramInt1 * paramInt2];
    this.format = paramInt3;
  }
  
  protected void checkAlpha() {
    if (this.pixels == null)
      return; 
    for (byte b = 0; b < this.pixels.length; b++) {
      if ((this.pixels[b] & 0xFF000000) != -16777216) {
        this.format = 2;
        break;
      } 
    } 
  }
  
  public PImage(Image paramImage) {
    this.format = 1;
    if (paramImage instanceof BufferedImage) {
      BufferedImage bufferedImage = (BufferedImage)paramImage;
      this.width = bufferedImage.getWidth();
      this.height = bufferedImage.getHeight();
      this.pixels = new int[this.width * this.height];
      WritableRaster writableRaster = bufferedImage.getRaster();
      writableRaster.getDataElements(0, 0, this.width, this.height, this.pixels);
      if (bufferedImage.getType() == 2)
        this.format = 2; 
    } else {
      this.width = paramImage.getWidth(null);
      this.height = paramImage.getHeight(null);
      this.pixels = new int[this.width * this.height];
      PixelGrabber pixelGrabber = new PixelGrabber(paramImage, 0, 0, this.width, this.height, this.pixels, 0, this.width);
      try {
        pixelGrabber.grabPixels();
      } catch (InterruptedException interruptedException) {}
    } 
  }
  
  public Image getImage() {
    loadPixels();
    boolean bool = (this.format == 1) ? true : true;
    BufferedImage bufferedImage = new BufferedImage(this.width, this.height, bool);
    WritableRaster writableRaster = bufferedImage.getRaster();
    writableRaster.setDataElements(0, 0, this.width, this.height, this.pixels);
    return bufferedImage;
  }
  
  public void delete() {
    if (this.cacheMap != null) {
      Set<PGraphics> set = this.cacheMap.keySet();
      if (!set.isEmpty()) {
        Object[] arrayOfObject = set.toArray();
        for (byte b = 0; b < arrayOfObject.length; b++) {
          Object object = getCache((PGraphics)arrayOfObject[b]);
          Method method = null;
          try {
            Class<?> clazz = object.getClass();
            method = clazz.getMethod("delete", new Class[0]);
          } catch (Exception exception) {}
          if (method != null)
            try {
              method.invoke(object, new Object[0]);
            } catch (Exception exception) {} 
        } 
      } 
    } 
  }
  
  public void setCache(PGraphics paramPGraphics, Object paramObject) {
    if (this.cacheMap == null)
      this.cacheMap = new HashMap<PGraphics, Object>(); 
    this.cacheMap.put(paramPGraphics, paramObject);
  }
  
  public Object getCache(PGraphics paramPGraphics) {
    return (this.cacheMap == null) ? null : this.cacheMap.get(paramPGraphics);
  }
  
  public void removeCache(PGraphics paramPGraphics) {
    if (this.cacheMap != null)
      this.cacheMap.remove(paramPGraphics); 
  }
  
  public void setParams(PGraphics paramPGraphics, Object paramObject) {
    if (this.paramMap == null)
      this.paramMap = new HashMap<PGraphics, Object>(); 
    this.paramMap.put(paramPGraphics, paramObject);
  }
  
  public Object getParams(PGraphics paramPGraphics) {
    return (this.paramMap == null) ? null : this.paramMap.get(paramPGraphics);
  }
  
  public void removeParams(PGraphics paramPGraphics) {
    if (this.paramMap != null)
      this.paramMap.remove(paramPGraphics); 
  }
  
  public boolean isModified() {
    return this.modified;
  }
  
  public void setModified() {
    this.modified = true;
  }
  
  public void setModified(boolean paramBoolean) {
    this.modified = paramBoolean;
  }
  
  public int getModifiedX1() {
    return this.mx1;
  }
  
  public int getModifiedX2() {
    return this.mx2;
  }
  
  public int getModifiedY1() {
    return this.my1;
  }
  
  public int getModifiedY2() {
    return this.my2;
  }
  
  public void loadPixels() {}
  
  public void updatePixels() {
    updatePixelsImpl(0, 0, this.width, this.height);
  }
  
  public void updatePixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    updatePixelsImpl(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected void updatePixelsImpl(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt1 + paramInt3;
    int j = paramInt2 + paramInt4;
    if (!this.modified) {
      this.mx1 = paramInt1;
      this.mx2 = i;
      this.my1 = paramInt2;
      this.my2 = j;
      this.modified = true;
    } else {
      if (paramInt1 < this.mx1)
        this.mx1 = paramInt1; 
      if (paramInt1 > this.mx2)
        this.mx2 = paramInt1; 
      if (paramInt2 < this.my1)
        this.my1 = paramInt2; 
      if (paramInt2 > this.my2)
        this.my2 = paramInt2; 
      if (i < this.mx1)
        this.mx1 = i; 
      if (i > this.mx2)
        this.mx2 = i; 
      if (j < this.my1)
        this.my1 = j; 
      if (j > this.my2)
        this.my2 = j; 
    } 
  }
  
  public Object clone() throws CloneNotSupportedException {
    return get();
  }
  
  public void resize(int paramInt1, int paramInt2) {
    loadPixels();
    if (paramInt1 <= 0 && paramInt2 <= 0) {
      this.width = 0;
      this.height = 0;
      this.pixels = new int[0];
    } else {
      if (paramInt1 == 0) {
        float f = paramInt2 / this.height;
        paramInt1 = (int)(this.width * f);
      } else if (paramInt2 == 0) {
        float f = paramInt1 / this.width;
        paramInt2 = (int)(this.height * f);
      } 
      PImage pImage = new PImage(paramInt1, paramInt2, this.format);
      pImage.copy(this, 0, 0, this.width, this.height, 0, 0, paramInt1, paramInt2);
      this.width = paramInt1;
      this.height = paramInt2;
      this.pixels = pImage.pixels;
    } 
    updatePixels();
  }
  
  public int get(int paramInt1, int paramInt2) {
    if (paramInt1 < 0 || paramInt2 < 0 || paramInt1 >= this.width || paramInt2 >= this.height)
      return 0; 
    switch (this.format) {
      case 1:
        return this.pixels[paramInt2 * this.width + paramInt1] | 0xFF000000;
      case 2:
        return this.pixels[paramInt2 * this.width + paramInt1];
      case 4:
        return this.pixels[paramInt2 * this.width + paramInt1] << 24 | 0xFFFFFF;
    } 
    return 0;
  }
  
  public PImage get(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt1 < 0) {
      paramInt3 += paramInt1;
      paramInt1 = 0;
    } 
    if (paramInt2 < 0) {
      paramInt4 += paramInt2;
      paramInt2 = 0;
    } 
    if (paramInt1 + paramInt3 > this.width)
      paramInt3 = this.width - paramInt1; 
    if (paramInt2 + paramInt4 > this.height)
      paramInt4 = this.height - paramInt2; 
    return getImpl(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected PImage getImpl(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    PImage pImage = new PImage(paramInt3, paramInt4, this.format);
    pImage.parent = this.parent;
    int i = paramInt2 * this.width + paramInt1;
    int j = 0;
    for (int k = paramInt2; k < paramInt2 + paramInt4; k++) {
      System.arraycopy(this.pixels, i, pImage.pixels, j, paramInt3);
      i += this.width;
      j += paramInt3;
    } 
    return pImage;
  }
  
  public PImage get() {
    return get(0, 0, this.width, this.height);
  }
  
  public void set(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 < 0 || paramInt2 < 0 || paramInt1 >= this.width || paramInt2 >= this.height)
      return; 
    this.pixels[paramInt2 * this.width + paramInt1] = paramInt3;
    updatePixelsImpl(paramInt1, paramInt2, paramInt1 + 1, paramInt2 + 1);
  }
  
  public void set(int paramInt1, int paramInt2, PImage paramPImage) {
    int i = 0;
    int j = 0;
    int k = paramPImage.width;
    int m = paramPImage.height;
    if (paramInt1 < 0) {
      i -= paramInt1;
      k += paramInt1;
      paramInt1 = 0;
    } 
    if (paramInt2 < 0) {
      j -= paramInt2;
      m += paramInt2;
      paramInt2 = 0;
    } 
    if (paramInt1 + k > this.width)
      k = this.width - paramInt1; 
    if (paramInt2 + m > this.height)
      m = this.height - paramInt2; 
    if (k <= 0 || m <= 0)
      return; 
    setImpl(paramInt1, paramInt2, i, j, k, m, paramPImage);
  }
  
  protected void setImpl(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, PImage paramPImage) {
    int i = paramInt4 * paramPImage.width + paramInt3;
    int j = paramInt2 * this.width + paramInt1;
    for (int k = paramInt4; k < paramInt4 + paramInt6; k++) {
      System.arraycopy(paramPImage.pixels, i, this.pixels, j, paramInt5);
      i += paramPImage.width;
      j += this.width;
    } 
    updatePixelsImpl(paramInt3, paramInt4, paramInt3 + paramInt5, paramInt4 + paramInt6);
  }
  
  public void mask(int[] paramArrayOfint) {
    loadPixels();
    if (paramArrayOfint.length != this.pixels.length)
      throw new RuntimeException("The PImage used with mask() must be the same size as the applet."); 
    for (byte b = 0; b < this.pixels.length; b++)
      this.pixels[b] = (paramArrayOfint[b] & 0xFF) << 24 | this.pixels[b] & 0xFFFFFF; 
    this.format = 2;
    updatePixels();
  }
  
  public void mask(PImage paramPImage) {
    paramPImage.loadPixels();
    mask(paramPImage.pixels);
  }
  
  public void filter(int paramInt) {
    byte b;
    loadPixels();
    switch (paramInt) {
      case 11:
        filter(11, 1.0F);
        break;
      case 12:
        if (this.format == 4) {
          for (byte b1 = 0; b1 < this.pixels.length; b1++) {
            int i = 255 - this.pixels[b1];
            this.pixels[b1] = 0xFF000000 | i << 16 | i << 8 | i;
          } 
          this.format = 1;
          break;
        } 
        for (b = 0; b < this.pixels.length; b++) {
          int i = this.pixels[b];
          int j = 77 * (i >> 16 & 0xFF) + 151 * (i >> 8 & 0xFF) + 28 * (i & 0xFF) >> 8;
          this.pixels[b] = i & 0xFF000000 | j << 16 | j << 8 | j;
        } 
        break;
      case 13:
        for (b = 0; b < this.pixels.length; b++)
          this.pixels[b] = this.pixels[b] ^ 0xFFFFFF; 
        break;
      case 15:
        throw new RuntimeException("Use filter(POSTERIZE, int levels) instead of filter(POSTERIZE)");
      case 14:
        for (b = 0; b < this.pixels.length; b++)
          this.pixels[b] = this.pixels[b] | 0xFF000000; 
        this.format = 1;
        break;
      case 16:
        filter(16, 0.5F);
        break;
      case 17:
        dilate(true);
        break;
      case 18:
        dilate(false);
        break;
    } 
    updatePixels();
  }
  
  public void filter(int paramInt, float paramFloat) {
    int i;
    int j;
    int k;
    byte b;
    loadPixels();
    switch (paramInt) {
      case 11:
        if (this.format == 4) {
          blurAlpha(paramFloat);
          break;
        } 
        if (this.format == 2) {
          blurARGB(paramFloat);
          break;
        } 
        blurRGB(paramFloat);
        break;
      case 12:
        throw new RuntimeException("Use filter(GRAY) instead of filter(GRAY, param)");
      case 13:
        throw new RuntimeException("Use filter(INVERT) instead of filter(INVERT, param)");
      case 14:
        throw new RuntimeException("Use filter(OPAQUE) instead of filter(OPAQUE, param)");
      case 15:
        i = (int)paramFloat;
        if (i < 2 || i > 255)
          throw new RuntimeException("Levels must be between 2 and 255 for filter(POSTERIZE, levels)"); 
        j = i - 1;
        for (k = 0; k < this.pixels.length; k++) {
          int m = this.pixels[k] >> 16 & 0xFF;
          int n = this.pixels[k] >> 8 & 0xFF;
          int i1 = this.pixels[k] & 0xFF;
          m = (m * i >> 8) * 255 / j;
          n = (n * i >> 8) * 255 / j;
          i1 = (i1 * i >> 8) * 255 / j;
          this.pixels[k] = 0xFF000000 & this.pixels[k] | m << 16 | n << 8 | i1;
        } 
        break;
      case 16:
        k = (int)(paramFloat * 255.0F);
        for (b = 0; b < this.pixels.length; b++) {
          int m = Math.max((this.pixels[b] & 0xFF0000) >> 16, Math.max((this.pixels[b] & 0xFF00) >> 8, this.pixels[b] & 0xFF));
          this.pixels[b] = this.pixels[b] & 0xFF000000 | ((m < k) ? 0 : 16777215);
        } 
        break;
      case 17:
        throw new RuntimeException("Use filter(ERODE) instead of filter(ERODE, param)");
      case 18:
        throw new RuntimeException("Use filter(DILATE) instead of filter(DILATE, param)");
    } 
    updatePixels();
  }
  
  protected void buildBlurKernel(float paramFloat) {
    int i = (int)(paramFloat * 3.5F);
    i = (i < 1) ? 1 : ((i < 248) ? i : 248);
    if (this.blurRadius != i) {
      this.blurRadius = i;
      this.blurKernelSize = 1 + this.blurRadius << 1;
      this.blurKernel = new int[this.blurKernelSize];
      this.blurMult = new int[this.blurKernelSize][256];
      byte b = 1;
      int k = i - 1;
      while (b < i) {
        int m = k * k;
        this.blurKernel[i + b] = m = k * k;
        int[] arrayOfInt1 = this.blurMult[i + b];
        int[] arrayOfInt2 = this.blurMult[k--];
        for (byte b1 = 0; b1 < 'Ā'; b1++) {
          arrayOfInt2[b1] = m * b1;
          arrayOfInt1[b1] = m * b1;
        } 
        b++;
      } 
      int j = this.blurKernel[i] = i * i;
      int[] arrayOfInt = this.blurMult[i];
      for (b = 0; b < 'Ā'; b++)
        arrayOfInt[b] = j * b; 
    } 
  }
  
  protected void blurAlpha(float paramFloat) {
    int[] arrayOfInt = new int[this.pixels.length];
    int k = 0;
    buildBlurKernel(paramFloat);
    byte b;
    for (b = 0; b < this.height; b++) {
      for (byte b1 = 0; b1 < this.width; b1++) {
        byte b2;
        int m = 0;
        int n = m;
        int i1 = b1 - this.blurRadius;
        if (i1 < 0) {
          b2 = -i1;
          i1 = 0;
        } else {
          if (i1 >= this.width)
            break; 
          b2 = 0;
        } 
        for (byte b3 = b2; b3 < this.blurKernelSize && i1 < this.width; b3++) {
          int i3 = this.pixels[i1 + k];
          int[] arrayOfInt1 = this.blurMult[b3];
          n += arrayOfInt1[i3 & 0xFF];
          m += this.blurKernel[b3];
          i1++;
        } 
        int i2 = k + b1;
        arrayOfInt[i2] = n / m;
      } 
      k += this.width;
    } 
    k = 0;
    int i = -this.blurRadius;
    int j = i * this.width;
    for (b = 0; b < this.height; b++) {
      for (byte b1 = 0; b1 < this.width; b1++) {
        int i1;
        int i2;
        byte b2;
        int m = 0;
        int n = m;
        if (i < 0) {
          b2 = i2 = -i;
          i1 = b1;
        } else {
          if (i >= this.height)
            break; 
          b2 = 0;
          i2 = i;
          i1 = b1 + j;
        } 
        for (byte b3 = b2; b3 < this.blurKernelSize && i2 < this.height; b3++) {
          int[] arrayOfInt1 = this.blurMult[b3];
          n += arrayOfInt1[arrayOfInt[i1]];
          m += this.blurKernel[b3];
          i2++;
          i1 += this.width;
        } 
        this.pixels[b1 + k] = n / m;
      } 
      k += this.width;
      j += this.width;
      i++;
    } 
  }
  
  protected void blurRGB(float paramFloat) {
    int[] arrayOfInt1 = new int[this.pixels.length];
    int[] arrayOfInt2 = new int[this.pixels.length];
    int[] arrayOfInt3 = new int[this.pixels.length];
    int k = 0;
    buildBlurKernel(paramFloat);
    byte b;
    for (b = 0; b < this.height; b++) {
      for (byte b1 = 0; b1 < this.width; b1++) {
        byte b2;
        int m = 0;
        int n = m;
        int i1 = n;
        int i2 = i1;
        int i3 = b1 - this.blurRadius;
        if (i3 < 0) {
          b2 = -i3;
          i3 = 0;
        } else {
          if (i3 >= this.width)
            break; 
          b2 = 0;
        } 
        for (byte b3 = b2; b3 < this.blurKernelSize && i3 < this.width; b3++) {
          int i5 = this.pixels[i3 + k];
          int[] arrayOfInt = this.blurMult[b3];
          n += arrayOfInt[(i5 & 0xFF0000) >> 16];
          i1 += arrayOfInt[(i5 & 0xFF00) >> 8];
          i2 += arrayOfInt[i5 & 0xFF];
          m += this.blurKernel[b3];
          i3++;
        } 
        int i4 = k + b1;
        arrayOfInt1[i4] = n / m;
        arrayOfInt2[i4] = i1 / m;
        arrayOfInt3[i4] = i2 / m;
      } 
      k += this.width;
    } 
    k = 0;
    int i = -this.blurRadius;
    int j = i * this.width;
    for (b = 0; b < this.height; b++) {
      for (byte b1 = 0; b1 < this.width; b1++) {
        int i3;
        int i4;
        byte b2;
        int m = 0;
        int n = m;
        int i1 = n;
        int i2 = i1;
        if (i < 0) {
          b2 = i4 = -i;
          i3 = b1;
        } else {
          if (i >= this.height)
            break; 
          b2 = 0;
          i4 = i;
          i3 = b1 + j;
        } 
        for (byte b3 = b2; b3 < this.blurKernelSize && i4 < this.height; b3++) {
          int[] arrayOfInt = this.blurMult[b3];
          n += arrayOfInt[arrayOfInt1[i3]];
          i1 += arrayOfInt[arrayOfInt2[i3]];
          i2 += arrayOfInt[arrayOfInt3[i3]];
          m += this.blurKernel[b3];
          i4++;
          i3 += this.width;
        } 
        this.pixels[b1 + k] = 0xFF000000 | n / m << 16 | i1 / m << 8 | i2 / m;
      } 
      k += this.width;
      j += this.width;
      i++;
    } 
  }
  
  protected void blurARGB(float paramFloat) {
    int k = this.pixels.length;
    int[] arrayOfInt1 = new int[k];
    int[] arrayOfInt2 = new int[k];
    int[] arrayOfInt3 = new int[k];
    int[] arrayOfInt4 = new int[k];
    int m = 0;
    buildBlurKernel(paramFloat);
    byte b;
    for (b = 0; b < this.height; b++) {
      for (byte b1 = 0; b1 < this.width; b1++) {
        byte b2;
        int n = 0;
        int i4 = n;
        int i1 = i4;
        int i2 = i1;
        int i3 = i2;
        int i5 = b1 - this.blurRadius;
        if (i5 < 0) {
          b2 = -i5;
          i5 = 0;
        } else {
          if (i5 >= this.width)
            break; 
          b2 = 0;
        } 
        for (byte b3 = b2; b3 < this.blurKernelSize && i5 < this.width; b3++) {
          int i7 = this.pixels[i5 + m];
          int[] arrayOfInt = this.blurMult[b3];
          i4 += arrayOfInt[(i7 & 0xFF000000) >>> 24];
          i1 += arrayOfInt[(i7 & 0xFF0000) >> 16];
          i2 += arrayOfInt[(i7 & 0xFF00) >> 8];
          i3 += arrayOfInt[i7 & 0xFF];
          n += this.blurKernel[b3];
          i5++;
        } 
        int i6 = m + b1;
        arrayOfInt4[i6] = i4 / n;
        arrayOfInt1[i6] = i1 / n;
        arrayOfInt2[i6] = i2 / n;
        arrayOfInt3[i6] = i3 / n;
      } 
      m += this.width;
    } 
    m = 0;
    int i = -this.blurRadius;
    int j = i * this.width;
    for (b = 0; b < this.height; b++) {
      for (byte b1 = 0; b1 < this.width; b1++) {
        int i5;
        int i6;
        byte b2;
        int n = 0;
        int i4 = n;
        int i1 = i4;
        int i2 = i1;
        int i3 = i2;
        if (i < 0) {
          b2 = i6 = -i;
          i5 = b1;
        } else {
          if (i >= this.height)
            break; 
          b2 = 0;
          i6 = i;
          i5 = b1 + j;
        } 
        for (byte b3 = b2; b3 < this.blurKernelSize && i6 < this.height; b3++) {
          int[] arrayOfInt = this.blurMult[b3];
          i4 += arrayOfInt[arrayOfInt4[i5]];
          i1 += arrayOfInt[arrayOfInt1[i5]];
          i2 += arrayOfInt[arrayOfInt2[i5]];
          i3 += arrayOfInt[arrayOfInt3[i5]];
          n += this.blurKernel[b3];
          i6++;
          i5 += this.width;
        } 
        this.pixels[b1 + m] = i4 / n << 24 | i1 / n << 16 | i2 / n << 8 | i3 / n;
      } 
      m += this.width;
      j += this.width;
      i++;
    } 
  }
  
  protected void dilate(boolean paramBoolean) {
    byte b = 0;
    int i = this.pixels.length;
    int[] arrayOfInt = new int[i];
    if (!paramBoolean) {
      while (b < i) {
        byte b1 = b;
        int j = b + this.width;
        while (b < j) {
          int m = this.pixels[b];
          int k = m;
          int n = b - 1;
          int i1 = b + 1;
          int i2 = b - this.width;
          int i3 = b + this.width;
          if (n < b1)
            n = b; 
          if (i1 >= j)
            i1 = b; 
          if (i2 < 0)
            i2 = b; 
          if (i3 >= i)
            i3 = b; 
          int i4 = this.pixels[i2];
          int i5 = this.pixels[n];
          int i6 = this.pixels[i3];
          int i7 = this.pixels[i1];
          int i8 = 77 * (k >> 16 & 0xFF) + 151 * (k >> 8 & 0xFF) + 28 * (k & 0xFF);
          int i9 = 77 * (i5 >> 16 & 0xFF) + 151 * (i5 >> 8 & 0xFF) + 28 * (i5 & 0xFF);
          int i10 = 77 * (i7 >> 16 & 0xFF) + 151 * (i7 >> 8 & 0xFF) + 28 * (i7 & 0xFF);
          int i11 = 77 * (i4 >> 16 & 0xFF) + 151 * (i4 >> 8 & 0xFF) + 28 * (i4 & 0xFF);
          int i12 = 77 * (i6 >> 16 & 0xFF) + 151 * (i6 >> 8 & 0xFF) + 28 * (i6 & 0xFF);
          if (i9 > i8) {
            m = i5;
            i8 = i9;
          } 
          if (i10 > i8) {
            m = i7;
            i8 = i10;
          } 
          if (i11 > i8) {
            m = i4;
            i8 = i11;
          } 
          if (i12 > i8) {
            m = i6;
            i8 = i12;
          } 
          arrayOfInt[b++] = m;
        } 
      } 
    } else {
      while (b < i) {
        byte b1 = b;
        int j = b + this.width;
        while (b < j) {
          int m = this.pixels[b];
          int k = m;
          int n = b - 1;
          int i1 = b + 1;
          int i2 = b - this.width;
          int i3 = b + this.width;
          if (n < b1)
            n = b; 
          if (i1 >= j)
            i1 = b; 
          if (i2 < 0)
            i2 = b; 
          if (i3 >= i)
            i3 = b; 
          int i4 = this.pixels[i2];
          int i5 = this.pixels[n];
          int i6 = this.pixels[i3];
          int i7 = this.pixels[i1];
          int i8 = 77 * (k >> 16 & 0xFF) + 151 * (k >> 8 & 0xFF) + 28 * (k & 0xFF);
          int i9 = 77 * (i5 >> 16 & 0xFF) + 151 * (i5 >> 8 & 0xFF) + 28 * (i5 & 0xFF);
          int i10 = 77 * (i7 >> 16 & 0xFF) + 151 * (i7 >> 8 & 0xFF) + 28 * (i7 & 0xFF);
          int i11 = 77 * (i4 >> 16 & 0xFF) + 151 * (i4 >> 8 & 0xFF) + 28 * (i4 & 0xFF);
          int i12 = 77 * (i6 >> 16 & 0xFF) + 151 * (i6 >> 8 & 0xFF) + 28 * (i6 & 0xFF);
          if (i9 < i8) {
            m = i5;
            i8 = i9;
          } 
          if (i10 < i8) {
            m = i7;
            i8 = i10;
          } 
          if (i11 < i8) {
            m = i4;
            i8 = i11;
          } 
          if (i12 < i8) {
            m = i6;
            i8 = i12;
          } 
          arrayOfInt[b++] = m;
        } 
      } 
    } 
    System.arraycopy(arrayOfInt, 0, this.pixels, 0, i);
  }
  
  public void copy(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
    blend(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, 0);
  }
  
  public void copy(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
    blend(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, 0);
  }
  
  public static int blendColor(int paramInt1, int paramInt2, int paramInt3) {
    switch (paramInt3) {
      case 0:
        return paramInt2;
      case 1:
        return blend_blend(paramInt1, paramInt2);
      case 2:
        return blend_add_pin(paramInt1, paramInt2);
      case 4:
        return blend_sub_pin(paramInt1, paramInt2);
      case 8:
        return blend_lightest(paramInt1, paramInt2);
      case 16:
        return blend_darkest(paramInt1, paramInt2);
      case 32:
        return blend_difference(paramInt1, paramInt2);
      case 64:
        return blend_exclusion(paramInt1, paramInt2);
      case 128:
        return blend_multiply(paramInt1, paramInt2);
      case 256:
        return blend_screen(paramInt1, paramInt2);
      case 1024:
        return blend_hard_light(paramInt1, paramInt2);
      case 2048:
        return blend_soft_light(paramInt1, paramInt2);
      case 512:
        return blend_overlay(paramInt1, paramInt2);
      case 4096:
        return blend_dodge(paramInt1, paramInt2);
      case 8192:
        return blend_burn(paramInt1, paramInt2);
    } 
    return 0;
  }
  
  public void blend(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    blend(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
  }
  
  public void blend(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    int i = paramInt1 + paramInt3;
    int j = paramInt2 + paramInt4;
    int k = paramInt5 + paramInt7;
    int m = paramInt6 + paramInt8;
    loadPixels();
    if (paramPImage == this) {
      if (intersect(paramInt1, paramInt2, i, j, paramInt5, paramInt6, k, m)) {
        blit_resize(get(paramInt1, paramInt2, i - paramInt1, j - paramInt2), 0, 0, i - paramInt1 - 1, j - paramInt2 - 1, this.pixels, this.width, this.height, paramInt5, paramInt6, k, m, paramInt9);
      } else {
        blit_resize(paramPImage, paramInt1, paramInt2, i, j, this.pixels, this.width, this.height, paramInt5, paramInt6, k, m, paramInt9);
      } 
    } else {
      paramPImage.loadPixels();
      blit_resize(paramPImage, paramInt1, paramInt2, i, j, this.pixels, this.width, this.height, paramInt5, paramInt6, k, m, paramInt9);
    } 
    updatePixels();
  }
  
  private boolean intersect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
    int i = paramInt3 - paramInt1 + 1;
    int j = paramInt4 - paramInt2 + 1;
    int k = paramInt7 - paramInt5 + 1;
    int m = paramInt8 - paramInt6 + 1;
    if (paramInt5 < paramInt1) {
      k += paramInt5 - paramInt1;
      if (k > i)
        k = i; 
    } else {
      int n = i + paramInt1 - paramInt5;
      if (k > n)
        k = n; 
    } 
    if (paramInt6 < paramInt2) {
      m += paramInt6 - paramInt2;
      if (m > j)
        m = j; 
    } else {
      int n = j + paramInt2 - paramInt6;
      if (m > n)
        m = n; 
    } 
    return (k > 0 && m > 0);
  }
  
  private void blit_resize(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11) {
    if (paramInt1 < 0)
      paramInt1 = 0; 
    if (paramInt2 < 0)
      paramInt2 = 0; 
    if (paramInt3 > paramPImage.width)
      paramInt3 = paramPImage.width; 
    if (paramInt4 > paramPImage.height)
      paramInt4 = paramPImage.height; 
    int i = paramInt3 - paramInt1;
    int j = paramInt4 - paramInt2;
    int k = paramInt9 - paramInt7;
    int m = paramInt10 - paramInt8;
    boolean bool = true;
    if (!bool) {
      i++;
      j++;
    } 
    if (k <= 0 || m <= 0 || i <= 0 || j <= 0 || paramInt7 >= paramInt5 || paramInt8 >= paramInt6 || paramInt1 >= paramPImage.width || paramInt2 >= paramPImage.height)
      return; 
    int n = (int)(i / k * 32768.0F);
    int i1 = (int)(j / m * 32768.0F);
    this.srcXOffset = (paramInt7 < 0) ? (-paramInt7 * n) : (paramInt1 * 32768);
    this.srcYOffset = (paramInt8 < 0) ? (-paramInt8 * i1) : (paramInt2 * 32768);
    if (paramInt7 < 0) {
      k += paramInt7;
      paramInt7 = 0;
    } 
    if (paramInt8 < 0) {
      m += paramInt8;
      paramInt8 = 0;
    } 
    k = low(k, paramInt5 - paramInt7);
    m = low(m, paramInt6 - paramInt8);
    int i2 = paramInt8 * paramInt5 + paramInt7;
    this.srcBuffer = paramPImage.pixels;
    if (bool) {
      byte b;
      this.iw = paramPImage.width;
      this.iw1 = paramPImage.width - 1;
      this.ih1 = paramPImage.height - 1;
      switch (paramInt11) {
        case 1:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_blend(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 2:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_add_pin(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 4:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_sub_pin(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 8:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_lightest(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 16:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_darkest(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 0:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = filter_bilinear();
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 32:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_difference(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 64:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_exclusion(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 128:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_multiply(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 256:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_screen(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 512:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_overlay(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 1024:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_hard_light(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 2048:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_soft_light(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 4096:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_dodge(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 8192:
          for (b = 0; b < m; b++) {
            filter_new_scanline();
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_burn(paramArrayOfint[i2 + b1], filter_bilinear());
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
      } 
    } else {
      byte b;
      switch (paramInt11) {
        case 1:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_blend(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 2:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_add_pin(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 4:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_sub_pin(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 8:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_lightest(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 16:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_darkest(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 0:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = this.srcBuffer[this.sY + (this.sX >> 15)];
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 32:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_difference(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 64:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_exclusion(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 128:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_multiply(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 256:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_screen(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 512:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_overlay(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 1024:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_hard_light(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 2048:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_soft_light(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 4096:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_dodge(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
        case 8192:
          for (b = 0; b < m; b++) {
            this.sX = this.srcXOffset;
            this.sY = (this.srcYOffset >> 15) * paramPImage.width;
            for (byte b1 = 0; b1 < k; b1++) {
              paramArrayOfint[i2 + b1] = blend_burn(paramArrayOfint[i2 + b1], this.srcBuffer[this.sY + (this.sX >> 15)]);
              this.sX += n;
            } 
            i2 += paramInt5;
            this.srcYOffset += i1;
          } 
          break;
      } 
    } 
  }
  
  private void filter_new_scanline() {
    this.sX = this.srcXOffset;
    this.fracV = this.srcYOffset & 0x7FFF;
    this.ifV = 32767 - this.fracV;
    this.v1 = (this.srcYOffset >> 15) * this.iw;
    this.v2 = low((this.srcYOffset >> 15) + 1, this.ih1) * this.iw;
  }
  
  private int filter_bilinear() {
    this.fracU = this.sX & 0x7FFF;
    this.ifU = 32767 - this.fracU;
    this.ul = this.ifU * this.ifV >> 15;
    this.ll = this.ifU * this.fracV >> 15;
    this.ur = this.fracU * this.ifV >> 15;
    this.lr = this.fracU * this.fracV >> 15;
    this.u1 = this.sX >> 15;
    this.u2 = low(this.u1 + 1, this.iw1);
    this.cUL = this.srcBuffer[this.v1 + this.u1];
    this.cUR = this.srcBuffer[this.v1 + this.u2];
    this.cLL = this.srcBuffer[this.v2 + this.u1];
    this.cLR = this.srcBuffer[this.v2 + this.u2];
    this.r = this.ul * ((this.cUL & 0xFF0000) >> 16) + this.ll * ((this.cLL & 0xFF0000) >> 16) + this.ur * ((this.cUR & 0xFF0000) >> 16) + this.lr * ((this.cLR & 0xFF0000) >> 16) << 1 & 0xFF0000;
    this.g = this.ul * (this.cUL & 0xFF00) + this.ll * (this.cLL & 0xFF00) + this.ur * (this.cUR & 0xFF00) + this.lr * (this.cLR & 0xFF00) >>> 15 & 0xFF00;
    this.b = this.ul * (this.cUL & 0xFF) + this.ll * (this.cLL & 0xFF) + this.ur * (this.cUR & 0xFF) + this.lr * (this.cLR & 0xFF) >>> 15;
    this.a = this.ul * ((this.cUL & 0xFF000000) >>> 24) + this.ll * ((this.cLL & 0xFF000000) >>> 24) + this.ur * ((this.cUR & 0xFF000000) >>> 24) + this.lr * ((this.cLR & 0xFF000000) >>> 24) << 9 & 0xFF000000;
    return this.a | this.r | this.g | this.b;
  }
  
  private static int low(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2) ? paramInt1 : paramInt2;
  }
  
  private static int high(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2) ? paramInt1 : paramInt2;
  }
  
  private static int peg(int paramInt) {
    return (paramInt < 0) ? 0 : ((paramInt > 255) ? 255 : paramInt);
  }
  
  private static int mix(int paramInt1, int paramInt2, int paramInt3) {
    return paramInt1 + ((paramInt2 - paramInt1) * paramInt3 >> 8);
  }
  
  private static int blend_blend(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | mix(paramInt1 & 0xFF0000, paramInt2 & 0xFF0000, i) & 0xFF0000 | mix(paramInt1 & 0xFF00, paramInt2 & 0xFF00, i) & 0xFF00 | mix(paramInt1 & 0xFF, paramInt2 & 0xFF, i);
  }
  
  private static int blend_add_pin(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | low((paramInt1 & 0xFF0000) + ((paramInt2 & 0xFF0000) >> 8) * i, 16711680) & 0xFF0000 | low((paramInt1 & 0xFF00) + ((paramInt2 & 0xFF00) >> 8) * i, 65280) & 0xFF00 | low((paramInt1 & 0xFF) + ((paramInt2 & 0xFF) * i >> 8), 255);
  }
  
  private static int blend_sub_pin(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | high((paramInt1 & 0xFF0000) - ((paramInt2 & 0xFF0000) >> 8) * i, 65280) & 0xFF0000 | high((paramInt1 & 0xFF00) - ((paramInt2 & 0xFF00) >> 8) * i, 255) & 0xFF00 | high((paramInt1 & 0xFF) - ((paramInt2 & 0xFF) * i >> 8), 0);
  }
  
  private static int blend_lightest(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | high(paramInt1 & 0xFF0000, ((paramInt2 & 0xFF0000) >> 8) * i) & 0xFF0000 | high(paramInt1 & 0xFF00, ((paramInt2 & 0xFF00) >> 8) * i) & 0xFF00 | high(paramInt1 & 0xFF, (paramInt2 & 0xFF) * i >> 8);
  }
  
  private static int blend_darkest(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | mix(paramInt1 & 0xFF0000, low(paramInt1 & 0xFF0000, ((paramInt2 & 0xFF0000) >> 8) * i), i) & 0xFF0000 | mix(paramInt1 & 0xFF00, low(paramInt1 & 0xFF00, ((paramInt2 & 0xFF00) >> 8) * i), i) & 0xFF00 | mix(paramInt1 & 0xFF, low(paramInt1 & 0xFF, (paramInt2 & 0xFF) * i >> 8), i);
  }
  
  private static int blend_difference(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    int j = (paramInt1 & 0xFF0000) >> 16;
    int k = (paramInt1 & 0xFF00) >> 8;
    int m = paramInt1 & 0xFF;
    int n = (paramInt2 & 0xFF0000) >> 16;
    int i1 = (paramInt2 & 0xFF00) >> 8;
    int i2 = paramInt2 & 0xFF;
    int i3 = (j > n) ? (j - n) : (n - j);
    int i4 = (k > i1) ? (k - i1) : (i1 - k);
    int i5 = (m > i2) ? (m - i2) : (i2 - m);
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | peg(j + ((i3 - j) * i >> 8)) << 16 | peg(k + ((i4 - k) * i >> 8)) << 8 | peg(m + ((i5 - m) * i >> 8));
  }
  
  private static int blend_exclusion(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    int j = (paramInt1 & 0xFF0000) >> 16;
    int k = (paramInt1 & 0xFF00) >> 8;
    int m = paramInt1 & 0xFF;
    int n = (paramInt2 & 0xFF0000) >> 16;
    int i1 = (paramInt2 & 0xFF00) >> 8;
    int i2 = paramInt2 & 0xFF;
    int i3 = j + n - (j * n >> 7);
    int i4 = k + i1 - (k * i1 >> 7);
    int i5 = m + i2 - (m * i2 >> 7);
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | peg(j + ((i3 - j) * i >> 8)) << 16 | peg(k + ((i4 - k) * i >> 8)) << 8 | peg(m + ((i5 - m) * i >> 8));
  }
  
  private static int blend_multiply(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    int j = (paramInt1 & 0xFF0000) >> 16;
    int k = (paramInt1 & 0xFF00) >> 8;
    int m = paramInt1 & 0xFF;
    int n = (paramInt2 & 0xFF0000) >> 16;
    int i1 = (paramInt2 & 0xFF00) >> 8;
    int i2 = paramInt2 & 0xFF;
    int i3 = j * n >> 8;
    int i4 = k * i1 >> 8;
    int i5 = m * i2 >> 8;
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | peg(j + ((i3 - j) * i >> 8)) << 16 | peg(k + ((i4 - k) * i >> 8)) << 8 | peg(m + ((i5 - m) * i >> 8));
  }
  
  private static int blend_screen(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    int j = (paramInt1 & 0xFF0000) >> 16;
    int k = (paramInt1 & 0xFF00) >> 8;
    int m = paramInt1 & 0xFF;
    int n = (paramInt2 & 0xFF0000) >> 16;
    int i1 = (paramInt2 & 0xFF00) >> 8;
    int i2 = paramInt2 & 0xFF;
    int i3 = 255 - ((255 - j) * (255 - n) >> 8);
    int i4 = 255 - ((255 - k) * (255 - i1) >> 8);
    int i5 = 255 - ((255 - m) * (255 - i2) >> 8);
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | peg(j + ((i3 - j) * i >> 8)) << 16 | peg(k + ((i4 - k) * i >> 8)) << 8 | peg(m + ((i5 - m) * i >> 8));
  }
  
  private static int blend_overlay(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    int j = (paramInt1 & 0xFF0000) >> 16;
    int k = (paramInt1 & 0xFF00) >> 8;
    int m = paramInt1 & 0xFF;
    int n = (paramInt2 & 0xFF0000) >> 16;
    int i1 = (paramInt2 & 0xFF00) >> 8;
    int i2 = paramInt2 & 0xFF;
    int i3 = (j < 128) ? (j * n >> 7) : (255 - ((255 - j) * (255 - n) >> 7));
    int i4 = (k < 128) ? (k * i1 >> 7) : (255 - ((255 - k) * (255 - i1) >> 7));
    int i5 = (m < 128) ? (m * i2 >> 7) : (255 - ((255 - m) * (255 - i2) >> 7));
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | peg(j + ((i3 - j) * i >> 8)) << 16 | peg(k + ((i4 - k) * i >> 8)) << 8 | peg(m + ((i5 - m) * i >> 8));
  }
  
  private static int blend_hard_light(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    int j = (paramInt1 & 0xFF0000) >> 16;
    int k = (paramInt1 & 0xFF00) >> 8;
    int m = paramInt1 & 0xFF;
    int n = (paramInt2 & 0xFF0000) >> 16;
    int i1 = (paramInt2 & 0xFF00) >> 8;
    int i2 = paramInt2 & 0xFF;
    int i3 = (n < 128) ? (j * n >> 7) : (255 - ((255 - j) * (255 - n) >> 7));
    int i4 = (i1 < 128) ? (k * i1 >> 7) : (255 - ((255 - k) * (255 - i1) >> 7));
    int i5 = (i2 < 128) ? (m * i2 >> 7) : (255 - ((255 - m) * (255 - i2) >> 7));
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | peg(j + ((i3 - j) * i >> 8)) << 16 | peg(k + ((i4 - k) * i >> 8)) << 8 | peg(m + ((i5 - m) * i >> 8));
  }
  
  private static int blend_soft_light(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    int j = (paramInt1 & 0xFF0000) >> 16;
    int k = (paramInt1 & 0xFF00) >> 8;
    int m = paramInt1 & 0xFF;
    int n = (paramInt2 & 0xFF0000) >> 16;
    int i1 = (paramInt2 & 0xFF00) >> 8;
    int i2 = paramInt2 & 0xFF;
    int i3 = (j * n >> 7) + (j * j >> 8) - (j * j * n >> 15);
    int i4 = (k * i1 >> 7) + (k * k >> 8) - (k * k * i1 >> 15);
    int i5 = (m * i2 >> 7) + (m * m >> 8) - (m * m * i2 >> 15);
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | peg(j + ((i3 - j) * i >> 8)) << 16 | peg(k + ((i4 - k) * i >> 8)) << 8 | peg(m + ((i5 - m) * i >> 8));
  }
  
  private static int blend_dodge(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    int j = (paramInt1 & 0xFF0000) >> 16;
    int k = (paramInt1 & 0xFF00) >> 8;
    int m = paramInt1 & 0xFF;
    int n = (paramInt2 & 0xFF0000) >> 16;
    int i1 = (paramInt2 & 0xFF00) >> 8;
    int i2 = paramInt2 & 0xFF;
    byte b1 = (n == 255) ? 255 : peg((j << 8) / (255 - n));
    byte b2 = (i1 == 255) ? 255 : peg((k << 8) / (255 - i1));
    byte b3 = (i2 == 255) ? 255 : peg((m << 8) / (255 - i2));
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | peg(j + ((b1 - j) * i >> 8)) << 16 | peg(k + ((b2 - k) * i >> 8)) << 8 | peg(m + ((b3 - m) * i >> 8));
  }
  
  private static int blend_burn(int paramInt1, int paramInt2) {
    int i = (paramInt2 & 0xFF000000) >>> 24;
    int j = (paramInt1 & 0xFF0000) >> 16;
    int k = (paramInt1 & 0xFF00) >> 8;
    int m = paramInt1 & 0xFF;
    int n = (paramInt2 & 0xFF0000) >> 16;
    int i1 = (paramInt2 & 0xFF00) >> 8;
    int i2 = paramInt2 & 0xFF;
    byte b1 = (n == 0) ? 0 : (255 - peg((255 - j << 8) / n));
    byte b2 = (i1 == 0) ? 0 : (255 - peg((255 - k << 8) / i1));
    byte b3 = (i2 == 0) ? 0 : (255 - peg((255 - m << 8) / i2));
    return low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | peg(j + ((b1 - j) * i >> 8)) << 16 | peg(k + ((b2 - k) * i >> 8)) << 8 | peg(m + ((b3 - m) * i >> 8));
  }
  
  protected static PImage loadTIFF(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte[42] != paramArrayOfbyte[102] || paramArrayOfbyte[43] != paramArrayOfbyte[103]) {
      System.err.println("Error: Processing can only read its own TIFF files.");
      return null;
    } 
    int i = (paramArrayOfbyte[30] & 0xFF) << 8 | paramArrayOfbyte[31] & 0xFF;
    int j = (paramArrayOfbyte[42] & 0xFF) << 8 | paramArrayOfbyte[43] & 0xFF;
    int k = (paramArrayOfbyte[114] & 0xFF) << 24 | (paramArrayOfbyte[115] & 0xFF) << 16 | (paramArrayOfbyte[116] & 0xFF) << 8 | paramArrayOfbyte[117] & 0xFF;
    if (k != i * j * 3) {
      System.err.println("Error: Processing can only read its own TIFF files. (" + i + ", " + j + ")");
      return null;
    } 
    for (byte b1 = 0; b1 < TIFF_HEADER.length; b1++) {
      if (b1 != 30 && b1 != 31 && b1 != 42 && b1 != 43 && b1 != 102 && b1 != 103 && b1 != 114 && b1 != 115 && b1 != 116 && b1 != 117 && paramArrayOfbyte[b1] != TIFF_HEADER[b1]) {
        System.err.println("Error: Processing can only read its own TIFF files. (" + b1 + ")");
        return null;
      } 
    } 
    PImage pImage = new PImage(i, j, 1);
    char c = '̀';
    k /= 3;
    for (byte b2 = 0; b2 < k; b2++)
      pImage.pixels[b2] = 0xFF000000 | (paramArrayOfbyte[c++] & 0xFF) << 16 | (paramArrayOfbyte[c++] & 0xFF) << 8 | paramArrayOfbyte[c++] & 0xFF; 
    return pImage;
  }
  
  protected boolean saveTIFF(OutputStream paramOutputStream) {
    try {
      byte[] arrayOfByte = new byte[768];
      System.arraycopy(TIFF_HEADER, 0, arrayOfByte, 0, TIFF_HEADER.length);
      arrayOfByte[30] = (byte)(this.width >> 8 & 0xFF);
      arrayOfByte[31] = (byte)(this.width & 0xFF);
      arrayOfByte[102] = (byte)(this.height >> 8 & 0xFF);
      arrayOfByte[42] = (byte)(this.height >> 8 & 0xFF);
      arrayOfByte[103] = (byte)(this.height & 0xFF);
      arrayOfByte[43] = (byte)(this.height & 0xFF);
      int i = this.width * this.height * 3;
      arrayOfByte[114] = (byte)(i >> 24 & 0xFF);
      arrayOfByte[115] = (byte)(i >> 16 & 0xFF);
      arrayOfByte[116] = (byte)(i >> 8 & 0xFF);
      arrayOfByte[117] = (byte)(i & 0xFF);
      paramOutputStream.write(arrayOfByte);
      for (byte b = 0; b < this.pixels.length; b++) {
        paramOutputStream.write(this.pixels[b] >> 16 & 0xFF);
        paramOutputStream.write(this.pixels[b] >> 8 & 0xFF);
        paramOutputStream.write(this.pixels[b] & 0xFF);
      } 
      paramOutputStream.flush();
      return true;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return false;
    } 
  }
  
  protected boolean saveTGA(OutputStream paramOutputStream) {
    byte[] arrayOfByte = new byte[18];
    if (this.format == 4) {
      arrayOfByte[2] = 11;
      arrayOfByte[16] = 8;
      arrayOfByte[17] = 40;
    } else if (this.format == 1) {
      arrayOfByte[2] = 10;
      arrayOfByte[16] = 24;
      arrayOfByte[17] = 32;
    } else if (this.format == 2) {
      arrayOfByte[2] = 10;
      arrayOfByte[16] = 32;
      arrayOfByte[17] = 40;
    } else {
      throw new RuntimeException("Image format not recognized inside save()");
    } 
    arrayOfByte[12] = (byte)(this.width & 0xFF);
    arrayOfByte[13] = (byte)(this.width >> 8);
    arrayOfByte[14] = (byte)(this.height & 0xFF);
    arrayOfByte[15] = (byte)(this.height >> 8);
    try {
      paramOutputStream.write(arrayOfByte);
      int i = this.height * this.width;
      int j = 0;
      int[] arrayOfInt = new int[128];
      if (this.format == 4) {
        while (j < i) {
          boolean bool = false;
          byte b = 1;
          int k = this.pixels[j] & 0xFF;
          while (j + b < i) {
            if (k != (this.pixels[j + b] & 0xFF) || b == '') {
              bool = (b > 1) ? true : false;
              break;
            } 
            b++;
          } 
          if (bool) {
            paramOutputStream.write(0x80 | b - 1);
            paramOutputStream.write(k);
          } else {
            for (b = 1; j + b < i; b++) {
              int m = this.pixels[j + b] & 0xFF;
              if ((k != m && b < '') || b < 3) {
                arrayOfInt[b] = k = m;
              } else {
                if (k == m)
                  b -= 2; 
                break;
              } 
            } 
            paramOutputStream.write(b - 1);
            for (byte b1 = 0; b1 < b; b1++)
              paramOutputStream.write(arrayOfInt[b1]); 
          } 
          j += b;
        } 
      } else {
        while (j < i) {
          boolean bool = false;
          int k = this.pixels[j];
          byte b;
          for (b = 1; j + b < i; b++) {
            if (k != this.pixels[j + b] || b == '') {
              bool = (b > 1) ? true : false;
              break;
            } 
          } 
          if (bool) {
            paramOutputStream.write(0x80 | b - 1);
            paramOutputStream.write(k & 0xFF);
            paramOutputStream.write(k >> 8 & 0xFF);
            paramOutputStream.write(k >> 16 & 0xFF);
            if (this.format == 2)
              paramOutputStream.write(k >>> 24 & 0xFF); 
          } else {
            for (b = 1; j + b < i; b++) {
              if ((k != this.pixels[j + b] && b < '') || b < 3) {
                arrayOfInt[b] = k = this.pixels[j + b];
              } else {
                if (k == this.pixels[j + b])
                  b -= 2; 
                break;
              } 
            } 
            paramOutputStream.write(b - 1);
            if (this.format == 2) {
              for (byte b1 = 0; b1 < b; b1++) {
                k = arrayOfInt[b1];
                paramOutputStream.write(k & 0xFF);
                paramOutputStream.write(k >> 8 & 0xFF);
                paramOutputStream.write(k >> 16 & 0xFF);
                paramOutputStream.write(k >>> 24 & 0xFF);
              } 
            } else {
              for (byte b1 = 0; b1 < b; b1++) {
                k = arrayOfInt[b1];
                paramOutputStream.write(k & 0xFF);
                paramOutputStream.write(k >> 8 & 0xFF);
                paramOutputStream.write(k >> 16 & 0xFF);
              } 
            } 
          } 
          j += b;
        } 
      } 
      paramOutputStream.flush();
      return true;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return false;
    } 
  }
  
  protected boolean saveImageIO(String paramString) throws IOException {
    try {
      boolean bool = (this.format == 2) ? true : true;
      String str1 = paramString.toLowerCase();
      if (str1.endsWith("bmp") || str1.endsWith("jpg") || str1.endsWith("jpeg"))
        bool = true; 
      BufferedImage bufferedImage = new BufferedImage(this.width, this.height, bool);
      bufferedImage.setRGB(0, 0, this.width, this.height, this.pixels, 0, this.width);
      File file = new File(paramString);
      String str2 = paramString.substring(paramString.lastIndexOf('.') + 1);
      return ImageIO.write(bufferedImage, str2, file);
    } catch (Exception exception) {
      exception.printStackTrace();
      throw new IOException("image save failed.");
    } 
  }
  
  public void save(String paramString) {
    boolean bool = false;
    if (this.parent != null) {
      paramString = this.parent.savePath(paramString);
    } else {
      String str = "PImage.save() requires an absolute path. Use createImage(), or pass savePath() to save().";
      PGraphics.showException(str);
    } 
    loadPixels();
    try {
      BufferedOutputStream bufferedOutputStream = null;
      if (this.saveImageFormats == null)
        this.saveImageFormats = ImageIO.getWriterFormatNames(); 
      if (this.saveImageFormats != null)
        for (byte b = 0; b < this.saveImageFormats.length; b++) {
          if (paramString.endsWith("." + this.saveImageFormats[b])) {
            if (!saveImageIO(paramString))
              throw new RuntimeException("Error while saving image."); 
            return;
          } 
        }  
      if (paramString.toLowerCase().endsWith(".tga")) {
        bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString), 32768);
        bool = saveTGA(bufferedOutputStream);
      } else {
        if (!paramString.toLowerCase().endsWith(".tif") && !paramString.toLowerCase().endsWith(".tiff"))
          paramString = paramString + ".tif"; 
        bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString), 32768);
        bool = saveTIFF(bufferedOutputStream);
      } 
      bufferedOutputStream.flush();
      bufferedOutputStream.close();
    } catch (IOException iOException) {
      iOException.printStackTrace();
      bool = false;
    } 
    if (!bool)
      throw new RuntimeException("Error while saving image."); 
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PImage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */