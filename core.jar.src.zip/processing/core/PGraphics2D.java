package processing.core;

import java.awt.Toolkit;
import java.awt.image.DirectColorModel;
import java.awt.image.MemoryImageSource;
import java.util.Arrays;

public class PGraphics2D extends PGraphics {
  PMatrix2D ctm = new PMatrix2D();
  
  PPolygon fpolygon;
  
  PPolygon spolygon;
  
  float[][] svertices;
  
  PPolygon tpolygon;
  
  int[] vertexOrder;
  
  PLine line;
  
  float[][] matrixStack = new float[32][6];
  
  int matrixStackDepth;
  
  DirectColorModel cm;
  
  MemoryImageSource mis;
  
  protected void allocate() {
    this.pixelCount = this.width * this.height;
    this.pixels = new int[this.pixelCount];
    if (this.primarySurface) {
      this.cm = new DirectColorModel(32, 16711680, 65280, 255);
      this.mis = new MemoryImageSource(this.width, this.height, this.pixels, 0, this.width);
      this.mis.setFullBufferUpdates(true);
      this.mis.setAnimated(true);
      this.image = Toolkit.getDefaultToolkit().createImage(this.mis);
    } 
  }
  
  public boolean canDraw() {
    return true;
  }
  
  public void beginDraw() {
    if (!this.settingsInited) {
      defaultSettings();
      this.fpolygon = new PPolygon(this);
      this.spolygon = new PPolygon(this);
      this.spolygon.vertexCount = 4;
      this.svertices = new float[2][];
    } 
    resetMatrix();
    this.vertexCount = 0;
  }
  
  public void endDraw() {
    if (this.mis != null)
      this.mis.newPixels(this.pixels, this.cm, 0, this.width); 
    updatePixels();
  }
  
  public void beginShape(int paramInt) {
    this.shape = paramInt;
    this.vertexCount = 0;
    this.curveVertexCount = 0;
    this.fpolygon.reset(4);
    this.spolygon.reset(4);
    this.textureImage = null;
  }
  
  public void vertex(float paramFloat1, float paramFloat2, float paramFloat3) {
    showDepthWarningXYZ("vertex");
  }
  
  public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    showDepthWarningXYZ("vertex");
  }
  
  public void breakShape() {
    showWarning("This renderer cannot handle concave shapes or shapes with holes.");
  }
  
  public void endShape(int paramInt) {
    byte b;
    if (this.ctm.isIdentity()) {
      for (byte b1 = 0; b1 < this.vertexCount; b1++) {
        this.vertices[b1][18] = this.vertices[b1][0];
        this.vertices[b1][19] = this.vertices[b1][1];
      } 
    } else {
      for (byte b1 = 0; b1 < this.vertexCount; b1++) {
        this.vertices[b1][18] = this.ctm.multX(this.vertices[b1][0], this.vertices[b1][1]);
        this.vertices[b1][19] = this.ctm.multY(this.vertices[b1][0], this.vertices[b1][1]);
      } 
    } 
    this.fpolygon.texture(this.textureImage);
    this.spolygon.interpARGB = true;
    this.fpolygon.interpARGB = true;
    switch (this.shape) {
      case 2:
        if (this.stroke) {
          if (this.ctm.m00 == this.ctm.m11 && this.strokeWeight == 1.0F) {
            for (byte b2 = 0; b2 < this.vertexCount; b2++)
              thin_point(this.vertices[b2][18], this.vertices[b2][19], this.strokeColor); 
            break;
          } 
          for (byte b1 = 0; b1 < this.vertexCount; b1++) {
            float[] arrayOfFloat = this.vertices[b1];
            thick_point(arrayOfFloat[18], arrayOfFloat[19], arrayOfFloat[20], arrayOfFloat[13], arrayOfFloat[14], arrayOfFloat[15], arrayOfFloat[16]);
          } 
        } 
        break;
      case 4:
        if (this.stroke) {
          boolean bool = (this.shape == 4) ? true : true;
          draw_lines(this.vertices, this.vertexCount - 1, 1, bool, 0);
        } 
        break;
      case 11:
        if (this.fill || this.textureImage != null) {
          this.fpolygon.vertexCount = 3;
          for (byte b1 = 1; b1 < this.vertexCount - 1; b1++) {
            this.fpolygon.vertices[2][3] = this.vertices[0][3];
            this.fpolygon.vertices[2][4] = this.vertices[0][4];
            this.fpolygon.vertices[2][5] = this.vertices[0][5];
            this.fpolygon.vertices[2][6] = this.vertices[0][6];
            this.fpolygon.vertices[2][18] = this.vertices[0][18];
            this.fpolygon.vertices[2][19] = this.vertices[0][19];
            if (this.textureImage != null) {
              this.fpolygon.vertices[2][7] = this.vertices[0][7];
              this.fpolygon.vertices[2][8] = this.vertices[0][8];
            } 
            for (byte b2 = 0; b2 < 2; b2++) {
              this.fpolygon.vertices[b2][3] = this.vertices[b1 + b2][3];
              this.fpolygon.vertices[b2][4] = this.vertices[b1 + b2][4];
              this.fpolygon.vertices[b2][5] = this.vertices[b1 + b2][5];
              this.fpolygon.vertices[b2][6] = this.vertices[b1 + b2][6];
              this.fpolygon.vertices[b2][18] = this.vertices[b1 + b2][18];
              this.fpolygon.vertices[b2][19] = this.vertices[b1 + b2][19];
              if (this.textureImage != null) {
                this.fpolygon.vertices[b2][7] = this.vertices[b1 + b2][7];
                this.fpolygon.vertices[b2][8] = this.vertices[b1 + b2][8];
              } 
            } 
            this.fpolygon.render();
          } 
        } 
        if (this.stroke) {
          byte b1;
          for (b1 = 1; b1 < this.vertexCount; b1++)
            draw_line(this.vertices[0], this.vertices[b1]); 
          for (b1 = 1; b1 < this.vertexCount - 1; b1++)
            draw_line(this.vertices[b1], this.vertices[b1 + 1]); 
          draw_line(this.vertices[this.vertexCount - 1], this.vertices[1]);
        } 
        break;
      case 9:
      case 10:
        b = (this.shape == 9) ? 3 : 1;
        if (this.fill || this.textureImage != null) {
          this.fpolygon.vertexCount = 3;
          for (int i = 0; i < this.vertexCount - 2; i += b) {
            for (byte b1 = 0; b1 < 3; b1++) {
              this.fpolygon.vertices[b1][3] = this.vertices[i + b1][3];
              this.fpolygon.vertices[b1][4] = this.vertices[i + b1][4];
              this.fpolygon.vertices[b1][5] = this.vertices[i + b1][5];
              this.fpolygon.vertices[b1][6] = this.vertices[i + b1][6];
              this.fpolygon.vertices[b1][18] = this.vertices[i + b1][18];
              this.fpolygon.vertices[b1][19] = this.vertices[i + b1][19];
              this.fpolygon.vertices[b1][20] = this.vertices[i + b1][20];
              if (this.textureImage != null) {
                this.fpolygon.vertices[b1][7] = this.vertices[i + b1][7];
                this.fpolygon.vertices[b1][8] = this.vertices[i + b1][8];
              } 
            } 
            this.fpolygon.render();
          } 
        } 
        if (this.stroke) {
          if (this.shape == 10) {
            draw_lines(this.vertices, this.vertexCount - 1, 1, 1, 0);
          } else {
            draw_lines(this.vertices, this.vertexCount - 1, 1, 1, 3);
          } 
          draw_lines(this.vertices, this.vertexCount - 2, 2, b, 0);
        } 
        break;
      case 16:
        if (this.fill || this.textureImage != null) {
          this.fpolygon.vertexCount = 4;
          for (byte b1 = 0; b1 < this.vertexCount - 3; b1 += 4) {
            for (byte b2 = 0; b2 < 4; b2++) {
              int i = b1 + b2;
              this.fpolygon.vertices[b2][3] = this.vertices[i][3];
              this.fpolygon.vertices[b2][4] = this.vertices[i][4];
              this.fpolygon.vertices[b2][5] = this.vertices[i][5];
              this.fpolygon.vertices[b2][6] = this.vertices[i][6];
              this.fpolygon.vertices[b2][18] = this.vertices[i][18];
              this.fpolygon.vertices[b2][19] = this.vertices[i][19];
              this.fpolygon.vertices[b2][20] = this.vertices[i][20];
              if (this.textureImage != null) {
                this.fpolygon.vertices[b2][7] = this.vertices[i][7];
                this.fpolygon.vertices[b2][8] = this.vertices[i][8];
              } 
            } 
            this.fpolygon.render();
          } 
        } 
        if (this.stroke)
          for (byte b1 = 0; b1 < this.vertexCount - 3; b1 += 4) {
            draw_line(this.vertices[b1 + 0], this.vertices[b1 + 1]);
            draw_line(this.vertices[b1 + 1], this.vertices[b1 + 2]);
            draw_line(this.vertices[b1 + 2], this.vertices[b1 + 3]);
            draw_line(this.vertices[b1 + 3], this.vertices[b1 + 0]);
          }  
        break;
      case 17:
        if (this.fill || this.textureImage != null) {
          this.fpolygon.vertexCount = 4;
          for (byte b1 = 0; b1 < this.vertexCount - 3; b1 += 2) {
            for (byte b2 = 0; b2 < 4; b2++) {
              int i = b1 + b2;
              if (b2 == 2)
                i = b1 + 3; 
              if (b2 == 3)
                i = b1 + 2; 
              this.fpolygon.vertices[b2][3] = this.vertices[i][3];
              this.fpolygon.vertices[b2][4] = this.vertices[i][4];
              this.fpolygon.vertices[b2][5] = this.vertices[i][5];
              this.fpolygon.vertices[b2][6] = this.vertices[i][6];
              this.fpolygon.vertices[b2][18] = this.vertices[i][18];
              this.fpolygon.vertices[b2][19] = this.vertices[i][19];
              this.fpolygon.vertices[b2][20] = this.vertices[i][20];
              if (this.textureImage != null) {
                this.fpolygon.vertices[b2][7] = this.vertices[i][7];
                this.fpolygon.vertices[b2][8] = this.vertices[i][8];
              } 
            } 
            this.fpolygon.render();
          } 
        } 
        if (this.stroke) {
          draw_lines(this.vertices, this.vertexCount - 1, 1, 2, 0);
          draw_lines(this.vertices, this.vertexCount - 2, 2, 1, 0);
        } 
        break;
      case 20:
        if (isConvex()) {
          if (this.fill || this.textureImage != null)
            this.fpolygon.renderPolygon(this.vertices, this.vertexCount); 
          if (this.stroke) {
            draw_lines(this.vertices, this.vertexCount - 1, 1, 1, 0);
            if (paramInt == 2)
              draw_line(this.vertices[this.vertexCount - 1], this.vertices[0]); 
          } 
          break;
        } 
        if (this.fill || this.textureImage != null) {
          boolean bool = this.smooth;
          if (this.stroke)
            this.smooth = false; 
          concaveRender();
          if (this.stroke)
            this.smooth = bool; 
        } 
        if (this.stroke) {
          draw_lines(this.vertices, this.vertexCount - 1, 1, 1, 0);
          if (paramInt == 2)
            draw_line(this.vertices[this.vertexCount - 1], this.vertices[0]); 
        } 
        break;
    } 
    this.shape = 0;
  }
  
  private boolean isConvex() {
    if (this.vertexCount < 3)
      return true; 
    int i = 0;
    for (byte b = 0; b < this.vertexCount; b++) {
      float[] arrayOfFloat1 = this.vertices[b];
      float[] arrayOfFloat2 = this.vertices[(b + 1) % this.vertexCount];
      float[] arrayOfFloat3 = this.vertices[(b + 2) % this.vertexCount];
      float f = (arrayOfFloat2[18] - arrayOfFloat1[18]) * (arrayOfFloat3[19] - arrayOfFloat2[19]) - (arrayOfFloat2[19] - arrayOfFloat1[19]) * (arrayOfFloat3[18] - arrayOfFloat2[18]);
      if (f < 0.0F) {
        i |= 0x1;
      } else if (f > 0.0F) {
        i |= 0x2;
      } 
      if (i == 3)
        return false; 
    } 
    return (i != 0) ? true : true;
  }
  
  protected void concaveRender() {
    if (this.vertexOrder == null || this.vertexOrder.length != this.vertices.length)
      this.vertexOrder = new int[this.vertices.length]; 
    if (this.tpolygon == null)
      this.tpolygon = new PPolygon(this); 
    this.tpolygon.reset(3);
    float f = 0.0F;
    int i = this.vertexCount - 1;
    byte b1 = 0;
    while (b1 < this.vertexCount) {
      f += this.vertices[b1][0] * this.vertices[i][1] - this.vertices[i][0] * this.vertices[b1][1];
      i = b1++;
    } 
    if (f == 0.0F)
      return; 
    float[] arrayOfFloat1 = this.vertices[0];
    float[] arrayOfFloat2 = this.vertices[this.vertexCount - 1];
    if (Math.abs(arrayOfFloat1[0] - arrayOfFloat2[0]) < 1.0E-4F && Math.abs(arrayOfFloat1[1] - arrayOfFloat2[1]) < 1.0E-4F && Math.abs(arrayOfFloat1[2] - arrayOfFloat2[2]) < 1.0E-4F)
      this.vertexCount--; 
    int j;
    for (j = 0; j < this.vertexCount; j++)
      this.vertexOrder[j] = (f > 0.0F) ? j : (this.vertexCount - 1 - j); 
    j = this.vertexCount;
    int k = 2 * j;
    byte b2 = 0;
    int m = j - 1;
    while (j > 2) {
      boolean bool = true;
      if (0 >= k--)
        break; 
      int n = m;
      if (j <= n)
        n = 0; 
      m = n + 1;
      if (j <= m)
        m = 0; 
      int i1 = m + 1;
      if (j <= i1)
        i1 = 0; 
      double d1 = (-10.0F * this.vertices[this.vertexOrder[n]][0]);
      double d2 = (10.0F * this.vertices[this.vertexOrder[n]][1]);
      double d3 = (-10.0F * this.vertices[this.vertexOrder[m]][0]);
      double d4 = (10.0F * this.vertices[this.vertexOrder[m]][1]);
      double d5 = (-10.0F * this.vertices[this.vertexOrder[i1]][0]);
      double d6 = (10.0F * this.vertices[this.vertexOrder[i1]][1]);
      if (9.999999747378752E-5D > (d3 - d1) * (d6 - d2) - (d4 - d2) * (d5 - d1))
        continue; 
      int i2;
      for (i2 = 0; i2 < j; i2++) {
        if (i2 != n && i2 != m && i2 != i1) {
          double d7 = (-10.0F * this.vertices[this.vertexOrder[i2]][0]);
          double d8 = (10.0F * this.vertices[this.vertexOrder[i2]][1]);
          double d9 = d5 - d3;
          double d10 = d6 - d4;
          double d11 = d1 - d5;
          double d12 = d2 - d6;
          double d13 = d3 - d1;
          double d14 = d4 - d2;
          double d15 = d7 - d1;
          double d16 = d8 - d2;
          double d17 = d7 - d3;
          double d18 = d8 - d4;
          double d19 = d7 - d5;
          double d20 = d8 - d6;
          double d21 = d9 * d18 - d10 * d17;
          double d22 = d13 * d16 - d14 * d15;
          double d23 = d11 * d20 - d12 * d19;
          if (d21 >= 0.0D && d23 >= 0.0D && d22 >= 0.0D)
            bool = false; 
        } 
      } 
      if (bool) {
        this.tpolygon.renderTriangle(this.vertices[this.vertexOrder[n]], this.vertices[this.vertexOrder[m]], this.vertices[this.vertexOrder[i1]]);
        b2++;
        i2 = m;
        for (int i3 = m + 1; i3 < j; i3++) {
          this.vertexOrder[i2] = this.vertexOrder[i3];
          i2++;
        } 
        k = 2 * --j;
      } 
    } 
  }
  
  public void point(float paramFloat1, float paramFloat2, float paramFloat3) {
    showDepthWarningXYZ("point");
  }
  
  protected void rectImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.smooth || this.strokeAlpha || this.ctm.isWarped()) {
      super.rectImpl(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    } else {
      int i = (int)(paramFloat1 + this.ctm.m02);
      int j = (int)(paramFloat2 + this.ctm.m12);
      int k = (int)(paramFloat3 + this.ctm.m02);
      int m = (int)(paramFloat4 + this.ctm.m12);
      if (this.fill)
        simple_rect_fill(i, j, k, m); 
      if (this.stroke)
        if (this.strokeWeight == 1.0F) {
          thin_flat_line(i, j, k, j);
          thin_flat_line(k, j, k, m);
          thin_flat_line(k, m, i, m);
          thin_flat_line(i, m, i, j);
        } else {
          thick_flat_line(i, j, this.strokeR, this.strokeG, this.strokeB, this.strokeA, k, j, this.strokeR, this.strokeG, this.strokeB, this.strokeA);
          thick_flat_line(k, j, this.strokeR, this.strokeG, this.strokeB, this.strokeA, k, m, this.strokeR, this.strokeG, this.strokeB, this.strokeA);
          thick_flat_line(k, m, this.strokeR, this.strokeG, this.strokeB, this.strokeA, i, m, this.strokeR, this.strokeG, this.strokeB, this.strokeA);
          thick_flat_line(i, m, this.strokeR, this.strokeG, this.strokeB, this.strokeA, i, j, this.strokeR, this.strokeG, this.strokeB, this.strokeA);
        }  
    } 
  }
  
  private void simple_rect_fill(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt4 < paramInt2) {
      int j = paramInt2;
      paramInt2 = paramInt4;
      paramInt4 = j;
    } 
    if (paramInt3 < paramInt1) {
      int j = paramInt1;
      paramInt1 = paramInt3;
      paramInt3 = j;
    } 
    if (paramInt1 > this.width1 || paramInt3 < 0 || paramInt2 > this.height1 || paramInt4 < 0)
      return; 
    if (paramInt1 < 0)
      paramInt1 = 0; 
    if (paramInt3 > this.width)
      paramInt3 = this.width; 
    if (paramInt2 < 0)
      paramInt2 = 0; 
    if (paramInt4 > this.height)
      paramInt4 = this.height; 
    int i = paramInt3 - paramInt1;
    if (this.fillAlpha) {
      for (int j = paramInt2; j < paramInt4; j++) {
        int k = j * this.width + paramInt1;
        for (byte b = 0; b < i; b++) {
          this.pixels[k] = blend_fill(this.pixels[k]);
          k++;
        } 
      } 
    } else {
      int j = paramInt4 - paramInt2;
      int k = paramInt2 * this.width + paramInt1;
      int m = k;
      byte b;
      for (b = 0; b < i; b++)
        this.pixels[k + b] = this.fillColor; 
      for (b = 0; b < j; b++) {
        System.arraycopy(this.pixels, m, this.pixels, k, i);
        k += this.width;
      } 
    } 
  }
  
  protected void ellipseImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.smooth || this.strokeWeight != 1.0F || this.fillAlpha || this.strokeAlpha || this.ctm.isWarped()) {
      float f1 = paramFloat3 / 2.0F;
      float f2 = paramFloat4 / 2.0F;
      float f3 = paramFloat1 + f1;
      float f4 = paramFloat2 + f2;
      float f5 = screenX(paramFloat1, paramFloat2);
      float f6 = screenY(paramFloat1, paramFloat2);
      float f7 = screenX(paramFloat1 + paramFloat3, paramFloat2 + paramFloat4);
      float f8 = screenY(paramFloat1 + paramFloat3, paramFloat2 + paramFloat4);
      int i = (int)(6.2831855F * PApplet.dist(f5, f6, f7, f8) / 8.0F);
      if (i < 4)
        return; 
      float f9 = 720.0F / i;
      float f10 = 0.0F;
      if (this.fill) {
        boolean bool = this.stroke;
        this.stroke = false;
        beginShape();
        for (byte b = 0; b < i; b++) {
          vertex(f3 + cosLUT[(int)f10] * f1, f4 + sinLUT[(int)f10] * f2);
          f10 += f9;
        } 
        endShape(2);
        this.stroke = bool;
      } 
      if (this.stroke) {
        boolean bool = this.fill;
        this.fill = false;
        f10 = 0.0F;
        beginShape();
        for (byte b = 0; b < i; b++) {
          vertex(f3 + cosLUT[(int)f10] * f1, f4 + sinLUT[(int)f10] * f2);
          f10 += f9;
        } 
        endShape(2);
        this.fill = bool;
      } 
    } else {
      float f1 = paramFloat3 / 2.0F;
      float f2 = paramFloat4 / 2.0F;
      int i = (int)(paramFloat1 + f1 + this.ctm.m02);
      int j = (int)(paramFloat2 + f2 + this.ctm.m12);
      int k = (int)f1;
      int m = (int)f2;
      if (k == m) {
        if (this.fill)
          flat_circle_fill(i, j, k); 
        if (this.stroke)
          flat_circle_stroke(i, j, k); 
      } else {
        if (this.fill)
          flat_ellipse_internal(i, j, k, m, true); 
        if (this.stroke)
          flat_ellipse_internal(i, j, k, m, false); 
      } 
    } 
  }
  
  private void flat_circle_stroke(int paramInt1, int paramInt2, int paramInt3) {
    byte b1 = 0;
    int i = paramInt3;
    byte b2 = 1;
    int j = 2 * paramInt3 - 1;
    int k = 0;
    while (b1 < i) {
      thin_point((paramInt1 + b1), (paramInt2 + i), this.strokeColor);
      thin_point((paramInt1 + i), (paramInt2 - b1), this.strokeColor);
      thin_point((paramInt1 - b1), (paramInt2 - i), this.strokeColor);
      thin_point((paramInt1 - i), (paramInt2 + b1), this.strokeColor);
      b1++;
      k += b2;
      b2 += 2;
      if (j < 2 * k) {
        i--;
        k -= j;
        j -= 2;
      } 
      if (b1 > i)
        break; 
      thin_point((paramInt1 + i), (paramInt2 + b1), this.strokeColor);
      thin_point((paramInt1 + b1), (paramInt2 - i), this.strokeColor);
      thin_point((paramInt1 - i), (paramInt2 - b1), this.strokeColor);
      thin_point((paramInt1 - b1), (paramInt2 + i), this.strokeColor);
    } 
  }
  
  private void flat_circle_fill(int paramInt1, int paramInt2, int paramInt3) {
    byte b1 = 0;
    int i = paramInt3;
    byte b2 = 1;
    int j = 2 * paramInt3 - 1;
    int k = 0;
    while (b1 < i) {
      int m;
      for (m = paramInt1; m < paramInt1 + b1; m++)
        thin_point(m, (paramInt2 + i), this.fillColor); 
      for (m = paramInt1; m < paramInt1 + i; m++)
        thin_point(m, (paramInt2 - b1), this.fillColor); 
      for (m = paramInt1 - b1; m < paramInt1; m++)
        thin_point(m, (paramInt2 - i), this.fillColor); 
      for (m = paramInt1 - i; m < paramInt1; m++)
        thin_point(m, (paramInt2 + b1), this.fillColor); 
      b1++;
      k += b2;
      b2 += 2;
      if (j < 2 * k) {
        i--;
        k -= j;
        j -= 2;
      } 
      if (b1 > i)
        break; 
      for (m = paramInt1; m < paramInt1 + i; m++)
        thin_point(m, (paramInt2 + b1), this.fillColor); 
      for (m = paramInt1; m < paramInt1 + b1; m++)
        thin_point(m, (paramInt2 - i), this.fillColor); 
      for (m = paramInt1 - i; m < paramInt1; m++)
        thin_point(m, (paramInt2 - b1), this.fillColor); 
      for (m = paramInt1 - b1; m < paramInt1; m++)
        thin_point(m, (paramInt2 + i), this.fillColor); 
    } 
  }
  
  private final void flat_ellipse_symmetry(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    if (paramBoolean) {
      for (int i = paramInt1 - paramInt3 + 1; i < paramInt1 + paramInt3; i++) {
        thin_point(i, (paramInt2 - paramInt4), this.fillColor);
        thin_point(i, (paramInt2 + paramInt4), this.fillColor);
      } 
    } else {
      thin_point((paramInt1 - paramInt3), (paramInt2 + paramInt4), this.strokeColor);
      thin_point((paramInt1 + paramInt3), (paramInt2 + paramInt4), this.strokeColor);
      thin_point((paramInt1 - paramInt3), (paramInt2 - paramInt4), this.strokeColor);
      thin_point((paramInt1 + paramInt3), (paramInt2 - paramInt4), this.strokeColor);
    } 
  }
  
  private void flat_ellipse_internal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    int j = paramInt3 * paramInt3;
    int k = paramInt4 * paramInt4;
    byte b = 0;
    int i = paramInt4;
    int m = j * (1 - 2 * paramInt4) + 2 * k;
    int n = k - 2 * j * (2 * paramInt4 - 1);
    flat_ellipse_symmetry(paramInt1, paramInt2, b, i, paramBoolean);
    do {
      if (m < 0) {
        m += 2 * k * (2 * b + 3);
        n += 4 * k * (b + 1);
        b++;
      } else if (n < 0) {
        m += 2 * k * (2 * b + 3) - 4 * j * (i - 1);
        n += 4 * k * (b + 1) - 2 * j * (2 * i - 3);
        b++;
        i--;
      } else {
        m -= 4 * j * (i - 1);
        n -= 2 * j * (2 * i - 3);
        i--;
      } 
      flat_ellipse_symmetry(paramInt1, paramInt2, b, i, paramBoolean);
    } while (i > 0);
  }
  
  protected void arcImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    float f1 = paramFloat3 / 2.0F;
    float f2 = paramFloat4 / 2.0F;
    float f3 = paramFloat1 + f1;
    float f4 = paramFloat2 + f2;
    if (this.fill) {
      boolean bool = this.stroke;
      this.stroke = false;
      int i = (int)(-0.5F + paramFloat5 / 6.2831855F * 720.0F);
      int j = (int)(0.5F + paramFloat6 / 6.2831855F * 720.0F);
      beginShape();
      vertex(f3, f4);
      for (int k = i; k < j; k++) {
        int m = k % 720;
        if (m < 0)
          m += 720; 
        vertex(f3 + cosLUT[m] * f1, f4 + sinLUT[m] * f2);
      } 
      endShape(2);
      this.stroke = bool;
    } 
    if (this.stroke) {
      boolean bool = this.fill;
      this.fill = false;
      int i = (int)(0.5F + paramFloat5 / 6.2831855F * 720.0F);
      int j = (int)(0.5F + paramFloat6 / 6.2831855F * 720.0F);
      beginShape();
      byte b = 1;
      int k;
      for (k = i; k < j; k += b) {
        int m = k % 720;
        if (m < 0)
          m += 720; 
        vertex(f3 + cosLUT[m] * f1, f4 + sinLUT[m] * f2);
      } 
      vertex(f3 + cosLUT[j % 720] * f1, f4 + sinLUT[j % 720] * f2);
      endShape();
      this.fill = bool;
    } 
  }
  
  public void box(float paramFloat) {
    showDepthWarning("box");
  }
  
  public void box(float paramFloat1, float paramFloat2, float paramFloat3) {
    showDepthWarning("box");
  }
  
  public void sphereDetail(int paramInt) {
    showDepthWarning("sphereDetail");
  }
  
  public void sphereDetail(int paramInt1, int paramInt2) {
    showDepthWarning("sphereDetail");
  }
  
  public void sphere(float paramFloat) {
    showDepthWarning("sphere");
  }
  
  public void bezier(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12) {
    showDepthWarningXYZ("bezier");
  }
  
  public void curve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12) {
    showDepthWarningXYZ("curve");
  }
  
  protected void imageImpl(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramFloat3 - paramFloat1 == paramPImage.width && paramFloat4 - paramFloat2 == paramPImage.height && !this.tint && !this.ctm.isWarped()) {
      simple_image(paramPImage, (int)(paramFloat1 + this.ctm.m02), (int)(paramFloat2 + this.ctm.m12), paramInt1, paramInt2, paramInt3, paramInt4);
    } else {
      super.imageImpl(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4);
    } 
  }
  
  private void simple_image(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    int i = paramInt1 + paramPImage.width;
    int j = paramInt2 + paramPImage.height;
    if (paramInt1 > this.width1 || i < 0 || paramInt2 > this.height1 || j < 0)
      return; 
    if (paramInt1 < 0) {
      paramInt3 -= paramInt1;
      paramInt1 = 0;
    } 
    if (paramInt2 < 0) {
      paramInt4 -= paramInt2;
      paramInt2 = 0;
    } 
    if (i > this.width) {
      paramInt5 -= i - this.width;
      i = this.width;
    } 
    if (j > this.height) {
      paramInt6 -= j - this.height;
      j = this.height;
    } 
    int k = paramInt4 * paramPImage.width + paramInt3;
    int m = paramInt2 * this.width;
    if (paramPImage.format == 2) {
      for (int n = paramInt2; n < j; n++) {
        byte b = 0;
        for (int i1 = paramInt1; i1 < i; i1++)
          this.pixels[m + i1] = blend_color(this.pixels[m + i1], paramPImage.pixels[k + b++]); 
        k += paramPImage.width;
        m += this.width;
      } 
    } else if (paramPImage.format == 4) {
      for (int n = paramInt2; n < j; n++) {
        byte b = 0;
        for (int i1 = paramInt1; i1 < i; i1++)
          this.pixels[m + i1] = blend_color_alpha(this.pixels[m + i1], this.fillColor, paramPImage.pixels[k + b++]); 
        k += paramPImage.width;
        m += this.width;
      } 
    } else if (paramPImage.format == 1) {
      m += paramInt1;
      int n = i - paramInt1;
      for (int i1 = paramInt2; i1 < j; i1++) {
        System.arraycopy(paramPImage.pixels, k, this.pixels, m, n);
        k += paramPImage.width;
        m += this.width;
      } 
    } 
  }
  
  private void thin_point_at(int paramInt1, int paramInt2, float paramFloat, int paramInt3) {
    int i = paramInt2 * this.width + paramInt1;
    this.pixels[i] = paramInt3;
  }
  
  private void thin_point_at_index(int paramInt1, float paramFloat, int paramInt2) {
    this.pixels[paramInt1] = paramInt2;
  }
  
  private void thick_point(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    this.spolygon.reset(4);
    this.spolygon.interpARGB = false;
    float f = this.strokeWeight / 2.0F;
    float[] arrayOfFloat = this.spolygon.vertices[0];
    arrayOfFloat[18] = paramFloat1 - f;
    arrayOfFloat[19] = paramFloat2 - f;
    arrayOfFloat[20] = paramFloat3;
    arrayOfFloat[3] = paramFloat4;
    arrayOfFloat[4] = paramFloat5;
    arrayOfFloat[5] = paramFloat6;
    arrayOfFloat[6] = paramFloat7;
    arrayOfFloat = this.spolygon.vertices[1];
    arrayOfFloat[18] = paramFloat1 + f;
    arrayOfFloat[19] = paramFloat2 - f;
    arrayOfFloat[20] = paramFloat3;
    arrayOfFloat = this.spolygon.vertices[2];
    arrayOfFloat[18] = paramFloat1 + f;
    arrayOfFloat[19] = paramFloat2 + f;
    arrayOfFloat[20] = paramFloat3;
    arrayOfFloat = this.spolygon.vertices[3];
    arrayOfFloat[18] = paramFloat1 - f;
    arrayOfFloat[19] = paramFloat2 + f;
    arrayOfFloat[20] = paramFloat3;
    this.spolygon.render();
  }
  
  private void thin_flat_line(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i;
    int j;
    int k;
    int m;
    int i5;
    int n = thin_flat_line_clip_code(paramInt1, paramInt2);
    int i1 = thin_flat_line_clip_code(paramInt3, paramInt4);
    if ((n & i1) != 0)
      return; 
    int i2 = n | i1;
    if (i2 != 0) {
      float f1 = 0.0F;
      float f2 = 1.0F;
      float f3 = 0.0F;
      for (byte b = 0; b < 4; b++) {
        if ((i2 >> b) % 2 == 1) {
          f3 = thin_flat_line_slope(paramInt1, paramInt2, paramInt3, paramInt4, b + 1);
          if ((n >> b) % 2 == 1) {
            f1 = Math.max(f3, f1);
          } else {
            f2 = Math.min(f3, f2);
          } 
        } 
      } 
      if (f1 > f2)
        return; 
      i = (int)(paramInt1 + f1 * (paramInt3 - paramInt1));
      j = (int)(paramInt2 + f1 * (paramInt4 - paramInt2));
      k = (int)(paramInt1 + f2 * (paramInt3 - paramInt1));
      m = (int)(paramInt2 + f2 * (paramInt4 - paramInt2));
    } else {
      i = paramInt1;
      k = paramInt3;
      j = paramInt2;
      m = paramInt4;
    } 
    i2 = 0;
    int i3 = m - j;
    int i4 = k - i;
    if (Math.abs(i3) > Math.abs(i4)) {
      i5 = i3;
      i3 = i4;
      i4 = i5;
      i2 = 1;
    } 
    if (i4 == 0) {
      i5 = 0;
    } else {
      i5 = (i3 << 16) / i4;
    } 
    if (i == k) {
      if (j > m) {
        int i9 = j;
        j = m;
        m = i9;
      } 
      int i7 = j * this.width + i;
      for (int i8 = j; i8 <= m; i8++) {
        thin_point_at_index(i7, 0.0F, this.strokeColor);
        i7 += this.width;
      } 
      return;
    } 
    if (j == m) {
      if (i > k) {
        int i9 = i;
        i = k;
        k = i9;
      } 
      int i7 = j * this.width + i;
      for (int i8 = i; i8 <= k; i8++)
        thin_point_at_index(i7++, 0.0F, this.strokeColor); 
      return;
    } 
    if (i2 != 0) {
      if (i4 > 0) {
        i4 += j;
        int i8 = 32768 + (i << 16);
        while (j <= i4) {
          thin_point_at(i8 >> 16, j, 0.0F, this.strokeColor);
          i8 += i5;
          j++;
        } 
        return;
      } 
      i4 += j;
      int i7 = 32768 + (i << 16);
      while (j >= i4) {
        thin_point_at(i7 >> 16, j, 0.0F, this.strokeColor);
        i7 -= i5;
        j--;
      } 
      return;
    } 
    if (i4 > 0) {
      i4 += i;
      int i7 = 32768 + (j << 16);
      while (i <= i4) {
        thin_point_at(i, i7 >> 16, 0.0F, this.strokeColor);
        i7 += i5;
        i++;
      } 
      return;
    } 
    i4 += i;
    int i6 = 32768 + (j << 16);
    while (i >= i4) {
      thin_point_at(i, i6 >> 16, 0.0F, this.strokeColor);
      i6 -= i5;
      i--;
    } 
  }
  
  private int thin_flat_line_clip_code(float paramFloat1, float paramFloat2) {
    return ((paramFloat2 < 0.0F) ? 8 : 0) | ((paramFloat2 > this.height1) ? 4 : 0) | ((paramFloat1 < 0.0F) ? 2 : 0) | ((paramFloat1 > this.width1) ? 1 : 0);
  }
  
  private float thin_flat_line_slope(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt) {
    switch (paramInt) {
      case 4:
        return -paramFloat2 / (paramFloat4 - paramFloat2);
      case 3:
        return (this.height1 - paramFloat2) / (paramFloat4 - paramFloat2);
      case 2:
        return -paramFloat1 / (paramFloat3 - paramFloat1);
      case 1:
        return (this.width1 - paramFloat1) / (paramFloat3 - paramFloat1);
    } 
    return -1.0F;
  }
  
  private void thick_flat_line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12) {
    this.spolygon.interpARGB = (paramFloat3 != paramFloat9 || paramFloat4 != paramFloat10 || paramFloat5 != paramFloat11 || paramFloat6 != paramFloat12);
    float f1 = paramFloat7 - paramFloat1 + 1.0E-4F;
    float f2 = paramFloat8 - paramFloat2 + 1.0E-4F;
    float f3 = (float)Math.sqrt((f1 * f1 + f2 * f2));
    float f4 = this.strokeWeight / f3 / 2.0F;
    float f5 = f4 * f2;
    float f6 = f4 * f1;
    float f7 = f4 * f2;
    float f8 = f4 * f1;
    this.spolygon.reset(4);
    float[] arrayOfFloat = this.spolygon.vertices[0];
    arrayOfFloat[18] = paramFloat1 + f5;
    arrayOfFloat[19] = paramFloat2 - f6;
    arrayOfFloat[3] = paramFloat3;
    arrayOfFloat[4] = paramFloat4;
    arrayOfFloat[5] = paramFloat5;
    arrayOfFloat[6] = paramFloat6;
    arrayOfFloat = this.spolygon.vertices[1];
    arrayOfFloat[18] = paramFloat1 - f5;
    arrayOfFloat[19] = paramFloat2 + f6;
    arrayOfFloat[3] = paramFloat3;
    arrayOfFloat[4] = paramFloat4;
    arrayOfFloat[5] = paramFloat5;
    arrayOfFloat[6] = paramFloat6;
    arrayOfFloat = this.spolygon.vertices[2];
    arrayOfFloat[18] = paramFloat7 - f7;
    arrayOfFloat[19] = paramFloat8 + f8;
    arrayOfFloat[3] = paramFloat9;
    arrayOfFloat[4] = paramFloat10;
    arrayOfFloat[5] = paramFloat11;
    arrayOfFloat[6] = paramFloat12;
    arrayOfFloat = this.spolygon.vertices[3];
    arrayOfFloat[18] = paramFloat7 + f7;
    arrayOfFloat[19] = paramFloat8 - f8;
    arrayOfFloat[3] = paramFloat9;
    arrayOfFloat[4] = paramFloat10;
    arrayOfFloat[5] = paramFloat11;
    arrayOfFloat[6] = paramFloat12;
    this.spolygon.render();
  }
  
  private void draw_line(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
    if (this.strokeWeight == 1.0F) {
      if (this.line == null)
        this.line = new PLine(this); 
      this.line.reset();
      this.line.setIntensities(paramArrayOffloat1[13], paramArrayOffloat1[14], paramArrayOffloat1[15], paramArrayOffloat1[16], paramArrayOffloat2[13], paramArrayOffloat2[14], paramArrayOffloat2[15], paramArrayOffloat2[16]);
      this.line.setVertices(paramArrayOffloat1[18], paramArrayOffloat1[19], paramArrayOffloat1[20], paramArrayOffloat2[18], paramArrayOffloat2[19], paramArrayOffloat2[20]);
      this.line.draw();
    } else {
      thick_flat_line(paramArrayOffloat1[18], paramArrayOffloat1[19], paramArrayOffloat1[13], paramArrayOffloat1[14], paramArrayOffloat1[15], paramArrayOffloat1[16], paramArrayOffloat2[18], paramArrayOffloat2[19], paramArrayOffloat2[13], paramArrayOffloat2[14], paramArrayOffloat2[15], paramArrayOffloat2[16]);
    } 
  }
  
  private void draw_lines(float[][] paramArrayOffloat, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.strokeWeight == 1.0F) {
      int i;
      for (i = 0; i < paramInt1; i += paramInt3) {
        if (paramInt4 == 0 || (i + paramInt2) % paramInt4 != 0) {
          float[] arrayOfFloat1 = paramArrayOffloat[i];
          float[] arrayOfFloat2 = paramArrayOffloat[i + paramInt2];
          if (this.line == null)
            this.line = new PLine(this); 
          this.line.reset();
          this.line.setIntensities(arrayOfFloat1[13], arrayOfFloat1[14], arrayOfFloat1[15], arrayOfFloat1[16], arrayOfFloat2[13], arrayOfFloat2[14], arrayOfFloat2[15], arrayOfFloat2[16]);
          this.line.setVertices(arrayOfFloat1[18], arrayOfFloat1[19], arrayOfFloat1[20], arrayOfFloat2[18], arrayOfFloat2[19], arrayOfFloat2[20]);
          this.line.draw();
        } 
      } 
    } else {
      int i;
      for (i = 0; i < paramInt1; i += paramInt3) {
        if (paramInt4 == 0 || (i + paramInt2) % paramInt4 != 0) {
          float[] arrayOfFloat1 = paramArrayOffloat[i];
          float[] arrayOfFloat2 = paramArrayOffloat[i + paramInt2];
          thick_flat_line(arrayOfFloat1[18], arrayOfFloat1[19], arrayOfFloat1[13], arrayOfFloat1[14], arrayOfFloat1[15], arrayOfFloat1[16], arrayOfFloat2[18], arrayOfFloat2[19], arrayOfFloat2[13], arrayOfFloat2[14], arrayOfFloat2[15], arrayOfFloat2[16]);
        } 
      } 
    } 
  }
  
  private void thin_point(float paramFloat1, float paramFloat2, int paramInt) {
    int i = (int)(paramFloat1 + 0.4999F);
    int j = (int)(paramFloat2 + 0.4999F);
    if (i < 0 || i > this.width1 || j < 0 || j > this.height1)
      return; 
    int k = j * this.width + i;
    if ((paramInt & 0xFF000000) == -16777216) {
      this.pixels[k] = paramInt;
    } else {
      int m = paramInt >> 24 & 0xFF;
      int n = m ^ 0xFF;
      int i1 = this.strokeColor;
      int i2 = this.pixels[k];
      int i3 = n * (i2 >> 16 & 0xFF) + m * (i1 >> 16 & 0xFF) & 0xFF00;
      int i4 = n * (i2 >> 8 & 0xFF) + m * (i1 >> 8 & 0xFF) & 0xFF00;
      int i5 = n * (i2 & 0xFF) + m * (i1 & 0xFF) >> 8;
      this.pixels[k] = 0xFF000000 | i3 << 8 | i4 | i5;
    } 
  }
  
  public void translate(float paramFloat1, float paramFloat2) {
    this.ctm.translate(paramFloat1, paramFloat2);
  }
  
  public void translate(float paramFloat1, float paramFloat2, float paramFloat3) {
    showDepthWarningXYZ("translate");
  }
  
  public void rotate(float paramFloat) {
    this.ctm.rotate(paramFloat);
  }
  
  public void rotateX(float paramFloat) {
    showDepthWarning("rotateX");
  }
  
  public void rotateY(float paramFloat) {
    showDepthWarning("rotateY");
  }
  
  public void rotateZ(float paramFloat) {
    showDepthWarning("rotateZ");
  }
  
  public void rotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    showVariationWarning("rotate(angle, x, y, z)");
  }
  
  public void scale(float paramFloat) {
    this.ctm.scale(paramFloat);
  }
  
  public void scale(float paramFloat1, float paramFloat2) {
    this.ctm.scale(paramFloat1, paramFloat2);
  }
  
  public void scale(float paramFloat1, float paramFloat2, float paramFloat3) {
    showDepthWarningXYZ("scale");
  }
  
  public void skewX(float paramFloat) {
    this.ctm.shearX(paramFloat);
  }
  
  public void skewY(float paramFloat) {
    this.ctm.shearY(paramFloat);
  }
  
  public void pushMatrix() {
    if (this.matrixStackDepth == 32)
      throw new RuntimeException("Too many calls to pushMatrix()."); 
    this.ctm.get(this.matrixStack[this.matrixStackDepth]);
    this.matrixStackDepth++;
  }
  
  public void popMatrix() {
    if (this.matrixStackDepth == 0)
      throw new RuntimeException("Too many calls to popMatrix(), and not enough to pushMatrix()."); 
    this.matrixStackDepth--;
    this.ctm.set(this.matrixStack[this.matrixStackDepth]);
  }
  
  public void resetMatrix() {
    this.ctm.reset();
  }
  
  public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    this.ctm.apply(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16) {
    showDepthWarningXYZ("applyMatrix");
  }
  
  public void printMatrix() {
    this.ctm.print();
  }
  
  public float screenX(float paramFloat1, float paramFloat2) {
    return this.ctm.m00 * paramFloat1 + this.ctm.m01 * paramFloat2 + this.ctm.m02;
  }
  
  public float screenY(float paramFloat1, float paramFloat2) {
    return this.ctm.m10 * paramFloat1 + this.ctm.m11 * paramFloat2 + this.ctm.m12;
  }
  
  protected void backgroundImpl() {
    Arrays.fill(this.pixels, this.backgroundColor);
  }
  
  private final int blend_fill(int paramInt) {
    int i = this.fillAi;
    int j = i ^ 0xFF;
    int k = j * (paramInt >> 16 & 0xFF) + i * this.fillRi & 0xFF00;
    int m = j * (paramInt >> 8 & 0xFF) + i * this.fillGi & 0xFF00;
    int n = j * (paramInt & 0xFF) + i * this.fillBi & 0xFF00;
    return 0xFF000000 | k << 8 | m | n >> 8;
  }
  
  private final int blend_color(int paramInt1, int paramInt2) {
    int i = paramInt2 >>> 24;
    if (i == 255)
      return paramInt2; 
    int j = i ^ 0xFF;
    int k = j * (paramInt1 >> 16 & 0xFF) + i * (paramInt2 >> 16 & 0xFF) & 0xFF00;
    int m = j * (paramInt1 >> 8 & 0xFF) + i * (paramInt2 >> 8 & 0xFF) & 0xFF00;
    int n = j * (paramInt1 & 0xFF) + i * (paramInt2 & 0xFF) >> 8;
    return 0xFF000000 | k << 8 | m | n;
  }
  
  private final int blend_color_alpha(int paramInt1, int paramInt2, int paramInt3) {
    paramInt3 = paramInt3 * (paramInt2 >>> 24) >> 8;
    int i = paramInt3 ^ 0xFF;
    int j = i * (paramInt1 >> 16 & 0xFF) + paramInt3 * (paramInt2 >> 16 & 0xFF) & 0xFF00;
    int k = i * (paramInt1 >> 8 & 0xFF) + paramInt3 * (paramInt2 >> 8 & 0xFF) & 0xFF00;
    int m = i * (paramInt1 & 0xFF) + paramInt3 * (paramInt2 & 0xFF) >> 8;
    return 0xFF000000 | j << 8 | k | m;
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PGraphics2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */