package processing.core;

import java.util.HashMap;

public class PShape implements PConstants {
  protected String name;
  
  protected HashMap<String, PShape> nameTable;
  
  public static final int GROUP = 0;
  
  public static final int PRIMITIVE = 1;
  
  public static final int PATH = 2;
  
  public static final int GEOMETRY = 3;
  
  protected int family = 0;
  
  protected int primitive;
  
  protected PMatrix matrix;
  
  protected PImage image;
  
  public float width;
  
  public float height;
  
  public float depth;
  
  protected boolean visible = true;
  
  protected boolean stroke;
  
  protected int strokeColor;
  
  protected float strokeWeight;
  
  protected int strokeCap;
  
  protected int strokeJoin;
  
  protected boolean fill;
  
  protected int fillColor;
  
  protected boolean style = true;
  
  protected float[] params;
  
  protected int vertexCount;
  
  protected float[][] vertices;
  
  public static final int VERTEX = 0;
  
  public static final int BEZIER_VERTEX = 1;
  
  public static final int QUAD_BEZIER_VERTEX = 2;
  
  public static final int CURVE_VERTEX = 3;
  
  public static final int BREAK = 4;
  
  protected int vertexCodeCount;
  
  protected int[] vertexCodes;
  
  protected boolean close;
  
  protected PShape parent;
  
  protected int childCount;
  
  protected PShape[] children;
  
  public PShape() {}
  
  public PShape(int paramInt) {}
  
  public void setName(String paramString) {
    this.name = paramString;
  }
  
  public String getName() {
    return this.name;
  }
  
  public boolean isVisible() {
    return this.visible;
  }
  
  public void setVisible(boolean paramBoolean) {
    this.visible = paramBoolean;
  }
  
  public void disableStyle() {
    this.style = false;
    for (byte b = 0; b < this.childCount; b++)
      this.children[b].disableStyle(); 
  }
  
  public void enableStyle() {
    this.style = true;
    for (byte b = 0; b < this.childCount; b++)
      this.children[b].enableStyle(); 
  }
  
  public float getWidth() {
    return this.width;
  }
  
  public float getHeight() {
    return this.height;
  }
  
  public float getDepth() {
    return this.depth;
  }
  
  public boolean is3D() {
    return false;
  }
  
  protected void pre(PGraphics paramPGraphics) {
    if (this.matrix != null) {
      paramPGraphics.pushMatrix();
      paramPGraphics.applyMatrix(this.matrix);
    } 
    if (this.style) {
      paramPGraphics.pushStyle();
      styles(paramPGraphics);
    } 
  }
  
  protected void styles(PGraphics paramPGraphics) {
    if (this.stroke) {
      paramPGraphics.stroke(this.strokeColor);
      paramPGraphics.strokeWeight(this.strokeWeight);
      paramPGraphics.strokeCap(this.strokeCap);
      paramPGraphics.strokeJoin(this.strokeJoin);
    } else {
      paramPGraphics.noStroke();
    } 
    if (this.fill) {
      paramPGraphics.fill(this.fillColor);
    } else {
      paramPGraphics.noFill();
    } 
  }
  
  public void post(PGraphics paramPGraphics) {
    if (this.matrix != null)
      paramPGraphics.popMatrix(); 
    if (this.style)
      paramPGraphics.popStyle(); 
  }
  
  public void draw(PGraphics paramPGraphics) {
    if (this.visible) {
      pre(paramPGraphics);
      drawImpl(paramPGraphics);
      post(paramPGraphics);
    } 
  }
  
  public void drawImpl(PGraphics paramPGraphics) {
    if (this.family == 0) {
      drawGroup(paramPGraphics);
    } else if (this.family == 1) {
      drawPrimitive(paramPGraphics);
    } else if (this.family == 3) {
      drawGeometry(paramPGraphics);
    } else if (this.family == 2) {
      drawPath(paramPGraphics);
    } 
  }
  
  protected void drawGroup(PGraphics paramPGraphics) {
    for (byte b = 0; b < this.childCount; b++)
      this.children[b].draw(paramPGraphics); 
  }
  
  protected void drawPrimitive(PGraphics paramPGraphics) {
    if (this.primitive == 2) {
      paramPGraphics.point(this.params[0], this.params[1]);
    } else if (this.primitive == 4) {
      if (this.params.length == 4) {
        paramPGraphics.line(this.params[0], this.params[1], this.params[2], this.params[3]);
      } else {
        paramPGraphics.line(this.params[0], this.params[1], this.params[2], this.params[3], this.params[4], this.params[5]);
      } 
    } else if (this.primitive == 8) {
      paramPGraphics.triangle(this.params[0], this.params[1], this.params[2], this.params[3], this.params[4], this.params[5]);
    } else if (this.primitive == 16) {
      paramPGraphics.quad(this.params[0], this.params[1], this.params[2], this.params[3], this.params[4], this.params[5], this.params[6], this.params[7]);
    } else if (this.primitive == 30) {
      if (this.image != null) {
        paramPGraphics.imageMode(0);
        paramPGraphics.image(this.image, this.params[0], this.params[1], this.params[2], this.params[3]);
      } else {
        paramPGraphics.rectMode(0);
        paramPGraphics.rect(this.params[0], this.params[1], this.params[2], this.params[3]);
      } 
    } else if (this.primitive == 31) {
      paramPGraphics.ellipseMode(0);
      paramPGraphics.ellipse(this.params[0], this.params[1], this.params[2], this.params[3]);
    } else if (this.primitive == 32) {
      paramPGraphics.ellipseMode(0);
      paramPGraphics.arc(this.params[0], this.params[1], this.params[2], this.params[3], this.params[4], this.params[5]);
    } else if (this.primitive == 41) {
      if (this.params.length == 1) {
        paramPGraphics.box(this.params[0]);
      } else {
        paramPGraphics.box(this.params[0], this.params[1], this.params[2]);
      } 
    } else if (this.primitive == 40) {
      paramPGraphics.sphere(this.params[0]);
    } 
  }
  
  protected void drawGeometry(PGraphics paramPGraphics) {
    paramPGraphics.beginShape(this.primitive);
    if (this.style) {
      for (byte b = 0; b < this.vertexCount; b++)
        paramPGraphics.vertex(this.vertices[b]); 
    } else {
      for (byte b = 0; b < this.vertexCount; b++) {
        float[] arrayOfFloat = this.vertices[b];
        if (arrayOfFloat[2] == 0.0F) {
          paramPGraphics.vertex(arrayOfFloat[0], arrayOfFloat[1]);
        } else {
          paramPGraphics.vertex(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2]);
        } 
      } 
    } 
    paramPGraphics.endShape();
  }
  
  protected void drawPath(PGraphics paramPGraphics) {
    if (this.vertices == null)
      return; 
    paramPGraphics.beginShape();
    if (this.vertexCodeCount == 0) {
      if ((this.vertices[0]).length == 2) {
        for (byte b = 0; b < this.vertexCount; b++)
          paramPGraphics.vertex(this.vertices[b][0], this.vertices[b][1]); 
      } else {
        for (byte b = 0; b < this.vertexCount; b++)
          paramPGraphics.vertex(this.vertices[b][0], this.vertices[b][1], this.vertices[b][2]); 
      } 
    } else {
      byte b = 0;
      if ((this.vertices[0]).length == 2) {
        for (byte b1 = 0; b1 < this.vertexCodeCount; b1++) {
          switch (this.vertexCodes[b1]) {
            case 0:
              paramPGraphics.vertex(this.vertices[b][0], this.vertices[b][1]);
              b++;
              break;
            case 2:
              paramPGraphics.quadVertex(this.vertices[b + 0][0], this.vertices[b + 0][1], this.vertices[b + 1][0], this.vertices[b + 1][1]);
              b += 2;
              break;
            case 1:
              paramPGraphics.bezierVertex(this.vertices[b + 0][0], this.vertices[b + 0][1], this.vertices[b + 1][0], this.vertices[b + 1][1], this.vertices[b + 2][0], this.vertices[b + 2][1]);
              b += 3;
              break;
            case 3:
              paramPGraphics.curveVertex(this.vertices[b][0], this.vertices[b][1]);
              b++;
            case 4:
              paramPGraphics.breakShape();
              break;
          } 
        } 
      } else {
        for (byte b1 = 0; b1 < this.vertexCodeCount; b1++) {
          switch (this.vertexCodes[b1]) {
            case 0:
              paramPGraphics.vertex(this.vertices[b][0], this.vertices[b][1], this.vertices[b][2]);
              b++;
              break;
            case 2:
              paramPGraphics.quadVertex(this.vertices[b + 0][0], this.vertices[b + 0][1], this.vertices[b + 0][2], this.vertices[b + 1][0], this.vertices[b + 1][1], this.vertices[b + 0][2]);
              b += 2;
              break;
            case 1:
              paramPGraphics.bezierVertex(this.vertices[b + 0][0], this.vertices[b + 0][1], this.vertices[b + 0][2], this.vertices[b + 1][0], this.vertices[b + 1][1], this.vertices[b + 1][2], this.vertices[b + 2][0], this.vertices[b + 2][1], this.vertices[b + 2][2]);
              b += 3;
              break;
            case 3:
              paramPGraphics.curveVertex(this.vertices[b][0], this.vertices[b][1], this.vertices[b][2]);
              b++;
            case 4:
              paramPGraphics.breakShape();
              break;
          } 
        } 
      } 
    } 
    paramPGraphics.endShape(this.close ? 2 : 1);
  }
  
  public PShape getParent() {
    return this.parent;
  }
  
  public int getChildCount() {
    return this.childCount;
  }
  
  public PShape[] getChildren() {
    return this.children;
  }
  
  public PShape getChild(int paramInt) {
    return this.children[paramInt];
  }
  
  public PShape getChild(String paramString) {
    if (this.name != null && this.name.equals(paramString))
      return this; 
    if (this.nameTable != null) {
      PShape pShape = this.nameTable.get(paramString);
      if (pShape != null)
        return pShape; 
    } 
    for (byte b = 0; b < this.childCount; b++) {
      PShape pShape = this.children[b].getChild(paramString);
      if (pShape != null)
        return pShape; 
    } 
    return null;
  }
  
  public PShape findChild(String paramString) {
    return (this.parent == null) ? getChild(paramString) : this.parent.findChild(paramString);
  }
  
  public void addChild(PShape paramPShape) {
    if (this.children == null)
      this.children = new PShape[1]; 
    if (this.childCount == this.children.length)
      this.children = (PShape[])PApplet.expand(this.children); 
    this.children[this.childCount++] = paramPShape;
    paramPShape.parent = this;
    if (paramPShape.getName() != null)
      addName(paramPShape.getName(), paramPShape); 
  }
  
  public void addChild(PShape paramPShape, int paramInt) {
    if (paramInt < this.childCount) {
      if (this.childCount == this.children.length)
        this.children = (PShape[])PApplet.expand(this.children); 
      for (int i = this.childCount - 1; i >= paramInt; i--)
        this.children[i + 1] = this.children[i]; 
      this.childCount++;
      this.children[paramInt] = paramPShape;
      paramPShape.parent = this;
      if (paramPShape.getName() != null)
        addName(paramPShape.getName(), paramPShape); 
    } 
  }
  
  public void removeChild(int paramInt) {
    if (paramInt < this.childCount) {
      PShape pShape = this.children[paramInt];
      for (int i = paramInt; i < this.childCount - 1; i++)
        this.children[i] = this.children[i + 1]; 
      this.childCount--;
      if (pShape.getName() != null && this.nameTable != null)
        this.nameTable.remove(pShape.getName()); 
    } 
  }
  
  public void addName(String paramString, PShape paramPShape) {
    if (this.parent != null) {
      this.parent.addName(paramString, paramPShape);
    } else {
      if (this.nameTable == null)
        this.nameTable = new HashMap<String, PShape>(); 
      this.nameTable.put(paramString, paramPShape);
    } 
  }
  
  public int getChildIndex(PShape paramPShape) {
    for (byte b = 0; b < this.childCount; b++) {
      if (this.children[b] == paramPShape)
        return b; 
    } 
    return -1;
  }
  
  public int getFamily() {
    return this.family;
  }
  
  public int getPrimitive() {
    return this.primitive;
  }
  
  public float[] getParams() {
    return getParams(null);
  }
  
  public float[] getParams(float[] paramArrayOffloat) {
    if (paramArrayOffloat == null || paramArrayOffloat.length != this.params.length)
      paramArrayOffloat = new float[this.params.length]; 
    PApplet.arrayCopy(this.params, paramArrayOffloat);
    return paramArrayOffloat;
  }
  
  public float getParam(int paramInt) {
    return this.params[paramInt];
  }
  
  public int getVertexCount() {
    return this.vertexCount;
  }
  
  public float[] getVertex(int paramInt) {
    if (paramInt < 0 || paramInt >= this.vertexCount) {
      String str = "No vertex " + paramInt + " for this shape, " + "only vertices 0 through " + (this.vertexCount - 1) + ".";
      throw new IllegalArgumentException(str);
    } 
    return this.vertices[paramInt];
  }
  
  public float getVertexX(int paramInt) {
    return this.vertices[paramInt][0];
  }
  
  public float getVertexY(int paramInt) {
    return this.vertices[paramInt][1];
  }
  
  public float getVertexZ(int paramInt) {
    return this.vertices[paramInt][2];
  }
  
  public int[] getVertexCodes() {
    if (this.vertexCodes == null)
      return null; 
    if (this.vertexCodes.length != this.vertexCodeCount)
      this.vertexCodes = PApplet.subset(this.vertexCodes, 0, this.vertexCodeCount); 
    return this.vertexCodes;
  }
  
  public int getVertexCodeCount() {
    return this.vertexCodeCount;
  }
  
  public int getVertexCode(int paramInt) {
    return this.vertexCodes[paramInt];
  }
  
  public boolean isClosed() {
    return this.close;
  }
  
  public boolean contains(float paramFloat1, float paramFloat2) {
    if (this.family == 2) {
      boolean bool = false;
      byte b = 0;
      int i;
      for (i = this.vertexCount - 1; b < this.vertexCount; i = b++) {
        if (((this.vertices[b][1] > paramFloat2) ? true : false) != ((this.vertices[i][1] > paramFloat2) ? true : false) && paramFloat1 < (this.vertices[i][0] - this.vertices[b][0]) * (paramFloat2 - this.vertices[b][1]) / (this.vertices[i][1] - this.vertices[b][1]) + this.vertices[b][0])
          bool = !bool ? true : false; 
      } 
      return bool;
    } 
    throw new IllegalArgumentException("The contains() method is only implemented for paths.");
  }
  
  public void translate(float paramFloat1, float paramFloat2) {
    checkMatrix(2);
    this.matrix.translate(paramFloat1, paramFloat2);
  }
  
  public void translate(float paramFloat1, float paramFloat2, float paramFloat3) {
    checkMatrix(3);
    this.matrix.translate(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void rotateX(float paramFloat) {
    rotate(paramFloat, 1.0F, 0.0F, 0.0F);
  }
  
  public void rotateY(float paramFloat) {
    rotate(paramFloat, 0.0F, 1.0F, 0.0F);
  }
  
  public void rotateZ(float paramFloat) {
    rotate(paramFloat, 0.0F, 0.0F, 1.0F);
  }
  
  public void rotate(float paramFloat) {
    checkMatrix(2);
    this.matrix.rotate(paramFloat);
  }
  
  public void rotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    checkMatrix(3);
    this.matrix.rotate(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void scale(float paramFloat) {
    checkMatrix(2);
    this.matrix.scale(paramFloat);
  }
  
  public void scale(float paramFloat1, float paramFloat2) {
    checkMatrix(2);
    this.matrix.scale(paramFloat1, paramFloat2);
  }
  
  public void scale(float paramFloat1, float paramFloat2, float paramFloat3) {
    checkMatrix(3);
    this.matrix.scale(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void resetMatrix() {
    checkMatrix(2);
    this.matrix.reset();
  }
  
  public void applyMatrix(PMatrix paramPMatrix) {
    if (paramPMatrix instanceof PMatrix2D) {
      applyMatrix((PMatrix2D)paramPMatrix);
    } else if (paramPMatrix instanceof PMatrix3D) {
      applyMatrix(paramPMatrix);
    } 
  }
  
  public void applyMatrix(PMatrix2D paramPMatrix2D) {
    applyMatrix(paramPMatrix2D.m00, paramPMatrix2D.m01, 0.0F, paramPMatrix2D.m02, paramPMatrix2D.m10, paramPMatrix2D.m11, 0.0F, paramPMatrix2D.m12, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
  }
  
  public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    checkMatrix(2);
    this.matrix.apply(paramFloat1, paramFloat2, paramFloat3, 0.0F, paramFloat4, paramFloat5, paramFloat6, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
  }
  
  public void apply(PMatrix3D paramPMatrix3D) {
    applyMatrix(paramPMatrix3D.m00, paramPMatrix3D.m01, paramPMatrix3D.m02, paramPMatrix3D.m03, paramPMatrix3D.m10, paramPMatrix3D.m11, paramPMatrix3D.m12, paramPMatrix3D.m13, paramPMatrix3D.m20, paramPMatrix3D.m21, paramPMatrix3D.m22, paramPMatrix3D.m23, paramPMatrix3D.m30, paramPMatrix3D.m31, paramPMatrix3D.m32, paramPMatrix3D.m33);
  }
  
  public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16) {
    checkMatrix(3);
    this.matrix.apply(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
  }
  
  protected void checkMatrix(int paramInt) {
    if (this.matrix == null) {
      if (paramInt == 2) {
        this.matrix = new PMatrix2D();
      } else {
        this.matrix = new PMatrix3D();
      } 
    } else if (paramInt == 3 && this.matrix instanceof PMatrix2D) {
      this.matrix = new PMatrix3D(this.matrix);
    } 
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */