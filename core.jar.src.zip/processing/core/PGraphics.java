package processing.core;

import java.awt.Color;
import java.awt.Image;
import java.util.HashMap;

public class PGraphics extends PImage implements PConstants {
  protected int width1;
  
  protected int height1;
  
  public int pixelCount;
  
  public boolean smooth = false;
  
  protected boolean settingsInited;
  
  protected PGraphics raw;
  
  protected String path;
  
  protected boolean primarySurface;
  
  protected boolean[] hints = new boolean[10];
  
  public int colorMode;
  
  public float colorModeX;
  
  public float colorModeY;
  
  public float colorModeZ;
  
  public float colorModeA;
  
  boolean colorModeScale;
  
  boolean colorModeDefault;
  
  public boolean tint;
  
  public int tintColor;
  
  protected boolean tintAlpha;
  
  protected float tintR;
  
  protected float tintG;
  
  protected float tintB;
  
  protected float tintA;
  
  protected int tintRi;
  
  protected int tintGi;
  
  protected int tintBi;
  
  protected int tintAi;
  
  public boolean fill;
  
  public int fillColor = -1;
  
  protected boolean fillAlpha;
  
  protected float fillR;
  
  protected float fillG;
  
  protected float fillB;
  
  protected float fillA;
  
  protected int fillRi;
  
  protected int fillGi;
  
  protected int fillBi;
  
  protected int fillAi;
  
  public boolean stroke;
  
  public int strokeColor = -16777216;
  
  protected boolean strokeAlpha;
  
  protected float strokeR;
  
  protected float strokeG;
  
  protected float strokeB;
  
  protected float strokeA;
  
  protected int strokeRi;
  
  protected int strokeGi;
  
  protected int strokeBi;
  
  protected int strokeAi;
  
  protected static final float DEFAULT_STROKE_WEIGHT = 1.0F;
  
  protected static final int DEFAULT_STROKE_JOIN = 8;
  
  protected static final int DEFAULT_STROKE_CAP = 2;
  
  public float strokeWeight = 1.0F;
  
  public int strokeJoin = 8;
  
  public int strokeCap = 2;
  
  public int rectMode;
  
  public int ellipseMode;
  
  public int shapeMode;
  
  public int imageMode = 0;
  
  public PFont textFont;
  
  public int textAlign = 37;
  
  public int textAlignY = 0;
  
  public int textMode = 4;
  
  public float textSize;
  
  public float textLeading;
  
  public float ambientR;
  
  public float ambientG;
  
  public float ambientB;
  
  public float specularR;
  
  public float specularG;
  
  public float specularB;
  
  public float emissiveR;
  
  public float emissiveG;
  
  public float emissiveB;
  
  public float shininess;
  
  static final int STYLE_STACK_DEPTH = 64;
  
  PStyle[] styleStack = new PStyle[64];
  
  int styleStackDepth;
  
  public int backgroundColor = -3355444;
  
  protected boolean backgroundAlpha;
  
  protected float backgroundR;
  
  protected float backgroundG;
  
  protected float backgroundB;
  
  protected float backgroundA;
  
  protected int backgroundRi;
  
  protected int backgroundGi;
  
  protected int backgroundBi;
  
  protected int backgroundAi;
  
  static final int MATRIX_STACK_DEPTH = 32;
  
  public Image image;
  
  protected float calcR;
  
  protected float calcG;
  
  protected float calcB;
  
  protected float calcA;
  
  protected int calcRi;
  
  protected int calcGi;
  
  protected int calcBi;
  
  protected int calcAi;
  
  protected int calcColor;
  
  protected boolean calcAlpha;
  
  int cacheHsbKey;
  
  float[] cacheHsbValue = new float[3];
  
  protected int shape;
  
  public static final int DEFAULT_VERTICES = 512;
  
  protected float[][] vertices = new float[512][37];
  
  protected int vertexCount;
  
  protected boolean bezierInited = false;
  
  public int bezierDetail = 20;
  
  protected PMatrix3D bezierBasisMatrix = new PMatrix3D(-1.0F, 3.0F, -3.0F, 1.0F, 3.0F, -6.0F, 3.0F, 0.0F, -3.0F, 3.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F);
  
  protected PMatrix3D bezierDrawMatrix;
  
  protected boolean curveInited = false;
  
  protected int curveDetail = 20;
  
  public float curveTightness = 0.0F;
  
  protected PMatrix3D curveBasisMatrix;
  
  protected PMatrix3D curveDrawMatrix;
  
  protected PMatrix3D bezierBasisInverse;
  
  protected PMatrix3D curveToBezierMatrix;
  
  protected float[][] curveVertices;
  
  protected int curveVertexCount;
  
  protected static final float[] sinLUT = new float[720];
  
  protected static final float[] cosLUT = new float[720];
  
  protected static final float SINCOS_PRECISION = 0.5F;
  
  protected static final int SINCOS_LENGTH = 720;
  
  protected float textX;
  
  protected float textY;
  
  protected float textZ;
  
  protected char[] textBuffer = new char[8192];
  
  protected char[] textWidthBuffer = new char[8192];
  
  protected int textBreakCount;
  
  protected int[] textBreakStart;
  
  protected int[] textBreakStop;
  
  public boolean edge = true;
  
  protected static final int NORMAL_MODE_AUTO = 0;
  
  protected static final int NORMAL_MODE_SHAPE = 1;
  
  protected static final int NORMAL_MODE_VERTEX = 2;
  
  protected int normalMode;
  
  protected boolean autoNormal;
  
  public float normalX;
  
  public float normalY;
  
  public float normalZ;
  
  public int textureMode;
  
  public float textureU;
  
  public float textureV;
  
  public PImage textureImage;
  
  float[] sphereX;
  
  float[] sphereY;
  
  float[] sphereZ;
  
  public int sphereDetailU = 0;
  
  public int sphereDetailV = 0;
  
  static float[] lerpColorHSB1;
  
  static float[] lerpColorHSB2;
  
  protected static HashMap<String, Object> warnings;
  
  public void setParent(PApplet paramPApplet) {
    this.parent = paramPApplet;
  }
  
  public void setPrimary(boolean paramBoolean) {
    this.primarySurface = paramBoolean;
    if (this.primarySurface)
      this.format = 1; 
  }
  
  public void setPath(String paramString) {
    this.path = paramString;
  }
  
  public void setSize(int paramInt1, int paramInt2) {
    this.width = paramInt1;
    this.height = paramInt2;
    this.width1 = this.width - 1;
    this.height1 = this.height - 1;
    allocate();
    reapplySettings();
  }
  
  protected void allocate() {}
  
  public void dispose() {}
  
  public boolean canDraw() {
    return true;
  }
  
  public void beginDraw() {}
  
  public void endDraw() {}
  
  public void flush() {}
  
  protected void checkSettings() {
    if (!this.settingsInited)
      defaultSettings(); 
  }
  
  protected void defaultSettings() {
    noSmooth();
    colorMode(1, 255.0F);
    fill(255);
    stroke(0);
    strokeWeight(1.0F);
    strokeJoin(8);
    strokeCap(2);
    this.shape = 0;
    rectMode(0);
    ellipseMode(3);
    this.autoNormal = true;
    this.textFont = null;
    this.textSize = 12.0F;
    this.textLeading = 14.0F;
    this.textAlign = 37;
    this.textMode = 4;
    if (this.primarySurface)
      background(this.backgroundColor); 
    this.settingsInited = true;
  }
  
  protected void reapplySettings() {
    if (!this.settingsInited)
      return; 
    colorMode(this.colorMode, this.colorModeX, this.colorModeY, this.colorModeZ);
    if (this.fill) {
      fill(this.fillColor);
    } else {
      noFill();
    } 
    if (this.stroke) {
      stroke(this.strokeColor);
      strokeWeight(this.strokeWeight);
      strokeCap(this.strokeCap);
      strokeJoin(this.strokeJoin);
    } else {
      noStroke();
    } 
    if (this.tint) {
      tint(this.tintColor);
    } else {
      noTint();
    } 
    if (this.smooth) {
      smooth();
    } else {
      noSmooth();
    } 
    if (this.textFont != null) {
      float f = this.textLeading;
      textFont(this.textFont, this.textSize);
      textLeading(f);
    } 
    textMode(this.textMode);
    textAlign(this.textAlign, this.textAlignY);
    background(this.backgroundColor);
  }
  
  public void hint(int paramInt) {
    if (paramInt > 0) {
      this.hints[paramInt] = true;
    } else {
      this.hints[-paramInt] = false;
    } 
  }
  
  public boolean hintEnabled(int paramInt) {
    return (paramInt > 0) ? this.hints[paramInt] : this.hints[-paramInt];
  }
  
  public void beginShape() {
    beginShape(20);
  }
  
  public void beginShape(int paramInt) {
    this.shape = paramInt;
  }
  
  public void edge(boolean paramBoolean) {
    this.edge = paramBoolean;
  }
  
  public void normal(float paramFloat1, float paramFloat2, float paramFloat3) {
    this.normalX = paramFloat1;
    this.normalY = paramFloat2;
    this.normalZ = paramFloat3;
    if (this.shape != 0)
      if (this.normalMode == 0) {
        this.normalMode = 1;
      } else if (this.normalMode == 1) {
        this.normalMode = 2;
      }  
  }
  
  public void textureMode(int paramInt) {
    this.textureMode = paramInt;
  }
  
  public void texture(PImage paramPImage) {
    this.textureImage = paramPImage;
  }
  
  public void noTexture() {
    this.textureImage = null;
  }
  
  protected void vertexCheck() {
    if (this.vertexCount == this.vertices.length) {
      float[][] arrayOfFloat = new float[this.vertexCount << 1][37];
      System.arraycopy(this.vertices, 0, arrayOfFloat, 0, this.vertexCount);
      this.vertices = arrayOfFloat;
    } 
  }
  
  public void vertex(float paramFloat1, float paramFloat2) {
    vertexCheck();
    float[] arrayOfFloat = this.vertices[this.vertexCount];
    this.curveVertexCount = 0;
    arrayOfFloat[0] = paramFloat1;
    arrayOfFloat[1] = paramFloat2;
    arrayOfFloat[12] = this.edge ? 1.0F : 0.0F;
    boolean bool = (this.textureImage != null) ? true : false;
    if (this.fill || bool)
      if (this.textureImage == null) {
        arrayOfFloat[3] = this.fillR;
        arrayOfFloat[4] = this.fillG;
        arrayOfFloat[5] = this.fillB;
        arrayOfFloat[6] = this.fillA;
      } else if (this.tint) {
        arrayOfFloat[3] = this.tintR;
        arrayOfFloat[4] = this.tintG;
        arrayOfFloat[5] = this.tintB;
        arrayOfFloat[6] = this.tintA;
      } else {
        arrayOfFloat[3] = 1.0F;
        arrayOfFloat[4] = 1.0F;
        arrayOfFloat[5] = 1.0F;
        arrayOfFloat[6] = 1.0F;
      }  
    if (this.stroke) {
      arrayOfFloat[13] = this.strokeR;
      arrayOfFloat[14] = this.strokeG;
      arrayOfFloat[15] = this.strokeB;
      arrayOfFloat[16] = this.strokeA;
      arrayOfFloat[17] = this.strokeWeight;
    } 
    if (bool) {
      arrayOfFloat[7] = this.textureU;
      arrayOfFloat[8] = this.textureV;
    } 
    if (this.autoNormal) {
      float f = this.normalX * this.normalX + this.normalY * this.normalY + this.normalZ * this.normalZ;
      if (f < 1.0E-4F) {
        arrayOfFloat[36] = 0.0F;
      } else {
        if (Math.abs(f - 1.0F) > 1.0E-4F) {
          float f1 = PApplet.sqrt(f);
          this.normalX /= f1;
          this.normalY /= f1;
          this.normalZ /= f1;
        } 
        arrayOfFloat[36] = 1.0F;
      } 
    } else {
      arrayOfFloat[36] = 1.0F;
    } 
    this.vertexCount++;
  }
  
  public void vertex(float paramFloat1, float paramFloat2, float paramFloat3) {
    vertexCheck();
    float[] arrayOfFloat = this.vertices[this.vertexCount];
    if (this.shape == 20 && this.vertexCount > 0) {
      float[] arrayOfFloat1 = this.vertices[this.vertexCount - 1];
      if (Math.abs(arrayOfFloat1[0] - paramFloat1) < 1.0E-4F && Math.abs(arrayOfFloat1[1] - paramFloat2) < 1.0E-4F && Math.abs(arrayOfFloat1[2] - paramFloat3) < 1.0E-4F)
        return; 
    } 
    this.curveVertexCount = 0;
    arrayOfFloat[0] = paramFloat1;
    arrayOfFloat[1] = paramFloat2;
    arrayOfFloat[2] = paramFloat3;
    arrayOfFloat[12] = this.edge ? 1.0F : 0.0F;
    boolean bool = (this.textureImage != null) ? true : false;
    if (this.fill || bool) {
      if (this.textureImage == null) {
        arrayOfFloat[3] = this.fillR;
        arrayOfFloat[4] = this.fillG;
        arrayOfFloat[5] = this.fillB;
        arrayOfFloat[6] = this.fillA;
      } else if (this.tint) {
        arrayOfFloat[3] = this.tintR;
        arrayOfFloat[4] = this.tintG;
        arrayOfFloat[5] = this.tintB;
        arrayOfFloat[6] = this.tintA;
      } else {
        arrayOfFloat[3] = 1.0F;
        arrayOfFloat[4] = 1.0F;
        arrayOfFloat[5] = 1.0F;
        arrayOfFloat[6] = 1.0F;
      } 
      arrayOfFloat[25] = this.ambientR;
      arrayOfFloat[26] = this.ambientG;
      arrayOfFloat[27] = this.ambientB;
      arrayOfFloat[28] = this.specularR;
      arrayOfFloat[29] = this.specularG;
      arrayOfFloat[30] = this.specularB;
      arrayOfFloat[31] = this.shininess;
      arrayOfFloat[32] = this.emissiveR;
      arrayOfFloat[33] = this.emissiveG;
      arrayOfFloat[34] = this.emissiveB;
    } 
    if (this.stroke) {
      arrayOfFloat[13] = this.strokeR;
      arrayOfFloat[14] = this.strokeG;
      arrayOfFloat[15] = this.strokeB;
      arrayOfFloat[16] = this.strokeA;
      arrayOfFloat[17] = this.strokeWeight;
    } 
    if (bool) {
      arrayOfFloat[7] = this.textureU;
      arrayOfFloat[8] = this.textureV;
    } 
    if (this.autoNormal) {
      float f = this.normalX * this.normalX + this.normalY * this.normalY + this.normalZ * this.normalZ;
      if (f < 1.0E-4F) {
        arrayOfFloat[36] = 0.0F;
      } else {
        if (Math.abs(f - 1.0F) > 1.0E-4F) {
          float f1 = PApplet.sqrt(f);
          this.normalX /= f1;
          this.normalY /= f1;
          this.normalZ /= f1;
        } 
        arrayOfFloat[36] = 1.0F;
      } 
    } else {
      arrayOfFloat[36] = 1.0F;
    } 
    arrayOfFloat[9] = this.normalX;
    arrayOfFloat[10] = this.normalY;
    arrayOfFloat[11] = this.normalZ;
    arrayOfFloat[35] = 0.0F;
    this.vertexCount++;
  }
  
  public void vertexFields(float[] paramArrayOffloat) {
    vertexCheck();
    this.curveVertexCount = 0;
    float[] arrayOfFloat = this.vertices[this.vertexCount];
    System.arraycopy(paramArrayOffloat, 0, arrayOfFloat, 0, 37);
    this.vertexCount++;
  }
  
  public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    vertexTexture(paramFloat3, paramFloat4);
    vertex(paramFloat1, paramFloat2);
  }
  
  public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    vertexTexture(paramFloat4, paramFloat5);
    vertex(paramFloat1, paramFloat2, paramFloat3);
  }
  
  protected void vertexTexture(float paramFloat1, float paramFloat2) {
    if (this.textureImage == null)
      throw new RuntimeException("You must first call texture() before using u and v coordinates with vertex()"); 
    if (this.textureMode == 2) {
      paramFloat1 /= this.textureImage.width;
      paramFloat2 /= this.textureImage.height;
    } 
    this.textureU = paramFloat1;
    this.textureV = paramFloat2;
    if (this.textureU < 0.0F) {
      this.textureU = 0.0F;
    } else if (this.textureU > 1.0F) {
      this.textureU = 1.0F;
    } 
    if (this.textureV < 0.0F) {
      this.textureV = 0.0F;
    } else if (this.textureV > 1.0F) {
      this.textureV = 1.0F;
    } 
  }
  
  public void breakShape() {
    showWarning("This renderer cannot currently handle concave shapes, or shapes with holes.");
  }
  
  public void endShape() {
    endShape(1);
  }
  
  public void endShape(int paramInt) {}
  
  protected void bezierVertexCheck() {
    if (this.shape == 0 || this.shape != 20)
      throw new RuntimeException("beginShape() or beginShape(POLYGON) must be used before bezierVertex() or quadVertex()"); 
    if (this.vertexCount == 0)
      throw new RuntimeException("vertex() must be used at least oncebefore bezierVertex() or quadVertex()"); 
  }
  
  public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    bezierInitCheck();
    bezierVertexCheck();
    PMatrix3D pMatrix3D = this.bezierDrawMatrix;
    float[] arrayOfFloat = this.vertices[this.vertexCount - 1];
    float f1 = arrayOfFloat[0];
    float f2 = arrayOfFloat[1];
    float f3 = pMatrix3D.m10 * f1 + pMatrix3D.m11 * paramFloat1 + pMatrix3D.m12 * paramFloat3 + pMatrix3D.m13 * paramFloat5;
    float f4 = pMatrix3D.m20 * f1 + pMatrix3D.m21 * paramFloat1 + pMatrix3D.m22 * paramFloat3 + pMatrix3D.m23 * paramFloat5;
    float f5 = pMatrix3D.m30 * f1 + pMatrix3D.m31 * paramFloat1 + pMatrix3D.m32 * paramFloat3 + pMatrix3D.m33 * paramFloat5;
    float f6 = pMatrix3D.m10 * f2 + pMatrix3D.m11 * paramFloat2 + pMatrix3D.m12 * paramFloat4 + pMatrix3D.m13 * paramFloat6;
    float f7 = pMatrix3D.m20 * f2 + pMatrix3D.m21 * paramFloat2 + pMatrix3D.m22 * paramFloat4 + pMatrix3D.m23 * paramFloat6;
    float f8 = pMatrix3D.m30 * f2 + pMatrix3D.m31 * paramFloat2 + pMatrix3D.m32 * paramFloat4 + pMatrix3D.m33 * paramFloat6;
    for (byte b = 0; b < this.bezierDetail; b++) {
      f1 += f3;
      f3 += f4;
      f4 += f5;
      f2 += f6;
      f6 += f7;
      f7 += f8;
      vertex(f1, f2);
    } 
  }
  
  public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9) {
    bezierInitCheck();
    bezierVertexCheck();
    PMatrix3D pMatrix3D = this.bezierDrawMatrix;
    float[] arrayOfFloat = this.vertices[this.vertexCount - 1];
    float f1 = arrayOfFloat[0];
    float f2 = arrayOfFloat[1];
    float f3 = arrayOfFloat[2];
    float f4 = pMatrix3D.m10 * f1 + pMatrix3D.m11 * paramFloat1 + pMatrix3D.m12 * paramFloat4 + pMatrix3D.m13 * paramFloat7;
    float f5 = pMatrix3D.m20 * f1 + pMatrix3D.m21 * paramFloat1 + pMatrix3D.m22 * paramFloat4 + pMatrix3D.m23 * paramFloat7;
    float f6 = pMatrix3D.m30 * f1 + pMatrix3D.m31 * paramFloat1 + pMatrix3D.m32 * paramFloat4 + pMatrix3D.m33 * paramFloat7;
    float f7 = pMatrix3D.m10 * f2 + pMatrix3D.m11 * paramFloat2 + pMatrix3D.m12 * paramFloat5 + pMatrix3D.m13 * paramFloat8;
    float f8 = pMatrix3D.m20 * f2 + pMatrix3D.m21 * paramFloat2 + pMatrix3D.m22 * paramFloat5 + pMatrix3D.m23 * paramFloat8;
    float f9 = pMatrix3D.m30 * f2 + pMatrix3D.m31 * paramFloat2 + pMatrix3D.m32 * paramFloat5 + pMatrix3D.m33 * paramFloat8;
    float f10 = pMatrix3D.m10 * f3 + pMatrix3D.m11 * paramFloat3 + pMatrix3D.m12 * paramFloat6 + pMatrix3D.m13 * paramFloat9;
    float f11 = pMatrix3D.m20 * f3 + pMatrix3D.m21 * paramFloat3 + pMatrix3D.m22 * paramFloat6 + pMatrix3D.m23 * paramFloat9;
    float f12 = pMatrix3D.m30 * f3 + pMatrix3D.m31 * paramFloat3 + pMatrix3D.m32 * paramFloat6 + pMatrix3D.m33 * paramFloat9;
    for (byte b = 0; b < this.bezierDetail; b++) {
      f1 += f4;
      f4 += f5;
      f5 += f6;
      f2 += f7;
      f7 += f8;
      f8 += f9;
      f3 += f10;
      f10 += f11;
      f11 += f12;
      vertex(f1, f2, f3);
    } 
  }
  
  public void quadVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    float[] arrayOfFloat = this.vertices[this.vertexCount - 1];
    float f1 = arrayOfFloat[0];
    float f2 = arrayOfFloat[1];
    bezierVertex(f1 + (paramFloat1 - f1) * 2.0F / 3.0F, f2 + (paramFloat2 - f2) * 2.0F / 3.0F, paramFloat3 + (paramFloat1 - paramFloat3) * 2.0F / 3.0F, paramFloat4 + (paramFloat2 - paramFloat4) * 2.0F / 3.0F, paramFloat3, paramFloat4);
  }
  
  public void quadVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    float[] arrayOfFloat = this.vertices[this.vertexCount - 1];
    float f1 = arrayOfFloat[0];
    float f2 = arrayOfFloat[1];
    float f3 = arrayOfFloat[2];
    bezierVertex(f1 + (paramFloat1 - f1) * 2.0F / 3.0F, f2 + (paramFloat2 - f2) * 2.0F / 3.0F, f3 + (paramFloat3 - f3) * 2.0F / 3.0F, paramFloat4 + (paramFloat1 - paramFloat4) * 2.0F / 3.0F, paramFloat5 + (paramFloat2 - paramFloat5) * 2.0F / 3.0F, paramFloat6 + (paramFloat3 - paramFloat6) * 2.0F / 3.0F, paramFloat4, paramFloat5, paramFloat6);
  }
  
  protected void curveVertexCheck() {
    if (this.shape != 20)
      throw new RuntimeException("You must use beginShape() or beginShape(POLYGON) before curveVertex()"); 
    if (this.curveVertices == null)
      this.curveVertices = new float[128][3]; 
    if (this.curveVertexCount == this.curveVertices.length) {
      float[][] arrayOfFloat = new float[this.curveVertexCount << 1][3];
      System.arraycopy(this.curveVertices, 0, arrayOfFloat, 0, this.curveVertexCount);
      this.curveVertices = arrayOfFloat;
    } 
    curveInitCheck();
  }
  
  public void curveVertex(float paramFloat1, float paramFloat2) {
    curveVertexCheck();
    float[] arrayOfFloat = this.curveVertices[this.curveVertexCount];
    arrayOfFloat[0] = paramFloat1;
    arrayOfFloat[1] = paramFloat2;
    this.curveVertexCount++;
    if (this.curveVertexCount > 3)
      curveVertexSegment(this.curveVertices[this.curveVertexCount - 4][0], this.curveVertices[this.curveVertexCount - 4][1], this.curveVertices[this.curveVertexCount - 3][0], this.curveVertices[this.curveVertexCount - 3][1], this.curveVertices[this.curveVertexCount - 2][0], this.curveVertices[this.curveVertexCount - 2][1], this.curveVertices[this.curveVertexCount - 1][0], this.curveVertices[this.curveVertexCount - 1][1]); 
  }
  
  public void curveVertex(float paramFloat1, float paramFloat2, float paramFloat3) {
    curveVertexCheck();
    float[] arrayOfFloat = this.curveVertices[this.curveVertexCount];
    arrayOfFloat[0] = paramFloat1;
    arrayOfFloat[1] = paramFloat2;
    arrayOfFloat[2] = paramFloat3;
    this.curveVertexCount++;
    if (this.curveVertexCount > 3)
      curveVertexSegment(this.curveVertices[this.curveVertexCount - 4][0], this.curveVertices[this.curveVertexCount - 4][1], this.curveVertices[this.curveVertexCount - 4][2], this.curveVertices[this.curveVertexCount - 3][0], this.curveVertices[this.curveVertexCount - 3][1], this.curveVertices[this.curveVertexCount - 3][2], this.curveVertices[this.curveVertexCount - 2][0], this.curveVertices[this.curveVertexCount - 2][1], this.curveVertices[this.curveVertexCount - 2][2], this.curveVertices[this.curveVertexCount - 1][0], this.curveVertices[this.curveVertexCount - 1][1], this.curveVertices[this.curveVertexCount - 1][2]); 
  }
  
  protected void curveVertexSegment(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    float f1 = paramFloat3;
    float f2 = paramFloat4;
    PMatrix3D pMatrix3D = this.curveDrawMatrix;
    float f3 = pMatrix3D.m10 * paramFloat1 + pMatrix3D.m11 * paramFloat3 + pMatrix3D.m12 * paramFloat5 + pMatrix3D.m13 * paramFloat7;
    float f4 = pMatrix3D.m20 * paramFloat1 + pMatrix3D.m21 * paramFloat3 + pMatrix3D.m22 * paramFloat5 + pMatrix3D.m23 * paramFloat7;
    float f5 = pMatrix3D.m30 * paramFloat1 + pMatrix3D.m31 * paramFloat3 + pMatrix3D.m32 * paramFloat5 + pMatrix3D.m33 * paramFloat7;
    float f6 = pMatrix3D.m10 * paramFloat2 + pMatrix3D.m11 * paramFloat4 + pMatrix3D.m12 * paramFloat6 + pMatrix3D.m13 * paramFloat8;
    float f7 = pMatrix3D.m20 * paramFloat2 + pMatrix3D.m21 * paramFloat4 + pMatrix3D.m22 * paramFloat6 + pMatrix3D.m23 * paramFloat8;
    float f8 = pMatrix3D.m30 * paramFloat2 + pMatrix3D.m31 * paramFloat4 + pMatrix3D.m32 * paramFloat6 + pMatrix3D.m33 * paramFloat8;
    int i = this.curveVertexCount;
    vertex(f1, f2);
    for (byte b = 0; b < this.curveDetail; b++) {
      f1 += f3;
      f3 += f4;
      f4 += f5;
      f2 += f6;
      f6 += f7;
      f7 += f8;
      vertex(f1, f2);
    } 
    this.curveVertexCount = i;
  }
  
  protected void curveVertexSegment(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12) {
    float f1 = paramFloat4;
    float f2 = paramFloat5;
    float f3 = paramFloat6;
    PMatrix3D pMatrix3D = this.curveDrawMatrix;
    float f4 = pMatrix3D.m10 * paramFloat1 + pMatrix3D.m11 * paramFloat4 + pMatrix3D.m12 * paramFloat7 + pMatrix3D.m13 * paramFloat10;
    float f5 = pMatrix3D.m20 * paramFloat1 + pMatrix3D.m21 * paramFloat4 + pMatrix3D.m22 * paramFloat7 + pMatrix3D.m23 * paramFloat10;
    float f6 = pMatrix3D.m30 * paramFloat1 + pMatrix3D.m31 * paramFloat4 + pMatrix3D.m32 * paramFloat7 + pMatrix3D.m33 * paramFloat10;
    float f7 = pMatrix3D.m10 * paramFloat2 + pMatrix3D.m11 * paramFloat5 + pMatrix3D.m12 * paramFloat8 + pMatrix3D.m13 * paramFloat11;
    float f8 = pMatrix3D.m20 * paramFloat2 + pMatrix3D.m21 * paramFloat5 + pMatrix3D.m22 * paramFloat8 + pMatrix3D.m23 * paramFloat11;
    float f9 = pMatrix3D.m30 * paramFloat2 + pMatrix3D.m31 * paramFloat5 + pMatrix3D.m32 * paramFloat8 + pMatrix3D.m33 * paramFloat11;
    int i = this.curveVertexCount;
    float f10 = pMatrix3D.m10 * paramFloat3 + pMatrix3D.m11 * paramFloat6 + pMatrix3D.m12 * paramFloat9 + pMatrix3D.m13 * paramFloat12;
    float f11 = pMatrix3D.m20 * paramFloat3 + pMatrix3D.m21 * paramFloat6 + pMatrix3D.m22 * paramFloat9 + pMatrix3D.m23 * paramFloat12;
    float f12 = pMatrix3D.m30 * paramFloat3 + pMatrix3D.m31 * paramFloat6 + pMatrix3D.m32 * paramFloat9 + pMatrix3D.m33 * paramFloat12;
    vertex(f1, f2, f3);
    for (byte b = 0; b < this.curveDetail; b++) {
      f1 += f4;
      f4 += f5;
      f5 += f6;
      f2 += f7;
      f7 += f8;
      f8 += f9;
      f3 += f10;
      f10 += f11;
      f11 += f12;
      vertex(f1, f2, f3);
    } 
    this.curveVertexCount = i;
  }
  
  public void point(float paramFloat1, float paramFloat2) {
    beginShape(2);
    vertex(paramFloat1, paramFloat2);
    endShape();
  }
  
  public void point(float paramFloat1, float paramFloat2, float paramFloat3) {
    beginShape(2);
    vertex(paramFloat1, paramFloat2, paramFloat3);
    endShape();
  }
  
  public void line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    beginShape(4);
    vertex(paramFloat1, paramFloat2);
    vertex(paramFloat3, paramFloat4);
    endShape();
  }
  
  public void line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    beginShape(4);
    vertex(paramFloat1, paramFloat2, paramFloat3);
    vertex(paramFloat4, paramFloat5, paramFloat6);
    endShape();
  }
  
  public void triangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    beginShape(9);
    vertex(paramFloat1, paramFloat2);
    vertex(paramFloat3, paramFloat4);
    vertex(paramFloat5, paramFloat6);
    endShape();
  }
  
  public void quad(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    beginShape(16);
    vertex(paramFloat1, paramFloat2);
    vertex(paramFloat3, paramFloat4);
    vertex(paramFloat5, paramFloat6);
    vertex(paramFloat7, paramFloat8);
    endShape();
  }
  
  public void rectMode(int paramInt) {
    this.rectMode = paramInt;
  }
  
  public void rect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    float f1;
    float f2;
    switch (this.rectMode) {
      case 0:
        paramFloat3 += paramFloat1;
        paramFloat4 += paramFloat2;
        break;
      case 2:
        f1 = paramFloat3;
        f2 = paramFloat4;
        paramFloat3 = paramFloat1 + f1;
        paramFloat4 = paramFloat2 + f2;
        paramFloat1 -= f1;
        paramFloat2 -= f2;
        break;
      case 3:
        f1 = paramFloat3 / 2.0F;
        f2 = paramFloat4 / 2.0F;
        paramFloat3 = paramFloat1 + f1;
        paramFloat4 = paramFloat2 + f2;
        paramFloat1 -= f1;
        paramFloat2 -= f2;
        break;
    } 
    if (paramFloat1 > paramFloat3) {
      float f = paramFloat1;
      paramFloat1 = paramFloat3;
      paramFloat3 = f;
    } 
    if (paramFloat2 > paramFloat4) {
      float f = paramFloat2;
      paramFloat2 = paramFloat4;
      paramFloat4 = f;
    } 
    rectImpl(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  protected void rectImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    quad(paramFloat1, paramFloat2, paramFloat3, paramFloat2, paramFloat3, paramFloat4, paramFloat1, paramFloat4);
  }
  
  private void quadraticVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    float[] arrayOfFloat = this.vertices[this.vertexCount - 1];
    float f1 = arrayOfFloat[0];
    float f2 = arrayOfFloat[1];
    float f3 = f1 + 0.6666667F * (paramFloat1 - f1);
    float f4 = f2 + 0.6666667F * (paramFloat2 - f2);
    float f5 = f3 + (paramFloat3 - f1) / 3.0F;
    float f6 = f4 + (paramFloat4 - f2) / 3.0F;
    bezierVertex(f3, f4, f5, f6, paramFloat3, paramFloat4);
  }
  
  public void rect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    float f1;
    float f2;
    switch (this.rectMode) {
      case 0:
        paramFloat3 += paramFloat1;
        paramFloat4 += paramFloat2;
        break;
      case 2:
        f1 = paramFloat3;
        f2 = paramFloat4;
        paramFloat3 = paramFloat1 + f1;
        paramFloat4 = paramFloat2 + f2;
        paramFloat1 -= f1;
        paramFloat2 -= f2;
        break;
      case 3:
        f1 = paramFloat3 / 2.0F;
        f2 = paramFloat4 / 2.0F;
        paramFloat3 = paramFloat1 + f1;
        paramFloat4 = paramFloat2 + f2;
        paramFloat1 -= f1;
        paramFloat2 -= f2;
        break;
    } 
    if (paramFloat1 > paramFloat3) {
      float f = paramFloat1;
      paramFloat1 = paramFloat3;
      paramFloat3 = f;
    } 
    if (paramFloat2 > paramFloat4) {
      float f = paramFloat2;
      paramFloat2 = paramFloat4;
      paramFloat4 = f;
    } 
    rectImpl(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  protected void rectImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    beginShape();
    vertex(paramFloat3 - paramFloat5, paramFloat2);
    quadraticVertex(paramFloat3, paramFloat2, paramFloat3, paramFloat2 + paramFloat6);
    vertex(paramFloat3, paramFloat4 - paramFloat6);
    quadraticVertex(paramFloat3, paramFloat4, paramFloat3 - paramFloat5, paramFloat4);
    vertex(paramFloat1 + paramFloat5, paramFloat4);
    quadraticVertex(paramFloat1, paramFloat4, paramFloat1, paramFloat4 - paramFloat6);
    vertex(paramFloat1, paramFloat2 + paramFloat6);
    quadraticVertex(paramFloat1, paramFloat2, paramFloat1 + paramFloat5, paramFloat2);
    endShape(2);
  }
  
  public void rect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    float f1;
    float f2;
    switch (this.rectMode) {
      case 0:
        paramFloat3 += paramFloat1;
        paramFloat4 += paramFloat2;
        break;
      case 2:
        f1 = paramFloat3;
        f2 = paramFloat4;
        paramFloat3 = paramFloat1 + f1;
        paramFloat4 = paramFloat2 + f2;
        paramFloat1 -= f1;
        paramFloat2 -= f2;
        break;
      case 3:
        f1 = paramFloat3 / 2.0F;
        f2 = paramFloat4 / 2.0F;
        paramFloat3 = paramFloat1 + f1;
        paramFloat4 = paramFloat2 + f2;
        paramFloat1 -= f1;
        paramFloat2 -= f2;
        break;
    } 
    if (paramFloat1 > paramFloat3) {
      float f = paramFloat1;
      paramFloat1 = paramFloat3;
      paramFloat3 = f;
    } 
    if (paramFloat2 > paramFloat4) {
      float f = paramFloat2;
      paramFloat2 = paramFloat4;
      paramFloat4 = f;
    } 
    rectImpl(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
  }
  
  protected void rectImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    beginShape();
    if (paramFloat6 != 0.0F) {
      vertex(paramFloat3 - paramFloat6, paramFloat2);
      quadraticVertex(paramFloat3, paramFloat2, paramFloat3, paramFloat2 + paramFloat6);
    } else {
      vertex(paramFloat3, paramFloat2);
    } 
    if (paramFloat8 != 0.0F) {
      vertex(paramFloat3, paramFloat4 - paramFloat8);
      quadraticVertex(paramFloat3, paramFloat4, paramFloat3 - paramFloat8, paramFloat4);
    } else {
      vertex(paramFloat3, paramFloat4);
    } 
    if (paramFloat7 != 0.0F) {
      vertex(paramFloat1 + paramFloat7, paramFloat4);
      quadraticVertex(paramFloat1, paramFloat4, paramFloat1, paramFloat4 - paramFloat7);
    } else {
      vertex(paramFloat1, paramFloat4);
    } 
    if (paramFloat5 != 0.0F) {
      vertex(paramFloat1, paramFloat2 + paramFloat5);
      quadraticVertex(paramFloat1, paramFloat2, paramFloat1 + paramFloat5, paramFloat2);
    } else {
      vertex(paramFloat1, paramFloat2);
    } 
    endShape(2);
  }
  
  public void ellipseMode(int paramInt) {
    this.ellipseMode = paramInt;
  }
  
  public void ellipse(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    float f1 = paramFloat1;
    float f2 = paramFloat2;
    float f3 = paramFloat3;
    float f4 = paramFloat4;
    if (this.ellipseMode == 1) {
      f3 = paramFloat3 - paramFloat1;
      f4 = paramFloat4 - paramFloat2;
    } else if (this.ellipseMode == 2) {
      f1 = paramFloat1 - paramFloat3;
      f2 = paramFloat2 - paramFloat4;
      f3 = paramFloat3 * 2.0F;
      f4 = paramFloat4 * 2.0F;
    } else if (this.ellipseMode == 3) {
      f1 = paramFloat1 - paramFloat3 / 2.0F;
      f2 = paramFloat2 - paramFloat4 / 2.0F;
    } 
    if (f3 < 0.0F) {
      f1 += f3;
      f3 = -f3;
    } 
    if (f4 < 0.0F) {
      f2 += f4;
      f4 = -f4;
    } 
    ellipseImpl(f1, f2, f3, f4);
  }
  
  protected void ellipseImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {}
  
  public void arc(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    float f1 = paramFloat1;
    float f2 = paramFloat2;
    float f3 = paramFloat3;
    float f4 = paramFloat4;
    if (this.ellipseMode == 1) {
      f3 = paramFloat3 - paramFloat1;
      f4 = paramFloat4 - paramFloat2;
    } else if (this.ellipseMode == 2) {
      f1 = paramFloat1 - paramFloat3;
      f2 = paramFloat2 - paramFloat4;
      f3 = paramFloat3 * 2.0F;
      f4 = paramFloat4 * 2.0F;
    } else if (this.ellipseMode == 3) {
      f1 = paramFloat1 - paramFloat3 / 2.0F;
      f2 = paramFloat2 - paramFloat4 / 2.0F;
    } 
    if (Float.isInfinite(paramFloat5) || Float.isInfinite(paramFloat6))
      return; 
    if (paramFloat6 < paramFloat5)
      return; 
    while (paramFloat5 < 0.0F) {
      paramFloat5 += 6.2831855F;
      paramFloat6 += 6.2831855F;
    } 
    if (paramFloat6 - paramFloat5 > 6.2831855F) {
      paramFloat5 = 0.0F;
      paramFloat6 = 6.2831855F;
    } 
    arcImpl(f1, f2, f3, f4, paramFloat5, paramFloat6);
  }
  
  protected void arcImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {}
  
  public void box(float paramFloat) {
    box(paramFloat, paramFloat, paramFloat);
  }
  
  public void box(float paramFloat1, float paramFloat2, float paramFloat3) {
    float f1 = -paramFloat1 / 2.0F;
    float f2 = paramFloat1 / 2.0F;
    float f3 = -paramFloat2 / 2.0F;
    float f4 = paramFloat2 / 2.0F;
    float f5 = -paramFloat3 / 2.0F;
    float f6 = paramFloat3 / 2.0F;
    beginShape(16);
    normal(0.0F, 0.0F, 1.0F);
    vertex(f1, f3, f5);
    vertex(f2, f3, f5);
    vertex(f2, f4, f5);
    vertex(f1, f4, f5);
    normal(1.0F, 0.0F, 0.0F);
    vertex(f2, f3, f5);
    vertex(f2, f3, f6);
    vertex(f2, f4, f6);
    vertex(f2, f4, f5);
    normal(0.0F, 0.0F, -1.0F);
    vertex(f2, f3, f6);
    vertex(f1, f3, f6);
    vertex(f1, f4, f6);
    vertex(f2, f4, f6);
    normal(-1.0F, 0.0F, 0.0F);
    vertex(f1, f3, f6);
    vertex(f1, f3, f5);
    vertex(f1, f4, f5);
    vertex(f1, f4, f6);
    normal(0.0F, 1.0F, 0.0F);
    vertex(f1, f3, f6);
    vertex(f2, f3, f6);
    vertex(f2, f3, f5);
    vertex(f1, f3, f5);
    normal(0.0F, -1.0F, 0.0F);
    vertex(f1, f4, f5);
    vertex(f2, f4, f5);
    vertex(f2, f4, f6);
    vertex(f1, f4, f6);
    endShape();
  }
  
  public void sphereDetail(int paramInt) {
    sphereDetail(paramInt, paramInt);
  }
  
  public void sphereDetail(int paramInt1, int paramInt2) {
    if (paramInt1 < 3)
      paramInt1 = 3; 
    if (paramInt2 < 2)
      paramInt2 = 2; 
    if (paramInt1 == this.sphereDetailU && paramInt2 == this.sphereDetailV)
      return; 
    float f1 = 720.0F / paramInt1;
    float[] arrayOfFloat1 = new float[paramInt1];
    float[] arrayOfFloat2 = new float[paramInt1];
    int i;
    for (i = 0; i < paramInt1; i++) {
      arrayOfFloat1[i] = cosLUT[(int)(i * f1) % 720];
      arrayOfFloat2[i] = sinLUT[(int)(i * f1) % 720];
    } 
    i = paramInt1 * (paramInt2 - 1) + 2;
    byte b1 = 0;
    this.sphereX = new float[i];
    this.sphereY = new float[i];
    this.sphereZ = new float[i];
    float f2 = 360.0F / paramInt2;
    float f3 = f2;
    for (byte b2 = 1; b2 < paramInt2; b2++) {
      float f4 = sinLUT[(int)f3 % 720];
      float f5 = -cosLUT[(int)f3 % 720];
      for (byte b = 0; b < paramInt1; b++) {
        this.sphereX[b1] = arrayOfFloat1[b] * f4;
        this.sphereY[b1] = f5;
        this.sphereZ[b1++] = arrayOfFloat2[b] * f4;
      } 
      f3 += f2;
    } 
    this.sphereDetailU = paramInt1;
    this.sphereDetailV = paramInt2;
  }
  
  public void sphere(float paramFloat) {
    if (this.sphereDetailU < 3 || this.sphereDetailV < 2)
      sphereDetail(30); 
    edge(false);
    beginShape(10);
    int i;
    for (i = 0; i < this.sphereDetailU; i++) {
      normal(0.0F, -1.0F, 0.0F);
      vertex(0.0F, -paramFloat, 0.0F);
      normal(this.sphereX[i], this.sphereY[i], this.sphereZ[i]);
      vertex(paramFloat * this.sphereX[i], paramFloat * this.sphereY[i], paramFloat * this.sphereZ[i]);
    } 
    normal(0.0F, -1.0F, 0.0F);
    vertex(0.0F, -1.0F, 0.0F);
    normal(this.sphereX[0], this.sphereY[0], this.sphereZ[0]);
    vertex(paramFloat * this.sphereX[0], paramFloat * this.sphereY[0], paramFloat * this.sphereZ[0]);
    endShape();
    int j = 0;
    byte b;
    for (b = 2; b < this.sphereDetailV; b++) {
      int k = j;
      j += this.sphereDetailU;
      int m = j;
      beginShape(10);
      for (byte b1 = 0; b1 < this.sphereDetailU; b1++) {
        normal(this.sphereX[i], this.sphereY[i], this.sphereZ[i]);
        vertex(paramFloat * this.sphereX[i], paramFloat * this.sphereY[i], paramFloat * this.sphereZ[i++]);
        normal(this.sphereX[m], this.sphereY[m], this.sphereZ[m]);
        vertex(paramFloat * this.sphereX[m], paramFloat * this.sphereY[m], paramFloat * this.sphereZ[m++]);
      } 
      i = k;
      m = j;
      normal(this.sphereX[i], this.sphereY[i], this.sphereZ[i]);
      vertex(paramFloat * this.sphereX[i], paramFloat * this.sphereY[i], this.sphereZ[i]);
      normal(this.sphereX[m], this.sphereY[m], this.sphereZ[m]);
      vertex(paramFloat * this.sphereX[m], paramFloat * this.sphereY[m], paramFloat * this.sphereZ[m]);
      endShape();
    } 
    beginShape(10);
    for (b = 0; b < this.sphereDetailU; b++) {
      int k = j + b;
      normal(this.sphereX[k], this.sphereY[k], this.sphereZ[k]);
      vertex(paramFloat * this.sphereX[k], paramFloat * this.sphereY[k], paramFloat * this.sphereZ[k]);
      normal(0.0F, 1.0F, 0.0F);
      vertex(0.0F, paramFloat, 0.0F);
    } 
    normal(this.sphereX[j], this.sphereY[j], this.sphereZ[j]);
    vertex(paramFloat * this.sphereX[j], paramFloat * this.sphereY[j], paramFloat * this.sphereZ[j]);
    normal(0.0F, 1.0F, 0.0F);
    vertex(0.0F, paramFloat, 0.0F);
    endShape();
    edge(true);
  }
  
  public float bezierPoint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    float f = 1.0F - paramFloat5;
    return paramFloat1 * f * f * f + 3.0F * paramFloat2 * paramFloat5 * f * f + 3.0F * paramFloat3 * paramFloat5 * paramFloat5 * f + paramFloat4 * paramFloat5 * paramFloat5 * paramFloat5;
  }
  
  public float bezierTangent(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    return 3.0F * paramFloat5 * paramFloat5 * (-paramFloat1 + 3.0F * paramFloat2 - 3.0F * paramFloat3 + paramFloat4) + 6.0F * paramFloat5 * (paramFloat1 - 2.0F * paramFloat2 + paramFloat3) + 3.0F * (-paramFloat1 + paramFloat2);
  }
  
  protected void bezierInitCheck() {
    if (!this.bezierInited)
      bezierInit(); 
  }
  
  protected void bezierInit() {
    bezierDetail(this.bezierDetail);
    this.bezierInited = true;
  }
  
  public void bezierDetail(int paramInt) {
    this.bezierDetail = paramInt;
    if (this.bezierDrawMatrix == null)
      this.bezierDrawMatrix = new PMatrix3D(); 
    splineForward(paramInt, this.bezierDrawMatrix);
    this.bezierDrawMatrix.apply(this.bezierBasisMatrix);
  }
  
  public void bezier(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    beginShape();
    vertex(paramFloat1, paramFloat2);
    bezierVertex(paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
    endShape();
  }
  
  public void bezier(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12) {
    beginShape();
    vertex(paramFloat1, paramFloat2, paramFloat3);
    bezierVertex(paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12);
    endShape();
  }
  
  public float curvePoint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    curveInitCheck();
    float f1 = paramFloat5 * paramFloat5;
    float f2 = paramFloat5 * f1;
    PMatrix3D pMatrix3D = this.curveBasisMatrix;
    return paramFloat1 * (f2 * pMatrix3D.m00 + f1 * pMatrix3D.m10 + paramFloat5 * pMatrix3D.m20 + pMatrix3D.m30) + paramFloat2 * (f2 * pMatrix3D.m01 + f1 * pMatrix3D.m11 + paramFloat5 * pMatrix3D.m21 + pMatrix3D.m31) + paramFloat3 * (f2 * pMatrix3D.m02 + f1 * pMatrix3D.m12 + paramFloat5 * pMatrix3D.m22 + pMatrix3D.m32) + paramFloat4 * (f2 * pMatrix3D.m03 + f1 * pMatrix3D.m13 + paramFloat5 * pMatrix3D.m23 + pMatrix3D.m33);
  }
  
  public float curveTangent(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    curveInitCheck();
    float f1 = paramFloat5 * paramFloat5 * 3.0F;
    float f2 = paramFloat5 * 2.0F;
    PMatrix3D pMatrix3D = this.curveBasisMatrix;
    return paramFloat1 * (f1 * pMatrix3D.m00 + f2 * pMatrix3D.m10 + pMatrix3D.m20) + paramFloat2 * (f1 * pMatrix3D.m01 + f2 * pMatrix3D.m11 + pMatrix3D.m21) + paramFloat3 * (f1 * pMatrix3D.m02 + f2 * pMatrix3D.m12 + pMatrix3D.m22) + paramFloat4 * (f1 * pMatrix3D.m03 + f2 * pMatrix3D.m13 + pMatrix3D.m23);
  }
  
  public void curveDetail(int paramInt) {
    this.curveDetail = paramInt;
    curveInit();
  }
  
  public void curveTightness(float paramFloat) {
    this.curveTightness = paramFloat;
    curveInit();
  }
  
  protected void curveInitCheck() {
    if (!this.curveInited)
      curveInit(); 
  }
  
  protected void curveInit() {
    if (this.curveDrawMatrix == null) {
      this.curveBasisMatrix = new PMatrix3D();
      this.curveDrawMatrix = new PMatrix3D();
      this.curveInited = true;
    } 
    float f = this.curveTightness;
    this.curveBasisMatrix.set((f - 1.0F) / 2.0F, (f + 3.0F) / 2.0F, (-3.0F - f) / 2.0F, (1.0F - f) / 2.0F, 1.0F - f, (-5.0F - f) / 2.0F, f + 2.0F, (f - 1.0F) / 2.0F, (f - 1.0F) / 2.0F, 0.0F, (1.0F - f) / 2.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
    splineForward(this.curveDetail, this.curveDrawMatrix);
    if (this.bezierBasisInverse == null) {
      this.bezierBasisInverse = this.bezierBasisMatrix.get();
      this.bezierBasisInverse.invert();
      this.curveToBezierMatrix = new PMatrix3D();
    } 
    this.curveToBezierMatrix.set(this.curveBasisMatrix);
    this.curveToBezierMatrix.preApply(this.bezierBasisInverse);
    this.curveDrawMatrix.apply(this.curveBasisMatrix);
  }
  
  public void curve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    beginShape();
    curveVertex(paramFloat1, paramFloat2);
    curveVertex(paramFloat3, paramFloat4);
    curveVertex(paramFloat5, paramFloat6);
    curveVertex(paramFloat7, paramFloat8);
    endShape();
  }
  
  public void curve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12) {
    beginShape();
    curveVertex(paramFloat1, paramFloat2, paramFloat3);
    curveVertex(paramFloat4, paramFloat5, paramFloat6);
    curveVertex(paramFloat7, paramFloat8, paramFloat9);
    curveVertex(paramFloat10, paramFloat11, paramFloat12);
    endShape();
  }
  
  protected void splineForward(int paramInt, PMatrix3D paramPMatrix3D) {
    float f1 = 1.0F / paramInt;
    float f2 = f1 * f1;
    float f3 = f2 * f1;
    paramPMatrix3D.set(0.0F, 0.0F, 0.0F, 1.0F, f3, f2, f1, 0.0F, 6.0F * f3, 2.0F * f2, 0.0F, 0.0F, 6.0F * f3, 0.0F, 0.0F, 0.0F);
  }
  
  public void smooth() {
    this.smooth = true;
  }
  
  public void noSmooth() {
    this.smooth = false;
  }
  
  public void imageMode(int paramInt) {
    if (paramInt == 0 || paramInt == 1 || paramInt == 3) {
      this.imageMode = paramInt;
    } else {
      String str = "imageMode() only works with CORNER, CORNERS, or CENTER";
      throw new RuntimeException(str);
    } 
  }
  
  public void image(PImage paramPImage, float paramFloat1, float paramFloat2) {
    if (paramPImage.width == -1 || paramPImage.height == -1)
      return; 
    if (this.imageMode == 0 || this.imageMode == 1) {
      imageImpl(paramPImage, paramFloat1, paramFloat2, paramFloat1 + paramPImage.width, paramFloat2 + paramPImage.height, 0, 0, paramPImage.width, paramPImage.height);
    } else if (this.imageMode == 3) {
      float f1 = paramFloat1 - (paramPImage.width / 2);
      float f2 = paramFloat2 - (paramPImage.height / 2);
      imageImpl(paramPImage, f1, f2, f1 + paramPImage.width, f2 + paramPImage.height, 0, 0, paramPImage.width, paramPImage.height);
    } 
  }
  
  public void image(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    image(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, 0, 0, paramPImage.width, paramPImage.height);
  }
  
  public void image(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramPImage.width == -1 || paramPImage.height == -1)
      return; 
    if (this.imageMode == 0) {
      if (paramFloat3 < 0.0F) {
        paramFloat1 += paramFloat3;
        paramFloat3 = -paramFloat3;
      } 
      if (paramFloat4 < 0.0F) {
        paramFloat2 += paramFloat4;
        paramFloat4 = -paramFloat4;
      } 
      imageImpl(paramPImage, paramFloat1, paramFloat2, paramFloat1 + paramFloat3, paramFloat2 + paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4);
    } else if (this.imageMode == 1) {
      if (paramFloat3 < paramFloat1) {
        float f = paramFloat1;
        paramFloat1 = paramFloat3;
        paramFloat3 = f;
      } 
      if (paramFloat4 < paramFloat2) {
        float f = paramFloat2;
        paramFloat2 = paramFloat4;
        paramFloat4 = f;
      } 
      imageImpl(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4);
    } else if (this.imageMode == 3) {
      if (paramFloat3 < 0.0F)
        paramFloat3 = -paramFloat3; 
      if (paramFloat4 < 0.0F)
        paramFloat4 = -paramFloat4; 
      float f1 = paramFloat1 - paramFloat3 / 2.0F;
      float f2 = paramFloat2 - paramFloat4 / 2.0F;
      imageImpl(paramPImage, f1, f2, f1 + paramFloat3, f2 + paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4);
    } 
  }
  
  protected void imageImpl(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    boolean bool = this.stroke;
    int i = this.textureMode;
    this.stroke = false;
    this.textureMode = 2;
    beginShape(16);
    texture(paramPImage);
    vertex(paramFloat1, paramFloat2, paramInt1, paramInt2);
    vertex(paramFloat1, paramFloat4, paramInt1, paramInt4);
    vertex(paramFloat3, paramFloat4, paramInt3, paramInt4);
    vertex(paramFloat3, paramFloat2, paramInt3, paramInt2);
    endShape();
    this.stroke = bool;
    this.textureMode = i;
  }
  
  public void shapeMode(int paramInt) {
    this.shapeMode = paramInt;
  }
  
  public void shape(PShape paramPShape) {
    if (paramPShape.isVisible()) {
      if (this.shapeMode == 3) {
        pushMatrix();
        translate(-paramPShape.getWidth() / 2.0F, -paramPShape.getHeight() / 2.0F);
      } 
      paramPShape.draw(this);
      if (this.shapeMode == 3)
        popMatrix(); 
    } 
  }
  
  public void shape(PShape paramPShape, float paramFloat1, float paramFloat2) {
    if (paramPShape.isVisible()) {
      pushMatrix();
      if (this.shapeMode == 3) {
        translate(paramFloat1 - paramPShape.getWidth() / 2.0F, paramFloat2 - paramPShape.getHeight() / 2.0F);
      } else if (this.shapeMode == 0 || this.shapeMode == 1) {
        translate(paramFloat1, paramFloat2);
      } 
      paramPShape.draw(this);
      popMatrix();
    } 
  }
  
  public void shape(PShape paramPShape, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (paramPShape.isVisible()) {
      pushMatrix();
      if (this.shapeMode == 3) {
        translate(paramFloat1 - paramFloat3 / 2.0F, paramFloat2 - paramFloat4 / 2.0F);
        scale(paramFloat3 / paramPShape.getWidth(), paramFloat4 / paramPShape.getHeight());
      } else if (this.shapeMode == 0) {
        translate(paramFloat1, paramFloat2);
        scale(paramFloat3 / paramPShape.getWidth(), paramFloat4 / paramPShape.getHeight());
      } else if (this.shapeMode == 1) {
        paramFloat3 -= paramFloat1;
        paramFloat4 -= paramFloat2;
        translate(paramFloat1, paramFloat2);
        scale(paramFloat3 / paramPShape.getWidth(), paramFloat4 / paramPShape.getHeight());
      } 
      paramPShape.draw(this);
      popMatrix();
    } 
  }
  
  public void textAlign(int paramInt) {
    textAlign(paramInt, 0);
  }
  
  public void textAlign(int paramInt1, int paramInt2) {
    this.textAlign = paramInt1;
    this.textAlignY = paramInt2;
  }
  
  public float textAscent() {
    if (this.textFont == null)
      defaultFontOrDeath("textAscent"); 
    return this.textFont.ascent() * ((this.textMode == 256) ? this.textFont.size : this.textSize);
  }
  
  public float textDescent() {
    if (this.textFont == null)
      defaultFontOrDeath("textDescent"); 
    return this.textFont.descent() * ((this.textMode == 256) ? this.textFont.size : this.textSize);
  }
  
  public void textFont(PFont paramPFont) {
    if (paramPFont != null) {
      this.textFont = paramPFont;
      if (this.hints[3])
        paramPFont.findFont(); 
      textSize(paramPFont.size);
    } else {
      throw new RuntimeException("A null PFont was passed to textFont()");
    } 
  }
  
  public void textFont(PFont paramPFont, float paramFloat) {
    textFont(paramPFont);
    textSize(paramFloat);
  }
  
  public void textLeading(float paramFloat) {
    this.textLeading = paramFloat;
  }
  
  public void textMode(int paramInt) {
    if (paramInt == 37 || paramInt == 39) {
      showWarning("Since Processing beta, textMode() is now textAlign().");
      return;
    } 
    if (textModeCheck(paramInt)) {
      this.textMode = paramInt;
    } else {
      String str = String.valueOf(paramInt);
      switch (paramInt) {
        case 256:
          str = "SCREEN";
          break;
        case 4:
          str = "MODEL";
          break;
        case 5:
          str = "SHAPE";
          break;
      } 
      showWarning("textMode(" + str + ") is not supported by this renderer.");
    } 
  }
  
  protected boolean textModeCheck(int paramInt) {
    return true;
  }
  
  public void textSize(float paramFloat) {
    if (this.textFont == null)
      defaultFontOrDeath("textSize", paramFloat); 
    this.textSize = paramFloat;
    this.textLeading = (textAscent() + textDescent()) * 1.275F;
  }
  
  public float textWidth(char paramChar) {
    this.textWidthBuffer[0] = paramChar;
    return textWidthImpl(this.textWidthBuffer, 0, 1);
  }
  
  public float textWidth(String paramString) {
    if (this.textFont == null)
      defaultFontOrDeath("textWidth"); 
    int i = paramString.length();
    if (i > this.textWidthBuffer.length)
      this.textWidthBuffer = new char[i + 10]; 
    paramString.getChars(0, i, this.textWidthBuffer, 0);
    float f = 0.0F;
    byte b = 0;
    int j = 0;
    while (b < i) {
      if (this.textWidthBuffer[b] == '\n') {
        f = Math.max(f, textWidthImpl(this.textWidthBuffer, j, b));
        j = b + 1;
      } 
      b++;
    } 
    if (j < i)
      f = Math.max(f, textWidthImpl(this.textWidthBuffer, j, b)); 
    return f;
  }
  
  public float textWidth(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    return textWidthImpl(paramArrayOfchar, paramInt1, paramInt1 + paramInt2);
  }
  
  protected float textWidthImpl(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    float f = 0.0F;
    for (int i = paramInt1; i < paramInt2; i++)
      f += this.textFont.width(paramArrayOfchar[i]) * this.textSize; 
    return f;
  }
  
  public void text(char paramChar) {
    text(paramChar, this.textX, this.textY, this.textZ);
  }
  
  public void text(char paramChar, float paramFloat1, float paramFloat2) {
    if (this.textFont == null)
      defaultFontOrDeath("text"); 
    if (this.textMode == 256)
      loadPixels(); 
    if (this.textAlignY == 3) {
      paramFloat2 += textAscent() / 2.0F;
    } else if (this.textAlignY == 101) {
      paramFloat2 += textAscent();
    } else if (this.textAlignY == 102) {
      paramFloat2 -= textDescent();
    } 
    this.textBuffer[0] = paramChar;
    textLineAlignImpl(this.textBuffer, 0, 1, paramFloat1, paramFloat2);
    if (this.textMode == 256)
      updatePixels(); 
  }
  
  public void text(char paramChar, float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramFloat3 != 0.0F)
      translate(0.0F, 0.0F, paramFloat3); 
    text(paramChar, paramFloat1, paramFloat2);
    this.textZ = paramFloat3;
    if (paramFloat3 != 0.0F)
      translate(0.0F, 0.0F, -paramFloat3); 
  }
  
  public void text(String paramString) {
    text(paramString, this.textX, this.textY, this.textZ);
  }
  
  public void text(String paramString, float paramFloat1, float paramFloat2) {
    if (this.textFont == null)
      defaultFontOrDeath("text"); 
    if (this.textMode == 256)
      loadPixels(); 
    int i = paramString.length();
    if (i > this.textBuffer.length)
      this.textBuffer = new char[i + 10]; 
    paramString.getChars(0, i, this.textBuffer, 0);
    text(this.textBuffer, 0, i, paramFloat1, paramFloat2);
  }
  
  public void text(char[] paramArrayOfchar, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
    float f = 0.0F;
    int i;
    for (i = paramInt1; i < paramInt2; i++) {
      if (paramArrayOfchar[i] == '\n')
        f += this.textLeading; 
    } 
    if (this.textAlignY == 3) {
      paramFloat2 += (textAscent() - f) / 2.0F;
    } else if (this.textAlignY == 101) {
      paramFloat2 += textAscent();
    } else if (this.textAlignY == 102) {
      paramFloat2 -= textDescent() + f;
    } 
    for (i = 0; i < paramInt2; i++) {
      if (paramArrayOfchar[i] == '\n') {
        textLineAlignImpl(paramArrayOfchar, paramInt1, i, paramFloat1, paramFloat2);
        paramInt1 = i + 1;
        paramFloat2 += this.textLeading;
      } 
    } 
    if (paramInt1 < paramInt2)
      textLineAlignImpl(paramArrayOfchar, paramInt1, i, paramFloat1, paramFloat2); 
    if (this.textMode == 256)
      updatePixels(); 
  }
  
  public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramFloat3 != 0.0F)
      translate(0.0F, 0.0F, paramFloat3); 
    text(paramString, paramFloat1, paramFloat2);
    this.textZ = paramFloat3;
    if (paramFloat3 != 0.0F)
      translate(0.0F, 0.0F, -paramFloat3); 
  }
  
  public void text(char[] paramArrayOfchar, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramFloat3 != 0.0F)
      translate(0.0F, 0.0F, paramFloat3); 
    text(paramArrayOfchar, paramInt1, paramInt2, paramFloat1, paramFloat2);
    this.textZ = paramFloat3;
    if (paramFloat3 != 0.0F)
      translate(0.0F, 0.0F, -paramFloat3); 
  }
  
  public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    float f1;
    float f2;
    if (this.textFont == null)
      defaultFontOrDeath("text"); 
    if (this.textMode == 256)
      loadPixels(); 
    switch (this.rectMode) {
      case 0:
        paramFloat3 += paramFloat1;
        paramFloat4 += paramFloat2;
        break;
      case 2:
        f1 = paramFloat3;
        f2 = paramFloat4;
        paramFloat3 = paramFloat1 + f1;
        paramFloat4 = paramFloat2 + f2;
        paramFloat1 -= f1;
        paramFloat2 -= f2;
        break;
      case 3:
        f1 = paramFloat3 / 2.0F;
        f2 = paramFloat4 / 2.0F;
        paramFloat3 = paramFloat1 + f1;
        paramFloat4 = paramFloat2 + f2;
        paramFloat1 -= f1;
        paramFloat2 -= f2;
        break;
    } 
    if (paramFloat3 < paramFloat1) {
      float f = paramFloat1;
      paramFloat1 = paramFloat3;
      paramFloat3 = f;
    } 
    if (paramFloat4 < paramFloat2) {
      float f = paramFloat2;
      paramFloat2 = paramFloat4;
      paramFloat4 = f;
    } 
    float f3 = paramFloat3 - paramFloat1;
    float f4 = textWidth(' ');
    if (this.textBreakStart == null) {
      this.textBreakStart = new int[20];
      this.textBreakStop = new int[20];
    } 
    this.textBreakCount = 0;
    int i = paramString.length();
    if (i + 1 > this.textBuffer.length)
      this.textBuffer = new char[i + 1]; 
    paramString.getChars(0, i, this.textBuffer, 0);
    this.textBuffer[i++] = '\n';
    int j = 0;
    for (byte b = 0; b < i; b++) {
      if (this.textBuffer[b] == '\n') {
        boolean bool = textSentence(this.textBuffer, j, b, f3, f4);
        if (!bool)
          break; 
        j = b + 1;
      } 
    } 
    float f5 = paramFloat1;
    if (this.textAlign == 3) {
      f5 += f3 / 2.0F;
    } else if (this.textAlign == 39) {
      f5 = paramFloat3;
    } 
    float f6 = paramFloat4 - paramFloat2;
    float f7 = textAscent() + textDescent();
    int k = 1 + PApplet.floor((f6 - f7) / this.textLeading);
    int m = Math.min(this.textBreakCount, k);
    if (this.textAlignY == 3) {
      float f8 = textAscent() + this.textLeading * (m - 1);
      float f9 = paramFloat2 + textAscent() + (f6 - f8) / 2.0F;
      for (byte b1 = 0; b1 < m; b1++) {
        textLineAlignImpl(this.textBuffer, this.textBreakStart[b1], this.textBreakStop[b1], f5, f9);
        f9 += this.textLeading;
      } 
    } else if (this.textAlignY == 102) {
      float f = paramFloat4 - textDescent() - this.textLeading * (m - 1);
      for (byte b1 = 0; b1 < m; b1++) {
        textLineAlignImpl(this.textBuffer, this.textBreakStart[b1], this.textBreakStop[b1], f5, f);
        f += this.textLeading;
      } 
    } else {
      float f = paramFloat2 + textAscent();
      for (byte b1 = 0; b1 < m; b1++) {
        textLineAlignImpl(this.textBuffer, this.textBreakStart[b1], this.textBreakStop[b1], f5, f);
        f += this.textLeading;
      } 
    } 
    if (this.textMode == 256)
      updatePixels(); 
  }
  
  protected boolean textSentence(char[] paramArrayOfchar, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
    float f = 0.0F;
    int i = paramInt1;
    int j = paramInt1;
    for (int k = paramInt1; k <= paramInt2; k++) {
      if (paramArrayOfchar[k] == ' ' || k == paramInt2) {
        float f1 = textWidthImpl(paramArrayOfchar, j, k);
        if (f + f1 > paramFloat1) {
          if (f != 0.0F) {
            k = j;
            textSentenceBreak(i, k);
            while (k < paramInt2 && paramArrayOfchar[k] == ' ')
              k++; 
          } else {
            while (true) {
              if (--k == j)
                return false; 
              f1 = textWidthImpl(paramArrayOfchar, j, k);
              if (f1 <= paramFloat1) {
                textSentenceBreak(i, k);
                break;
              } 
            } 
          } 
          i = k;
          j = k;
          f = 0.0F;
          continue;
        } 
        if (k == paramInt2) {
          textSentenceBreak(i, k);
          k++;
          continue;
        } 
        f += f1 + paramFloat2;
        j = k + 1;
        k++;
        continue;
      } 
    } 
    return true;
  }
  
  protected void textSentenceBreak(int paramInt1, int paramInt2) {
    if (this.textBreakCount == this.textBreakStart.length) {
      this.textBreakStart = PApplet.expand(this.textBreakStart);
      this.textBreakStop = PApplet.expand(this.textBreakStop);
    } 
    this.textBreakStart[this.textBreakCount] = paramInt1;
    this.textBreakStop[this.textBreakCount] = paramInt2;
    this.textBreakCount++;
  }
  
  public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    if (paramFloat5 != 0.0F)
      translate(0.0F, 0.0F, paramFloat5); 
    text(paramString, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    this.textZ = paramFloat5;
    if (paramFloat5 != 0.0F)
      translate(0.0F, 0.0F, -paramFloat5); 
  }
  
  public void text(int paramInt, float paramFloat1, float paramFloat2) {
    text(String.valueOf(paramInt), paramFloat1, paramFloat2);
  }
  
  public void text(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3) {
    text(String.valueOf(paramInt), paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void text(float paramFloat1, float paramFloat2, float paramFloat3) {
    text(PApplet.nfs(paramFloat1, 0, 3), paramFloat2, paramFloat3);
  }
  
  public void text(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    text(PApplet.nfs(paramFloat1, 0, 3), paramFloat2, paramFloat3, paramFloat4);
  }
  
  protected void textLineAlignImpl(char[] paramArrayOfchar, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
    if (this.textAlign == 3) {
      paramFloat1 -= textWidthImpl(paramArrayOfchar, paramInt1, paramInt2) / 2.0F;
    } else if (this.textAlign == 39) {
      paramFloat1 -= textWidthImpl(paramArrayOfchar, paramInt1, paramInt2);
    } 
    textLineImpl(paramArrayOfchar, paramInt1, paramInt2, paramFloat1, paramFloat2);
  }
  
  protected void textLineImpl(char[] paramArrayOfchar, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
    for (int i = paramInt1; i < paramInt2; i++) {
      textCharImpl(paramArrayOfchar[i], paramFloat1, paramFloat2);
      paramFloat1 += textWidth(paramArrayOfchar[i]);
    } 
    this.textX = paramFloat1;
    this.textY = paramFloat2;
    this.textZ = 0.0F;
  }
  
  protected void textCharImpl(char paramChar, float paramFloat1, float paramFloat2) {
    PFont.Glyph glyph = this.textFont.getGlyph(paramChar);
    if (glyph != null)
      if (this.textMode == 4) {
        float f1 = glyph.height / this.textFont.size;
        float f2 = glyph.width / this.textFont.size;
        float f3 = glyph.leftExtent / this.textFont.size;
        float f4 = glyph.topExtent / this.textFont.size;
        float f5 = paramFloat1 + f3 * this.textSize;
        float f6 = paramFloat2 - f4 * this.textSize;
        float f7 = f5 + f2 * this.textSize;
        float f8 = f6 + f1 * this.textSize;
        textCharModelImpl(glyph.image, f5, f6, f7, f8, glyph.width, glyph.height);
      } else if (this.textMode == 256) {
        int i = (int)paramFloat1 + glyph.leftExtent;
        int j = (int)paramFloat2 - glyph.topExtent;
        int k = glyph.width;
        int m = glyph.height;
        textCharScreenImpl(glyph.image, i, j, k, m);
      }  
  }
  
  protected void textCharModelImpl(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2) {
    boolean bool1 = this.tint;
    int i = this.tintColor;
    float f1 = this.tintR;
    float f2 = this.tintG;
    float f3 = this.tintB;
    float f4 = this.tintA;
    boolean bool2 = this.tintAlpha;
    this.tint = true;
    this.tintColor = this.fillColor;
    this.tintR = this.fillR;
    this.tintG = this.fillG;
    this.tintB = this.fillB;
    this.tintA = this.fillA;
    this.tintAlpha = this.fillAlpha;
    imageImpl(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, 0, 0, paramInt1, paramInt2);
    this.tint = bool1;
    this.tintColor = i;
    this.tintR = f1;
    this.tintG = f2;
    this.tintB = f3;
    this.tintA = f4;
    this.tintAlpha = bool2;
  }
  
  protected void textCharScreenImpl(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = 0;
    int j = 0;
    if (paramInt1 >= this.width || paramInt2 >= this.height || paramInt1 + paramInt3 < 0 || paramInt2 + paramInt4 < 0)
      return; 
    if (paramInt1 < 0) {
      i -= paramInt1;
      paramInt3 += paramInt1;
      paramInt1 = 0;
    } 
    if (paramInt2 < 0) {
      j -= paramInt2;
      paramInt4 += paramInt2;
      paramInt2 = 0;
    } 
    if (paramInt1 + paramInt3 > this.width)
      paramInt3 -= paramInt1 + paramInt3 - this.width; 
    if (paramInt2 + paramInt4 > this.height)
      paramInt4 -= paramInt2 + paramInt4 - this.height; 
    int k = this.fillRi;
    int m = this.fillGi;
    int n = this.fillBi;
    int i1 = this.fillAi;
    int[] arrayOfInt = paramPImage.pixels;
    for (int i2 = j; i2 < j + paramInt4; i2++) {
      for (int i3 = i; i3 < i + paramInt3; i3++) {
        int i4 = i1 * arrayOfInt[i2 * paramPImage.width + i3] >> 8;
        int i5 = i4 ^ 0xFF;
        int i6 = this.pixels[(paramInt2 + i2 - j) * this.width + paramInt1 + i3 - i];
        this.pixels[(paramInt2 + i2 - j) * this.width + paramInt1 + i3 - i] = 0xFF000000 | (i4 * k + i5 * (i6 >> 16 & 0xFF) & 0xFF00) << 8 | i4 * m + i5 * (i6 >> 8 & 0xFF) & 0xFF00 | i4 * n + i5 * (i6 & 0xFF) >> 8;
      } 
    } 
  }
  
  public void pushMatrix() {
    showMethodWarning("pushMatrix");
  }
  
  public void popMatrix() {
    showMethodWarning("popMatrix");
  }
  
  public void translate(float paramFloat1, float paramFloat2) {
    showMissingWarning("translate");
  }
  
  public void translate(float paramFloat1, float paramFloat2, float paramFloat3) {
    showMissingWarning("translate");
  }
  
  public void rotate(float paramFloat) {
    showMissingWarning("rotate");
  }
  
  public void rotateX(float paramFloat) {
    showMethodWarning("rotateX");
  }
  
  public void rotateY(float paramFloat) {
    showMethodWarning("rotateY");
  }
  
  public void rotateZ(float paramFloat) {
    showMethodWarning("rotateZ");
  }
  
  public void rotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    showMissingWarning("rotate");
  }
  
  public void scale(float paramFloat) {
    showMissingWarning("scale");
  }
  
  public void scale(float paramFloat1, float paramFloat2) {
    showMissingWarning("scale");
  }
  
  public void scale(float paramFloat1, float paramFloat2, float paramFloat3) {
    showMissingWarning("scale");
  }
  
  public void shearX(float paramFloat) {
    showMissingWarning("shearX");
  }
  
  public void shearY(float paramFloat) {
    showMissingWarning("shearY");
  }
  
  public void resetMatrix() {
    showMethodWarning("resetMatrix");
  }
  
  public void applyMatrix(PMatrix paramPMatrix) {
    if (paramPMatrix instanceof PMatrix2D) {
      applyMatrix((PMatrix2D)paramPMatrix);
    } else if (paramPMatrix instanceof PMatrix3D) {
      applyMatrix((PMatrix3D)paramPMatrix);
    } 
  }
  
  public void applyMatrix(PMatrix2D paramPMatrix2D) {
    applyMatrix(paramPMatrix2D.m00, paramPMatrix2D.m01, paramPMatrix2D.m02, paramPMatrix2D.m10, paramPMatrix2D.m11, paramPMatrix2D.m12);
  }
  
  public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    showMissingWarning("applyMatrix");
  }
  
  public void applyMatrix(PMatrix3D paramPMatrix3D) {
    applyMatrix(paramPMatrix3D.m00, paramPMatrix3D.m01, paramPMatrix3D.m02, paramPMatrix3D.m03, paramPMatrix3D.m10, paramPMatrix3D.m11, paramPMatrix3D.m12, paramPMatrix3D.m13, paramPMatrix3D.m20, paramPMatrix3D.m21, paramPMatrix3D.m22, paramPMatrix3D.m23, paramPMatrix3D.m30, paramPMatrix3D.m31, paramPMatrix3D.m32, paramPMatrix3D.m33);
  }
  
  public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16) {
    showMissingWarning("applyMatrix");
  }
  
  public PMatrix getMatrix() {
    showMissingWarning("getMatrix");
    return null;
  }
  
  public PMatrix2D getMatrix(PMatrix2D paramPMatrix2D) {
    showMissingWarning("getMatrix");
    return null;
  }
  
  public PMatrix3D getMatrix(PMatrix3D paramPMatrix3D) {
    showMissingWarning("getMatrix");
    return null;
  }
  
  public void setMatrix(PMatrix paramPMatrix) {
    if (paramPMatrix instanceof PMatrix2D) {
      setMatrix((PMatrix2D)paramPMatrix);
    } else if (paramPMatrix instanceof PMatrix3D) {
      setMatrix((PMatrix3D)paramPMatrix);
    } 
  }
  
  public void setMatrix(PMatrix2D paramPMatrix2D) {
    showMissingWarning("setMatrix");
  }
  
  public void setMatrix(PMatrix3D paramPMatrix3D) {
    showMissingWarning("setMatrix");
  }
  
  public void printMatrix() {
    showMethodWarning("printMatrix");
  }
  
  public void beginCamera() {
    showMethodWarning("beginCamera");
  }
  
  public void endCamera() {
    showMethodWarning("endCamera");
  }
  
  public void camera() {
    showMissingWarning("camera");
  }
  
  public void camera(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9) {
    showMissingWarning("camera");
  }
  
  public void printCamera() {
    showMethodWarning("printCamera");
  }
  
  public void ortho() {
    showMissingWarning("ortho");
  }
  
  public void ortho(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    showMissingWarning("ortho");
  }
  
  public void ortho(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    showMissingWarning("ortho");
  }
  
  public void perspective() {
    showMissingWarning("perspective");
  }
  
  public void perspective(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    showMissingWarning("perspective");
  }
  
  public void frustum(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    showMethodWarning("frustum");
  }
  
  public void printProjection() {
    showMethodWarning("printCamera");
  }
  
  public float screenX(float paramFloat1, float paramFloat2) {
    showMissingWarning("screenX");
    return 0.0F;
  }
  
  public float screenY(float paramFloat1, float paramFloat2) {
    showMissingWarning("screenY");
    return 0.0F;
  }
  
  public float screenX(float paramFloat1, float paramFloat2, float paramFloat3) {
    showMissingWarning("screenX");
    return 0.0F;
  }
  
  public float screenY(float paramFloat1, float paramFloat2, float paramFloat3) {
    showMissingWarning("screenY");
    return 0.0F;
  }
  
  public float screenZ(float paramFloat1, float paramFloat2, float paramFloat3) {
    showMissingWarning("screenZ");
    return 0.0F;
  }
  
  public float modelX(float paramFloat1, float paramFloat2, float paramFloat3) {
    showMissingWarning("modelX");
    return 0.0F;
  }
  
  public float modelY(float paramFloat1, float paramFloat2, float paramFloat3) {
    showMissingWarning("modelY");
    return 0.0F;
  }
  
  public float modelZ(float paramFloat1, float paramFloat2, float paramFloat3) {
    showMissingWarning("modelZ");
    return 0.0F;
  }
  
  public void pushStyle() {
    if (this.styleStackDepth == this.styleStack.length)
      this.styleStack = (PStyle[])PApplet.expand(this.styleStack); 
    if (this.styleStack[this.styleStackDepth] == null)
      this.styleStack[this.styleStackDepth] = new PStyle(); 
    PStyle pStyle = this.styleStack[this.styleStackDepth++];
    getStyle(pStyle);
  }
  
  public void popStyle() {
    if (this.styleStackDepth == 0)
      throw new RuntimeException("Too many popStyle() without enough pushStyle()"); 
    this.styleStackDepth--;
    style(this.styleStack[this.styleStackDepth]);
  }
  
  public void style(PStyle paramPStyle) {
    imageMode(paramPStyle.imageMode);
    rectMode(paramPStyle.rectMode);
    ellipseMode(paramPStyle.ellipseMode);
    shapeMode(paramPStyle.shapeMode);
    if (paramPStyle.tint) {
      tint(paramPStyle.tintColor);
    } else {
      noTint();
    } 
    if (paramPStyle.fill) {
      fill(paramPStyle.fillColor);
    } else {
      noFill();
    } 
    if (paramPStyle.stroke) {
      stroke(paramPStyle.strokeColor);
    } else {
      noStroke();
    } 
    strokeWeight(paramPStyle.strokeWeight);
    strokeCap(paramPStyle.strokeCap);
    strokeJoin(paramPStyle.strokeJoin);
    colorMode(1, 1.0F);
    ambient(paramPStyle.ambientR, paramPStyle.ambientG, paramPStyle.ambientB);
    emissive(paramPStyle.emissiveR, paramPStyle.emissiveG, paramPStyle.emissiveB);
    specular(paramPStyle.specularR, paramPStyle.specularG, paramPStyle.specularB);
    shininess(paramPStyle.shininess);
    colorMode(paramPStyle.colorMode, paramPStyle.colorModeX, paramPStyle.colorModeY, paramPStyle.colorModeZ, paramPStyle.colorModeA);
    if (paramPStyle.textFont != null) {
      textFont(paramPStyle.textFont, paramPStyle.textSize);
      textLeading(paramPStyle.textLeading);
    } 
    textAlign(paramPStyle.textAlign, paramPStyle.textAlignY);
    textMode(paramPStyle.textMode);
  }
  
  public PStyle getStyle() {
    return getStyle((PStyle)null);
  }
  
  public PStyle getStyle(PStyle paramPStyle) {
    if (paramPStyle == null)
      paramPStyle = new PStyle(); 
    paramPStyle.imageMode = this.imageMode;
    paramPStyle.rectMode = this.rectMode;
    paramPStyle.ellipseMode = this.ellipseMode;
    paramPStyle.shapeMode = this.shapeMode;
    paramPStyle.colorMode = this.colorMode;
    paramPStyle.colorModeX = this.colorModeX;
    paramPStyle.colorModeY = this.colorModeY;
    paramPStyle.colorModeZ = this.colorModeZ;
    paramPStyle.colorModeA = this.colorModeA;
    paramPStyle.tint = this.tint;
    paramPStyle.tintColor = this.tintColor;
    paramPStyle.fill = this.fill;
    paramPStyle.fillColor = this.fillColor;
    paramPStyle.stroke = this.stroke;
    paramPStyle.strokeColor = this.strokeColor;
    paramPStyle.strokeWeight = this.strokeWeight;
    paramPStyle.strokeCap = this.strokeCap;
    paramPStyle.strokeJoin = this.strokeJoin;
    paramPStyle.ambientR = this.ambientR;
    paramPStyle.ambientG = this.ambientG;
    paramPStyle.ambientB = this.ambientB;
    paramPStyle.specularR = this.specularR;
    paramPStyle.specularG = this.specularG;
    paramPStyle.specularB = this.specularB;
    paramPStyle.emissiveR = this.emissiveR;
    paramPStyle.emissiveG = this.emissiveG;
    paramPStyle.emissiveB = this.emissiveB;
    paramPStyle.shininess = this.shininess;
    paramPStyle.textFont = this.textFont;
    paramPStyle.textAlign = this.textAlign;
    paramPStyle.textAlignY = this.textAlignY;
    paramPStyle.textMode = this.textMode;
    paramPStyle.textSize = this.textSize;
    paramPStyle.textLeading = this.textLeading;
    return paramPStyle;
  }
  
  public void strokeWeight(float paramFloat) {
    this.strokeWeight = paramFloat;
  }
  
  public void strokeJoin(int paramInt) {
    this.strokeJoin = paramInt;
  }
  
  public void strokeCap(int paramInt) {
    this.strokeCap = paramInt;
  }
  
  public void noStroke() {
    this.stroke = false;
  }
  
  public void stroke(int paramInt) {
    colorCalc(paramInt);
    strokeFromCalc();
  }
  
  public void stroke(int paramInt, float paramFloat) {
    colorCalc(paramInt, paramFloat);
    strokeFromCalc();
  }
  
  public void stroke(float paramFloat) {
    colorCalc(paramFloat);
    strokeFromCalc();
  }
  
  public void stroke(float paramFloat1, float paramFloat2) {
    colorCalc(paramFloat1, paramFloat2);
    strokeFromCalc();
  }
  
  public void stroke(float paramFloat1, float paramFloat2, float paramFloat3) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    strokeFromCalc();
  }
  
  public void stroke(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    strokeFromCalc();
  }
  
  protected void strokeFromCalc() {
    this.stroke = true;
    this.strokeR = this.calcR;
    this.strokeG = this.calcG;
    this.strokeB = this.calcB;
    this.strokeA = this.calcA;
    this.strokeRi = this.calcRi;
    this.strokeGi = this.calcGi;
    this.strokeBi = this.calcBi;
    this.strokeAi = this.calcAi;
    this.strokeColor = this.calcColor;
    this.strokeAlpha = this.calcAlpha;
  }
  
  public void noTint() {
    this.tint = false;
  }
  
  public void tint(int paramInt) {
    colorCalc(paramInt);
    tintFromCalc();
  }
  
  public void tint(int paramInt, float paramFloat) {
    colorCalc(paramInt, paramFloat);
    tintFromCalc();
  }
  
  public void tint(float paramFloat) {
    colorCalc(paramFloat);
    tintFromCalc();
  }
  
  public void tint(float paramFloat1, float paramFloat2) {
    colorCalc(paramFloat1, paramFloat2);
    tintFromCalc();
  }
  
  public void tint(float paramFloat1, float paramFloat2, float paramFloat3) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    tintFromCalc();
  }
  
  public void tint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    tintFromCalc();
  }
  
  protected void tintFromCalc() {
    this.tint = true;
    this.tintR = this.calcR;
    this.tintG = this.calcG;
    this.tintB = this.calcB;
    this.tintA = this.calcA;
    this.tintRi = this.calcRi;
    this.tintGi = this.calcGi;
    this.tintBi = this.calcBi;
    this.tintAi = this.calcAi;
    this.tintColor = this.calcColor;
    this.tintAlpha = this.calcAlpha;
  }
  
  public void noFill() {
    this.fill = false;
  }
  
  public void fill(int paramInt) {
    colorCalc(paramInt);
    fillFromCalc();
  }
  
  public void fill(int paramInt, float paramFloat) {
    colorCalc(paramInt, paramFloat);
    fillFromCalc();
  }
  
  public void fill(float paramFloat) {
    colorCalc(paramFloat);
    fillFromCalc();
  }
  
  public void fill(float paramFloat1, float paramFloat2) {
    colorCalc(paramFloat1, paramFloat2);
    fillFromCalc();
  }
  
  public void fill(float paramFloat1, float paramFloat2, float paramFloat3) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    fillFromCalc();
  }
  
  public void fill(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    fillFromCalc();
  }
  
  protected void fillFromCalc() {
    this.fill = true;
    this.fillR = this.calcR;
    this.fillG = this.calcG;
    this.fillB = this.calcB;
    this.fillA = this.calcA;
    this.fillRi = this.calcRi;
    this.fillGi = this.calcGi;
    this.fillBi = this.calcBi;
    this.fillAi = this.calcAi;
    this.fillColor = this.calcColor;
    this.fillAlpha = this.calcAlpha;
  }
  
  public void ambient(int paramInt) {
    colorCalc(paramInt);
    ambientFromCalc();
  }
  
  public void ambient(float paramFloat) {
    colorCalc(paramFloat);
    ambientFromCalc();
  }
  
  public void ambient(float paramFloat1, float paramFloat2, float paramFloat3) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    ambientFromCalc();
  }
  
  protected void ambientFromCalc() {
    this.ambientR = this.calcR;
    this.ambientG = this.calcG;
    this.ambientB = this.calcB;
  }
  
  public void specular(int paramInt) {
    colorCalc(paramInt);
    specularFromCalc();
  }
  
  public void specular(float paramFloat) {
    colorCalc(paramFloat);
    specularFromCalc();
  }
  
  public void specular(float paramFloat1, float paramFloat2, float paramFloat3) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    specularFromCalc();
  }
  
  protected void specularFromCalc() {
    this.specularR = this.calcR;
    this.specularG = this.calcG;
    this.specularB = this.calcB;
  }
  
  public void shininess(float paramFloat) {
    this.shininess = paramFloat;
  }
  
  public void emissive(int paramInt) {
    colorCalc(paramInt);
    emissiveFromCalc();
  }
  
  public void emissive(float paramFloat) {
    colorCalc(paramFloat);
    emissiveFromCalc();
  }
  
  public void emissive(float paramFloat1, float paramFloat2, float paramFloat3) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    emissiveFromCalc();
  }
  
  protected void emissiveFromCalc() {
    this.emissiveR = this.calcR;
    this.emissiveG = this.calcG;
    this.emissiveB = this.calcB;
  }
  
  public void lights() {
    showMethodWarning("lights");
  }
  
  public void noLights() {
    showMethodWarning("noLights");
  }
  
  public void ambientLight(float paramFloat1, float paramFloat2, float paramFloat3) {
    showMethodWarning("ambientLight");
  }
  
  public void ambientLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    showMethodWarning("ambientLight");
  }
  
  public void directionalLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    showMethodWarning("directionalLight");
  }
  
  public void pointLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    showMethodWarning("pointLight");
  }
  
  public void spotLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11) {
    showMethodWarning("spotLight");
  }
  
  public void lightFalloff(float paramFloat1, float paramFloat2, float paramFloat3) {
    showMethodWarning("lightFalloff");
  }
  
  public void lightSpecular(float paramFloat1, float paramFloat2, float paramFloat3) {
    showMethodWarning("lightSpecular");
  }
  
  public void background(int paramInt) {
    colorCalc(paramInt);
    backgroundFromCalc();
  }
  
  public void background(int paramInt, float paramFloat) {
    colorCalc(paramInt, paramFloat);
    backgroundFromCalc();
  }
  
  public void background(float paramFloat) {
    colorCalc(paramFloat);
    backgroundFromCalc();
  }
  
  public void background(float paramFloat1, float paramFloat2) {
    if (this.format == 1) {
      background(paramFloat1);
    } else {
      colorCalc(paramFloat1, paramFloat2);
      backgroundFromCalc();
    } 
  }
  
  public void background(float paramFloat1, float paramFloat2, float paramFloat3) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    backgroundFromCalc();
  }
  
  public void background(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    backgroundFromCalc();
  }
  
  protected void backgroundFromCalc() {
    this.backgroundR = this.calcR;
    this.backgroundG = this.calcG;
    this.backgroundB = this.calcB;
    this.backgroundA = (this.format == 1) ? this.colorModeA : this.calcA;
    this.backgroundRi = this.calcRi;
    this.backgroundGi = this.calcGi;
    this.backgroundBi = this.calcBi;
    this.backgroundAi = (this.format == 1) ? 255 : this.calcAi;
    this.backgroundAlpha = (this.format == 1) ? false : this.calcAlpha;
    this.backgroundColor = this.calcColor;
    backgroundImpl();
  }
  
  public void background(PImage paramPImage) {
    if (paramPImage.width != this.width || paramPImage.height != this.height)
      throw new RuntimeException("background image must be the same size as your application"); 
    if (paramPImage.format != 1 && paramPImage.format != 2)
      throw new RuntimeException("background images should be RGB or ARGB"); 
    this.backgroundColor = 0;
    backgroundImpl(paramPImage);
  }
  
  protected void backgroundImpl(PImage paramPImage) {
    set(0, 0, paramPImage);
  }
  
  protected void backgroundImpl() {
    pushStyle();
    pushMatrix();
    resetMatrix();
    fill(this.backgroundColor);
    rect(0.0F, 0.0F, this.width, this.height);
    popMatrix();
    popStyle();
  }
  
  public void colorMode(int paramInt) {
    colorMode(paramInt, this.colorModeX, this.colorModeY, this.colorModeZ, this.colorModeA);
  }
  
  public void colorMode(int paramInt, float paramFloat) {
    colorMode(paramInt, paramFloat, paramFloat, paramFloat, paramFloat);
  }
  
  public void colorMode(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3) {
    colorMode(paramInt, paramFloat1, paramFloat2, paramFloat3, this.colorModeA);
  }
  
  public void colorMode(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.colorMode = paramInt;
    this.colorModeX = paramFloat1;
    this.colorModeY = paramFloat2;
    this.colorModeZ = paramFloat3;
    this.colorModeA = paramFloat4;
    this.colorModeScale = (paramFloat4 != 1.0F || paramFloat1 != paramFloat2 || paramFloat2 != paramFloat3 || paramFloat3 != paramFloat4);
    this.colorModeDefault = (this.colorMode == 1 && this.colorModeA == 255.0F && this.colorModeX == 255.0F && this.colorModeY == 255.0F && this.colorModeZ == 255.0F);
  }
  
  protected void colorCalc(int paramInt) {
    if ((paramInt & 0xFF000000) == 0 && paramInt <= this.colorModeX) {
      colorCalc(paramInt);
    } else {
      colorCalcARGB(paramInt, this.colorModeA);
    } 
  }
  
  protected void colorCalc(int paramInt, float paramFloat) {
    if ((paramInt & 0xFF000000) == 0 && paramInt <= this.colorModeX) {
      colorCalc(paramInt, paramFloat);
    } else {
      colorCalcARGB(paramInt, paramFloat);
    } 
  }
  
  protected void colorCalc(float paramFloat) {
    colorCalc(paramFloat, this.colorModeA);
  }
  
  protected void colorCalc(float paramFloat1, float paramFloat2) {
    if (paramFloat1 > this.colorModeX)
      paramFloat1 = this.colorModeX; 
    if (paramFloat2 > this.colorModeA)
      paramFloat2 = this.colorModeA; 
    if (paramFloat1 < 0.0F)
      paramFloat1 = 0.0F; 
    if (paramFloat2 < 0.0F)
      paramFloat2 = 0.0F; 
    this.calcR = this.colorModeScale ? (paramFloat1 / this.colorModeX) : paramFloat1;
    this.calcG = this.calcR;
    this.calcB = this.calcR;
    this.calcA = this.colorModeScale ? (paramFloat2 / this.colorModeA) : paramFloat2;
    this.calcRi = (int)(this.calcR * 255.0F);
    this.calcGi = (int)(this.calcG * 255.0F);
    this.calcBi = (int)(this.calcB * 255.0F);
    this.calcAi = (int)(this.calcA * 255.0F);
    this.calcColor = this.calcAi << 24 | this.calcRi << 16 | this.calcGi << 8 | this.calcBi;
    this.calcAlpha = (this.calcAi != 255);
  }
  
  protected void colorCalc(float paramFloat1, float paramFloat2, float paramFloat3) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3, this.colorModeA);
  }
  
  protected void colorCalc(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    float f1;
    float f2;
    float f3;
    float f4;
    float f5;
    if (paramFloat1 > this.colorModeX)
      paramFloat1 = this.colorModeX; 
    if (paramFloat2 > this.colorModeY)
      paramFloat2 = this.colorModeY; 
    if (paramFloat3 > this.colorModeZ)
      paramFloat3 = this.colorModeZ; 
    if (paramFloat4 > this.colorModeA)
      paramFloat4 = this.colorModeA; 
    if (paramFloat1 < 0.0F)
      paramFloat1 = 0.0F; 
    if (paramFloat2 < 0.0F)
      paramFloat2 = 0.0F; 
    if (paramFloat3 < 0.0F)
      paramFloat3 = 0.0F; 
    if (paramFloat4 < 0.0F)
      paramFloat4 = 0.0F; 
    switch (this.colorMode) {
      case 1:
        if (this.colorModeScale) {
          this.calcR = paramFloat1 / this.colorModeX;
          this.calcG = paramFloat2 / this.colorModeY;
          this.calcB = paramFloat3 / this.colorModeZ;
          this.calcA = paramFloat4 / this.colorModeA;
          break;
        } 
        this.calcR = paramFloat1;
        this.calcG = paramFloat2;
        this.calcB = paramFloat3;
        this.calcA = paramFloat4;
        break;
      case 3:
        paramFloat1 /= this.colorModeX;
        paramFloat2 /= this.colorModeY;
        paramFloat3 /= this.colorModeZ;
        this.calcA = this.colorModeScale ? (paramFloat4 / this.colorModeA) : paramFloat4;
        if (paramFloat2 == 0.0F) {
          this.calcR = this.calcG = this.calcB = paramFloat3;
          break;
        } 
        f1 = (paramFloat1 - (int)paramFloat1) * 6.0F;
        f2 = f1 - (int)f1;
        f3 = paramFloat3 * (1.0F - paramFloat2);
        f4 = paramFloat3 * (1.0F - paramFloat2 * f2);
        f5 = paramFloat3 * (1.0F - paramFloat2 * (1.0F - f2));
        switch ((int)f1) {
          case 0:
            this.calcR = paramFloat3;
            this.calcG = f5;
            this.calcB = f3;
            break;
          case 1:
            this.calcR = f4;
            this.calcG = paramFloat3;
            this.calcB = f3;
            break;
          case 2:
            this.calcR = f3;
            this.calcG = paramFloat3;
            this.calcB = f5;
            break;
          case 3:
            this.calcR = f3;
            this.calcG = f4;
            this.calcB = paramFloat3;
            break;
          case 4:
            this.calcR = f5;
            this.calcG = f3;
            this.calcB = paramFloat3;
            break;
          case 5:
            this.calcR = paramFloat3;
            this.calcG = f3;
            this.calcB = f4;
            break;
        } 
        break;
    } 
    this.calcRi = (int)(255.0F * this.calcR);
    this.calcGi = (int)(255.0F * this.calcG);
    this.calcBi = (int)(255.0F * this.calcB);
    this.calcAi = (int)(255.0F * this.calcA);
    this.calcColor = this.calcAi << 24 | this.calcRi << 16 | this.calcGi << 8 | this.calcBi;
    this.calcAlpha = (this.calcAi != 255);
  }
  
  protected void colorCalcARGB(int paramInt, float paramFloat) {
    if (paramFloat == this.colorModeA) {
      this.calcAi = paramInt >> 24 & 0xFF;
      this.calcColor = paramInt;
    } else {
      this.calcAi = (int)((paramInt >> 24 & 0xFF) * paramFloat / this.colorModeA);
      this.calcColor = this.calcAi << 24 | paramInt & 0xFFFFFF;
    } 
    this.calcRi = paramInt >> 16 & 0xFF;
    this.calcGi = paramInt >> 8 & 0xFF;
    this.calcBi = paramInt & 0xFF;
    this.calcA = this.calcAi / 255.0F;
    this.calcR = this.calcRi / 255.0F;
    this.calcG = this.calcGi / 255.0F;
    this.calcB = this.calcBi / 255.0F;
    this.calcAlpha = (this.calcAi != 255);
  }
  
  public final int color(int paramInt) {
    colorCalc(paramInt);
    return this.calcColor;
  }
  
  public final int color(float paramFloat) {
    colorCalc(paramFloat);
    return this.calcColor;
  }
  
  public final int color(int paramInt1, int paramInt2) {
    colorCalc(paramInt1, paramInt2);
    return this.calcColor;
  }
  
  public final int color(int paramInt, float paramFloat) {
    colorCalc(paramInt, paramFloat);
    return this.calcColor;
  }
  
  public final int color(float paramFloat1, float paramFloat2) {
    colorCalc(paramFloat1, paramFloat2);
    return this.calcColor;
  }
  
  public final int color(int paramInt1, int paramInt2, int paramInt3) {
    colorCalc(paramInt1, paramInt2, paramInt3);
    return this.calcColor;
  }
  
  public final int color(float paramFloat1, float paramFloat2, float paramFloat3) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    return this.calcColor;
  }
  
  public final int color(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    colorCalc(paramInt1, paramInt2, paramInt3, paramInt4);
    return this.calcColor;
  }
  
  public final int color(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    return this.calcColor;
  }
  
  public final float alpha(int paramInt) {
    float f = (paramInt >> 24 & 0xFF);
    return (this.colorModeA == 255.0F) ? f : (f / 255.0F * this.colorModeA);
  }
  
  public final float red(int paramInt) {
    float f = (paramInt >> 16 & 0xFF);
    return this.colorModeDefault ? f : (f / 255.0F * this.colorModeX);
  }
  
  public final float green(int paramInt) {
    float f = (paramInt >> 8 & 0xFF);
    return this.colorModeDefault ? f : (f / 255.0F * this.colorModeY);
  }
  
  public final float blue(int paramInt) {
    float f = (paramInt & 0xFF);
    return this.colorModeDefault ? f : (f / 255.0F * this.colorModeZ);
  }
  
  public final float hue(int paramInt) {
    if (paramInt != this.cacheHsbKey) {
      Color.RGBtoHSB(paramInt >> 16 & 0xFF, paramInt >> 8 & 0xFF, paramInt & 0xFF, this.cacheHsbValue);
      this.cacheHsbKey = paramInt;
    } 
    return this.cacheHsbValue[0] * this.colorModeX;
  }
  
  public final float saturation(int paramInt) {
    if (paramInt != this.cacheHsbKey) {
      Color.RGBtoHSB(paramInt >> 16 & 0xFF, paramInt >> 8 & 0xFF, paramInt & 0xFF, this.cacheHsbValue);
      this.cacheHsbKey = paramInt;
    } 
    return this.cacheHsbValue[1] * this.colorModeY;
  }
  
  public final float brightness(int paramInt) {
    if (paramInt != this.cacheHsbKey) {
      Color.RGBtoHSB(paramInt >> 16 & 0xFF, paramInt >> 8 & 0xFF, paramInt & 0xFF, this.cacheHsbValue);
      this.cacheHsbKey = paramInt;
    } 
    return this.cacheHsbValue[2] * this.colorModeZ;
  }
  
  public int lerpColor(int paramInt1, int paramInt2, float paramFloat) {
    return lerpColor(paramInt1, paramInt2, paramFloat, this.colorMode);
  }
  
  public static int lerpColor(int paramInt1, int paramInt2, float paramFloat, int paramInt3) {
    if (paramInt3 == 1) {
      float f1 = (paramInt1 >> 24 & 0xFF);
      float f2 = (paramInt1 >> 16 & 0xFF);
      float f3 = (paramInt1 >> 8 & 0xFF);
      float f4 = (paramInt1 & 0xFF);
      float f5 = (paramInt2 >> 24 & 0xFF);
      float f6 = (paramInt2 >> 16 & 0xFF);
      float f7 = (paramInt2 >> 8 & 0xFF);
      float f8 = (paramInt2 & 0xFF);
      return (int)(f1 + (f5 - f1) * paramFloat) << 24 | (int)(f2 + (f6 - f2) * paramFloat) << 16 | (int)(f3 + (f7 - f3) * paramFloat) << 8 | (int)(f4 + (f8 - f4) * paramFloat);
    } 
    if (paramInt3 == 3) {
      if (lerpColorHSB1 == null) {
        lerpColorHSB1 = new float[3];
        lerpColorHSB2 = new float[3];
      } 
      float f1 = (paramInt1 >> 24 & 0xFF);
      float f2 = (paramInt2 >> 24 & 0xFF);
      int i = (int)(f1 + (f2 - f1) * paramFloat) << 24;
      Color.RGBtoHSB(paramInt1 >> 16 & 0xFF, paramInt1 >> 8 & 0xFF, paramInt1 & 0xFF, lerpColorHSB1);
      Color.RGBtoHSB(paramInt2 >> 16 & 0xFF, paramInt2 >> 8 & 0xFF, paramInt2 & 0xFF, lerpColorHSB2);
      float f3 = PApplet.lerp(lerpColorHSB1[0], lerpColorHSB2[0], paramFloat);
      float f4 = PApplet.lerp(lerpColorHSB1[1], lerpColorHSB2[1], paramFloat);
      float f5 = PApplet.lerp(lerpColorHSB1[2], lerpColorHSB2[2], paramFloat);
      return i | Color.HSBtoRGB(f3, f4, f5) & 0xFFFFFF;
    } 
    return 0;
  }
  
  public void beginRaw(PGraphics paramPGraphics) {
    this.raw = paramPGraphics;
    paramPGraphics.beginDraw();
  }
  
  public void endRaw() {
    if (this.raw != null) {
      flush();
      this.raw.endDraw();
      this.raw.dispose();
      this.raw = null;
    } 
  }
  
  public static void showWarning(String paramString) {
    if (warnings == null)
      warnings = new HashMap<String, Object>(); 
    if (!warnings.containsKey(paramString)) {
      System.err.println(paramString);
      warnings.put(paramString, new Object());
    } 
  }
  
  public static void showDepthWarning(String paramString) {
    showWarning(paramString + "() can only be used with a renderer that " + "supports 3D, such as P3D or OPENGL.");
  }
  
  public static void showDepthWarningXYZ(String paramString) {
    showWarning(paramString + "() with x, y, and z coordinates " + "can only be used with a renderer that " + "supports 3D, such as P3D or OPENGL. " + "Use a version without a z-coordinate instead.");
  }
  
  public static void showMethodWarning(String paramString) {
    showWarning(paramString + "() is not available with this renderer.");
  }
  
  public static void showVariationWarning(String paramString) {
    showWarning(paramString + " is not available with this renderer.");
  }
  
  public static void showMissingWarning(String paramString) {
    showWarning(paramString + "(), or this particular variation of it, " + "is not available with this renderer.");
  }
  
  public static void showException(String paramString) {
    throw new RuntimeException(paramString);
  }
  
  protected void defaultFontOrDeath(String paramString) {
    defaultFontOrDeath(paramString, 12.0F);
  }
  
  protected void defaultFontOrDeath(String paramString, float paramFloat) {
    if (this.parent != null) {
      this.textFont = this.parent.createDefaultFont(paramFloat);
    } else {
      throw new RuntimeException("Use textFont() before " + paramString + "()");
    } 
  }
  
  public boolean displayable() {
    return true;
  }
  
  public boolean is2D() {
    return true;
  }
  
  public boolean is3D() {
    return false;
  }
  
  protected String[] getSupportedShapeFormats() {
    showMissingWarning("getSupportedShapeFormats");
    return null;
  }
  
  protected PShape loadShape(String paramString, Object paramObject) {
    showMissingWarning("loadShape");
    return null;
  }
  
  protected PShape createShape(int paramInt, Object paramObject) {
    showMissingWarning("createShape");
    return null;
  }
  
  public void screenBlend(int paramInt) {
    showMissingWarning("screenBlend");
  }
  
  public void textureBlend(int paramInt) {
    showMissingWarning("textureBlend");
  }
  
  public PShape beginRecord() {
    showMissingWarning("beginRecord");
    return null;
  }
  
  public void endRecord() {
    showMissingWarning("endRecord");
  }
  
  public boolean isRecording() {
    showMissingWarning("isRecording");
    return false;
  }
  
  public void mergeShapes(boolean paramBoolean) {
    showMissingWarning("mergeShapes");
  }
  
  public void shapeName(String paramString) {
    showMissingWarning("shapeName");
  }
  
  public void autoNormal(boolean paramBoolean) {
    this.autoNormal = paramBoolean;
  }
  
  public void matrixMode(int paramInt) {
    showMissingWarning("matrixMode");
  }
  
  public void beginText() {
    showMissingWarning("beginText");
  }
  
  public void endText() {
    showMissingWarning("endText");
  }
  
  public void texture(PImage... paramVarArgs) {
    showMissingWarning("texture");
  }
  
  public void vertex(float... paramVarArgs) {
    showMissingWarning("vertex");
  }
  
  static {
    for (byte b = 0; b < 'ː'; b++) {
      sinLUT[b] = (float)Math.sin((b * 0.017453292F * 0.5F));
      cosLUT[b] = (float)Math.cos((b * 0.017453292F * 0.5F));
    } 
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PGraphics.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */