package processing.core;

import java.awt.Toolkit;
import java.awt.image.DirectColorModel;
import java.awt.image.MemoryImageSource;
import java.util.Arrays;

public class PGraphics3D extends PGraphics {
  public float[] zbuffer;
  
  public PMatrix3D modelview;
  
  public PMatrix3D modelviewInv;
  
  protected boolean sizeChanged;
  
  public PMatrix3D camera;
  
  protected PMatrix3D cameraInv;
  
  public float cameraFOV;
  
  public float cameraX;
  
  public float cameraY;
  
  public float cameraZ;
  
  public float cameraNear;
  
  public float cameraFar;
  
  public float cameraAspect;
  
  public PMatrix3D projection;
  
  public static final int MAX_LIGHTS = 8;
  
  public int lightCount = 0;
  
  public int[] lightType;
  
  public PVector[] lightPosition;
  
  public PVector[] lightNormal;
  
  public float[] lightFalloffConstant;
  
  public float[] lightFalloffLinear;
  
  public float[] lightFalloffQuadratic;
  
  public float[] lightSpotAngle;
  
  public float[] lightSpotAngleCos;
  
  public float[] lightSpotConcentration;
  
  public float[][] lightDiffuse;
  
  public float[][] lightSpecular;
  
  public float[] currentLightSpecular;
  
  public float currentLightFalloffConstant;
  
  public float currentLightFalloffLinear;
  
  public float currentLightFalloffQuadratic;
  
  public static final int TRI_DIFFUSE_R = 0;
  
  public static final int TRI_DIFFUSE_G = 1;
  
  public static final int TRI_DIFFUSE_B = 2;
  
  public static final int TRI_DIFFUSE_A = 3;
  
  public static final int TRI_SPECULAR_R = 4;
  
  public static final int TRI_SPECULAR_G = 5;
  
  public static final int TRI_SPECULAR_B = 6;
  
  public static final int TRI_COLOR_COUNT = 7;
  
  private boolean lightingDependsOnVertexPosition;
  
  static final int LIGHT_AMBIENT_R = 0;
  
  static final int LIGHT_AMBIENT_G = 1;
  
  static final int LIGHT_AMBIENT_B = 2;
  
  static final int LIGHT_DIFFUSE_R = 3;
  
  static final int LIGHT_DIFFUSE_G = 4;
  
  static final int LIGHT_DIFFUSE_B = 5;
  
  static final int LIGHT_SPECULAR_R = 6;
  
  static final int LIGHT_SPECULAR_G = 7;
  
  static final int LIGHT_SPECULAR_B = 8;
  
  static final int LIGHT_COLOR_COUNT = 9;
  
  protected float[] tempLightingContribution = new float[9];
  
  protected PVector lightTriangleNorm = new PVector();
  
  protected boolean manipulatingCamera;
  
  float[][] matrixStack = new float[32][16];
  
  float[][] matrixInvStack = new float[32][16];
  
  int matrixStackDepth;
  
  protected int matrixMode = 1;
  
  float[][] pmatrixStack = new float[32][16];
  
  int pmatrixStackDepth;
  
  protected PMatrix3D forwardTransform;
  
  protected PMatrix3D reverseTransform;
  
  protected float leftScreen;
  
  protected float rightScreen;
  
  protected float topScreen;
  
  protected float bottomScreen;
  
  protected float nearPlane;
  
  private boolean frustumMode = false;
  
  protected static boolean s_enableAccurateTextures = false;
  
  public PSmoothTriangle smoothTriangle;
  
  protected int shapeFirst;
  
  protected int shapeLast;
  
  protected int shapeLastPlusClipped;
  
  protected int[] vertexOrder = new int[512];
  
  protected int pathCount;
  
  protected int[] pathOffset = new int[64];
  
  protected int[] pathLength = new int[64];
  
  protected static final int VERTEX1 = 0;
  
  protected static final int VERTEX2 = 1;
  
  protected static final int VERTEX3 = 2;
  
  protected static final int STROKE_COLOR = 1;
  
  protected static final int TEXTURE_INDEX = 3;
  
  protected static final int POINT_FIELD_COUNT = 2;
  
  protected static final int LINE_FIELD_COUNT = 2;
  
  protected static final int TRIANGLE_FIELD_COUNT = 4;
  
  static final int DEFAULT_POINTS = 512;
  
  protected int[][] points = new int[512][2];
  
  protected int pointCount;
  
  static final int DEFAULT_LINES = 512;
  
  public PLine line;
  
  protected int[][] lines = new int[512][2];
  
  protected int lineCount;
  
  static final int DEFAULT_TRIANGLES = 256;
  
  public PTriangle triangle;
  
  protected int[][] triangles = new int[256][4];
  
  protected float[][][] triangleColors = new float[256][3][7];
  
  protected int triangleCount;
  
  static final int DEFAULT_TEXTURES = 3;
  
  protected PImage[] textures = new PImage[3];
  
  int textureIndex;
  
  DirectColorModel cm;
  
  MemoryImageSource mis;
  
  float[] worldNormal = new float[4];
  
  PVector lightPositionVec = new PVector();
  
  PVector lightDirectionVec = new PVector();
  
  public void setSize(int paramInt1, int paramInt2) {
    this.width = paramInt1;
    this.height = paramInt2;
    this.width1 = this.width - 1;
    this.height1 = this.height - 1;
    allocate();
    reapplySettings();
    this.lightType = new int[8];
    this.lightPosition = new PVector[8];
    this.lightNormal = new PVector[8];
    for (byte b = 0; b < 8; b++) {
      this.lightPosition[b] = new PVector();
      this.lightNormal[b] = new PVector();
    } 
    this.lightDiffuse = new float[8][3];
    this.lightSpecular = new float[8][3];
    this.lightFalloffConstant = new float[8];
    this.lightFalloffLinear = new float[8];
    this.lightFalloffQuadratic = new float[8];
    this.lightSpotAngle = new float[8];
    this.lightSpotAngleCos = new float[8];
    this.lightSpotConcentration = new float[8];
    this.currentLightSpecular = new float[3];
    this.projection = new PMatrix3D();
    this.modelview = new PMatrix3D();
    this.modelviewInv = new PMatrix3D();
    this.forwardTransform = this.modelview;
    this.reverseTransform = this.modelviewInv;
    this.cameraFOV = 1.0471976F;
    this.cameraX = this.width / 2.0F;
    this.cameraY = this.height / 2.0F;
    this.cameraZ = this.cameraY / (float)Math.tan((this.cameraFOV / 2.0F));
    this.cameraNear = this.cameraZ / 10.0F;
    this.cameraFar = this.cameraZ * 10.0F;
    this.cameraAspect = this.width / this.height;
    this.camera = new PMatrix3D();
    this.cameraInv = new PMatrix3D();
    this.sizeChanged = true;
  }
  
  protected void allocate() {
    this.pixelCount = this.width * this.height;
    this.pixels = new int[this.pixelCount];
    this.zbuffer = new float[this.pixelCount];
    if (this.primarySurface) {
      this.cm = new DirectColorModel(32, 16711680, 65280, 255);
      this.mis = new MemoryImageSource(this.width, this.height, this.pixels, 0, this.width);
      this.mis.setFullBufferUpdates(true);
      this.mis.setAnimated(true);
      this.image = Toolkit.getDefaultToolkit().createImage(this.mis);
    } else {
      Arrays.fill(this.zbuffer, Float.MAX_VALUE);
    } 
    this.line = new PLine(this);
    this.triangle = new PTriangle(this);
    this.smoothTriangle = new PSmoothTriangle(this);
  }
  
  public void beginDraw() {
    if (!this.settingsInited)
      defaultSettings(); 
    if (this.sizeChanged) {
      camera();
      perspective();
      this.sizeChanged = false;
    } 
    resetMatrix();
    this.vertexCount = 0;
    this.modelview.set(this.camera);
    this.modelviewInv.set(this.cameraInv);
    this.lightCount = 0;
    this.lightingDependsOnVertexPosition = false;
    lightFalloff(1.0F, 0.0F, 0.0F);
    lightSpecular(0.0F, 0.0F, 0.0F);
    this.shapeFirst = 0;
    Arrays.fill((Object[])this.textures, (Object)null);
    this.textureIndex = 0;
    normal(0.0F, 0.0F, 1.0F);
  }
  
  public void endDraw() {
    if (this.hints[5])
      flush(); 
    if (this.mis != null)
      this.mis.newPixels(this.pixels, this.cm, 0, this.width); 
    updatePixels();
  }
  
  protected void defaultSettings() {
    super.defaultSettings();
    this.manipulatingCamera = false;
    this.forwardTransform = this.modelview;
    this.reverseTransform = this.modelviewInv;
    camera();
    perspective();
    textureMode(2);
    emissive(0.0F);
    specular(0.5F);
    shininess(1.0F);
  }
  
  public void hint(int paramInt) {
    if (paramInt == -5) {
      flush();
    } else if (paramInt == 4 && this.zbuffer != null) {
      Arrays.fill(this.zbuffer, Float.MAX_VALUE);
    } 
    super.hint(paramInt);
  }
  
  public void beginShape(int paramInt) {
    this.shape = paramInt;
    if (this.hints[5]) {
      this.shapeFirst = this.vertexCount;
      this.shapeLast = 0;
    } else {
      this.vertexCount = 0;
      if (this.line != null)
        this.line.reset(); 
      this.lineCount = 0;
      if (this.triangle != null)
        this.triangle.reset(); 
      this.triangleCount = 0;
    } 
    this.textureImage = null;
    this.curveVertexCount = 0;
    this.normalMode = 0;
  }
  
  public void texture(PImage paramPImage) {
    this.textureImage = paramPImage;
    if (this.textureIndex == this.textures.length - 1)
      this.textures = (PImage[])PApplet.expand(this.textures); 
    if (this.textures[this.textureIndex] != null)
      this.textureIndex++; 
    this.textures[this.textureIndex] = paramPImage;
  }
  
  public void vertex(float paramFloat1, float paramFloat2) {
    vertex(paramFloat1, paramFloat2, 0.0F);
  }
  
  public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    vertex(paramFloat1, paramFloat2, 0.0F, paramFloat3, paramFloat4);
  }
  
  public void endShape(int paramInt) {
    this.shapeLast = this.vertexCount;
    this.shapeLastPlusClipped = this.shapeLast;
    if (this.vertexCount == 0) {
      this.shape = 0;
      return;
    } 
    endShapeModelToCamera(this.shapeFirst, this.shapeLast);
    if (this.stroke)
      endShapeStroke(paramInt); 
    if (this.fill || this.textureImage != null)
      endShapeFill(); 
    endShapeLighting((this.lightCount > 0 && this.fill));
    endShapeCameraToScreen(this.shapeFirst, this.shapeLastPlusClipped);
    if (!this.hints[5]) {
      if ((this.fill || this.textureImage != null) && this.triangleCount > 0) {
        renderTriangles(0, this.triangleCount);
        if (this.raw != null)
          rawTriangles(0, this.triangleCount); 
        this.triangleCount = 0;
      } 
      if (this.stroke) {
        if (this.pointCount > 0) {
          renderPoints(0, this.pointCount);
          if (this.raw != null)
            rawPoints(0, this.pointCount); 
          this.pointCount = 0;
        } 
        if (this.lineCount > 0) {
          renderLines(0, this.lineCount);
          if (this.raw != null)
            rawLines(0, this.lineCount); 
          this.lineCount = 0;
        } 
      } 
      this.pathCount = 0;
    } 
    this.shape = 0;
  }
  
  protected void endShapeModelToCamera(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt2; i++) {
      float[] arrayOfFloat = this.vertices[i];
      arrayOfFloat[21] = this.modelview.m00 * arrayOfFloat[0] + this.modelview.m01 * arrayOfFloat[1] + this.modelview.m02 * arrayOfFloat[2] + this.modelview.m03;
      arrayOfFloat[22] = this.modelview.m10 * arrayOfFloat[0] + this.modelview.m11 * arrayOfFloat[1] + this.modelview.m12 * arrayOfFloat[2] + this.modelview.m13;
      arrayOfFloat[23] = this.modelview.m20 * arrayOfFloat[0] + this.modelview.m21 * arrayOfFloat[1] + this.modelview.m22 * arrayOfFloat[2] + this.modelview.m23;
      arrayOfFloat[24] = this.modelview.m30 * arrayOfFloat[0] + this.modelview.m31 * arrayOfFloat[1] + this.modelview.m32 * arrayOfFloat[2] + this.modelview.m33;
      if (arrayOfFloat[24] != 0.0F && arrayOfFloat[24] != 1.0F) {
        arrayOfFloat[21] = arrayOfFloat[21] / arrayOfFloat[24];
        arrayOfFloat[22] = arrayOfFloat[22] / arrayOfFloat[24];
        arrayOfFloat[23] = arrayOfFloat[23] / arrayOfFloat[24];
      } 
      arrayOfFloat[24] = 1.0F;
    } 
  }
  
  protected void endShapeStroke(int paramInt) {
    int i;
    int j;
    int k;
    switch (this.shape) {
      case 2:
        i = this.shapeLast;
        for (j = this.shapeFirst; j < i; j++)
          addPoint(j); 
        break;
      case 4:
        i = this.lineCount;
        j = this.shapeLast - 1;
        if (this.shape != 4)
          addLineBreak(); 
        for (k = this.shapeFirst; k < j; k += 2) {
          if (this.shape == 4)
            addLineBreak(); 
          addLine(k, k + 1);
        } 
        if (paramInt == 2)
          addLine(j, this.lines[i][0]); 
        break;
      case 9:
        for (i = this.shapeFirst; i < this.shapeLast - 2; i += 3) {
          addLineBreak();
          addLine(i + 0, i + 1);
          addLine(i + 1, i + 2);
          addLine(i + 2, i + 0);
        } 
        break;
      case 10:
        i = this.shapeLast - 1;
        addLineBreak();
        for (j = this.shapeFirst; j < i; j++)
          addLine(j, j + 1); 
        i = this.shapeLast - 2;
        for (j = this.shapeFirst; j < i; j++) {
          addLineBreak();
          addLine(j, j + 2);
        } 
        break;
      case 11:
        for (i = this.shapeFirst + 1; i < this.shapeLast; i++) {
          addLineBreak();
          addLine(this.shapeFirst, i);
        } 
        addLineBreak();
        for (i = this.shapeFirst + 1; i < this.shapeLast - 1; i++)
          addLine(i, i + 1); 
        addLine(this.shapeLast - 1, this.shapeFirst + 1);
        break;
      case 16:
        for (i = this.shapeFirst; i < this.shapeLast; i += 4) {
          addLineBreak();
          addLine(i + 0, i + 1);
          addLine(i + 1, i + 2);
          addLine(i + 2, i + 3);
          addLine(i + 3, i + 0);
        } 
        break;
      case 17:
        for (i = this.shapeFirst; i < this.shapeLast - 3; i += 2) {
          addLineBreak();
          addLine(i + 0, i + 2);
          addLine(i + 2, i + 3);
          addLine(i + 3, i + 1);
          addLine(i + 1, i + 0);
        } 
        break;
      case 20:
        i = this.shapeLast - 1;
        addLineBreak();
        for (j = this.shapeFirst; j < i; j++)
          addLine(j, j + 1); 
        if (paramInt == 2)
          addLine(i, this.shapeFirst); 
        break;
    } 
  }
  
  protected void endShapeFill() {
    int i;
    int j;
    switch (this.shape) {
      case 11:
        i = this.shapeLast - 1;
        for (j = this.shapeFirst + 1; j < i; j++)
          addTriangle(this.shapeFirst, j, j + 1); 
        break;
      case 9:
        i = this.shapeLast - 2;
        for (j = this.shapeFirst; j < i; j += 3) {
          if (j % 2 == 0) {
            addTriangle(j, j + 2, j + 1);
          } else {
            addTriangle(j, j + 1, j + 2);
          } 
        } 
        break;
      case 10:
        i = this.shapeLast - 2;
        for (j = this.shapeFirst; j < i; j++) {
          if (j % 2 == 0) {
            addTriangle(j, j + 2, j + 1);
          } else {
            addTriangle(j, j + 1, j + 2);
          } 
        } 
        break;
      case 16:
        i = this.vertexCount - 3;
        for (j = this.shapeFirst; j < i; j += 4) {
          addTriangle(j, j + 1, j + 2);
          addTriangle(j, j + 2, j + 3);
        } 
        break;
      case 17:
        i = this.vertexCount - 3;
        for (j = this.shapeFirst; j < i; j += 2) {
          addTriangle(j + 0, j + 2, j + 1);
          addTriangle(j + 2, j + 3, j + 1);
        } 
        break;
      case 20:
        addPolygonTriangles();
        break;
    } 
  }
  
  protected void endShapeLighting(boolean paramBoolean) {
    if (paramBoolean) {
      if (!this.lightingDependsOnVertexPosition && this.normalMode == 1) {
        calcLightingContribution(this.shapeFirst, this.tempLightingContribution);
        for (byte b = 0; b < this.triangleCount; b++)
          lightTriangle(b, this.tempLightingContribution); 
      } else {
        for (byte b = 0; b < this.triangleCount; b++)
          lightTriangle(b); 
      } 
    } else {
      for (byte b = 0; b < this.triangleCount; b++) {
        int i = this.triangles[b][0];
        copyPrelitVertexColor(b, i, 0);
        i = this.triangles[b][1];
        copyPrelitVertexColor(b, i, 1);
        i = this.triangles[b][2];
        copyPrelitVertexColor(b, i, 2);
      } 
    } 
  }
  
  protected void endShapeCameraToScreen(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt2; i++) {
      float[] arrayOfFloat = this.vertices[i];
      float f1 = this.projection.m00 * arrayOfFloat[21] + this.projection.m01 * arrayOfFloat[22] + this.projection.m02 * arrayOfFloat[23] + this.projection.m03 * arrayOfFloat[24];
      float f2 = this.projection.m10 * arrayOfFloat[21] + this.projection.m11 * arrayOfFloat[22] + this.projection.m12 * arrayOfFloat[23] + this.projection.m13 * arrayOfFloat[24];
      float f3 = this.projection.m20 * arrayOfFloat[21] + this.projection.m21 * arrayOfFloat[22] + this.projection.m22 * arrayOfFloat[23] + this.projection.m23 * arrayOfFloat[24];
      float f4 = this.projection.m30 * arrayOfFloat[21] + this.projection.m31 * arrayOfFloat[22] + this.projection.m32 * arrayOfFloat[23] + this.projection.m33 * arrayOfFloat[24];
      if (f4 != 0.0F && f4 != 1.0F) {
        f1 /= f4;
        f2 /= f4;
        f3 /= f4;
      } 
      arrayOfFloat[18] = this.width * (1.0F + f1) / 2.0F;
      arrayOfFloat[19] = this.height * (1.0F + f2) / 2.0F;
      arrayOfFloat[20] = (f3 + 1.0F) / 2.0F;
    } 
  }
  
  protected void addPoint(int paramInt) {
    if (this.pointCount == this.points.length) {
      int[][] arrayOfInt = new int[this.pointCount << 1][2];
      System.arraycopy(this.points, 0, arrayOfInt, 0, this.pointCount);
      this.points = arrayOfInt;
    } 
    this.points[this.pointCount][0] = paramInt;
    this.points[this.pointCount][1] = this.strokeColor;
    this.pointCount++;
  }
  
  protected void renderPoints(int paramInt1, int paramInt2) {
    if (this.strokeWeight != 1.0F) {
      for (int i = paramInt1; i < paramInt2; i++) {
        float[] arrayOfFloat = this.vertices[this.points[i][0]];
        renderLineVertices(arrayOfFloat, arrayOfFloat);
      } 
    } else {
      for (int i = paramInt1; i < paramInt2; i++) {
        float[] arrayOfFloat = this.vertices[this.points[i][0]];
        int j = (int)(arrayOfFloat[18] + 0.4999F);
        int k = (int)(arrayOfFloat[19] + 0.4999F);
        if (j >= 0 && j < this.width && k >= 0 && k < this.height) {
          int m = k * this.width + j;
          this.pixels[m] = this.points[i][1];
          this.zbuffer[m] = arrayOfFloat[20];
        } 
      } 
    } 
  }
  
  protected void rawPoints(int paramInt1, int paramInt2) {
    this.raw.colorMode(1, 1.0F);
    this.raw.noFill();
    this.raw.strokeWeight(this.vertices[this.lines[paramInt1][0]][17]);
    this.raw.beginShape(2);
    for (int i = paramInt1; i < paramInt2; i++) {
      float[] arrayOfFloat = this.vertices[this.lines[i][0]];
      if (this.raw.is3D()) {
        if (arrayOfFloat[24] != 0.0F) {
          this.raw.stroke(arrayOfFloat[13], arrayOfFloat[14], arrayOfFloat[15], arrayOfFloat[16]);
          this.raw.vertex(arrayOfFloat[21] / arrayOfFloat[24], arrayOfFloat[22] / arrayOfFloat[24], arrayOfFloat[23] / arrayOfFloat[24]);
        } 
      } else {
        this.raw.stroke(arrayOfFloat[13], arrayOfFloat[14], arrayOfFloat[15], arrayOfFloat[16]);
        this.raw.vertex(arrayOfFloat[18], arrayOfFloat[19]);
      } 
    } 
    this.raw.endShape();
  }
  
  protected final void addLineBreak() {
    if (this.pathCount == this.pathOffset.length) {
      this.pathOffset = PApplet.expand(this.pathOffset);
      this.pathLength = PApplet.expand(this.pathLength);
    } 
    this.pathOffset[this.pathCount] = this.lineCount;
    this.pathLength[this.pathCount] = 0;
    this.pathCount++;
  }
  
  protected void addLine(int paramInt1, int paramInt2) {
    addLineWithClip(paramInt1, paramInt2);
  }
  
  protected final void addLineWithClip(int paramInt1, int paramInt2) {
    float f1 = this.vertices[paramInt1][23];
    float f2 = this.vertices[paramInt2][23];
    if (f1 > this.cameraNear) {
      if (f2 > this.cameraNear)
        return; 
      int j = interpolateClipVertex(paramInt1, paramInt2);
      addLineWithoutClip(j, paramInt2);
      return;
    } 
    if (f2 <= this.cameraNear) {
      addLineWithoutClip(paramInt1, paramInt2);
      return;
    } 
    int i = interpolateClipVertex(paramInt1, paramInt2);
    addLineWithoutClip(paramInt1, i);
  }
  
  protected final void addLineWithoutClip(int paramInt1, int paramInt2) {
    if (this.lineCount == this.lines.length) {
      int[][] arrayOfInt = new int[this.lineCount << 1][2];
      System.arraycopy(this.lines, 0, arrayOfInt, 0, this.lineCount);
      this.lines = arrayOfInt;
    } 
    this.lines[this.lineCount][0] = paramInt1;
    this.lines[this.lineCount][1] = paramInt2;
    this.lineCount++;
    this.pathLength[this.pathCount - 1] = this.pathLength[this.pathCount - 1] + 1;
  }
  
  protected void renderLines(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt2; i++)
      renderLineVertices(this.vertices[this.lines[i][0]], this.vertices[this.lines[i][1]]); 
  }
  
  protected void renderLineVertices(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
    if (paramArrayOffloat1[17] > 1.25F || paramArrayOffloat1[17] < 0.75F) {
      float f1 = paramArrayOffloat1[18];
      float f2 = paramArrayOffloat1[19];
      float f3 = paramArrayOffloat2[18];
      float f4 = paramArrayOffloat2[19];
      float f5 = paramArrayOffloat1[17] / 2.0F;
      if (f1 == f3 && f2 == f4) {
        f2 -= f5;
        f4 += f5;
      } 
      float f6 = f3 - f1 + 1.0E-4F;
      float f7 = f4 - f2 + 1.0E-4F;
      float f8 = (float)Math.sqrt((f6 * f6 + f7 * f7));
      float f9 = f5 / f8;
      float f10 = f9 * f7;
      float f11 = f9 * f6;
      float f12 = f9 * f7;
      float f13 = f9 * f6;
      float f14 = f1 + f10;
      float f15 = f2 - f11;
      float f16 = f1 - f10;
      float f17 = f2 + f11;
      float f18 = f3 + f12;
      float f19 = f4 - f13;
      float f20 = f3 - f12;
      float f21 = f4 + f13;
      if (this.smooth) {
        this.smoothTriangle.reset(3);
        this.smoothTriangle.smooth = true;
        this.smoothTriangle.interpARGB = true;
        this.smoothTriangle.setVertices(f14, f15, paramArrayOffloat1[20], f20, f21, paramArrayOffloat2[20], f16, f17, paramArrayOffloat1[20]);
        this.smoothTriangle.setIntensities(paramArrayOffloat1[13], paramArrayOffloat1[14], paramArrayOffloat1[15], paramArrayOffloat1[16], paramArrayOffloat2[13], paramArrayOffloat2[14], paramArrayOffloat2[15], paramArrayOffloat2[16], paramArrayOffloat1[13], paramArrayOffloat1[14], paramArrayOffloat1[15], paramArrayOffloat1[16]);
        this.smoothTriangle.render();
        this.smoothTriangle.setVertices(f14, f15, paramArrayOffloat1[20], f20, f21, paramArrayOffloat2[20], f18, f19, paramArrayOffloat2[20]);
        this.smoothTriangle.setIntensities(paramArrayOffloat1[13], paramArrayOffloat1[14], paramArrayOffloat1[15], paramArrayOffloat1[16], paramArrayOffloat2[13], paramArrayOffloat2[14], paramArrayOffloat2[15], paramArrayOffloat2[16], paramArrayOffloat2[13], paramArrayOffloat2[14], paramArrayOffloat2[15], paramArrayOffloat2[16]);
        this.smoothTriangle.render();
      } else {
        this.triangle.reset();
        this.triangle.setVertices(f14, f15, paramArrayOffloat1[20], f20, f21, paramArrayOffloat2[20], f16, f17, paramArrayOffloat1[20]);
        this.triangle.setIntensities(paramArrayOffloat1[13], paramArrayOffloat1[14], paramArrayOffloat1[15], paramArrayOffloat1[16], paramArrayOffloat2[13], paramArrayOffloat2[14], paramArrayOffloat2[15], paramArrayOffloat2[16], paramArrayOffloat1[13], paramArrayOffloat1[14], paramArrayOffloat1[15], paramArrayOffloat1[16]);
        this.triangle.render();
        this.triangle.setVertices(f14, f15, paramArrayOffloat1[20], f20, f21, paramArrayOffloat2[20], f18, f19, paramArrayOffloat2[20]);
        this.triangle.setIntensities(paramArrayOffloat1[13], paramArrayOffloat1[14], paramArrayOffloat1[15], paramArrayOffloat1[16], paramArrayOffloat2[13], paramArrayOffloat2[14], paramArrayOffloat2[15], paramArrayOffloat2[16], paramArrayOffloat2[13], paramArrayOffloat2[14], paramArrayOffloat2[15], paramArrayOffloat2[16]);
        this.triangle.render();
      } 
    } else {
      this.line.reset();
      this.line.setIntensities(paramArrayOffloat1[13], paramArrayOffloat1[14], paramArrayOffloat1[15], paramArrayOffloat1[16], paramArrayOffloat2[13], paramArrayOffloat2[14], paramArrayOffloat2[15], paramArrayOffloat2[16]);
      this.line.setVertices(paramArrayOffloat1[18], paramArrayOffloat1[19], paramArrayOffloat1[20], paramArrayOffloat2[18], paramArrayOffloat2[19], paramArrayOffloat2[20]);
      this.line.draw();
    } 
  }
  
  protected void rawLines(int paramInt1, int paramInt2) {
    this.raw.colorMode(1, 1.0F);
    this.raw.noFill();
    this.raw.beginShape(4);
    for (int i = paramInt1; i < paramInt2; i++) {
      float[] arrayOfFloat1 = this.vertices[this.lines[i][0]];
      float[] arrayOfFloat2 = this.vertices[this.lines[i][1]];
      this.raw.strokeWeight(this.vertices[this.lines[i][1]][17]);
      if (this.raw.is3D()) {
        if (arrayOfFloat1[24] != 0.0F && arrayOfFloat2[24] != 0.0F) {
          this.raw.stroke(arrayOfFloat1[13], arrayOfFloat1[14], arrayOfFloat1[15], arrayOfFloat1[16]);
          this.raw.vertex(arrayOfFloat1[21] / arrayOfFloat1[24], arrayOfFloat1[22] / arrayOfFloat1[24], arrayOfFloat1[23] / arrayOfFloat1[24]);
          this.raw.stroke(arrayOfFloat2[13], arrayOfFloat2[14], arrayOfFloat2[15], arrayOfFloat2[16]);
          this.raw.vertex(arrayOfFloat2[21] / arrayOfFloat2[24], arrayOfFloat2[22] / arrayOfFloat2[24], arrayOfFloat2[23] / arrayOfFloat2[24]);
        } 
      } else if (this.raw.is2D()) {
        this.raw.stroke(arrayOfFloat1[13], arrayOfFloat1[14], arrayOfFloat1[15], arrayOfFloat1[16]);
        this.raw.vertex(arrayOfFloat1[18], arrayOfFloat1[19]);
        this.raw.stroke(arrayOfFloat2[13], arrayOfFloat2[14], arrayOfFloat2[15], arrayOfFloat2[16]);
        this.raw.vertex(arrayOfFloat2[18], arrayOfFloat2[19]);
      } 
    } 
    this.raw.endShape();
  }
  
  protected void addTriangle(int paramInt1, int paramInt2, int paramInt3) {
    addTriangleWithClip(paramInt1, paramInt2, paramInt3);
  }
  
  protected final void addTriangleWithClip(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool1 = false;
    boolean bool2 = false;
    byte b = 0;
    this.cameraNear = -8.0F;
    if (this.vertices[paramInt1][23] > this.cameraNear) {
      bool1 = true;
      b++;
    } 
    if (this.vertices[paramInt2][23] > this.cameraNear) {
      bool2 = true;
      b++;
    } 
    if (this.vertices[paramInt3][23] > this.cameraNear)
      b++; 
    if (b == 0) {
      addTriangleWithoutClip(paramInt1, paramInt2, paramInt3);
    } else if (b != 3) {
      if (b == 2) {
        int i;
        int j;
        int k;
        if (!bool1) {
          i = paramInt1;
          j = paramInt2;
          k = paramInt3;
        } else if (!bool2) {
          i = paramInt2;
          j = paramInt1;
          k = paramInt3;
        } else {
          i = paramInt3;
          j = paramInt2;
          k = paramInt1;
        } 
        int m = interpolateClipVertex(i, j);
        int n = interpolateClipVertex(i, k);
        addTriangleWithoutClip(i, m, n);
      } else {
        int i;
        int j;
        int k;
        if (bool1) {
          i = paramInt3;
          j = paramInt2;
          k = paramInt1;
        } else if (bool2) {
          i = paramInt1;
          j = paramInt3;
          k = paramInt2;
        } else {
          i = paramInt1;
          j = paramInt2;
          k = paramInt3;
        } 
        int m = interpolateClipVertex(i, k);
        int n = interpolateClipVertex(j, k);
        addTriangleWithoutClip(i, m, j);
        addTriangleWithoutClip(j, m, n);
      } 
    } 
  }
  
  protected final int interpolateClipVertex(int paramInt1, int paramInt2) {
    float[] arrayOfFloat1;
    float[] arrayOfFloat2;
    if (this.vertices[paramInt1][23] < this.vertices[paramInt2][23]) {
      arrayOfFloat1 = this.vertices[paramInt2];
      arrayOfFloat2 = this.vertices[paramInt1];
    } else {
      arrayOfFloat1 = this.vertices[paramInt1];
      arrayOfFloat2 = this.vertices[paramInt2];
    } 
    float f1 = arrayOfFloat1[23];
    float f2 = arrayOfFloat2[23];
    float f3 = f1 - f2;
    if (f3 == 0.0F)
      return paramInt1; 
    float f4 = (this.cameraNear - f2) / f3;
    float f5 = 1.0F - f4;
    vertex(f4 * arrayOfFloat1[0] + f5 * arrayOfFloat2[0], f4 * arrayOfFloat1[1] + f5 * arrayOfFloat2[1], f4 * arrayOfFloat1[2] + f5 * arrayOfFloat2[2]);
    int i = this.vertexCount - 1;
    this.shapeLastPlusClipped++;
    float[] arrayOfFloat3 = this.vertices[i];
    arrayOfFloat3[18] = f4 * arrayOfFloat1[18] + f5 * arrayOfFloat2[18];
    arrayOfFloat3[19] = f4 * arrayOfFloat1[19] + f5 * arrayOfFloat2[19];
    arrayOfFloat3[20] = f4 * arrayOfFloat1[20] + f5 * arrayOfFloat2[20];
    arrayOfFloat3[21] = f4 * arrayOfFloat1[21] + f5 * arrayOfFloat2[21];
    arrayOfFloat3[22] = f4 * arrayOfFloat1[22] + f5 * arrayOfFloat2[22];
    arrayOfFloat3[23] = f4 * arrayOfFloat1[23] + f5 * arrayOfFloat2[23];
    arrayOfFloat3[24] = f4 * arrayOfFloat1[24] + f5 * arrayOfFloat2[24];
    arrayOfFloat3[3] = f4 * arrayOfFloat1[3] + f5 * arrayOfFloat2[3];
    arrayOfFloat3[4] = f4 * arrayOfFloat1[4] + f5 * arrayOfFloat2[4];
    arrayOfFloat3[5] = f4 * arrayOfFloat1[5] + f5 * arrayOfFloat2[5];
    arrayOfFloat3[6] = f4 * arrayOfFloat1[6] + f5 * arrayOfFloat2[6];
    arrayOfFloat3[7] = f4 * arrayOfFloat1[7] + f5 * arrayOfFloat2[7];
    arrayOfFloat3[8] = f4 * arrayOfFloat1[8] + f5 * arrayOfFloat2[8];
    arrayOfFloat3[13] = f4 * arrayOfFloat1[13] + f5 * arrayOfFloat2[13];
    arrayOfFloat3[14] = f4 * arrayOfFloat1[14] + f5 * arrayOfFloat2[14];
    arrayOfFloat3[15] = f4 * arrayOfFloat1[15] + f5 * arrayOfFloat2[15];
    arrayOfFloat3[16] = f4 * arrayOfFloat1[16] + f5 * arrayOfFloat2[16];
    arrayOfFloat3[9] = f4 * arrayOfFloat1[9] + f5 * arrayOfFloat2[9];
    arrayOfFloat3[10] = f4 * arrayOfFloat1[10] + f5 * arrayOfFloat2[10];
    arrayOfFloat3[11] = f4 * arrayOfFloat1[11] + f5 * arrayOfFloat2[11];
    arrayOfFloat3[25] = f4 * arrayOfFloat1[25] + f5 * arrayOfFloat2[25];
    arrayOfFloat3[26] = f4 * arrayOfFloat1[26] + f5 * arrayOfFloat2[26];
    arrayOfFloat3[27] = f4 * arrayOfFloat1[27] + f5 * arrayOfFloat2[27];
    arrayOfFloat3[28] = f4 * arrayOfFloat1[28] + f5 * arrayOfFloat2[28];
    arrayOfFloat3[29] = f4 * arrayOfFloat1[29] + f5 * arrayOfFloat2[29];
    arrayOfFloat3[30] = f4 * arrayOfFloat1[30] + f5 * arrayOfFloat2[30];
    arrayOfFloat3[32] = f4 * arrayOfFloat1[32] + f5 * arrayOfFloat2[32];
    arrayOfFloat3[33] = f4 * arrayOfFloat1[33] + f5 * arrayOfFloat2[33];
    arrayOfFloat3[34] = f4 * arrayOfFloat1[34] + f5 * arrayOfFloat2[34];
    arrayOfFloat3[31] = f4 * arrayOfFloat1[31] + f5 * arrayOfFloat2[31];
    arrayOfFloat3[35] = 0.0F;
    return i;
  }
  
  protected final void addTriangleWithoutClip(int paramInt1, int paramInt2, int paramInt3) {
    if (this.triangleCount == this.triangles.length) {
      int[][] arrayOfInt = new int[this.triangleCount << 1][4];
      System.arraycopy(this.triangles, 0, arrayOfInt, 0, this.triangleCount);
      this.triangles = arrayOfInt;
      float[][][] arrayOfFloat = new float[this.triangleCount << 1][3][7];
      System.arraycopy(this.triangleColors, 0, arrayOfFloat, 0, this.triangleCount);
      this.triangleColors = arrayOfFloat;
    } 
    this.triangles[this.triangleCount][0] = paramInt1;
    this.triangles[this.triangleCount][1] = paramInt2;
    this.triangles[this.triangleCount][2] = paramInt3;
    if (this.textureImage == null) {
      this.triangles[this.triangleCount][3] = -1;
    } else {
      this.triangles[this.triangleCount][3] = this.textureIndex;
    } 
    this.triangleCount++;
  }
  
  protected void addPolygonTriangles() {
    if (this.vertexOrder.length != this.vertices.length) {
      int[] arrayOfInt = new int[this.vertices.length];
      PApplet.arrayCopy(this.vertexOrder, arrayOfInt, this.vertexOrder.length);
      this.vertexOrder = arrayOfInt;
    } 
    boolean bool = false;
    byte b1 = 1;
    float f = 0.0F;
    int i = this.shapeLast - 1;
    int j = this.shapeFirst;
    while (j < this.shapeLast) {
      f += this.vertices[j][bool] * this.vertices[i][b1] - this.vertices[i][bool] * this.vertices[j][b1];
      i = j++;
    } 
    if (f == 0.0F) {
      i = 0;
      j = 0;
      int i2;
      for (i2 = this.shapeFirst; i2 < this.shapeLast; i2++) {
        for (int i4 = i2; i4 < this.shapeLast; i4++) {
          if (this.vertices[i2][0] != this.vertices[i4][0])
            i = 1; 
          if (this.vertices[i2][1] != this.vertices[i4][1])
            j = 1; 
        } 
      } 
      if (i != 0) {
        b1 = 2;
      } else if (j != 0) {
        bool = true;
        b1 = 2;
      } else {
        return;
      } 
      i2 = this.shapeLast - 1;
      int i3 = this.shapeFirst;
      while (i3 < this.shapeLast) {
        f += this.vertices[i3][bool] * this.vertices[i2][b1] - this.vertices[i2][bool] * this.vertices[i3][b1];
        i2 = i3++;
      } 
    } 
    float[] arrayOfFloat1 = this.vertices[this.shapeFirst];
    float[] arrayOfFloat2 = this.vertices[this.shapeLast - 1];
    if (abs(arrayOfFloat1[0] - arrayOfFloat2[0]) < 1.0E-4F && abs(arrayOfFloat1[1] - arrayOfFloat2[1]) < 1.0E-4F && abs(arrayOfFloat1[2] - arrayOfFloat2[2]) < 1.0E-4F)
      this.shapeLast--; 
    int k = 0;
    if (f > 0.0F) {
      for (int i2 = this.shapeFirst; i2 < this.shapeLast; i2++) {
        k = i2 - this.shapeFirst;
        this.vertexOrder[k] = i2;
      } 
    } else {
      for (int i2 = this.shapeFirst; i2 < this.shapeLast; i2++) {
        k = i2 - this.shapeFirst;
        this.vertexOrder[k] = this.shapeLast - 1 - k;
      } 
    } 
    int m = this.shapeLast - this.shapeFirst;
    int n = 2 * m;
    byte b2 = 0;
    int i1 = m - 1;
    while (m > 2) {
      boolean bool1 = true;
      if (0 >= n--)
        break; 
      int i2 = i1;
      if (m <= i2)
        i2 = 0; 
      i1 = i2 + 1;
      if (m <= i1)
        i1 = 0; 
      int i3 = i1 + 1;
      if (m <= i3)
        i3 = 0; 
      double d1 = (-10.0F * this.vertices[this.vertexOrder[i2]][bool]);
      double d2 = (10.0F * this.vertices[this.vertexOrder[i2]][b1]);
      double d3 = (-10.0F * this.vertices[this.vertexOrder[i1]][bool]);
      double d4 = (10.0F * this.vertices[this.vertexOrder[i1]][b1]);
      double d5 = (-10.0F * this.vertices[this.vertexOrder[i3]][bool]);
      double d6 = (10.0F * this.vertices[this.vertexOrder[i3]][b1]);
      if (9.999999747378752E-5D > (d3 - d1) * (d6 - d2) - (d4 - d2) * (d5 - d1))
        continue; 
      int i4;
      for (i4 = 0; i4 < m; i4++) {
        if (i4 != i2 && i4 != i1 && i4 != i3) {
          double d7 = (-10.0F * this.vertices[this.vertexOrder[i4]][bool]);
          double d8 = (10.0F * this.vertices[this.vertexOrder[i4]][b1]);
          double d9 = d5 - d3;
          double d10 = d6 - d4;
          double d11 = d1 - d5;
          double d12 = d2 - d6;
          double d13 = d3 - d1;
          double d14 = d4 - d2;
          double d15 = d7 - d1;
          double d16 = d8 - d2;
          double d17 = d7 - d3;
          double d18 = d8 - d4;
          double d19 = d7 - d5;
          double d20 = d8 - d6;
          double d21 = d9 * d18 - d10 * d17;
          double d22 = d13 * d16 - d14 * d15;
          double d23 = d11 * d20 - d12 * d19;
          if (d21 >= 0.0D && d23 >= 0.0D && d22 >= 0.0D)
            bool1 = false; 
        } 
      } 
      if (bool1) {
        addTriangle(this.vertexOrder[i2], this.vertexOrder[i1], this.vertexOrder[i3]);
        b2++;
        i4 = i1;
        for (int i5 = i1 + 1; i5 < m; i5++) {
          this.vertexOrder[i4] = this.vertexOrder[i5];
          i4++;
        } 
        n = 2 * --m;
      } 
    } 
  }
  
  private void toWorldNormal(float paramFloat1, float paramFloat2, float paramFloat3, float[] paramArrayOffloat) {
    paramArrayOffloat[0] = this.modelviewInv.m00 * paramFloat1 + this.modelviewInv.m10 * paramFloat2 + this.modelviewInv.m20 * paramFloat3 + this.modelviewInv.m30;
    paramArrayOffloat[1] = this.modelviewInv.m01 * paramFloat1 + this.modelviewInv.m11 * paramFloat2 + this.modelviewInv.m21 * paramFloat3 + this.modelviewInv.m31;
    paramArrayOffloat[2] = this.modelviewInv.m02 * paramFloat1 + this.modelviewInv.m12 * paramFloat2 + this.modelviewInv.m22 * paramFloat3 + this.modelviewInv.m32;
    paramArrayOffloat[3] = this.modelviewInv.m03 * paramFloat1 + this.modelviewInv.m13 * paramFloat2 + this.modelviewInv.m23 * paramFloat3 + this.modelviewInv.m33;
    if (paramArrayOffloat[3] != 0.0F && paramArrayOffloat[3] != 1.0F) {
      paramArrayOffloat[0] = paramArrayOffloat[0] / paramArrayOffloat[3];
      paramArrayOffloat[1] = paramArrayOffloat[1] / paramArrayOffloat[3];
      paramArrayOffloat[2] = paramArrayOffloat[2] / paramArrayOffloat[3];
    } 
    paramArrayOffloat[3] = 1.0F;
    float f = mag(paramArrayOffloat[0], paramArrayOffloat[1], paramArrayOffloat[2]);
    if (f != 0.0F && f != 1.0F) {
      paramArrayOffloat[0] = paramArrayOffloat[0] / f;
      paramArrayOffloat[1] = paramArrayOffloat[1] / f;
      paramArrayOffloat[2] = paramArrayOffloat[2] / f;
    } 
  }
  
  private void calcLightingContribution(int paramInt, float[] paramArrayOffloat) {
    calcLightingContribution(paramInt, paramArrayOffloat, false);
  }
  
  private void calcLightingContribution(int paramInt, float[] paramArrayOffloat, boolean paramBoolean) {
    float[] arrayOfFloat = this.vertices[paramInt];
    float f1 = arrayOfFloat[28];
    float f2 = arrayOfFloat[29];
    float f3 = arrayOfFloat[30];
    float f4 = arrayOfFloat[21];
    float f5 = arrayOfFloat[22];
    float f6 = arrayOfFloat[23];
    float f7 = arrayOfFloat[31];
    float f8 = arrayOfFloat[9];
    float f9 = arrayOfFloat[10];
    float f10 = arrayOfFloat[11];
    if (!paramBoolean) {
      toWorldNormal(arrayOfFloat[9], arrayOfFloat[10], arrayOfFloat[11], this.worldNormal);
      f8 = this.worldNormal[0];
      f9 = this.worldNormal[1];
      f10 = this.worldNormal[2];
    } else {
      f8 = arrayOfFloat[9];
      f9 = arrayOfFloat[10];
      f10 = arrayOfFloat[11];
    } 
    float f11 = dot(f8, f9, f10, -f4, -f5, -f6);
    if (f11 < 0.0F) {
      f8 = -f8;
      f9 = -f9;
      f10 = -f10;
    } 
    paramArrayOffloat[0] = 0.0F;
    paramArrayOffloat[1] = 0.0F;
    paramArrayOffloat[2] = 0.0F;
    paramArrayOffloat[3] = 0.0F;
    paramArrayOffloat[4] = 0.0F;
    paramArrayOffloat[5] = 0.0F;
    paramArrayOffloat[6] = 0.0F;
    paramArrayOffloat[7] = 0.0F;
    paramArrayOffloat[8] = 0.0F;
    for (byte b = 0; b < this.lightCount; b++) {
      float f14;
      float f15;
      float f16;
      float f12 = this.lightFalloffConstant[b];
      float f13 = 1.0F;
      if (this.lightType[b] == 0) {
        if (this.lightFalloffQuadratic[b] != 0.0F || this.lightFalloffLinear[b] != 0.0F) {
          f14 = mag((this.lightPosition[b]).x - f4, (this.lightPosition[b]).y - f5, (this.lightPosition[b]).z - f6);
          f12 += this.lightFalloffQuadratic[b] * f14 + this.lightFalloffLinear[b] * sqrt(f14);
        } 
        if (f12 == 0.0F)
          f12 = 1.0F; 
        paramArrayOffloat[0] = paramArrayOffloat[0] + this.lightDiffuse[b][0] / f12;
        paramArrayOffloat[1] = paramArrayOffloat[1] + this.lightDiffuse[b][1] / f12;
        paramArrayOffloat[2] = paramArrayOffloat[2] + this.lightDiffuse[b][2] / f12;
        continue;
      } 
      float f17 = 0.0F;
      float f18 = 0.0F;
      if (this.lightType[b] == 1) {
        f14 = -(this.lightNormal[b]).x;
        f15 = -(this.lightNormal[b]).y;
        f16 = -(this.lightNormal[b]).z;
        f12 = 1.0F;
        f18 = f8 * f14 + f9 * f15 + f10 * f16;
        if (f18 <= 0.0F)
          continue; 
      } else {
        f14 = (this.lightPosition[b]).x - f4;
        f15 = (this.lightPosition[b]).y - f5;
        f16 = (this.lightPosition[b]).z - f6;
        float f = mag(f14, f15, f16);
        if (f != 0.0F) {
          f14 /= f;
          f15 /= f;
          f16 /= f;
        } 
        f18 = f8 * f14 + f9 * f15 + f10 * f16;
        if (f18 <= 0.0F)
          continue; 
        if (this.lightType[b] == 3) {
          f17 = -((this.lightNormal[b]).x * f14 + (this.lightNormal[b]).y * f15 + (this.lightNormal[b]).z * f16);
          if (f17 <= this.lightSpotAngleCos[b])
            continue; 
          f13 = (float)Math.pow(f17, this.lightSpotConcentration[b]);
        } 
        if (this.lightFalloffQuadratic[b] != 0.0F || this.lightFalloffLinear[b] != 0.0F)
          f12 += this.lightFalloffQuadratic[b] * f + this.lightFalloffLinear[b] * sqrt(f); 
      } 
      if (f12 == 0.0F)
        f12 = 1.0F; 
      float f19 = f18 * f13 / f12;
      paramArrayOffloat[3] = paramArrayOffloat[3] + this.lightDiffuse[b][0] * f19;
      paramArrayOffloat[4] = paramArrayOffloat[4] + this.lightDiffuse[b][1] * f19;
      paramArrayOffloat[5] = paramArrayOffloat[5] + this.lightDiffuse[b][2] * f19;
      if ((f1 > 0.0F || f2 > 0.0F || f3 > 0.0F) && (this.lightSpecular[b][0] > 0.0F || this.lightSpecular[b][1] > 0.0F || this.lightSpecular[b][2] > 0.0F)) {
        float f20 = mag(f4, f5, f6);
        if (f20 != 0.0F) {
          f4 /= f20;
          f5 /= f20;
          f6 /= f20;
        } 
        float f21 = f14 - f4;
        float f22 = f15 - f5;
        float f23 = f16 - f6;
        f20 = mag(f21, f22, f23);
        if (f20 != 0.0F) {
          f21 /= f20;
          f22 /= f20;
          f23 /= f20;
        } 
        float f24 = f21 * f8 + f22 * f9 + f23 * f10;
        if (f24 > 0.0F) {
          f24 = (float)Math.pow(f24, f7);
          f19 = f24 * f13 / f12;
          paramArrayOffloat[6] = paramArrayOffloat[6] + this.lightSpecular[b][0] * f19;
          paramArrayOffloat[7] = paramArrayOffloat[7] + this.lightSpecular[b][1] * f19;
          paramArrayOffloat[8] = paramArrayOffloat[8] + this.lightSpecular[b][2] * f19;
        } 
      } 
      continue;
    } 
  }
  
  private void applyLightingContribution(int paramInt, float[] paramArrayOffloat) {
    float[] arrayOfFloat = this.vertices[paramInt];
    arrayOfFloat[3] = clamp(arrayOfFloat[32] + arrayOfFloat[25] * paramArrayOffloat[0] + arrayOfFloat[3] * paramArrayOffloat[3]);
    arrayOfFloat[4] = clamp(arrayOfFloat[33] + arrayOfFloat[26] * paramArrayOffloat[1] + arrayOfFloat[4] * paramArrayOffloat[4]);
    arrayOfFloat[5] = clamp(arrayOfFloat[34] + arrayOfFloat[27] * paramArrayOffloat[2] + arrayOfFloat[5] * paramArrayOffloat[5]);
    arrayOfFloat[6] = clamp(arrayOfFloat[6]);
    arrayOfFloat[28] = clamp(arrayOfFloat[28] * paramArrayOffloat[6]);
    arrayOfFloat[29] = clamp(arrayOfFloat[29] * paramArrayOffloat[7]);
    arrayOfFloat[30] = clamp(arrayOfFloat[30] * paramArrayOffloat[8]);
    arrayOfFloat[35] = 1.0F;
  }
  
  private void lightVertex(int paramInt, float[] paramArrayOffloat) {
    calcLightingContribution(paramInt, paramArrayOffloat);
    applyLightingContribution(paramInt, paramArrayOffloat);
  }
  
  private void lightUnlitVertex(int paramInt, float[] paramArrayOffloat) {
    if (this.vertices[paramInt][35] == 0.0F)
      lightVertex(paramInt, paramArrayOffloat); 
  }
  
  private void copyPrelitVertexColor(int paramInt1, int paramInt2, int paramInt3) {
    float[] arrayOfFloat1 = this.triangleColors[paramInt1][paramInt3];
    float[] arrayOfFloat2 = this.vertices[paramInt2];
    arrayOfFloat1[0] = arrayOfFloat2[3];
    arrayOfFloat1[1] = arrayOfFloat2[4];
    arrayOfFloat1[2] = arrayOfFloat2[5];
    arrayOfFloat1[3] = arrayOfFloat2[6];
    arrayOfFloat1[4] = arrayOfFloat2[28];
    arrayOfFloat1[5] = arrayOfFloat2[29];
    arrayOfFloat1[6] = arrayOfFloat2[30];
  }
  
  private void copyVertexColor(int paramInt1, int paramInt2, int paramInt3, float[] paramArrayOffloat) {
    float[] arrayOfFloat1 = this.triangleColors[paramInt1][paramInt3];
    float[] arrayOfFloat2 = this.vertices[paramInt2];
    arrayOfFloat1[0] = clamp(arrayOfFloat2[32] + arrayOfFloat2[25] * paramArrayOffloat[0] + arrayOfFloat2[3] * paramArrayOffloat[3]);
    arrayOfFloat1[1] = clamp(arrayOfFloat2[33] + arrayOfFloat2[26] * paramArrayOffloat[1] + arrayOfFloat2[4] * paramArrayOffloat[4]);
    arrayOfFloat1[2] = clamp(arrayOfFloat2[34] + arrayOfFloat2[27] * paramArrayOffloat[2] + arrayOfFloat2[5] * paramArrayOffloat[5]);
    arrayOfFloat1[3] = clamp(arrayOfFloat2[6]);
    arrayOfFloat1[4] = clamp(arrayOfFloat2[28] * paramArrayOffloat[6]);
    arrayOfFloat1[5] = clamp(arrayOfFloat2[29] * paramArrayOffloat[7]);
    arrayOfFloat1[6] = clamp(arrayOfFloat2[30] * paramArrayOffloat[8]);
  }
  
  private void lightTriangle(int paramInt, float[] paramArrayOffloat) {
    int i = this.triangles[paramInt][0];
    copyVertexColor(paramInt, i, 0, paramArrayOffloat);
    i = this.triangles[paramInt][1];
    copyVertexColor(paramInt, i, 1, paramArrayOffloat);
    i = this.triangles[paramInt][2];
    copyVertexColor(paramInt, i, 2, paramArrayOffloat);
  }
  
  private void lightTriangle(int paramInt) {
    if (this.normalMode == 2) {
      int i = this.triangles[paramInt][0];
      lightUnlitVertex(i, this.tempLightingContribution);
      copyPrelitVertexColor(paramInt, i, 0);
      i = this.triangles[paramInt][1];
      lightUnlitVertex(i, this.tempLightingContribution);
      copyPrelitVertexColor(paramInt, i, 1);
      i = this.triangles[paramInt][2];
      lightUnlitVertex(i, this.tempLightingContribution);
      copyPrelitVertexColor(paramInt, i, 2);
    } else if (!this.lightingDependsOnVertexPosition) {
      int i = this.triangles[paramInt][0];
      int j = this.triangles[paramInt][1];
      int k = this.triangles[paramInt][2];
      cross(this.vertices[j][21] - this.vertices[i][21], this.vertices[j][22] - this.vertices[i][22], this.vertices[j][23] - this.vertices[i][23], this.vertices[k][21] - this.vertices[i][21], this.vertices[k][22] - this.vertices[i][22], this.vertices[k][23] - this.vertices[i][23], this.lightTriangleNorm);
      this.lightTriangleNorm.normalize();
      this.vertices[i][9] = this.lightTriangleNorm.x;
      this.vertices[i][10] = this.lightTriangleNorm.y;
      this.vertices[i][11] = this.lightTriangleNorm.z;
      calcLightingContribution(i, this.tempLightingContribution, true);
      copyVertexColor(paramInt, i, 0, this.tempLightingContribution);
      copyVertexColor(paramInt, j, 1, this.tempLightingContribution);
      copyVertexColor(paramInt, k, 2, this.tempLightingContribution);
    } else if (this.normalMode == 1) {
      int i = this.triangles[paramInt][0];
      this.vertices[i][9] = this.vertices[this.shapeFirst][9];
      this.vertices[i][10] = this.vertices[this.shapeFirst][10];
      this.vertices[i][11] = this.vertices[this.shapeFirst][11];
      calcLightingContribution(i, this.tempLightingContribution);
      copyVertexColor(paramInt, i, 0, this.tempLightingContribution);
      i = this.triangles[paramInt][1];
      this.vertices[i][9] = this.vertices[this.shapeFirst][9];
      this.vertices[i][10] = this.vertices[this.shapeFirst][10];
      this.vertices[i][11] = this.vertices[this.shapeFirst][11];
      calcLightingContribution(i, this.tempLightingContribution);
      copyVertexColor(paramInt, i, 1, this.tempLightingContribution);
      i = this.triangles[paramInt][2];
      this.vertices[i][9] = this.vertices[this.shapeFirst][9];
      this.vertices[i][10] = this.vertices[this.shapeFirst][10];
      this.vertices[i][11] = this.vertices[this.shapeFirst][11];
      calcLightingContribution(i, this.tempLightingContribution);
      copyVertexColor(paramInt, i, 2, this.tempLightingContribution);
    } else {
      int i = this.triangles[paramInt][0];
      int j = this.triangles[paramInt][1];
      int k = this.triangles[paramInt][2];
      cross(this.vertices[j][21] - this.vertices[i][21], this.vertices[j][22] - this.vertices[i][22], this.vertices[j][23] - this.vertices[i][23], this.vertices[k][21] - this.vertices[i][21], this.vertices[k][22] - this.vertices[i][22], this.vertices[k][23] - this.vertices[i][23], this.lightTriangleNorm);
      this.lightTriangleNorm.normalize();
      this.vertices[i][9] = this.lightTriangleNorm.x;
      this.vertices[i][10] = this.lightTriangleNorm.y;
      this.vertices[i][11] = this.lightTriangleNorm.z;
      calcLightingContribution(i, this.tempLightingContribution, true);
      copyVertexColor(paramInt, i, 0, this.tempLightingContribution);
      this.vertices[j][9] = this.lightTriangleNorm.x;
      this.vertices[j][10] = this.lightTriangleNorm.y;
      this.vertices[j][11] = this.lightTriangleNorm.z;
      calcLightingContribution(j, this.tempLightingContribution, true);
      copyVertexColor(paramInt, j, 1, this.tempLightingContribution);
      this.vertices[k][9] = this.lightTriangleNorm.x;
      this.vertices[k][10] = this.lightTriangleNorm.y;
      this.vertices[k][11] = this.lightTriangleNorm.z;
      calcLightingContribution(k, this.tempLightingContribution, true);
      copyVertexColor(paramInt, k, 2, this.tempLightingContribution);
    } 
  }
  
  protected void renderTriangles(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt2; i++) {
      float[] arrayOfFloat1 = this.vertices[this.triangles[i][0]];
      float[] arrayOfFloat2 = this.vertices[this.triangles[i][1]];
      float[] arrayOfFloat3 = this.vertices[this.triangles[i][2]];
      int j = this.triangles[i][3];
      this.triangle.reset();
      float f1 = clamp(this.triangleColors[i][0][0] + this.triangleColors[i][0][4]);
      float f2 = clamp(this.triangleColors[i][0][1] + this.triangleColors[i][0][5]);
      float f3 = clamp(this.triangleColors[i][0][2] + this.triangleColors[i][0][6]);
      float f4 = clamp(this.triangleColors[i][1][0] + this.triangleColors[i][1][4]);
      float f5 = clamp(this.triangleColors[i][1][1] + this.triangleColors[i][1][5]);
      float f6 = clamp(this.triangleColors[i][1][2] + this.triangleColors[i][1][6]);
      float f7 = clamp(this.triangleColors[i][2][0] + this.triangleColors[i][2][4]);
      float f8 = clamp(this.triangleColors[i][2][1] + this.triangleColors[i][2][5]);
      float f9 = clamp(this.triangleColors[i][2][2] + this.triangleColors[i][2][6]);
      boolean bool = false;
      if (s_enableAccurateTextures && this.frustumMode) {
        boolean bool1 = true;
        this.smoothTriangle.reset(3);
        this.smoothTriangle.smooth = true;
        this.smoothTriangle.interpARGB = true;
        this.smoothTriangle.setIntensities(f1, f2, f3, arrayOfFloat1[6], f4, f5, f6, arrayOfFloat2[6], f7, f8, f9, arrayOfFloat3[6]);
        if (j > -1 && this.textures[j] != null) {
          this.smoothTriangle.setCamVertices(arrayOfFloat1[21], arrayOfFloat1[22], arrayOfFloat1[23], arrayOfFloat2[21], arrayOfFloat2[22], arrayOfFloat2[23], arrayOfFloat3[21], arrayOfFloat3[22], arrayOfFloat3[23]);
          this.smoothTriangle.interpUV = true;
          this.smoothTriangle.texture(this.textures[j]);
          float f10 = (this.textures[j]).width;
          float f11 = (this.textures[j]).height;
          this.smoothTriangle.vertices[0][7] = arrayOfFloat1[7] * f10;
          this.smoothTriangle.vertices[0][8] = arrayOfFloat1[8] * f11;
          this.smoothTriangle.vertices[1][7] = arrayOfFloat2[7] * f10;
          this.smoothTriangle.vertices[1][8] = arrayOfFloat2[8] * f11;
          this.smoothTriangle.vertices[2][7] = arrayOfFloat3[7] * f10;
          this.smoothTriangle.vertices[2][8] = arrayOfFloat3[8] * f11;
        } else {
          this.smoothTriangle.interpUV = false;
          bool1 = false;
        } 
        this.smoothTriangle.setVertices(arrayOfFloat1[18], arrayOfFloat1[19], arrayOfFloat1[20], arrayOfFloat2[18], arrayOfFloat2[19], arrayOfFloat2[20], arrayOfFloat3[18], arrayOfFloat3[19], arrayOfFloat3[20]);
        if (!bool1 || this.smoothTriangle.precomputeAccurateTexturing()) {
          this.smoothTriangle.render();
        } else {
          bool = true;
        } 
      } 
      if (!s_enableAccurateTextures || bool || !this.frustumMode) {
        if (j > -1 && this.textures[j] != null) {
          this.triangle.setTexture(this.textures[j]);
          this.triangle.setUV(arrayOfFloat1[7], arrayOfFloat1[8], arrayOfFloat2[7], arrayOfFloat2[8], arrayOfFloat3[7], arrayOfFloat3[8]);
        } 
        this.triangle.setIntensities(f1, f2, f3, arrayOfFloat1[6], f4, f5, f6, arrayOfFloat2[6], f7, f8, f9, arrayOfFloat3[6]);
        this.triangle.setVertices(arrayOfFloat1[18], arrayOfFloat1[19], arrayOfFloat1[20], arrayOfFloat2[18], arrayOfFloat2[19], arrayOfFloat2[20], arrayOfFloat3[18], arrayOfFloat3[19], arrayOfFloat3[20]);
        this.triangle.render();
      } 
    } 
  }
  
  protected void rawTriangles(int paramInt1, int paramInt2) {
    this.raw.colorMode(1, 1.0F);
    this.raw.noStroke();
    this.raw.beginShape(9);
    for (int i = paramInt1; i < paramInt2; i++) {
      float[] arrayOfFloat1 = this.vertices[this.triangles[i][0]];
      float[] arrayOfFloat2 = this.vertices[this.triangles[i][1]];
      float[] arrayOfFloat3 = this.vertices[this.triangles[i][2]];
      float f1 = clamp(this.triangleColors[i][0][0] + this.triangleColors[i][0][4]);
      float f2 = clamp(this.triangleColors[i][0][1] + this.triangleColors[i][0][5]);
      float f3 = clamp(this.triangleColors[i][0][2] + this.triangleColors[i][0][6]);
      float f4 = clamp(this.triangleColors[i][1][0] + this.triangleColors[i][1][4]);
      float f5 = clamp(this.triangleColors[i][1][1] + this.triangleColors[i][1][5]);
      float f6 = clamp(this.triangleColors[i][1][2] + this.triangleColors[i][1][6]);
      float f7 = clamp(this.triangleColors[i][2][0] + this.triangleColors[i][2][4]);
      float f8 = clamp(this.triangleColors[i][2][1] + this.triangleColors[i][2][5]);
      float f9 = clamp(this.triangleColors[i][2][2] + this.triangleColors[i][2][6]);
      int j = this.triangles[i][3];
      PImage pImage = (j > -1) ? this.textures[j] : null;
      if (pImage != null) {
        if (this.raw.is3D()) {
          if (arrayOfFloat1[24] != 0.0F && arrayOfFloat2[24] != 0.0F && arrayOfFloat3[24] != 0.0F) {
            this.raw.fill(f1, f2, f3, arrayOfFloat1[6]);
            this.raw.vertex(arrayOfFloat1[21] / arrayOfFloat1[24], arrayOfFloat1[22] / arrayOfFloat1[24], arrayOfFloat1[23] / arrayOfFloat1[24], arrayOfFloat1[7], arrayOfFloat1[8]);
            this.raw.fill(f4, f5, f6, arrayOfFloat2[6]);
            this.raw.vertex(arrayOfFloat2[21] / arrayOfFloat2[24], arrayOfFloat2[22] / arrayOfFloat2[24], arrayOfFloat2[23] / arrayOfFloat2[24], arrayOfFloat2[7], arrayOfFloat2[8]);
            this.raw.fill(f7, f8, f9, arrayOfFloat3[6]);
            this.raw.vertex(arrayOfFloat3[21] / arrayOfFloat3[24], arrayOfFloat3[22] / arrayOfFloat3[24], arrayOfFloat3[23] / arrayOfFloat3[24], arrayOfFloat3[7], arrayOfFloat3[8]);
          } 
        } else if (this.raw.is2D()) {
          this.raw.fill(f1, f2, f3, arrayOfFloat1[6]);
          this.raw.vertex(arrayOfFloat1[18], arrayOfFloat1[19], arrayOfFloat1[7], arrayOfFloat1[8]);
          this.raw.fill(f4, f5, f6, arrayOfFloat2[6]);
          this.raw.vertex(arrayOfFloat2[18], arrayOfFloat2[19], arrayOfFloat2[7], arrayOfFloat2[8]);
          this.raw.fill(f7, f8, f9, arrayOfFloat3[6]);
          this.raw.vertex(arrayOfFloat3[18], arrayOfFloat3[19], arrayOfFloat3[7], arrayOfFloat3[8]);
        } 
      } else if (this.raw.is3D()) {
        if (arrayOfFloat1[24] != 0.0F && arrayOfFloat2[24] != 0.0F && arrayOfFloat3[24] != 0.0F) {
          this.raw.fill(f1, f2, f3, arrayOfFloat1[6]);
          this.raw.vertex(arrayOfFloat1[21] / arrayOfFloat1[24], arrayOfFloat1[22] / arrayOfFloat1[24], arrayOfFloat1[23] / arrayOfFloat1[24]);
          this.raw.fill(f4, f5, f6, arrayOfFloat2[6]);
          this.raw.vertex(arrayOfFloat2[21] / arrayOfFloat2[24], arrayOfFloat2[22] / arrayOfFloat2[24], arrayOfFloat2[23] / arrayOfFloat2[24]);
          this.raw.fill(f7, f8, f9, arrayOfFloat3[6]);
          this.raw.vertex(arrayOfFloat3[21] / arrayOfFloat3[24], arrayOfFloat3[22] / arrayOfFloat3[24], arrayOfFloat3[23] / arrayOfFloat3[24]);
        } 
      } else if (this.raw.is2D()) {
        this.raw.fill(f1, f2, f3, arrayOfFloat1[6]);
        this.raw.vertex(arrayOfFloat1[18], arrayOfFloat1[19]);
        this.raw.fill(f4, f5, f6, arrayOfFloat2[6]);
        this.raw.vertex(arrayOfFloat2[18], arrayOfFloat2[19]);
        this.raw.fill(f7, f8, f9, arrayOfFloat3[6]);
        this.raw.vertex(arrayOfFloat3[18], arrayOfFloat3[19]);
      } 
    } 
    this.raw.endShape();
  }
  
  public void flush() {
    if (this.hints[5])
      sort(); 
    render();
  }
  
  protected void render() {
    if (this.pointCount > 0) {
      renderPoints(0, this.pointCount);
      if (this.raw != null)
        rawPoints(0, this.pointCount); 
      this.pointCount = 0;
    } 
    if (this.lineCount > 0) {
      renderLines(0, this.lineCount);
      if (this.raw != null)
        rawLines(0, this.lineCount); 
      this.lineCount = 0;
      this.pathCount = 0;
    } 
    if (this.triangleCount > 0) {
      renderTriangles(0, this.triangleCount);
      if (this.raw != null)
        rawTriangles(0, this.triangleCount); 
      this.triangleCount = 0;
    } 
  }
  
  protected void sort() {
    if (this.triangleCount > 0)
      sortTrianglesInternal(0, this.triangleCount - 1); 
  }
  
  private void sortTrianglesInternal(int paramInt1, int paramInt2) {
    int i = (paramInt1 + paramInt2) / 2;
    sortTrianglesSwap(i, paramInt2);
    int j = sortTrianglesPartition(paramInt1 - 1, paramInt2);
    sortTrianglesSwap(j, paramInt2);
    if (j - paramInt1 > 1)
      sortTrianglesInternal(paramInt1, j - 1); 
    if (paramInt2 - j > 1)
      sortTrianglesInternal(j + 1, paramInt2); 
  }
  
  private int sortTrianglesPartition(int paramInt1, int paramInt2) {
    int i = paramInt2;
    while (true) {
      if (sortTrianglesCompare(++paramInt1, i) < 0.0F)
        continue; 
      while (paramInt2 != 0 && sortTrianglesCompare(--paramInt2, i) > 0.0F);
      sortTrianglesSwap(paramInt1, paramInt2);
      if (paramInt1 >= paramInt2) {
        sortTrianglesSwap(paramInt1, paramInt2);
        return paramInt1;
      } 
    } 
  }
  
  private void sortTrianglesSwap(int paramInt1, int paramInt2) {
    int[] arrayOfInt = this.triangles[paramInt1];
    this.triangles[paramInt1] = this.triangles[paramInt2];
    this.triangles[paramInt2] = arrayOfInt;
    float[][] arrayOfFloat = this.triangleColors[paramInt1];
    this.triangleColors[paramInt1] = this.triangleColors[paramInt2];
    this.triangleColors[paramInt2] = arrayOfFloat;
  }
  
  private float sortTrianglesCompare(int paramInt1, int paramInt2) {
    return this.vertices[this.triangles[paramInt2][0]][20] + this.vertices[this.triangles[paramInt2][1]][20] + this.vertices[this.triangles[paramInt2][2]][20] - this.vertices[this.triangles[paramInt1][0]][20] + this.vertices[this.triangles[paramInt1][1]][20] + this.vertices[this.triangles[paramInt1][2]][20];
  }
  
  protected void ellipseImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    float f1 = paramFloat3 / 2.0F;
    float f2 = paramFloat4 / 2.0F;
    float f3 = paramFloat1 + f1;
    float f4 = paramFloat2 + f2;
    int i = (int)(4.0D + Math.sqrt((paramFloat3 + paramFloat4)) * 3.0D);
    int j = PApplet.constrain(i, 6, 100);
    if (this.fill) {
      float f5 = 720.0F / j;
      float f6 = 0.0F;
      boolean bool1 = this.stroke;
      this.stroke = false;
      boolean bool2 = this.smooth;
      if (this.smooth && this.stroke)
        this.smooth = false; 
      beginShape(11);
      normal(0.0F, 0.0F, 1.0F);
      vertex(f3, f4);
      for (byte b = 0; b < j; b++) {
        vertex(f3 + cosLUT[(int)f6] * f1, f4 + sinLUT[(int)f6] * f2);
        f6 = (f6 + f5) % 720.0F;
      } 
      vertex(f3 + cosLUT[0] * f1, f4 + sinLUT[0] * f2);
      endShape();
      this.stroke = bool1;
      this.smooth = bool2;
    } 
    if (this.stroke) {
      float f5 = 720.0F / j;
      float f6 = 0.0F;
      boolean bool = this.fill;
      this.fill = false;
      f6 = 0.0F;
      beginShape();
      for (byte b = 0; b < j; b++) {
        vertex(f3 + cosLUT[(int)f6] * f1, f4 + sinLUT[(int)f6] * f2);
        f6 = (f6 + f5) % 720.0F;
      } 
      endShape(2);
      this.fill = bool;
    } 
  }
  
  protected void arcImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    float f1 = paramFloat3 / 2.0F;
    float f2 = paramFloat4 / 2.0F;
    float f3 = paramFloat1 + f1;
    float f4 = paramFloat2 + f2;
    if (this.fill) {
      boolean bool = this.stroke;
      this.stroke = false;
      int i = (int)(0.5F + paramFloat5 / 6.2831855F * 720.0F);
      int j = (int)(0.5F + paramFloat6 / 6.2831855F * 720.0F);
      beginShape(11);
      vertex(f3, f4);
      byte b = 1;
      int k;
      for (k = i; k < j; k += b) {
        int m = k % 720;
        if (m < 0)
          m += 720; 
        vertex(f3 + cosLUT[m] * f1, f4 + sinLUT[m] * f2);
      } 
      vertex(f3 + cosLUT[j % 720] * f1, f4 + sinLUT[j % 720] * f2);
      endShape();
      this.stroke = bool;
    } 
    if (this.stroke) {
      boolean bool = this.fill;
      this.fill = false;
      int i = (int)(0.5F + paramFloat5 / 6.2831855F * 720.0F);
      int j = (int)(0.5F + paramFloat6 / 6.2831855F * 720.0F);
      beginShape();
      byte b = 1;
      int k;
      for (k = i; k < j; k += b) {
        int m = k % 720;
        if (m < 0)
          m += 720; 
        vertex(f3 + cosLUT[m] * f1, f4 + sinLUT[m] * f2);
      } 
      vertex(f3 + cosLUT[j % 720] * f1, f4 + sinLUT[j % 720] * f2);
      endShape();
      this.fill = bool;
    } 
  }
  
  public void box(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.triangle != null)
      this.triangle.setCulling(true); 
    super.box(paramFloat1, paramFloat2, paramFloat3);
    if (this.triangle != null)
      this.triangle.setCulling(false); 
  }
  
  public void sphere(float paramFloat) {
    if (this.triangle != null)
      this.triangle.setCulling(true); 
    super.sphere(paramFloat);
    if (this.triangle != null)
      this.triangle.setCulling(false); 
  }
  
  public void smooth() {
    s_enableAccurateTextures = true;
    this.smooth = true;
  }
  
  public void noSmooth() {
    s_enableAccurateTextures = false;
    this.smooth = false;
  }
  
  protected boolean textModeCheck(int paramInt) {
    return (this.textMode == 4 || this.textMode == 256);
  }
  
  public void pushMatrix() {
    if (this.matrixMode == 0) {
      if (this.pmatrixStackDepth == 32)
        throw new RuntimeException("Too many calls to pushMatrix()."); 
      this.projection.get(this.pmatrixStack[this.pmatrixStackDepth]);
      this.pmatrixStackDepth++;
    } else {
      if (this.matrixStackDepth == 32)
        throw new RuntimeException("Too many calls to pushMatrix()."); 
      this.modelview.get(this.matrixStack[this.matrixStackDepth]);
      this.modelviewInv.get(this.matrixInvStack[this.matrixStackDepth]);
      this.matrixStackDepth++;
    } 
  }
  
  public void popMatrix() {
    if (this.matrixMode == 0) {
      if (this.pmatrixStackDepth == 0)
        throw new RuntimeException("Too many calls to popMatrix(), and not enough to pushMatrix()."); 
      this.pmatrixStackDepth--;
      this.projection.set(this.pmatrixStack[this.pmatrixStackDepth]);
    } else {
      if (this.matrixStackDepth == 0)
        throw new RuntimeException("Too many calls to popMatrix(), and not enough to pushMatrix()."); 
      this.matrixStackDepth--;
      this.modelview.set(this.matrixStack[this.matrixStackDepth]);
      this.modelviewInv.set(this.matrixInvStack[this.matrixStackDepth]);
    } 
  }
  
  public void translate(float paramFloat1, float paramFloat2) {
    translate(paramFloat1, paramFloat2, 0.0F);
  }
  
  public void translate(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.matrixMode == 0) {
      this.projection.translate(paramFloat1, paramFloat2, paramFloat3);
    } else {
      this.forwardTransform.translate(paramFloat1, paramFloat2, paramFloat3);
      this.reverseTransform.invTranslate(paramFloat1, paramFloat2, paramFloat3);
    } 
  }
  
  public void rotate(float paramFloat) {
    rotateZ(paramFloat);
  }
  
  public void rotateX(float paramFloat) {
    if (this.matrixMode == 0) {
      this.projection.rotateX(paramFloat);
    } else {
      this.forwardTransform.rotateX(paramFloat);
      this.reverseTransform.invRotateX(paramFloat);
    } 
  }
  
  public void rotateY(float paramFloat) {
    if (this.matrixMode == 0) {
      this.projection.rotateY(paramFloat);
    } else {
      this.forwardTransform.rotateY(paramFloat);
      this.reverseTransform.invRotateY(paramFloat);
    } 
  }
  
  public void rotateZ(float paramFloat) {
    if (this.matrixMode == 0) {
      this.projection.rotateZ(paramFloat);
    } else {
      this.forwardTransform.rotateZ(paramFloat);
      this.reverseTransform.invRotateZ(paramFloat);
    } 
  }
  
  public void rotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.matrixMode == 0) {
      this.projection.rotate(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    } else {
      this.forwardTransform.rotate(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
      this.reverseTransform.invRotate(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    } 
  }
  
  public void scale(float paramFloat) {
    scale(paramFloat, paramFloat, paramFloat);
  }
  
  public void scale(float paramFloat1, float paramFloat2) {
    scale(paramFloat1, paramFloat2, 1.0F);
  }
  
  public void scale(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (this.matrixMode == 0) {
      this.projection.scale(paramFloat1, paramFloat2, paramFloat3);
    } else {
      this.forwardTransform.scale(paramFloat1, paramFloat2, paramFloat3);
      this.reverseTransform.invScale(paramFloat1, paramFloat2, paramFloat3);
    } 
  }
  
  public void shearX(float paramFloat) {
    float f = (float)Math.tan(paramFloat);
    applyMatrix(1.0F, f, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
  }
  
  public void shearY(float paramFloat) {
    float f = (float)Math.tan(paramFloat);
    applyMatrix(1.0F, 0.0F, 0.0F, 0.0F, f, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
  }
  
  public void resetMatrix() {
    if (this.matrixMode == 0) {
      this.projection.reset();
    } else {
      this.forwardTransform.reset();
      this.reverseTransform.reset();
    } 
  }
  
  public void applyMatrix(PMatrix2D paramPMatrix2D) {
    applyMatrix(paramPMatrix2D.m00, paramPMatrix2D.m01, paramPMatrix2D.m02, paramPMatrix2D.m10, paramPMatrix2D.m11, paramPMatrix2D.m12);
  }
  
  public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    applyMatrix(paramFloat1, paramFloat2, paramFloat3, 0.0F, paramFloat4, paramFloat5, paramFloat6, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
  }
  
  public void applyMatrix(PMatrix3D paramPMatrix3D) {
    applyMatrix(paramPMatrix3D.m00, paramPMatrix3D.m01, paramPMatrix3D.m02, paramPMatrix3D.m03, paramPMatrix3D.m10, paramPMatrix3D.m11, paramPMatrix3D.m12, paramPMatrix3D.m13, paramPMatrix3D.m20, paramPMatrix3D.m21, paramPMatrix3D.m22, paramPMatrix3D.m23, paramPMatrix3D.m30, paramPMatrix3D.m31, paramPMatrix3D.m32, paramPMatrix3D.m33);
  }
  
  public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16) {
    if (this.matrixMode == 0) {
      this.projection.apply(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
    } else {
      this.forwardTransform.apply(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
      this.reverseTransform.invApply(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
    } 
  }
  
  public PMatrix getMatrix() {
    return (this.matrixMode == 0) ? this.projection.get() : this.modelview.get();
  }
  
  public PMatrix3D getMatrix(PMatrix3D paramPMatrix3D) {
    if (paramPMatrix3D == null)
      paramPMatrix3D = new PMatrix3D(); 
    if (this.matrixMode == 0) {
      paramPMatrix3D.set(this.projection);
    } else {
      paramPMatrix3D.set(this.modelview);
    } 
    return paramPMatrix3D;
  }
  
  public void setMatrix(PMatrix2D paramPMatrix2D) {
    resetMatrix();
    applyMatrix(paramPMatrix2D);
  }
  
  public void setMatrix(PMatrix3D paramPMatrix3D) {
    resetMatrix();
    applyMatrix(paramPMatrix3D);
  }
  
  public void printMatrix() {
    if (this.matrixMode == 0) {
      this.projection.print();
    } else {
      this.modelview.print();
    } 
  }
  
  public void beginCamera() {
    if (this.manipulatingCamera)
      throw new RuntimeException("beginCamera() cannot be called again before endCamera()"); 
    this.manipulatingCamera = true;
    this.forwardTransform = this.cameraInv;
    this.reverseTransform = this.camera;
  }
  
  public void endCamera() {
    if (!this.manipulatingCamera)
      throw new RuntimeException("Cannot call endCamera() without first calling beginCamera()"); 
    this.modelview.set(this.camera);
    this.modelviewInv.set(this.cameraInv);
    this.forwardTransform = this.modelview;
    this.reverseTransform = this.modelviewInv;
    this.manipulatingCamera = false;
  }
  
  public void camera() {
    camera(this.cameraX, this.cameraY, this.cameraZ, this.cameraX, this.cameraY, 0.0F, 0.0F, 1.0F, 0.0F);
  }
  
  public void camera(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9) {
    float f1 = paramFloat1 - paramFloat4;
    float f2 = paramFloat2 - paramFloat5;
    float f3 = paramFloat3 - paramFloat6;
    float f4 = sqrt(f1 * f1 + f2 * f2 + f3 * f3);
    if (f4 != 0.0F) {
      f1 /= f4;
      f2 /= f4;
      f3 /= f4;
    } 
    float f5 = paramFloat7;
    float f6 = paramFloat8;
    float f7 = paramFloat9;
    float f8 = f6 * f3 - f7 * f2;
    float f9 = -f5 * f3 + f7 * f1;
    float f10 = f5 * f2 - f6 * f1;
    f5 = f2 * f10 - f3 * f9;
    f6 = -f1 * f10 + f3 * f8;
    f7 = f1 * f9 - f2 * f8;
    f4 = sqrt(f8 * f8 + f9 * f9 + f10 * f10);
    if (f4 != 0.0F) {
      f8 /= f4;
      f9 /= f4;
      f10 /= f4;
    } 
    f4 = sqrt(f5 * f5 + f6 * f6 + f7 * f7);
    if (f4 != 0.0F) {
      f5 /= f4;
      f6 /= f4;
      f7 /= f4;
    } 
    this.camera.set(f8, f9, f10, 0.0F, f5, f6, f7, 0.0F, f1, f2, f3, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
    this.camera.translate(-paramFloat1, -paramFloat2, -paramFloat3);
    this.cameraInv.reset();
    this.cameraInv.invApply(f8, f9, f10, 0.0F, f5, f6, f7, 0.0F, f1, f2, f3, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
    this.cameraInv.translate(paramFloat1, paramFloat2, paramFloat3);
    this.modelview.set(this.camera);
    this.modelviewInv.set(this.cameraInv);
  }
  
  public void printCamera() {
    this.camera.print();
  }
  
  public void ortho() {
    ortho(0.0F, this.width, 0.0F, this.height, -10.0F, 10.0F);
  }
  
  public void ortho(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    float f1 = 2.0F / (paramFloat2 - paramFloat1);
    float f2 = 2.0F / (paramFloat4 - paramFloat3);
    float f3 = -2.0F / (paramFloat6 - paramFloat5);
    float f4 = -(paramFloat2 + paramFloat1) / (paramFloat2 - paramFloat1);
    float f5 = -(paramFloat4 + paramFloat3) / (paramFloat4 - paramFloat3);
    float f6 = -(paramFloat6 + paramFloat5) / (paramFloat6 - paramFloat5);
    this.projection.set(f1, 0.0F, 0.0F, f4, 0.0F, f2, 0.0F, f5, 0.0F, 0.0F, f3, f6, 0.0F, 0.0F, 0.0F, 1.0F);
    updateProjection();
    this.frustumMode = false;
  }
  
  public void perspective() {
    perspective(this.cameraFOV, this.cameraAspect, this.cameraNear, this.cameraFar);
  }
  
  public void perspective(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    float f1 = paramFloat3 * (float)Math.tan((paramFloat1 / 2.0F));
    float f2 = -f1;
    float f3 = f2 * paramFloat2;
    float f4 = f1 * paramFloat2;
    frustum(f3, f4, f2, f1, paramFloat3, paramFloat4);
  }
  
  public void frustum(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    this.leftScreen = paramFloat1;
    this.rightScreen = paramFloat2;
    this.bottomScreen = paramFloat3;
    this.topScreen = paramFloat4;
    this.nearPlane = paramFloat5;
    this.frustumMode = true;
    this.projection.set(2.0F * paramFloat5 / (paramFloat2 - paramFloat1), 0.0F, (paramFloat2 + paramFloat1) / (paramFloat2 - paramFloat1), 0.0F, 0.0F, 2.0F * paramFloat5 / (paramFloat4 - paramFloat3), (paramFloat4 + paramFloat3) / (paramFloat4 - paramFloat3), 0.0F, 0.0F, 0.0F, -(paramFloat6 + paramFloat5) / (paramFloat6 - paramFloat5), -(2.0F * paramFloat6 * paramFloat5) / (paramFloat6 - paramFloat5), 0.0F, 0.0F, -1.0F, 0.0F);
    updateProjection();
  }
  
  protected void updateProjection() {}
  
  public void printProjection() {
    this.projection.print();
  }
  
  public PMatrix getProjection() {
    return this.projection.get();
  }
  
  public void matrixMode(int paramInt) {
    if (paramInt == 0) {
      this.matrixMode = 0;
    } else if (paramInt == 1) {
      this.matrixMode = 1;
    } else {
      showWarning("Invalid matrix mode. Use PROJECTION or MODELVIEW");
    } 
  }
  
  public float screenX(float paramFloat1, float paramFloat2) {
    return screenX(paramFloat1, paramFloat2, 0.0F);
  }
  
  public float screenY(float paramFloat1, float paramFloat2) {
    return screenY(paramFloat1, paramFloat2, 0.0F);
  }
  
  public float screenX(float paramFloat1, float paramFloat2, float paramFloat3) {
    float f1 = this.modelview.m00 * paramFloat1 + this.modelview.m01 * paramFloat2 + this.modelview.m02 * paramFloat3 + this.modelview.m03;
    float f2 = this.modelview.m10 * paramFloat1 + this.modelview.m11 * paramFloat2 + this.modelview.m12 * paramFloat3 + this.modelview.m13;
    float f3 = this.modelview.m20 * paramFloat1 + this.modelview.m21 * paramFloat2 + this.modelview.m22 * paramFloat3 + this.modelview.m23;
    float f4 = this.modelview.m30 * paramFloat1 + this.modelview.m31 * paramFloat2 + this.modelview.m32 * paramFloat3 + this.modelview.m33;
    float f5 = this.projection.m00 * f1 + this.projection.m01 * f2 + this.projection.m02 * f3 + this.projection.m03 * f4;
    float f6 = this.projection.m30 * f1 + this.projection.m31 * f2 + this.projection.m32 * f3 + this.projection.m33 * f4;
    if (f6 != 0.0F)
      f5 /= f6; 
    return this.width * (1.0F + f5) / 2.0F;
  }
  
  public float screenY(float paramFloat1, float paramFloat2, float paramFloat3) {
    float f1 = this.modelview.m00 * paramFloat1 + this.modelview.m01 * paramFloat2 + this.modelview.m02 * paramFloat3 + this.modelview.m03;
    float f2 = this.modelview.m10 * paramFloat1 + this.modelview.m11 * paramFloat2 + this.modelview.m12 * paramFloat3 + this.modelview.m13;
    float f3 = this.modelview.m20 * paramFloat1 + this.modelview.m21 * paramFloat2 + this.modelview.m22 * paramFloat3 + this.modelview.m23;
    float f4 = this.modelview.m30 * paramFloat1 + this.modelview.m31 * paramFloat2 + this.modelview.m32 * paramFloat3 + this.modelview.m33;
    float f5 = this.projection.m10 * f1 + this.projection.m11 * f2 + this.projection.m12 * f3 + this.projection.m13 * f4;
    float f6 = this.projection.m30 * f1 + this.projection.m31 * f2 + this.projection.m32 * f3 + this.projection.m33 * f4;
    if (f6 != 0.0F)
      f5 /= f6; 
    return this.height * (1.0F + f5) / 2.0F;
  }
  
  public float screenZ(float paramFloat1, float paramFloat2, float paramFloat3) {
    float f1 = this.modelview.m00 * paramFloat1 + this.modelview.m01 * paramFloat2 + this.modelview.m02 * paramFloat3 + this.modelview.m03;
    float f2 = this.modelview.m10 * paramFloat1 + this.modelview.m11 * paramFloat2 + this.modelview.m12 * paramFloat3 + this.modelview.m13;
    float f3 = this.modelview.m20 * paramFloat1 + this.modelview.m21 * paramFloat2 + this.modelview.m22 * paramFloat3 + this.modelview.m23;
    float f4 = this.modelview.m30 * paramFloat1 + this.modelview.m31 * paramFloat2 + this.modelview.m32 * paramFloat3 + this.modelview.m33;
    float f5 = this.projection.m20 * f1 + this.projection.m21 * f2 + this.projection.m22 * f3 + this.projection.m23 * f4;
    float f6 = this.projection.m30 * f1 + this.projection.m31 * f2 + this.projection.m32 * f3 + this.projection.m33 * f4;
    if (f6 != 0.0F)
      f5 /= f6; 
    return (f5 + 1.0F) / 2.0F;
  }
  
  public float modelX(float paramFloat1, float paramFloat2, float paramFloat3) {
    float f1 = this.modelview.m00 * paramFloat1 + this.modelview.m01 * paramFloat2 + this.modelview.m02 * paramFloat3 + this.modelview.m03;
    float f2 = this.modelview.m10 * paramFloat1 + this.modelview.m11 * paramFloat2 + this.modelview.m12 * paramFloat3 + this.modelview.m13;
    float f3 = this.modelview.m20 * paramFloat1 + this.modelview.m21 * paramFloat2 + this.modelview.m22 * paramFloat3 + this.modelview.m23;
    float f4 = this.modelview.m30 * paramFloat1 + this.modelview.m31 * paramFloat2 + this.modelview.m32 * paramFloat3 + this.modelview.m33;
    float f5 = this.cameraInv.m00 * f1 + this.cameraInv.m01 * f2 + this.cameraInv.m02 * f3 + this.cameraInv.m03 * f4;
    float f6 = this.cameraInv.m30 * f1 + this.cameraInv.m31 * f2 + this.cameraInv.m32 * f3 + this.cameraInv.m33 * f4;
    return (f6 != 0.0F) ? (f5 / f6) : f5;
  }
  
  public float modelY(float paramFloat1, float paramFloat2, float paramFloat3) {
    float f1 = this.modelview.m00 * paramFloat1 + this.modelview.m01 * paramFloat2 + this.modelview.m02 * paramFloat3 + this.modelview.m03;
    float f2 = this.modelview.m10 * paramFloat1 + this.modelview.m11 * paramFloat2 + this.modelview.m12 * paramFloat3 + this.modelview.m13;
    float f3 = this.modelview.m20 * paramFloat1 + this.modelview.m21 * paramFloat2 + this.modelview.m22 * paramFloat3 + this.modelview.m23;
    float f4 = this.modelview.m30 * paramFloat1 + this.modelview.m31 * paramFloat2 + this.modelview.m32 * paramFloat3 + this.modelview.m33;
    float f5 = this.cameraInv.m10 * f1 + this.cameraInv.m11 * f2 + this.cameraInv.m12 * f3 + this.cameraInv.m13 * f4;
    float f6 = this.cameraInv.m30 * f1 + this.cameraInv.m31 * f2 + this.cameraInv.m32 * f3 + this.cameraInv.m33 * f4;
    return (f6 != 0.0F) ? (f5 / f6) : f5;
  }
  
  public float modelZ(float paramFloat1, float paramFloat2, float paramFloat3) {
    float f1 = this.modelview.m00 * paramFloat1 + this.modelview.m01 * paramFloat2 + this.modelview.m02 * paramFloat3 + this.modelview.m03;
    float f2 = this.modelview.m10 * paramFloat1 + this.modelview.m11 * paramFloat2 + this.modelview.m12 * paramFloat3 + this.modelview.m13;
    float f3 = this.modelview.m20 * paramFloat1 + this.modelview.m21 * paramFloat2 + this.modelview.m22 * paramFloat3 + this.modelview.m23;
    float f4 = this.modelview.m30 * paramFloat1 + this.modelview.m31 * paramFloat2 + this.modelview.m32 * paramFloat3 + this.modelview.m33;
    float f5 = this.cameraInv.m20 * f1 + this.cameraInv.m21 * f2 + this.cameraInv.m22 * f3 + this.cameraInv.m23 * f4;
    float f6 = this.cameraInv.m30 * f1 + this.cameraInv.m31 * f2 + this.cameraInv.m32 * f3 + this.cameraInv.m33 * f4;
    return (f6 != 0.0F) ? (f5 / f6) : f5;
  }
  
  public void strokeJoin(int paramInt) {
    if (paramInt != 8)
      showMethodWarning("strokeJoin"); 
  }
  
  public void strokeCap(int paramInt) {
    if (paramInt != 2)
      showMethodWarning("strokeCap"); 
  }
  
  protected void fillFromCalc() {
    super.fillFromCalc();
    ambientFromCalc();
  }
  
  public void lights() {
    int i = this.colorMode;
    this.colorMode = 1;
    lightFalloff(1.0F, 0.0F, 0.0F);
    lightSpecular(0.0F, 0.0F, 0.0F);
    ambientLight(this.colorModeX * 0.5F, this.colorModeY * 0.5F, this.colorModeZ * 0.5F);
    directionalLight(this.colorModeX * 0.5F, this.colorModeY * 0.5F, this.colorModeZ * 0.5F, 0.0F, 0.0F, -1.0F);
    this.colorMode = i;
    this.lightingDependsOnVertexPosition = false;
  }
  
  public void noLights() {
    flush();
    this.lightCount = 0;
  }
  
  public void ambientLight(float paramFloat1, float paramFloat2, float paramFloat3) {
    ambientLight(paramFloat1, paramFloat2, paramFloat3, 0.0F, 0.0F, 0.0F);
  }
  
  public void ambientLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.lightCount == 8)
      throw new RuntimeException("can only create 8 lights"); 
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    this.lightDiffuse[this.lightCount][0] = this.calcR;
    this.lightDiffuse[this.lightCount][1] = this.calcG;
    this.lightDiffuse[this.lightCount][2] = this.calcB;
    this.lightType[this.lightCount] = 0;
    this.lightFalloffConstant[this.lightCount] = this.currentLightFalloffConstant;
    this.lightFalloffLinear[this.lightCount] = this.currentLightFalloffLinear;
    this.lightFalloffQuadratic[this.lightCount] = this.currentLightFalloffQuadratic;
    lightPosition(this.lightCount, paramFloat4, paramFloat5, paramFloat6);
    this.lightCount++;
  }
  
  public void directionalLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.lightCount == 8)
      throw new RuntimeException("can only create 8 lights"); 
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    this.lightDiffuse[this.lightCount][0] = this.calcR;
    this.lightDiffuse[this.lightCount][1] = this.calcG;
    this.lightDiffuse[this.lightCount][2] = this.calcB;
    this.lightType[this.lightCount] = 1;
    this.lightFalloffConstant[this.lightCount] = this.currentLightFalloffConstant;
    this.lightFalloffLinear[this.lightCount] = this.currentLightFalloffLinear;
    this.lightFalloffQuadratic[this.lightCount] = this.currentLightFalloffQuadratic;
    this.lightSpecular[this.lightCount][0] = this.currentLightSpecular[0];
    this.lightSpecular[this.lightCount][1] = this.currentLightSpecular[1];
    this.lightSpecular[this.lightCount][2] = this.currentLightSpecular[2];
    lightDirection(this.lightCount, paramFloat4, paramFloat5, paramFloat6);
    this.lightCount++;
  }
  
  public void pointLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    if (this.lightCount == 8)
      throw new RuntimeException("can only create 8 lights"); 
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    this.lightDiffuse[this.lightCount][0] = this.calcR;
    this.lightDiffuse[this.lightCount][1] = this.calcG;
    this.lightDiffuse[this.lightCount][2] = this.calcB;
    this.lightType[this.lightCount] = 2;
    this.lightFalloffConstant[this.lightCount] = this.currentLightFalloffConstant;
    this.lightFalloffLinear[this.lightCount] = this.currentLightFalloffLinear;
    this.lightFalloffQuadratic[this.lightCount] = this.currentLightFalloffQuadratic;
    this.lightSpecular[this.lightCount][0] = this.currentLightSpecular[0];
    this.lightSpecular[this.lightCount][1] = this.currentLightSpecular[1];
    this.lightSpecular[this.lightCount][2] = this.currentLightSpecular[2];
    lightPosition(this.lightCount, paramFloat4, paramFloat5, paramFloat6);
    this.lightCount++;
    this.lightingDependsOnVertexPosition = true;
  }
  
  public void spotLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11) {
    if (this.lightCount == 8)
      throw new RuntimeException("can only create 8 lights"); 
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    this.lightDiffuse[this.lightCount][0] = this.calcR;
    this.lightDiffuse[this.lightCount][1] = this.calcG;
    this.lightDiffuse[this.lightCount][2] = this.calcB;
    this.lightType[this.lightCount] = 3;
    this.lightFalloffConstant[this.lightCount] = this.currentLightFalloffConstant;
    this.lightFalloffLinear[this.lightCount] = this.currentLightFalloffLinear;
    this.lightFalloffQuadratic[this.lightCount] = this.currentLightFalloffQuadratic;
    this.lightSpecular[this.lightCount][0] = this.currentLightSpecular[0];
    this.lightSpecular[this.lightCount][1] = this.currentLightSpecular[1];
    this.lightSpecular[this.lightCount][2] = this.currentLightSpecular[2];
    lightPosition(this.lightCount, paramFloat4, paramFloat5, paramFloat6);
    lightDirection(this.lightCount, paramFloat7, paramFloat8, paramFloat9);
    this.lightSpotAngle[this.lightCount] = paramFloat10;
    this.lightSpotAngleCos[this.lightCount] = Math.max(0.0F, (float)Math.cos(paramFloat10));
    this.lightSpotConcentration[this.lightCount] = paramFloat11;
    this.lightCount++;
    this.lightingDependsOnVertexPosition = true;
  }
  
  public void lightFalloff(float paramFloat1, float paramFloat2, float paramFloat3) {
    this.currentLightFalloffConstant = paramFloat1;
    this.currentLightFalloffLinear = paramFloat2;
    this.currentLightFalloffQuadratic = paramFloat3;
    this.lightingDependsOnVertexPosition = true;
  }
  
  public void lightSpecular(float paramFloat1, float paramFloat2, float paramFloat3) {
    colorCalc(paramFloat1, paramFloat2, paramFloat3);
    this.currentLightSpecular[0] = this.calcR;
    this.currentLightSpecular[1] = this.calcG;
    this.currentLightSpecular[2] = this.calcB;
    this.lightingDependsOnVertexPosition = true;
  }
  
  protected void lightPosition(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3) {
    this.lightPositionVec.set(paramFloat1, paramFloat2, paramFloat3);
    this.modelview.mult(this.lightPositionVec, this.lightPosition[paramInt]);
  }
  
  protected void lightDirection(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3) {
    this.lightNormal[paramInt].set(this.modelviewInv.m00 * paramFloat1 + this.modelviewInv.m10 * paramFloat2 + this.modelviewInv.m20 * paramFloat3 + this.modelviewInv.m30, this.modelviewInv.m01 * paramFloat1 + this.modelviewInv.m11 * paramFloat2 + this.modelviewInv.m21 * paramFloat3 + this.modelviewInv.m31, this.modelviewInv.m02 * paramFloat1 + this.modelviewInv.m12 * paramFloat2 + this.modelviewInv.m22 * paramFloat3 + this.modelviewInv.m32);
    this.lightNormal[paramInt].normalize();
  }
  
  protected void backgroundImpl(PImage paramPImage) {
    System.arraycopy(paramPImage.pixels, 0, this.pixels, 0, this.pixels.length);
    Arrays.fill(this.zbuffer, Float.MAX_VALUE);
  }
  
  protected void backgroundImpl() {
    Arrays.fill(this.pixels, this.backgroundColor);
    Arrays.fill(this.zbuffer, Float.MAX_VALUE);
  }
  
  public boolean is2D() {
    return false;
  }
  
  public boolean is3D() {
    return true;
  }
  
  private final float sqrt(float paramFloat) {
    return (float)Math.sqrt(paramFloat);
  }
  
  private final float mag(float paramFloat1, float paramFloat2, float paramFloat3) {
    return (float)Math.sqrt((paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2 + paramFloat3 * paramFloat3));
  }
  
  private final float clamp(float paramFloat) {
    return (paramFloat < 1.0F) ? paramFloat : 1.0F;
  }
  
  private final float abs(float paramFloat) {
    return (paramFloat < 0.0F) ? -paramFloat : paramFloat;
  }
  
  private float dot(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    return paramFloat1 * paramFloat4 + paramFloat2 * paramFloat5 + paramFloat3 * paramFloat6;
  }
  
  private final void cross(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, PVector paramPVector) {
    paramPVector.x = paramFloat2 * paramFloat6 - paramFloat3 * paramFloat5;
    paramPVector.y = paramFloat3 * paramFloat4 - paramFloat1 * paramFloat6;
    paramPVector.z = paramFloat1 * paramFloat5 - paramFloat2 * paramFloat4;
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PGraphics3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */