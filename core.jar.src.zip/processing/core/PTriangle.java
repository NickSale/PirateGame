package processing.core;

public class PTriangle implements PConstants {
  static final float PIXEL_CENTER = 0.5F;
  
  static final int R_GOURAUD = 1;
  
  static final int R_TEXTURE8 = 2;
  
  static final int R_TEXTURE24 = 4;
  
  static final int R_TEXTURE32 = 8;
  
  static final int R_ALPHA = 16;
  
  private int[] m_pixels;
  
  private int[] m_texture;
  
  private float[] m_zbuffer;
  
  private int SCREEN_WIDTH;
  
  private int SCREEN_HEIGHT;
  
  private int TEX_WIDTH;
  
  private int TEX_HEIGHT;
  
  private float F_TEX_WIDTH;
  
  private float F_TEX_HEIGHT;
  
  public boolean INTERPOLATE_UV;
  
  public boolean INTERPOLATE_RGB;
  
  public boolean INTERPOLATE_ALPHA;
  
  private static final int DEFAULT_INTERP_POWER = 3;
  
  private static int TEX_INTERP_POWER = 3;
  
  private float[] x_array = new float[3];
  
  private float[] y_array = new float[3];
  
  private float[] z_array = new float[3];
  
  private float[] camX = new float[3];
  
  private float[] camY = new float[3];
  
  private float[] camZ = new float[3];
  
  private float[] u_array = new float[3];
  
  private float[] v_array = new float[3];
  
  private float[] r_array = new float[3];
  
  private float[] g_array = new float[3];
  
  private float[] b_array = new float[3];
  
  private float[] a_array = new float[3];
  
  private int o0;
  
  private int o1;
  
  private int o2;
  
  private float r0;
  
  private float r1;
  
  private float r2;
  
  private float g0;
  
  private float g1;
  
  private float g2;
  
  private float b0;
  
  private float b1;
  
  private float b2;
  
  private float a0;
  
  private float a1;
  
  private float a2;
  
  private float u0;
  
  private float u1;
  
  private float u2;
  
  private float v0;
  
  private float v1;
  
  private float v2;
  
  private float dx2;
  
  private float dy0;
  
  private float dy1;
  
  private float dy2;
  
  private float dz0;
  
  private float dz2;
  
  private float du0;
  
  private float du2;
  
  private float dv0;
  
  private float dv2;
  
  private float dr0;
  
  private float dr2;
  
  private float dg0;
  
  private float dg2;
  
  private float db0;
  
  private float db2;
  
  private float da0;
  
  private float da2;
  
  private float uleft;
  
  private float vleft;
  
  private float uleftadd;
  
  private float vleftadd;
  
  private float xleft;
  
  private float xrght;
  
  private float xadd1;
  
  private float xadd2;
  
  private float zleft;
  
  private float zleftadd;
  
  private float rleft;
  
  private float gleft;
  
  private float bleft;
  
  private float aleft;
  
  private float rleftadd;
  
  private float gleftadd;
  
  private float bleftadd;
  
  private float aleftadd;
  
  private float dta;
  
  private float temp;
  
  private float width;
  
  private int iuadd;
  
  private int ivadd;
  
  private int iradd;
  
  private int igadd;
  
  private int ibadd;
  
  private int iaadd;
  
  private float izadd;
  
  private int m_fill;
  
  public int m_drawFlags;
  
  private PGraphics3D parent;
  
  private boolean noDepthTest;
  
  private boolean m_culling;
  
  private boolean m_singleRight;
  
  private boolean m_bilinear = true;
  
  private float ax;
  
  private float ay;
  
  private float az;
  
  private float bx;
  
  private float by;
  
  private float bz;
  
  private float cx;
  
  private float cy;
  
  private float cz;
  
  private float nearPlaneWidth;
  
  private float nearPlaneHeight;
  
  private float nearPlaneDepth;
  
  private float xmult;
  
  private float ymult;
  
  private float newax;
  
  private float newbx;
  
  private float newcx;
  
  private boolean firstSegment;
  
  public PTriangle(PGraphics3D paramPGraphics3D) {
    this.parent = paramPGraphics3D;
    reset();
  }
  
  public void reset() {
    this.SCREEN_WIDTH = this.parent.width;
    this.SCREEN_HEIGHT = this.parent.height;
    this.m_pixels = this.parent.pixels;
    this.m_zbuffer = this.parent.zbuffer;
    this.noDepthTest = this.parent.hints[4];
    this.INTERPOLATE_UV = false;
    this.INTERPOLATE_RGB = false;
    this.INTERPOLATE_ALPHA = false;
    this.m_texture = null;
    this.m_drawFlags = 0;
  }
  
  public void setCulling(boolean paramBoolean) {
    this.m_culling = paramBoolean;
  }
  
  public void setVertices(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9) {
    this.x_array[0] = paramFloat1;
    this.x_array[1] = paramFloat4;
    this.x_array[2] = paramFloat7;
    this.y_array[0] = paramFloat2;
    this.y_array[1] = paramFloat5;
    this.y_array[2] = paramFloat8;
    this.z_array[0] = paramFloat3;
    this.z_array[1] = paramFloat6;
    this.z_array[2] = paramFloat9;
  }
  
  public void setCamVertices(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9) {
    this.camX[0] = paramFloat1;
    this.camX[1] = paramFloat4;
    this.camX[2] = paramFloat7;
    this.camY[0] = paramFloat2;
    this.camY[1] = paramFloat5;
    this.camY[2] = paramFloat8;
    this.camZ[0] = paramFloat3;
    this.camZ[1] = paramFloat6;
    this.camZ[2] = paramFloat9;
  }
  
  public void setUV(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    this.u_array[0] = (paramFloat1 * this.F_TEX_WIDTH + 0.5F) * 65536.0F;
    this.u_array[1] = (paramFloat3 * this.F_TEX_WIDTH + 0.5F) * 65536.0F;
    this.u_array[2] = (paramFloat5 * this.F_TEX_WIDTH + 0.5F) * 65536.0F;
    this.v_array[0] = (paramFloat2 * this.F_TEX_HEIGHT + 0.5F) * 65536.0F;
    this.v_array[1] = (paramFloat4 * this.F_TEX_HEIGHT + 0.5F) * 65536.0F;
    this.v_array[2] = (paramFloat6 * this.F_TEX_HEIGHT + 0.5F) * 65536.0F;
  }
  
  public void setIntensities(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12) {
    if (paramFloat4 != 1.0F || paramFloat8 != 1.0F || paramFloat12 != 1.0F) {
      this.INTERPOLATE_ALPHA = true;
      this.a_array[0] = (paramFloat4 * 253.0F + 1.0F) * 65536.0F;
      this.a_array[1] = (paramFloat8 * 253.0F + 1.0F) * 65536.0F;
      this.a_array[2] = (paramFloat12 * 253.0F + 1.0F) * 65536.0F;
      this.m_drawFlags |= 0x10;
    } else {
      this.INTERPOLATE_ALPHA = false;
      this.m_drawFlags &= 0xFFFFFFEF;
    } 
    if (paramFloat1 != paramFloat5 || paramFloat5 != paramFloat9) {
      this.INTERPOLATE_RGB = true;
      this.m_drawFlags |= 0x1;
    } else if (paramFloat2 != paramFloat6 || paramFloat6 != paramFloat10) {
      this.INTERPOLATE_RGB = true;
      this.m_drawFlags |= 0x1;
    } else if (paramFloat3 != paramFloat7 || paramFloat7 != paramFloat11) {
      this.INTERPOLATE_RGB = true;
      this.m_drawFlags |= 0x1;
    } else {
      this.m_drawFlags &= 0xFFFFFFFE;
    } 
    this.r_array[0] = (paramFloat1 * 253.0F + 1.0F) * 65536.0F;
    this.r_array[1] = (paramFloat5 * 253.0F + 1.0F) * 65536.0F;
    this.r_array[2] = (paramFloat9 * 253.0F + 1.0F) * 65536.0F;
    this.g_array[0] = (paramFloat2 * 253.0F + 1.0F) * 65536.0F;
    this.g_array[1] = (paramFloat6 * 253.0F + 1.0F) * 65536.0F;
    this.g_array[2] = (paramFloat10 * 253.0F + 1.0F) * 65536.0F;
    this.b_array[0] = (paramFloat3 * 253.0F + 1.0F) * 65536.0F;
    this.b_array[1] = (paramFloat7 * 253.0F + 1.0F) * 65536.0F;
    this.b_array[2] = (paramFloat11 * 253.0F + 1.0F) * 65536.0F;
    this.m_fill = 0xFF000000 | (int)(255.0F * paramFloat1) << 16 | (int)(255.0F * paramFloat2) << 8 | (int)(255.0F * paramFloat3);
  }
  
  public void setTexture(PImage paramPImage) {
    this.m_texture = paramPImage.pixels;
    this.TEX_WIDTH = paramPImage.width;
    this.TEX_HEIGHT = paramPImage.height;
    this.F_TEX_WIDTH = (this.TEX_WIDTH - 1);
    this.F_TEX_HEIGHT = (this.TEX_HEIGHT - 1);
    this.INTERPOLATE_UV = true;
    if (paramPImage.format == 2) {
      this.m_drawFlags |= 0x8;
    } else if (paramPImage.format == 1) {
      this.m_drawFlags |= 0x4;
    } else if (paramPImage.format == 4) {
      this.m_drawFlags |= 0x2;
    } 
  }
  
  public void setUV(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
    if (this.m_bilinear) {
      this.u_array[0] = paramArrayOffloat1[0] * this.F_TEX_WIDTH * 65500.0F;
      this.u_array[1] = paramArrayOffloat1[1] * this.F_TEX_WIDTH * 65500.0F;
      this.u_array[2] = paramArrayOffloat1[2] * this.F_TEX_WIDTH * 65500.0F;
      this.v_array[0] = paramArrayOffloat2[0] * this.F_TEX_HEIGHT * 65500.0F;
      this.v_array[1] = paramArrayOffloat2[1] * this.F_TEX_HEIGHT * 65500.0F;
      this.v_array[2] = paramArrayOffloat2[2] * this.F_TEX_HEIGHT * 65500.0F;
    } else {
      this.u_array[0] = paramArrayOffloat1[0] * this.TEX_WIDTH * 65500.0F;
      this.u_array[1] = paramArrayOffloat1[1] * this.TEX_WIDTH * 65500.0F;
      this.u_array[2] = paramArrayOffloat1[2] * this.TEX_WIDTH * 65500.0F;
      this.v_array[0] = paramArrayOffloat2[0] * this.TEX_HEIGHT * 65500.0F;
      this.v_array[1] = paramArrayOffloat2[1] * this.TEX_HEIGHT * 65500.0F;
      this.v_array[2] = paramArrayOffloat2[2] * this.TEX_HEIGHT * 65500.0F;
    } 
  }
  
  public void render() {
    float f1 = this.y_array[0];
    float f2 = this.y_array[1];
    float f3 = this.y_array[2];
    this.firstSegment = true;
    if (this.m_culling) {
      float f = this.x_array[0];
      if ((this.x_array[2] - f) * (f2 - f1) < (this.x_array[1] - f) * (f3 - f1))
        return; 
    } 
    if (f1 < f2) {
      if (f3 < f2) {
        if (f3 < f1) {
          this.o0 = 2;
          this.o1 = 0;
          this.o2 = 1;
        } else {
          this.o0 = 0;
          this.o1 = 2;
          this.o2 = 1;
        } 
      } else {
        this.o0 = 0;
        this.o1 = 1;
        this.o2 = 2;
      } 
    } else if (f3 > f2) {
      if (f3 < f1) {
        this.o0 = 1;
        this.o1 = 2;
        this.o2 = 0;
      } else {
        this.o0 = 1;
        this.o1 = 0;
        this.o2 = 2;
      } 
    } else {
      this.o0 = 2;
      this.o1 = 1;
      this.o2 = 0;
    } 
    f1 = this.y_array[this.o0];
    int i = (int)(f1 + 0.5F);
    if (i > this.SCREEN_HEIGHT)
      return; 
    if (i < 0)
      i = 0; 
    f3 = this.y_array[this.o2];
    int j = (int)(f3 + 0.5F);
    if (j < 0)
      return; 
    if (j > this.SCREEN_HEIGHT)
      j = this.SCREEN_HEIGHT; 
    if (j > i) {
      float f4 = this.x_array[this.o0];
      float f5 = this.x_array[this.o1];
      float f6 = this.x_array[this.o2];
      f2 = this.y_array[this.o1];
      int k = (int)(f2 + 0.5F);
      if (k < 0)
        k = 0; 
      if (k > this.SCREEN_HEIGHT)
        k = this.SCREEN_HEIGHT; 
      this.dx2 = f6 - f4;
      this.dy0 = f2 - f1;
      this.dy2 = f3 - f1;
      this.xadd2 = this.dx2 / this.dy2;
      this.temp = this.dy0 / this.dy2;
      this.width = this.temp * this.dx2 + f4 - f5;
      if (this.INTERPOLATE_ALPHA) {
        this.a0 = this.a_array[this.o0];
        this.a1 = this.a_array[this.o1];
        this.a2 = this.a_array[this.o2];
        this.da0 = this.a1 - this.a0;
        this.da2 = this.a2 - this.a0;
        this.iaadd = (int)((this.temp * this.da2 - this.da0) / this.width);
      } 
      if (this.INTERPOLATE_RGB) {
        this.r0 = this.r_array[this.o0];
        this.r1 = this.r_array[this.o1];
        this.r2 = this.r_array[this.o2];
        this.g0 = this.g_array[this.o0];
        this.g1 = this.g_array[this.o1];
        this.g2 = this.g_array[this.o2];
        this.b0 = this.b_array[this.o0];
        this.b1 = this.b_array[this.o1];
        this.b2 = this.b_array[this.o2];
        this.dr0 = this.r1 - this.r0;
        this.dg0 = this.g1 - this.g0;
        this.db0 = this.b1 - this.b0;
        this.dr2 = this.r2 - this.r0;
        this.dg2 = this.g2 - this.g0;
        this.db2 = this.b2 - this.b0;
        this.iradd = (int)((this.temp * this.dr2 - this.dr0) / this.width);
        this.igadd = (int)((this.temp * this.dg2 - this.dg0) / this.width);
        this.ibadd = (int)((this.temp * this.db2 - this.db0) / this.width);
      } 
      if (this.INTERPOLATE_UV) {
        this.u0 = this.u_array[this.o0];
        this.u1 = this.u_array[this.o1];
        this.u2 = this.u_array[this.o2];
        this.v0 = this.v_array[this.o0];
        this.v1 = this.v_array[this.o1];
        this.v2 = this.v_array[this.o2];
        this.du0 = this.u1 - this.u0;
        this.dv0 = this.v1 - this.v0;
        this.du2 = this.u2 - this.u0;
        this.dv2 = this.v2 - this.v0;
        this.iuadd = (int)((this.temp * this.du2 - this.du0) / this.width);
        this.ivadd = (int)((this.temp * this.dv2 - this.dv0) / this.width);
      } 
      float f7 = this.z_array[this.o0];
      float f8 = this.z_array[this.o1];
      float f9 = this.z_array[this.o2];
      this.dz0 = f8 - f7;
      this.dz2 = f9 - f7;
      this.izadd = (this.temp * this.dz2 - this.dz0) / this.width;
      if (k > i) {
        this.dta = i + 0.5F - f1;
        this.xadd1 = (f5 - f4) / this.dy0;
        if (this.xadd2 > this.xadd1) {
          this.xleft = f4 + this.dta * this.xadd1;
          this.xrght = f4 + this.dta * this.xadd2;
          this.zleftadd = this.dz0 / this.dy0;
          this.zleft = this.dta * this.zleftadd + f7;
          if (this.INTERPOLATE_UV) {
            this.uleftadd = this.du0 / this.dy0;
            this.vleftadd = this.dv0 / this.dy0;
            this.uleft = this.dta * this.uleftadd + this.u0;
            this.vleft = this.dta * this.vleftadd + this.v0;
          } 
          if (this.INTERPOLATE_RGB) {
            this.rleftadd = this.dr0 / this.dy0;
            this.gleftadd = this.dg0 / this.dy0;
            this.bleftadd = this.db0 / this.dy0;
            this.rleft = this.dta * this.rleftadd + this.r0;
            this.gleft = this.dta * this.gleftadd + this.g0;
            this.bleft = this.dta * this.bleftadd + this.b0;
          } 
          if (this.INTERPOLATE_ALPHA) {
            this.aleftadd = this.da0 / this.dy0;
            this.aleft = this.dta * this.aleftadd + this.a0;
            if (this.m_drawFlags == 16) {
              drawsegment_plain_alpha(this.xadd1, this.xadd2, i, k);
            } else if (this.m_drawFlags == 17) {
              drawsegment_gouraud_alpha(this.xadd1, this.xadd2, i, k);
            } else if (this.m_drawFlags == 18) {
              drawsegment_texture8_alpha(this.xadd1, this.xadd2, i, k);
            } else if (this.m_drawFlags == 20) {
              drawsegment_texture24_alpha(this.xadd1, this.xadd2, i, k);
            } else if (this.m_drawFlags == 24) {
              drawsegment_texture32_alpha(this.xadd1, this.xadd2, i, k);
            } else if (this.m_drawFlags == 19) {
              drawsegment_gouraud_texture8_alpha(this.xadd1, this.xadd2, i, k);
            } else if (this.m_drawFlags == 21) {
              drawsegment_gouraud_texture24_alpha(this.xadd1, this.xadd2, i, k);
            } else if (this.m_drawFlags == 25) {
              drawsegment_gouraud_texture32_alpha(this.xadd1, this.xadd2, i, k);
            } 
          } else if (this.m_drawFlags == 0) {
            drawsegment_plain(this.xadd1, this.xadd2, i, k);
          } else if (this.m_drawFlags == 1) {
            drawsegment_gouraud(this.xadd1, this.xadd2, i, k);
          } else if (this.m_drawFlags == 2) {
            drawsegment_texture8(this.xadd1, this.xadd2, i, k);
          } else if (this.m_drawFlags == 4) {
            drawsegment_texture24(this.xadd1, this.xadd2, i, k);
          } else if (this.m_drawFlags == 8) {
            drawsegment_texture32(this.xadd1, this.xadd2, i, k);
          } else if (this.m_drawFlags == 3) {
            drawsegment_gouraud_texture8(this.xadd1, this.xadd2, i, k);
          } else if (this.m_drawFlags == 5) {
            drawsegment_gouraud_texture24(this.xadd1, this.xadd2, i, k);
          } else if (this.m_drawFlags == 9) {
            drawsegment_gouraud_texture32(this.xadd1, this.xadd2, i, k);
          } 
          this.m_singleRight = true;
        } else {
          this.xleft = f4 + this.dta * this.xadd2;
          this.xrght = f4 + this.dta * this.xadd1;
          this.zleftadd = this.dz2 / this.dy2;
          this.zleft = this.dta * this.zleftadd + f7;
          if (this.INTERPOLATE_UV) {
            this.uleftadd = this.du2 / this.dy2;
            this.vleftadd = this.dv2 / this.dy2;
            this.uleft = this.dta * this.uleftadd + this.u0;
            this.vleft = this.dta * this.vleftadd + this.v0;
          } 
          if (this.INTERPOLATE_RGB) {
            this.rleftadd = this.dr2 / this.dy2;
            this.gleftadd = this.dg2 / this.dy2;
            this.bleftadd = this.db2 / this.dy2;
            this.rleft = this.dta * this.rleftadd + this.r0;
            this.gleft = this.dta * this.gleftadd + this.g0;
            this.bleft = this.dta * this.bleftadd + this.b0;
          } 
          if (this.INTERPOLATE_ALPHA) {
            this.aleftadd = this.da2 / this.dy2;
            this.aleft = this.dta * this.aleftadd + this.a0;
            if (this.m_drawFlags == 16) {
              drawsegment_plain_alpha(this.xadd2, this.xadd1, i, k);
            } else if (this.m_drawFlags == 17) {
              drawsegment_gouraud_alpha(this.xadd2, this.xadd1, i, k);
            } else if (this.m_drawFlags == 18) {
              drawsegment_texture8_alpha(this.xadd2, this.xadd1, i, k);
            } else if (this.m_drawFlags == 20) {
              drawsegment_texture24_alpha(this.xadd2, this.xadd1, i, k);
            } else if (this.m_drawFlags == 24) {
              drawsegment_texture32_alpha(this.xadd2, this.xadd1, i, k);
            } else if (this.m_drawFlags == 19) {
              drawsegment_gouraud_texture8_alpha(this.xadd2, this.xadd1, i, k);
            } else if (this.m_drawFlags == 21) {
              drawsegment_gouraud_texture24_alpha(this.xadd2, this.xadd1, i, k);
            } else if (this.m_drawFlags == 25) {
              drawsegment_gouraud_texture32_alpha(this.xadd2, this.xadd1, i, k);
            } 
          } else if (this.m_drawFlags == 0) {
            drawsegment_plain(this.xadd2, this.xadd1, i, k);
          } else if (this.m_drawFlags == 1) {
            drawsegment_gouraud(this.xadd2, this.xadd1, i, k);
          } else if (this.m_drawFlags == 2) {
            drawsegment_texture8(this.xadd2, this.xadd1, i, k);
          } else if (this.m_drawFlags == 4) {
            drawsegment_texture24(this.xadd2, this.xadd1, i, k);
          } else if (this.m_drawFlags == 8) {
            drawsegment_texture32(this.xadd2, this.xadd1, i, k);
          } else if (this.m_drawFlags == 3) {
            drawsegment_gouraud_texture8(this.xadd2, this.xadd1, i, k);
          } else if (this.m_drawFlags == 5) {
            drawsegment_gouraud_texture24(this.xadd2, this.xadd1, i, k);
          } else if (this.m_drawFlags == 9) {
            drawsegment_gouraud_texture32(this.xadd2, this.xadd1, i, k);
          } 
          this.m_singleRight = false;
        } 
        if (j == k)
          return; 
        this.dy1 = f3 - f2;
        this.xadd1 = (f6 - f5) / this.dy1;
      } else {
        this.dy1 = f3 - f2;
        this.xadd1 = (f6 - f5) / this.dy1;
        if (this.xadd2 < this.xadd1) {
          this.xrght = (k + 0.5F - f1) * this.xadd2 + f4;
          this.m_singleRight = true;
        } else {
          this.dta = k + 0.5F - f1;
          this.xleft = this.dta * this.xadd2 + f4;
          this.zleftadd = this.dz2 / this.dy2;
          this.zleft = this.dta * this.zleftadd + f7;
          if (this.INTERPOLATE_UV) {
            this.uleftadd = this.du2 / this.dy2;
            this.vleftadd = this.dv2 / this.dy2;
            this.uleft = this.dta * this.uleftadd + this.u0;
            this.vleft = this.dta * this.vleftadd + this.v0;
          } 
          if (this.INTERPOLATE_RGB) {
            this.rleftadd = this.dr2 / this.dy2;
            this.gleftadd = this.dg2 / this.dy2;
            this.bleftadd = this.db2 / this.dy2;
            this.rleft = this.dta * this.rleftadd + this.r0;
            this.gleft = this.dta * this.gleftadd + this.g0;
            this.bleft = this.dta * this.bleftadd + this.b0;
          } 
          if (this.INTERPOLATE_ALPHA) {
            this.aleftadd = this.da2 / this.dy2;
            this.aleft = this.dta * this.aleftadd + this.a0;
          } 
          this.m_singleRight = false;
        } 
      } 
      if (this.m_singleRight) {
        this.dta = k + 0.5F - f2;
        this.xleft = this.dta * this.xadd1 + f5;
        this.zleftadd = (f9 - f8) / this.dy1;
        this.zleft = this.dta * this.zleftadd + f8;
        if (this.INTERPOLATE_UV) {
          this.uleftadd = (this.u2 - this.u1) / this.dy1;
          this.vleftadd = (this.v2 - this.v1) / this.dy1;
          this.uleft = this.dta * this.uleftadd + this.u1;
          this.vleft = this.dta * this.vleftadd + this.v1;
        } 
        if (this.INTERPOLATE_RGB) {
          this.rleftadd = (this.r2 - this.r1) / this.dy1;
          this.gleftadd = (this.g2 - this.g1) / this.dy1;
          this.bleftadd = (this.b2 - this.b1) / this.dy1;
          this.rleft = this.dta * this.rleftadd + this.r1;
          this.gleft = this.dta * this.gleftadd + this.g1;
          this.bleft = this.dta * this.bleftadd + this.b1;
        } 
        if (this.INTERPOLATE_ALPHA) {
          this.aleftadd = (this.a2 - this.a1) / this.dy1;
          this.aleft = this.dta * this.aleftadd + this.a1;
          if (this.m_drawFlags == 16) {
            drawsegment_plain_alpha(this.xadd1, this.xadd2, k, j);
          } else if (this.m_drawFlags == 17) {
            drawsegment_gouraud_alpha(this.xadd1, this.xadd2, k, j);
          } else if (this.m_drawFlags == 18) {
            drawsegment_texture8_alpha(this.xadd1, this.xadd2, k, j);
          } else if (this.m_drawFlags == 20) {
            drawsegment_texture24_alpha(this.xadd1, this.xadd2, k, j);
          } else if (this.m_drawFlags == 24) {
            drawsegment_texture32_alpha(this.xadd1, this.xadd2, k, j);
          } else if (this.m_drawFlags == 19) {
            drawsegment_gouraud_texture8_alpha(this.xadd1, this.xadd2, k, j);
          } else if (this.m_drawFlags == 21) {
            drawsegment_gouraud_texture24_alpha(this.xadd1, this.xadd2, k, j);
          } else if (this.m_drawFlags == 25) {
            drawsegment_gouraud_texture32_alpha(this.xadd1, this.xadd2, k, j);
          } 
        } else if (this.m_drawFlags == 0) {
          drawsegment_plain(this.xadd1, this.xadd2, k, j);
        } else if (this.m_drawFlags == 1) {
          drawsegment_gouraud(this.xadd1, this.xadd2, k, j);
        } else if (this.m_drawFlags == 2) {
          drawsegment_texture8(this.xadd1, this.xadd2, k, j);
        } else if (this.m_drawFlags == 4) {
          drawsegment_texture24(this.xadd1, this.xadd2, k, j);
        } else if (this.m_drawFlags == 8) {
          drawsegment_texture32(this.xadd1, this.xadd2, k, j);
        } else if (this.m_drawFlags == 3) {
          drawsegment_gouraud_texture8(this.xadd1, this.xadd2, k, j);
        } else if (this.m_drawFlags == 5) {
          drawsegment_gouraud_texture24(this.xadd1, this.xadd2, k, j);
        } else if (this.m_drawFlags == 9) {
          drawsegment_gouraud_texture32(this.xadd1, this.xadd2, k, j);
        } 
      } else {
        this.xrght = (k + 0.5F - f2) * this.xadd1 + f5;
        if (this.INTERPOLATE_ALPHA) {
          if (this.m_drawFlags == 16) {
            drawsegment_plain_alpha(this.xadd2, this.xadd1, k, j);
          } else if (this.m_drawFlags == 17) {
            drawsegment_gouraud_alpha(this.xadd2, this.xadd1, k, j);
          } else if (this.m_drawFlags == 18) {
            drawsegment_texture8_alpha(this.xadd2, this.xadd1, k, j);
          } else if (this.m_drawFlags == 20) {
            drawsegment_texture24_alpha(this.xadd2, this.xadd1, k, j);
          } else if (this.m_drawFlags == 24) {
            drawsegment_texture32_alpha(this.xadd2, this.xadd1, k, j);
          } else if (this.m_drawFlags == 19) {
            drawsegment_gouraud_texture8_alpha(this.xadd2, this.xadd1, k, j);
          } else if (this.m_drawFlags == 21) {
            drawsegment_gouraud_texture24_alpha(this.xadd2, this.xadd1, k, j);
          } else if (this.m_drawFlags == 25) {
            drawsegment_gouraud_texture32_alpha(this.xadd2, this.xadd1, k, j);
          } 
        } else if (this.m_drawFlags == 0) {
          drawsegment_plain(this.xadd2, this.xadd1, k, j);
        } else if (this.m_drawFlags == 1) {
          drawsegment_gouraud(this.xadd2, this.xadd1, k, j);
        } else if (this.m_drawFlags == 2) {
          drawsegment_texture8(this.xadd2, this.xadd1, k, j);
        } else if (this.m_drawFlags == 4) {
          drawsegment_texture24(this.xadd2, this.xadd1, k, j);
        } else if (this.m_drawFlags == 8) {
          drawsegment_texture32(this.xadd2, this.xadd1, k, j);
        } else if (this.m_drawFlags == 3) {
          drawsegment_gouraud_texture8(this.xadd2, this.xadd1, k, j);
        } else if (this.m_drawFlags == 5) {
          drawsegment_gouraud_texture24(this.xadd2, this.xadd1, k, j);
        } else if (this.m_drawFlags == 9) {
          drawsegment_gouraud_texture32(this.xadd2, this.xadd1, k, j);
        } 
      } 
    } 
  }
  
  private boolean precomputeAccurateTexturing() {
    float f1 = 65500.0F;
    float f2 = 65500.0F;
    if (this.firstSegment) {
      PMatrix3D pMatrix3D = new PMatrix3D(this.u_array[this.o0] / f1, this.v_array[this.o0] / f2, 1.0F, 0.0F, this.u_array[this.o1] / f1, this.v_array[this.o1] / f2, 1.0F, 0.0F, this.u_array[this.o2] / f1, this.v_array[this.o2] / f2, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
      if (!pMatrix3D.invert())
        return false; 
      float f3 = pMatrix3D.m00 * this.camX[this.o0] + pMatrix3D.m01 * this.camX[this.o1] + pMatrix3D.m02 * this.camX[this.o2];
      float f4 = pMatrix3D.m10 * this.camX[this.o0] + pMatrix3D.m11 * this.camX[this.o1] + pMatrix3D.m12 * this.camX[this.o2];
      float f5 = pMatrix3D.m20 * this.camX[this.o0] + pMatrix3D.m21 * this.camX[this.o1] + pMatrix3D.m22 * this.camX[this.o2];
      float f6 = pMatrix3D.m00 * this.camY[this.o0] + pMatrix3D.m01 * this.camY[this.o1] + pMatrix3D.m02 * this.camY[this.o2];
      float f7 = pMatrix3D.m10 * this.camY[this.o0] + pMatrix3D.m11 * this.camY[this.o1] + pMatrix3D.m12 * this.camY[this.o2];
      float f8 = pMatrix3D.m20 * this.camY[this.o0] + pMatrix3D.m21 * this.camY[this.o1] + pMatrix3D.m22 * this.camY[this.o2];
      float f9 = -(pMatrix3D.m00 * this.camZ[this.o0] + pMatrix3D.m01 * this.camZ[this.o1] + pMatrix3D.m02 * this.camZ[this.o2]);
      float f10 = -(pMatrix3D.m10 * this.camZ[this.o0] + pMatrix3D.m11 * this.camZ[this.o1] + pMatrix3D.m12 * this.camZ[this.o2]);
      float f11 = -(pMatrix3D.m20 * this.camZ[this.o0] + pMatrix3D.m21 * this.camZ[this.o1] + pMatrix3D.m22 * this.camZ[this.o2]);
      float f12 = f5;
      float f13 = f8;
      float f14 = f11;
      float f15 = f3 * this.TEX_WIDTH + f5;
      float f16 = f6 * this.TEX_WIDTH + f8;
      float f17 = f9 * this.TEX_WIDTH + f11;
      float f18 = f4 * this.TEX_HEIGHT + f5;
      float f19 = f7 * this.TEX_HEIGHT + f8;
      float f20 = f10 * this.TEX_HEIGHT + f11;
      float f21 = f15 - f5;
      float f22 = f16 - f8;
      float f23 = f17 - f11;
      float f24 = f18 - f5;
      float f25 = f19 - f8;
      float f26 = f20 - f11;
      this.ax = (f13 * f26 - f14 * f25) * this.TEX_WIDTH;
      this.ay = (f14 * f24 - f12 * f26) * this.TEX_WIDTH;
      this.az = (f12 * f25 - f13 * f24) * this.TEX_WIDTH;
      this.bx = (f22 * f14 - f23 * f13) * this.TEX_HEIGHT;
      this.by = (f23 * f12 - f21 * f14) * this.TEX_HEIGHT;
      this.bz = (f21 * f13 - f22 * f12) * this.TEX_HEIGHT;
      this.cx = f25 * f23 - f26 * f22;
      this.cy = f26 * f21 - f24 * f23;
      this.cz = f24 * f22 - f25 * f21;
    } 
    this.nearPlaneWidth = this.parent.rightScreen - this.parent.leftScreen;
    this.nearPlaneHeight = this.parent.topScreen - this.parent.bottomScreen;
    this.nearPlaneDepth = this.parent.nearPlane;
    this.xmult = this.nearPlaneWidth / this.SCREEN_WIDTH;
    this.ymult = this.nearPlaneHeight / this.SCREEN_HEIGHT;
    this.newax = this.ax * this.xmult;
    this.newbx = this.bx * this.xmult;
    this.newcx = this.cx * this.xmult;
    return true;
  }
  
  public static void setInterpPower(int paramInt) {
    TEX_INTERP_POWER = paramInt;
  }
  
  private void drawsegment_plain(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    while (paramInt1 < paramInt2) {
      int i = (int)(this.xleft + 0.5F);
      if (i < 0)
        i = 0; 
      int j = (int)(this.xrght + 0.5F);
      if (j > this.SCREEN_WIDTH)
        j = this.SCREEN_WIDTH; 
      float f1 = i + 0.5F - this.xleft;
      float f2 = this.izadd * f1 + this.zleft;
      i += paramInt1;
      j += paramInt1;
      while (i < j) {
        if (this.noDepthTest || f2 <= this.m_zbuffer[i]) {
          this.m_zbuffer[i] = f2;
          this.m_pixels[i] = this.m_fill;
        } 
        f2 += this.izadd;
        i++;
      } 
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.zleft += this.zleftadd;
    } 
  }
  
  private void drawsegment_plain_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    int i = this.m_fill & 0xFF0000;
    int j = this.m_fill & 0xFF00;
    int k = this.m_fill & 0xFF;
    float f = this.iaadd;
    while (paramInt1 < paramInt2) {
      int m = (int)(this.xleft + 0.5F);
      if (m < 0)
        m = 0; 
      int n = (int)(this.xrght + 0.5F);
      if (n > this.SCREEN_WIDTH)
        n = this.SCREEN_WIDTH; 
      float f1 = m + 0.5F - this.xleft;
      float f2 = this.izadd * f1 + this.zleft;
      int i1 = (int)(f * f1 + this.aleft);
      m += paramInt1;
      n += paramInt1;
      while (m < n) {
        if (this.noDepthTest || f2 <= this.m_zbuffer[m]) {
          int i2 = i1 >> 16;
          int i3 = this.m_pixels[m];
          int i4 = i3 & 0xFF00;
          int i5 = i3 & 0xFF;
          i3 &= 0xFF0000;
          i3 += (i - i3) * i2 >> 8;
          i4 += (j - i4) * i2 >> 8;
          i5 += (k - i5) * i2 >> 8;
          this.m_pixels[m] = 0xFF000000 | i3 & 0xFF0000 | i4 & 0xFF00 | i5 & 0xFF;
        } 
        f2 += this.izadd;
        i1 += this.iaadd;
        m++;
      } 
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.zleft += this.zleftadd;
    } 
  }
  
  private void drawsegment_gouraud(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    float f1 = this.iradd;
    float f2 = this.igadd;
    float f3 = this.ibadd;
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    while (paramInt1 < paramInt2) {
      int i = (int)(this.xleft + 0.5F);
      if (i < 0)
        i = 0; 
      int j = (int)(this.xrght + 0.5F);
      if (j > this.SCREEN_WIDTH)
        j = this.SCREEN_WIDTH; 
      float f4 = i + 0.5F - this.xleft;
      int k = (int)(f1 * f4 + this.rleft);
      int m = (int)(f2 * f4 + this.gleft);
      int n = (int)(f3 * f4 + this.bleft);
      float f5 = this.izadd * f4 + this.zleft;
      i += paramInt1;
      j += paramInt1;
      while (i < j) {
        if (this.noDepthTest || f5 <= this.m_zbuffer[i]) {
          this.m_zbuffer[i] = f5;
          this.m_pixels[i] = 0xFF000000 | k & 0xFF0000 | m >> 8 & 0xFF00 | n >> 16;
        } 
        k += this.iradd;
        m += this.igadd;
        n += this.ibadd;
        f5 += this.izadd;
        i++;
      } 
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.rleft += this.rleftadd;
      this.gleft += this.gleftadd;
      this.bleft += this.bleftadd;
      this.zleft += this.zleftadd;
    } 
  }
  
  private void drawsegment_gouraud_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    float f1 = this.iradd;
    float f2 = this.igadd;
    float f3 = this.ibadd;
    float f4 = this.iaadd;
    while (paramInt1 < paramInt2) {
      int i = (int)(this.xleft + 0.5F);
      if (i < 0)
        i = 0; 
      int j = (int)(this.xrght + 0.5F);
      if (j > this.SCREEN_WIDTH)
        j = this.SCREEN_WIDTH; 
      float f5 = i + 0.5F - this.xleft;
      int k = (int)(f1 * f5 + this.rleft);
      int m = (int)(f2 * f5 + this.gleft);
      int n = (int)(f3 * f5 + this.bleft);
      int i1 = (int)(f4 * f5 + this.aleft);
      float f6 = this.izadd * f5 + this.zleft;
      i += paramInt1;
      j += paramInt1;
      while (i < j) {
        if (this.noDepthTest || f6 <= this.m_zbuffer[i]) {
          int i2 = k & 0xFF0000;
          int i3 = m >> 8 & 0xFF00;
          int i4 = n >> 16;
          int i5 = this.m_pixels[i];
          int i6 = i5 & 0xFF0000;
          int i7 = i5 & 0xFF00;
          i5 &= 0xFF;
          int i8 = i1 >> 16;
          this.m_pixels[i] = 0xFF000000 | i6 + ((i2 - i6) * i8 >> 8) & 0xFF0000 | i7 + ((i3 - i7) * i8 >> 8) & 0xFF00 | i5 + ((i4 - i5) * i8 >> 8) & 0xFF;
        } 
        k += this.iradd;
        m += this.igadd;
        n += this.ibadd;
        i1 += this.iaadd;
        f6 += this.izadd;
        i++;
      } 
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.rleft += this.rleftadd;
      this.gleft += this.gleftadd;
      this.bleft += this.bleftadd;
      this.aleft += this.aleftadd;
      this.zleft += this.zleftadd;
    } 
  }
  
  private void drawsegment_texture8(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    int i = paramInt1;
    int j = this.m_texture.length - this.TEX_WIDTH - 2;
    boolean bool = this.parent.hints[7];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int k = TEX_INTERP_POWER;
    int m = 1 << k;
    if (bool)
      if (precomputeAccurateTexturing()) {
        this.newax *= m;
        this.newbx *= m;
        this.newcx *= m;
        f3 = this.nearPlaneDepth;
        this.firstSegment = false;
      } else {
        bool = false;
      }  
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    float f7 = this.iuadd;
    float f8 = this.ivadd;
    int n = this.m_fill & 0xFF0000;
    int i1 = this.m_fill & 0xFF00;
    int i2 = this.m_fill & 0xFF;
    while (paramInt1 < paramInt2) {
      int i3 = (int)(this.xleft + 0.5F);
      if (i3 < 0)
        i3 = 0; 
      int i4 = i3;
      int i5 = (int)(this.xrght + 0.5F);
      if (i5 > this.SCREEN_WIDTH)
        i5 = this.SCREEN_WIDTH; 
      float f9 = i3 + 0.5F - this.xleft;
      int i6 = (int)(f7 * f9 + this.uleft);
      int i7 = (int)(f8 * f9 + this.vleft);
      float f10 = this.izadd * f9 + this.zleft;
      i3 += paramInt1;
      i5 += paramInt1;
      if (bool) {
        f1 = this.xmult * (i4 + 0.5F - this.SCREEN_WIDTH / 2.0F);
        f2 = this.ymult * (i + 0.5F - this.SCREEN_HEIGHT / 2.0F);
        f4 = f1 * this.ax + f2 * this.ay + f3 * this.az;
        f5 = f1 * this.bx + f2 * this.by + f3 * this.bz;
        f6 = f1 * this.cx + f2 * this.cy + f3 * this.cz;
      } 
      boolean bool1 = (((this.newcx > 0.0F) ? true : false) == ((f6 > 0.0F) ? true : false)) ? false : true;
      int i8 = 0;
      int i9 = 0;
      int i10 = 0;
      float f11 = 0.0F;
      float f12 = 0.0F;
      float f13 = 0.0F;
      float f14 = 0.0F;
      if (bool && bool1) {
        int i11 = (i5 - i3 - 1) % m;
        int i12 = m - i11;
        float f15 = i11 / m;
        float f16 = i12 / m;
        i8 = i12;
        float f17 = f4 - f16 * this.newax;
        float f18 = f5 - f16 * this.newbx;
        float f19 = f6 - f16 * this.newcx;
        float f20 = 65536.0F / f19;
        f13 = f17 * f20;
        f14 = f18 * f20;
        f4 += f15 * this.newax;
        f5 += f15 * this.newbx;
        f6 += f15 * this.newcx;
        f20 = 65536.0F / f6;
        f11 = f4 * f20;
        f12 = f5 * f20;
        i9 = (int)(f11 - f13) >> k;
        i10 = (int)(f12 - f14) >> k;
        i6 = (int)f13 + (i12 - 1) * i9;
        i7 = (int)f14 + (i12 - 1) * i10;
      } else {
        float f = 65536.0F / f6;
        f11 = f4 * f;
        f12 = f5 * f;
      } 
      while (i3 < i5) {
        if (bool) {
          if (i8 == m)
            i8 = 0; 
          if (i8 == 0) {
            f4 += this.newax;
            f5 += this.newbx;
            f6 += this.newcx;
            float f = 65536.0F / f6;
            f13 = f11;
            f14 = f12;
            f11 = f4 * f;
            f12 = f5 * f;
            i6 = (int)f13;
            i7 = (int)f14;
            i9 = (int)(f11 - f13) >> k;
            i10 = (int)(f12 - f14) >> k;
          } else {
            i6 += i9;
            i7 += i10;
          } 
          i8++;
        } 
        try {
          if (this.noDepthTest || f10 <= this.m_zbuffer[i3]) {
            int i11;
            if (this.m_bilinear) {
              int i15 = (i7 >> 16) * this.TEX_WIDTH + (i6 >> 16);
              int i16 = i6 & 0xFFFF;
              i11 = this.m_texture[i15] & 0xFF;
              int i17 = this.m_texture[i15 + 1] & 0xFF;
              if (i15 < j)
                i15 += this.TEX_WIDTH; 
              int i18 = this.m_texture[i15] & 0xFF;
              int i19 = this.m_texture[i15 + 1] & 0xFF;
              i11 += (i17 - i11) * i16 >> 16;
              i18 += (i19 - i18) * i16 >> 16;
              i11 += (i18 - i11) * (i7 & 0xFFFF) >> 16;
            } else {
              i11 = this.m_texture[(i7 >> 16) * this.TEX_WIDTH + (i6 >> 16)] & 0xFF;
            } 
            int i12 = this.m_pixels[i3];
            int i13 = i12 & 0xFF00;
            int i14 = i12 & 0xFF;
            i12 &= 0xFF0000;
            this.m_pixels[i3] = 0xFF000000 | i12 + ((n - i12) * i11 >> 8) & 0xFF0000 | i13 + ((i1 - i13) * i11 >> 8) & 0xFF00 | i14 + ((i2 - i14) * i11 >> 8) & 0xFF;
          } 
        } catch (Exception exception) {}
        i4++;
        if (!bool) {
          i6 += this.iuadd;
          i7 += this.ivadd;
        } 
        f10 += this.izadd;
        i3++;
      } 
      i++;
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.uleft += this.uleftadd;
      this.vleft += this.vleftadd;
      this.zleft += this.zleftadd;
    } 
  }
  
  private void drawsegment_texture8_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    int i = paramInt1;
    int j = this.m_texture.length - this.TEX_WIDTH - 2;
    boolean bool = this.parent.hints[7];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int k = TEX_INTERP_POWER;
    int m = 1 << k;
    if (bool)
      if (precomputeAccurateTexturing()) {
        this.newax *= m;
        this.newbx *= m;
        this.newcx *= m;
        f3 = this.nearPlaneDepth;
        this.firstSegment = false;
      } else {
        bool = false;
      }  
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    float f7 = this.iuadd;
    float f8 = this.ivadd;
    float f9 = this.iaadd;
    int n = this.m_fill & 0xFF0000;
    int i1 = this.m_fill & 0xFF00;
    int i2 = this.m_fill & 0xFF;
    while (paramInt1 < paramInt2) {
      int i3 = (int)(this.xleft + 0.5F);
      if (i3 < 0)
        i3 = 0; 
      int i4 = i3;
      int i5 = (int)(this.xrght + 0.5F);
      if (i5 > this.SCREEN_WIDTH)
        i5 = this.SCREEN_WIDTH; 
      float f10 = i3 + 0.5F - this.xleft;
      int i6 = (int)(f7 * f10 + this.uleft);
      int i7 = (int)(f8 * f10 + this.vleft);
      int i8 = (int)(f9 * f10 + this.aleft);
      float f11 = this.izadd * f10 + this.zleft;
      i3 += paramInt1;
      i5 += paramInt1;
      if (bool) {
        f1 = this.xmult * (i4 + 0.5F - this.SCREEN_WIDTH / 2.0F);
        f2 = this.ymult * (i + 0.5F - this.SCREEN_HEIGHT / 2.0F);
        f4 = f1 * this.ax + f2 * this.ay + f3 * this.az;
        f5 = f1 * this.bx + f2 * this.by + f3 * this.bz;
        f6 = f1 * this.cx + f2 * this.cy + f3 * this.cz;
      } 
      boolean bool1 = (((this.newcx > 0.0F) ? true : false) == ((f6 > 0.0F) ? true : false)) ? false : true;
      int i9 = 0;
      int i10 = 0;
      int i11 = 0;
      float f12 = 0.0F;
      float f13 = 0.0F;
      float f14 = 0.0F;
      float f15 = 0.0F;
      if (bool && bool1) {
        int i12 = (i5 - i3 - 1) % m;
        int i13 = m - i12;
        float f16 = i12 / m;
        float f17 = i13 / m;
        i9 = i13;
        float f18 = f4 - f17 * this.newax;
        float f19 = f5 - f17 * this.newbx;
        float f20 = f6 - f17 * this.newcx;
        float f21 = 65536.0F / f20;
        f14 = f18 * f21;
        f15 = f19 * f21;
        f4 += f16 * this.newax;
        f5 += f16 * this.newbx;
        f6 += f16 * this.newcx;
        f21 = 65536.0F / f6;
        f12 = f4 * f21;
        f13 = f5 * f21;
        i10 = (int)(f12 - f14) >> k;
        i11 = (int)(f13 - f15) >> k;
        i6 = (int)f14 + (i13 - 1) * i10;
        i7 = (int)f15 + (i13 - 1) * i11;
      } else {
        float f = 65536.0F / f6;
        f12 = f4 * f;
        f13 = f5 * f;
      } 
      while (i3 < i5) {
        if (bool) {
          if (i9 == m)
            i9 = 0; 
          if (i9 == 0) {
            f4 += this.newax;
            f5 += this.newbx;
            f6 += this.newcx;
            float f = 65536.0F / f6;
            f14 = f12;
            f15 = f13;
            f12 = f4 * f;
            f13 = f5 * f;
            i6 = (int)f14;
            i7 = (int)f15;
            i10 = (int)(f12 - f14) >> k;
            i11 = (int)(f13 - f15) >> k;
          } else {
            i6 += i10;
            i7 += i11;
          } 
          i9++;
        } 
        try {
          if (this.noDepthTest || f11 <= this.m_zbuffer[i3]) {
            if (this.m_bilinear) {
              int i16 = (i7 >> 16) * this.TEX_WIDTH + (i6 >> 16);
              int i17 = i6 & 0xFFFF;
              i12 = this.m_texture[i16] & 0xFF;
              int i18 = this.m_texture[i16 + 1] & 0xFF;
              if (i16 < j)
                i16 += this.TEX_WIDTH; 
              int i19 = this.m_texture[i16] & 0xFF;
              int i20 = this.m_texture[i16 + 1] & 0xFF;
              i12 += (i18 - i12) * i17 >> 16;
              i19 += (i20 - i19) * i17 >> 16;
              i12 += (i19 - i12) * (i7 & 0xFFFF) >> 16;
            } else {
              i12 = this.m_texture[(i7 >> 16) * this.TEX_WIDTH + (i6 >> 16)] & 0xFF;
            } 
            int i12 = i12 * (i8 >> 16) >> 8;
            int i13 = this.m_pixels[i3];
            int i14 = i13 & 0xFF00;
            int i15 = i13 & 0xFF;
            i13 &= 0xFF0000;
            this.m_pixels[i3] = 0xFF000000 | i13 + ((n - i13) * i12 >> 8) & 0xFF0000 | i14 + ((i1 - i14) * i12 >> 8) & 0xFF00 | i15 + ((i2 - i15) * i12 >> 8) & 0xFF;
          } 
        } catch (Exception exception) {}
        i4++;
        if (!bool) {
          i6 += this.iuadd;
          i7 += this.ivadd;
        } 
        f11 += this.izadd;
        i8 += this.iaadd;
        i3++;
      } 
      i++;
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.uleft += this.uleftadd;
      this.vleft += this.vleftadd;
      this.zleft += this.zleftadd;
      this.aleft += this.aleftadd;
    } 
  }
  
  private void drawsegment_texture24(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    float f1 = this.iuadd;
    float f2 = this.ivadd;
    boolean bool = ((this.m_fill & 0xFFFFFF) != 16777215) ? true : false;
    int i = this.m_fill >> 16 & 0xFF;
    int j = this.m_fill >> 8 & 0xFF;
    int k = this.m_fill & 0xFF;
    int m = paramInt1 / this.SCREEN_WIDTH;
    int n = this.m_texture.length - this.TEX_WIDTH - 2;
    boolean bool1 = this.parent.hints[7];
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    float f7 = 0.0F;
    float f8 = 0.0F;
    int i1 = TEX_INTERP_POWER;
    int i2 = 1 << i1;
    if (bool1)
      if (precomputeAccurateTexturing()) {
        this.newax *= i2;
        this.newbx *= i2;
        this.newcx *= i2;
        f5 = this.nearPlaneDepth;
        this.firstSegment = false;
      } else {
        bool1 = false;
      }  
    while (paramInt1 < paramInt2) {
      int i3 = (int)(this.xleft + 0.5F);
      if (i3 < 0)
        i3 = 0; 
      int i4 = i3;
      int i5 = (int)(this.xrght + 0.5F);
      if (i5 > this.SCREEN_WIDTH)
        i5 = this.SCREEN_WIDTH; 
      float f9 = i3 + 0.5F - this.xleft;
      int i6 = (int)(f1 * f9 + this.uleft);
      int i7 = (int)(f2 * f9 + this.vleft);
      float f10 = this.izadd * f9 + this.zleft;
      i3 += paramInt1;
      i5 += paramInt1;
      if (bool1) {
        f3 = this.xmult * (i4 + 0.5F - this.SCREEN_WIDTH / 2.0F);
        f4 = this.ymult * (m + 0.5F - this.SCREEN_HEIGHT / 2.0F);
        f6 = f3 * this.ax + f4 * this.ay + f5 * this.az;
        f7 = f3 * this.bx + f4 * this.by + f5 * this.bz;
        f8 = f3 * this.cx + f4 * this.cy + f5 * this.cz;
      } 
      boolean bool2 = (((this.newcx > 0.0F) ? true : false) == ((f8 > 0.0F) ? true : false)) ? false : true;
      int i8 = 0;
      int i9 = 0;
      int i10 = 0;
      float f11 = 0.0F;
      float f12 = 0.0F;
      float f13 = 0.0F;
      float f14 = 0.0F;
      if (bool1 && bool2) {
        int i11 = (i5 - i3 - 1) % i2;
        int i12 = i2 - i11;
        float f15 = i11 / i2;
        float f16 = i12 / i2;
        i8 = i12;
        float f17 = f6 - f16 * this.newax;
        float f18 = f7 - f16 * this.newbx;
        float f19 = f8 - f16 * this.newcx;
        float f20 = 65536.0F / f19;
        f13 = f17 * f20;
        f14 = f18 * f20;
        f6 += f15 * this.newax;
        f7 += f15 * this.newbx;
        f8 += f15 * this.newcx;
        f20 = 65536.0F / f8;
        f11 = f6 * f20;
        f12 = f7 * f20;
        i9 = (int)(f11 - f13) >> i1;
        i10 = (int)(f12 - f14) >> i1;
        i6 = (int)f13 + (i12 - 1) * i9;
        i7 = (int)f14 + (i12 - 1) * i10;
      } else {
        float f = 65536.0F / f8;
        f11 = f6 * f;
        f12 = f7 * f;
      } 
      while (i3 < i5) {
        if (bool1) {
          if (i8 == i2)
            i8 = 0; 
          if (i8 == 0) {
            f6 += this.newax;
            f7 += this.newbx;
            f8 += this.newcx;
            float f = 65536.0F / f8;
            f13 = f11;
            f14 = f12;
            f11 = f6 * f;
            f12 = f7 * f;
            i6 = (int)f13;
            i7 = (int)f14;
            i9 = (int)(f11 - f13) >> i1;
            i10 = (int)(f12 - f14) >> i1;
          } else {
            i6 += i9;
            i7 += i10;
          } 
          i8++;
        } 
        try {
          if (this.noDepthTest || f10 <= this.m_zbuffer[i3]) {
            this.m_zbuffer[i3] = f10;
            if (this.m_bilinear) {
              int i11 = (i7 >> 16) * this.TEX_WIDTH + (i6 >> 16);
              int i12 = (i6 & 0xFFFF) >> 9;
              int i13 = (i7 & 0xFFFF) >> 9;
              int i14 = this.m_texture[i11];
              int i15 = this.m_texture[i11 + 1];
              if (i11 < n)
                i11 += this.TEX_WIDTH; 
              int i16 = this.m_texture[i11];
              int i17 = this.m_texture[i11 + 1];
              int i18 = i14 & 0xFF0000;
              int i19 = i16 & 0xFF0000;
              int i20 = i18 + (((i15 & 0xFF0000) - i18) * i12 >> 7);
              int i21 = i19 + (((i17 & 0xFF0000) - i19) * i12 >> 7);
              int i22 = i20 + ((i21 - i20) * i13 >> 7);
              if (bool)
                i22 = i22 * i >> 8 & 0xFF0000; 
              i18 = i14 & 0xFF00;
              i19 = i16 & 0xFF00;
              i20 = i18 + (((i15 & 0xFF00) - i18) * i12 >> 7);
              i21 = i19 + (((i17 & 0xFF00) - i19) * i12 >> 7);
              int i23 = i20 + ((i21 - i20) * i13 >> 7);
              if (bool)
                i23 = i23 * j >> 8 & 0xFF00; 
              i18 = i14 & 0xFF;
              i19 = i16 & 0xFF;
              i20 = i18 + (((i15 & 0xFF) - i18) * i12 >> 7);
              i21 = i19 + (((i17 & 0xFF) - i19) * i12 >> 7);
              int i24 = i20 + ((i21 - i20) * i13 >> 7);
              if (bool)
                i24 = i24 * k >> 8 & 0xFF; 
              this.m_pixels[i3] = 0xFF000000 | i22 & 0xFF0000 | i23 & 0xFF00 | i24 & 0xFF;
            } else {
              this.m_pixels[i3] = this.m_texture[(i7 >> 16) * this.TEX_WIDTH + (i6 >> 16)];
            } 
          } 
        } catch (Exception exception) {}
        f10 += this.izadd;
        i4++;
        if (!bool1) {
          i6 += this.iuadd;
          i7 += this.ivadd;
        } 
        i3++;
      } 
      m++;
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.zleft += this.zleftadd;
      this.uleft += this.uleftadd;
      this.vleft += this.vleftadd;
    } 
  }
  
  private void drawsegment_texture24_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    int i = paramInt1;
    int j = this.m_texture.length - this.TEX_WIDTH - 2;
    boolean bool = this.parent.hints[7];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int k = TEX_INTERP_POWER;
    int m = 1 << k;
    if (bool)
      if (precomputeAccurateTexturing()) {
        this.newax *= m;
        this.newbx *= m;
        this.newcx *= m;
        f3 = this.nearPlaneDepth;
        this.firstSegment = false;
      } else {
        bool = false;
      }  
    boolean bool1 = ((this.m_fill & 0xFFFFFF) != 16777215) ? true : false;
    int n = this.m_fill >> 16 & 0xFF;
    int i1 = this.m_fill >> 8 & 0xFF;
    int i2 = this.m_fill & 0xFF;
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    float f7 = this.iuadd;
    float f8 = this.ivadd;
    float f9 = this.iaadd;
    while (paramInt1 < paramInt2) {
      int i3 = (int)(this.xleft + 0.5F);
      if (i3 < 0)
        i3 = 0; 
      int i4 = i3;
      int i5 = (int)(this.xrght + 0.5F);
      if (i5 > this.SCREEN_WIDTH)
        i5 = this.SCREEN_WIDTH; 
      float f10 = i3 + 0.5F - this.xleft;
      int i6 = (int)(f7 * f10 + this.uleft);
      int i7 = (int)(f8 * f10 + this.vleft);
      int i8 = (int)(f9 * f10 + this.aleft);
      float f11 = this.izadd * f10 + this.zleft;
      i3 += paramInt1;
      i5 += paramInt1;
      if (bool) {
        f1 = this.xmult * (i4 + 0.5F - this.SCREEN_WIDTH / 2.0F);
        f2 = this.ymult * (i + 0.5F - this.SCREEN_HEIGHT / 2.0F);
        f4 = f1 * this.ax + f2 * this.ay + f3 * this.az;
        f5 = f1 * this.bx + f2 * this.by + f3 * this.bz;
        f6 = f1 * this.cx + f2 * this.cy + f3 * this.cz;
      } 
      boolean bool2 = (((this.newcx > 0.0F) ? true : false) == ((f6 > 0.0F) ? true : false)) ? false : true;
      int i9 = 0;
      int i10 = 0;
      int i11 = 0;
      float f12 = 0.0F;
      float f13 = 0.0F;
      float f14 = 0.0F;
      float f15 = 0.0F;
      if (bool && bool2) {
        int i12 = (i5 - i3 - 1) % m;
        int i13 = m - i12;
        float f16 = i12 / m;
        float f17 = i13 / m;
        i9 = i13;
        float f18 = f4 - f17 * this.newax;
        float f19 = f5 - f17 * this.newbx;
        float f20 = f6 - f17 * this.newcx;
        float f21 = 65536.0F / f20;
        f14 = f18 * f21;
        f15 = f19 * f21;
        f4 += f16 * this.newax;
        f5 += f16 * this.newbx;
        f6 += f16 * this.newcx;
        f21 = 65536.0F / f6;
        f12 = f4 * f21;
        f13 = f5 * f21;
        i10 = (int)(f12 - f14) >> k;
        i11 = (int)(f13 - f15) >> k;
        i6 = (int)f14 + (i13 - 1) * i10;
        i7 = (int)f15 + (i13 - 1) * i11;
      } else {
        float f = 65536.0F / f6;
        f12 = f4 * f;
        f13 = f5 * f;
      } 
      while (i3 < i5) {
        if (bool) {
          if (i9 == m)
            i9 = 0; 
          if (i9 == 0) {
            f4 += this.newax;
            f5 += this.newbx;
            f6 += this.newcx;
            float f = 65536.0F / f6;
            f14 = f12;
            f15 = f13;
            f12 = f4 * f;
            f13 = f5 * f;
            i6 = (int)f14;
            i7 = (int)f15;
            i10 = (int)(f12 - f14) >> k;
            i11 = (int)(f13 - f15) >> k;
          } else {
            i6 += i10;
            i7 += i11;
          } 
          i9++;
        } 
        try {
          if (this.noDepthTest || f11 <= this.m_zbuffer[i3]) {
            int i12 = i8 >> 16;
            if (this.m_bilinear) {
              int i13 = (i7 >> 16) * this.TEX_WIDTH + (i6 >> 16);
              int i14 = (i6 & 0xFFFF) >> 9;
              int i15 = (i7 & 0xFFFF) >> 9;
              int i16 = this.m_texture[i13];
              int i17 = this.m_texture[i13 + 1];
              if (i13 < j)
                i13 += this.TEX_WIDTH; 
              int i18 = this.m_texture[i13];
              int i19 = this.m_texture[i13 + 1];
              int i20 = i16 & 0xFF0000;
              int i21 = i18 & 0xFF0000;
              int i22 = i20 + (((i17 & 0xFF0000) - i20) * i14 >> 7);
              int i23 = i21 + (((i19 & 0xFF0000) - i21) * i14 >> 7);
              int i24 = i22 + ((i23 - i22) * i15 >> 7);
              if (bool1)
                i24 = i24 * n >> 8 & 0xFF0000; 
              i20 = i16 & 0xFF00;
              i21 = i18 & 0xFF00;
              i22 = i20 + (((i17 & 0xFF00) - i20) * i14 >> 7);
              i23 = i21 + (((i19 & 0xFF00) - i21) * i14 >> 7);
              int i25 = i22 + ((i23 - i22) * i15 >> 7);
              if (bool1)
                i25 = i25 * i1 >> 8 & 0xFF00; 
              i20 = i16 & 0xFF;
              i21 = i18 & 0xFF;
              i22 = i20 + (((i17 & 0xFF) - i20) * i14 >> 7);
              i23 = i21 + (((i19 & 0xFF) - i21) * i14 >> 7);
              int i26 = i22 + ((i23 - i22) * i15 >> 7);
              if (bool1)
                i26 = i26 * i2 >> 8 & 0xFF; 
              int i27 = this.m_pixels[i3];
              int i28 = i27 & 0xFF0000;
              int i29 = i27 & 0xFF00;
              i27 &= 0xFF;
              this.m_pixels[i3] = 0xFF000000 | i28 + ((i24 - i28) * i12 >> 8) & 0xFF0000 | i29 + ((i25 - i29) * i12 >> 8) & 0xFF00 | i27 + ((i26 - i27) * i12 >> 8) & 0xFF;
            } else {
              int i13 = this.m_texture[(i7 >> 16) * this.TEX_WIDTH + (i6 >> 16)];
              int i14 = i13 & 0xFF00;
              int i15 = i13 & 0xFF;
              i13 &= 0xFF0000;
              int i16 = this.m_pixels[i3];
              int i17 = i16 & 0xFF0000;
              int i18 = i16 & 0xFF00;
              i16 &= 0xFF;
              this.m_pixels[i3] = 0xFF000000 | i17 + ((i13 - i17) * i12 >> 8) & 0xFF0000 | i18 + ((i14 - i18) * i12 >> 8) & 0xFF00 | i16 + ((i15 - i16) * i12 >> 8) & 0xFF;
            } 
          } 
        } catch (Exception exception) {}
        i4++;
        if (!bool) {
          i6 += this.iuadd;
          i7 += this.ivadd;
        } 
        i8 += this.iaadd;
        f11 += this.izadd;
        i3++;
      } 
      i++;
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.uleft += this.uleftadd;
      this.vleft += this.vleftadd;
      this.zleft += this.zleftadd;
      this.aleft += this.aleftadd;
    } 
  }
  
  private void drawsegment_texture32(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    int i = paramInt1;
    int j = this.m_texture.length - this.TEX_WIDTH - 2;
    boolean bool = this.parent.hints[7];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int k = TEX_INTERP_POWER;
    int m = 1 << k;
    if (bool)
      if (precomputeAccurateTexturing()) {
        this.newax *= m;
        this.newbx *= m;
        this.newcx *= m;
        f3 = this.nearPlaneDepth;
        this.firstSegment = false;
      } else {
        bool = false;
      }  
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    boolean bool1 = (this.m_fill != -1) ? true : false;
    int n = this.m_fill >> 16 & 0xFF;
    int i1 = this.m_fill >> 8 & 0xFF;
    int i2 = this.m_fill & 0xFF;
    float f7 = this.iuadd;
    float f8 = this.ivadd;
    while (paramInt1 < paramInt2) {
      int i3 = (int)(this.xleft + 0.5F);
      if (i3 < 0)
        i3 = 0; 
      int i4 = i3;
      int i5 = (int)(this.xrght + 0.5F);
      if (i5 > this.SCREEN_WIDTH)
        i5 = this.SCREEN_WIDTH; 
      float f9 = i3 + 0.5F - this.xleft;
      int i6 = (int)(f7 * f9 + this.uleft);
      int i7 = (int)(f8 * f9 + this.vleft);
      float f10 = this.izadd * f9 + this.zleft;
      i3 += paramInt1;
      i5 += paramInt1;
      if (bool) {
        f1 = this.xmult * (i4 + 0.5F - this.SCREEN_WIDTH / 2.0F);
        f2 = this.ymult * (i + 0.5F - this.SCREEN_HEIGHT / 2.0F);
        f4 = f1 * this.ax + f2 * this.ay + f3 * this.az;
        f5 = f1 * this.bx + f2 * this.by + f3 * this.bz;
        f6 = f1 * this.cx + f2 * this.cy + f3 * this.cz;
      } 
      boolean bool2 = (((this.newcx > 0.0F) ? true : false) == ((f6 > 0.0F) ? true : false)) ? false : true;
      int i8 = 0;
      int i9 = 0;
      int i10 = 0;
      float f11 = 0.0F;
      float f12 = 0.0F;
      float f13 = 0.0F;
      float f14 = 0.0F;
      if (bool && bool2) {
        int i11 = (i5 - i3 - 1) % m;
        int i12 = m - i11;
        float f15 = i11 / m;
        float f16 = i12 / m;
        i8 = i12;
        float f17 = f4 - f16 * this.newax;
        float f18 = f5 - f16 * this.newbx;
        float f19 = f6 - f16 * this.newcx;
        float f20 = 65536.0F / f19;
        f13 = f17 * f20;
        f14 = f18 * f20;
        f4 += f15 * this.newax;
        f5 += f15 * this.newbx;
        f6 += f15 * this.newcx;
        f20 = 65536.0F / f6;
        f11 = f4 * f20;
        f12 = f5 * f20;
        i9 = (int)(f11 - f13) >> k;
        i10 = (int)(f12 - f14) >> k;
        i6 = (int)f13 + (i12 - 1) * i9;
        i7 = (int)f14 + (i12 - 1) * i10;
      } else {
        float f = 65536.0F / f6;
        f11 = f4 * f;
        f12 = f5 * f;
      } 
      while (i3 < i5) {
        if (bool) {
          if (i8 == m)
            i8 = 0; 
          if (i8 == 0) {
            f4 += this.newax;
            f5 += this.newbx;
            f6 += this.newcx;
            float f = 65536.0F / f6;
            f13 = f11;
            f14 = f12;
            f11 = f4 * f;
            f12 = f5 * f;
            i6 = (int)f13;
            i7 = (int)f14;
            i9 = (int)(f11 - f13) >> k;
            i10 = (int)(f12 - f14) >> k;
          } else {
            i6 += i9;
            i7 += i10;
          } 
          i8++;
        } 
        try {
          if (this.noDepthTest || f10 <= this.m_zbuffer[i3])
            if (this.m_bilinear) {
              int i11 = (i7 >> 16) * this.TEX_WIDTH + (i6 >> 16);
              int i12 = (i6 & 0xFFFF) >> 9;
              int i13 = (i7 & 0xFFFF) >> 9;
              int i14 = this.m_texture[i11];
              int i15 = this.m_texture[i11 + 1];
              if (i11 < j)
                i11 += this.TEX_WIDTH; 
              int i16 = this.m_texture[i11];
              int i17 = this.m_texture[i11 + 1];
              int i18 = i14 & 0xFF0000;
              int i19 = i16 & 0xFF0000;
              int i20 = i18 + (((i15 & 0xFF0000) - i18) * i12 >> 7);
              int i21 = i19 + (((i17 & 0xFF0000) - i19) * i12 >> 7);
              int i22 = i20 + ((i21 - i20) * i13 >> 7);
              if (bool1)
                i22 = i22 * n >> 8 & 0xFF0000; 
              i18 = i14 & 0xFF00;
              i19 = i16 & 0xFF00;
              i20 = i18 + (((i15 & 0xFF00) - i18) * i12 >> 7);
              i21 = i19 + (((i17 & 0xFF00) - i19) * i12 >> 7);
              int i23 = i20 + ((i21 - i20) * i13 >> 7);
              if (bool1)
                i23 = i23 * i1 >> 8 & 0xFF00; 
              i18 = i14 & 0xFF;
              i19 = i16 & 0xFF;
              i20 = i18 + (((i15 & 0xFF) - i18) * i12 >> 7);
              i21 = i19 + (((i17 & 0xFF) - i19) * i12 >> 7);
              int i24 = i20 + ((i21 - i20) * i13 >> 7);
              if (bool1)
                i24 = i24 * i2 >> 8 & 0xFF; 
              i14 >>>= 24;
              i16 >>>= 24;
              i20 = i14 + (((i15 >>> 24) - i14) * i12 >> 7);
              i21 = i16 + (((i17 >>> 24) - i16) * i12 >> 7);
              int i25 = i20 + ((i21 - i20) * i13 >> 7);
              int i26 = this.m_pixels[i3];
              int i27 = i26 & 0xFF0000;
              int i28 = i26 & 0xFF00;
              i26 &= 0xFF;
              this.m_pixels[i3] = 0xFF000000 | i27 + ((i22 - i27) * i25 >> 8) & 0xFF0000 | i28 + ((i23 - i28) * i25 >> 8) & 0xFF00 | i26 + ((i24 - i26) * i25 >> 8) & 0xFF;
            } else {
              int i11 = this.m_texture[(i7 >> 16) * this.TEX_WIDTH + (i6 >> 16)];
              int i12 = i11 >>> 24;
              int i13 = i11 & 0xFF00;
              int i14 = i11 & 0xFF;
              i11 &= 0xFF0000;
              int i15 = this.m_pixels[i3];
              int i16 = i15 & 0xFF0000;
              int i17 = i15 & 0xFF00;
              i15 &= 0xFF;
              this.m_pixels[i3] = 0xFF000000 | i16 + ((i11 - i16) * i12 >> 8) & 0xFF0000 | i17 + ((i13 - i17) * i12 >> 8) & 0xFF00 | i15 + ((i14 - i15) * i12 >> 8) & 0xFF;
            }  
        } catch (Exception exception) {}
        i4++;
        if (!bool) {
          i6 += this.iuadd;
          i7 += this.ivadd;
        } 
        f10 += this.izadd;
        i3++;
      } 
      i++;
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.uleft += this.uleftadd;
      this.vleft += this.vleftadd;
      this.zleft += this.zleftadd;
      this.aleft += this.aleftadd;
    } 
  }
  
  private void drawsegment_texture32_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    int i = paramInt1;
    int j = this.m_texture.length - this.TEX_WIDTH - 2;
    boolean bool = this.parent.hints[7];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int k = TEX_INTERP_POWER;
    int m = 1 << k;
    if (bool)
      if (precomputeAccurateTexturing()) {
        this.newax *= m;
        this.newbx *= m;
        this.newcx *= m;
        f3 = this.nearPlaneDepth;
        this.firstSegment = false;
      } else {
        bool = false;
      }  
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    boolean bool1 = ((this.m_fill & 0xFFFFFF) != 16777215) ? true : false;
    int n = this.m_fill >> 16 & 0xFF;
    int i1 = this.m_fill >> 8 & 0xFF;
    int i2 = this.m_fill & 0xFF;
    float f7 = this.iuadd;
    float f8 = this.ivadd;
    float f9 = this.iaadd;
    while (paramInt1 < paramInt2) {
      int i3 = (int)(this.xleft + 0.5F);
      if (i3 < 0)
        i3 = 0; 
      int i4 = i3;
      int i5 = (int)(this.xrght + 0.5F);
      if (i5 > this.SCREEN_WIDTH)
        i5 = this.SCREEN_WIDTH; 
      float f10 = i3 + 0.5F - this.xleft;
      int i6 = (int)(f7 * f10 + this.uleft);
      int i7 = (int)(f8 * f10 + this.vleft);
      int i8 = (int)(f9 * f10 + this.aleft);
      float f11 = this.izadd * f10 + this.zleft;
      i3 += paramInt1;
      i5 += paramInt1;
      if (bool) {
        f1 = this.xmult * (i4 + 0.5F - this.SCREEN_WIDTH / 2.0F);
        f2 = this.ymult * (i + 0.5F - this.SCREEN_HEIGHT / 2.0F);
        f4 = f1 * this.ax + f2 * this.ay + f3 * this.az;
        f5 = f1 * this.bx + f2 * this.by + f3 * this.bz;
        f6 = f1 * this.cx + f2 * this.cy + f3 * this.cz;
      } 
      boolean bool2 = (((this.newcx > 0.0F) ? true : false) == ((f6 > 0.0F) ? true : false)) ? false : true;
      int i9 = 0;
      int i10 = 0;
      int i11 = 0;
      float f12 = 0.0F;
      float f13 = 0.0F;
      float f14 = 0.0F;
      float f15 = 0.0F;
      if (bool && bool2) {
        int i12 = (i5 - i3 - 1) % m;
        int i13 = m - i12;
        float f16 = i12 / m;
        float f17 = i13 / m;
        i9 = i13;
        float f18 = f4 - f17 * this.newax;
        float f19 = f5 - f17 * this.newbx;
        float f20 = f6 - f17 * this.newcx;
        float f21 = 65536.0F / f20;
        f14 = f18 * f21;
        f15 = f19 * f21;
        f4 += f16 * this.newax;
        f5 += f16 * this.newbx;
        f6 += f16 * this.newcx;
        f21 = 65536.0F / f6;
        f12 = f4 * f21;
        f13 = f5 * f21;
        i10 = (int)(f12 - f14) >> k;
        i11 = (int)(f13 - f15) >> k;
        i6 = (int)f14 + (i13 - 1) * i10;
        i7 = (int)f15 + (i13 - 1) * i11;
      } else {
        float f = 65536.0F / f6;
        f12 = f4 * f;
        f13 = f5 * f;
      } 
      while (i3 < i5) {
        if (bool) {
          if (i9 == m)
            i9 = 0; 
          if (i9 == 0) {
            f4 += this.newax;
            f5 += this.newbx;
            f6 += this.newcx;
            float f = 65536.0F / f6;
            f14 = f12;
            f15 = f13;
            f12 = f4 * f;
            f13 = f5 * f;
            i6 = (int)f14;
            i7 = (int)f15;
            i10 = (int)(f12 - f14) >> k;
            i11 = (int)(f13 - f15) >> k;
          } else {
            i6 += i10;
            i7 += i11;
          } 
          i9++;
        } 
        try {
          if (this.noDepthTest || f11 <= this.m_zbuffer[i3]) {
            int i12 = i8 >> 16;
            if (this.m_bilinear) {
              int i13 = (i7 >> 16) * this.TEX_WIDTH + (i6 >> 16);
              int i14 = (i6 & 0xFFFF) >> 9;
              int i15 = (i7 & 0xFFFF) >> 9;
              int i16 = this.m_texture[i13];
              int i17 = this.m_texture[i13 + 1];
              if (i13 < j)
                i13 += this.TEX_WIDTH; 
              int i18 = this.m_texture[i13];
              int i19 = this.m_texture[i13 + 1];
              int i20 = i16 & 0xFF0000;
              int i21 = i18 & 0xFF0000;
              int i22 = i20 + (((i17 & 0xFF0000) - i20) * i14 >> 7);
              int i23 = i21 + (((i19 & 0xFF0000) - i21) * i14 >> 7);
              int i24 = i22 + ((i23 - i22) * i15 >> 7);
              if (bool1)
                i24 = i24 * n >> 8 & 0xFF0000; 
              i20 = i16 & 0xFF00;
              i21 = i18 & 0xFF00;
              i22 = i20 + (((i17 & 0xFF00) - i20) * i14 >> 7);
              i23 = i21 + (((i19 & 0xFF00) - i21) * i14 >> 7);
              int i25 = i22 + ((i23 - i22) * i15 >> 7);
              if (bool1)
                i25 = i25 * i1 >> 8 & 0xFF00; 
              i20 = i16 & 0xFF;
              i21 = i18 & 0xFF;
              i22 = i20 + (((i17 & 0xFF) - i20) * i14 >> 7);
              i23 = i21 + (((i19 & 0xFF) - i21) * i14 >> 7);
              int i26 = i22 + ((i23 - i22) * i15 >> 7);
              if (bool1)
                i26 = i26 * i2 >> 8 & 0xFF; 
              i16 >>>= 24;
              i18 >>>= 24;
              i22 = i16 + (((i17 >>> 24) - i16) * i14 >> 7);
              i23 = i18 + (((i19 >>> 24) - i18) * i14 >> 7);
              i12 = i12 * (i22 + ((i23 - i22) * i15 >> 7)) >> 8;
              int i27 = this.m_pixels[i3];
              int i28 = i27 & 0xFF0000;
              int i29 = i27 & 0xFF00;
              i27 &= 0xFF;
              this.m_pixels[i3] = 0xFF000000 | i28 + ((i24 - i28) * i12 >> 8) & 0xFF0000 | i29 + ((i25 - i29) * i12 >> 8) & 0xFF00 | i27 + ((i26 - i27) * i12 >> 8) & 0xFF;
            } else {
              int i13 = this.m_texture[(i7 >> 16) * this.TEX_WIDTH + (i6 >> 16)];
              i12 = i12 * (i13 >>> 24) >> 8;
              int i14 = i13 & 0xFF00;
              int i15 = i13 & 0xFF;
              i13 &= 0xFF0000;
              int i16 = this.m_pixels[i3];
              int i17 = i16 & 0xFF0000;
              int i18 = i16 & 0xFF00;
              i16 &= 0xFF;
              this.m_pixels[i3] = 0xFF000000 | i17 + ((i13 - i17) * i12 >> 8) & 0xFF0000 | i18 + ((i14 - i18) * i12 >> 8) & 0xFF00 | i16 + ((i15 - i16) * i12 >> 8) & 0xFF;
            } 
          } 
        } catch (Exception exception) {}
        i4++;
        if (!bool) {
          i6 += this.iuadd;
          i7 += this.ivadd;
        } 
        i8 += this.iaadd;
        f11 += this.izadd;
        i3++;
      } 
      i++;
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.uleft += this.uleftadd;
      this.vleft += this.vleftadd;
      this.zleft += this.zleftadd;
      this.aleft += this.aleftadd;
    } 
  }
  
  private void drawsegment_gouraud_texture8(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    int i = paramInt1;
    int j = this.m_texture.length - this.TEX_WIDTH - 2;
    boolean bool = this.parent.hints[7];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int k = TEX_INTERP_POWER;
    int m = 1 << k;
    if (bool)
      if (precomputeAccurateTexturing()) {
        this.newax *= m;
        this.newbx *= m;
        this.newcx *= m;
        f3 = this.nearPlaneDepth;
        this.firstSegment = false;
      } else {
        bool = false;
      }  
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    float f7 = this.iuadd;
    float f8 = this.ivadd;
    float f9 = this.iradd;
    float f10 = this.igadd;
    float f11 = this.ibadd;
    while (paramInt1 < paramInt2) {
      int n = (int)(this.xleft + 0.5F);
      if (n < 0)
        n = 0; 
      int i1 = n;
      int i2 = (int)(this.xrght + 0.5F);
      if (i2 > this.SCREEN_WIDTH)
        i2 = this.SCREEN_WIDTH; 
      float f12 = n + 0.5F - this.xleft;
      int i3 = (int)(f7 * f12 + this.uleft);
      int i4 = (int)(f8 * f12 + this.vleft);
      int i5 = (int)(f9 * f12 + this.rleft);
      int i6 = (int)(f10 * f12 + this.gleft);
      int i7 = (int)(f11 * f12 + this.bleft);
      float f13 = this.izadd * f12 + this.zleft;
      n += paramInt1;
      i2 += paramInt1;
      if (bool) {
        f1 = this.xmult * (i1 + 0.5F - this.SCREEN_WIDTH / 2.0F);
        f2 = this.ymult * (i + 0.5F - this.SCREEN_HEIGHT / 2.0F);
        f4 = f1 * this.ax + f2 * this.ay + f3 * this.az;
        f5 = f1 * this.bx + f2 * this.by + f3 * this.bz;
        f6 = f1 * this.cx + f2 * this.cy + f3 * this.cz;
      } 
      boolean bool1 = (((this.newcx > 0.0F) ? true : false) == ((f6 > 0.0F) ? true : false)) ? false : true;
      int i8 = 0;
      int i9 = 0;
      int i10 = 0;
      float f14 = 0.0F;
      float f15 = 0.0F;
      float f16 = 0.0F;
      float f17 = 0.0F;
      if (bool && bool1) {
        int i11 = (i2 - n - 1) % m;
        int i12 = m - i11;
        float f18 = i11 / m;
        float f19 = i12 / m;
        i8 = i12;
        float f20 = f4 - f19 * this.newax;
        float f21 = f5 - f19 * this.newbx;
        float f22 = f6 - f19 * this.newcx;
        float f23 = 65536.0F / f22;
        f16 = f20 * f23;
        f17 = f21 * f23;
        f4 += f18 * this.newax;
        f5 += f18 * this.newbx;
        f6 += f18 * this.newcx;
        f23 = 65536.0F / f6;
        f14 = f4 * f23;
        f15 = f5 * f23;
        i9 = (int)(f14 - f16) >> k;
        i10 = (int)(f15 - f17) >> k;
        i3 = (int)f16 + (i12 - 1) * i9;
        i4 = (int)f17 + (i12 - 1) * i10;
      } else {
        float f = 65536.0F / f6;
        f14 = f4 * f;
        f15 = f5 * f;
      } 
      while (n < i2) {
        if (bool) {
          if (i8 == m)
            i8 = 0; 
          if (i8 == 0) {
            f4 += this.newax;
            f5 += this.newbx;
            f6 += this.newcx;
            float f = 65536.0F / f6;
            f16 = f14;
            f17 = f15;
            f14 = f4 * f;
            f15 = f5 * f;
            i3 = (int)f16;
            i4 = (int)f17;
            i9 = (int)(f14 - f16) >> k;
            i10 = (int)(f15 - f17) >> k;
          } else {
            i3 += i9;
            i4 += i10;
          } 
          i8++;
        } 
        try {
          if (this.noDepthTest || f13 <= this.m_zbuffer[n]) {
            int i11;
            if (this.m_bilinear) {
              int i18 = (i4 >> 16) * this.TEX_WIDTH + (i3 >> 16);
              int i19 = i3 & 0xFFFF;
              i11 = this.m_texture[i18] & 0xFF;
              int i20 = this.m_texture[i18 + 1] & 0xFF;
              if (i18 < j)
                i18 += this.TEX_WIDTH; 
              int i21 = this.m_texture[i18] & 0xFF;
              int i22 = this.m_texture[i18 + 1] & 0xFF;
              i11 += (i20 - i11) * i19 >> 16;
              i21 += (i22 - i21) * i19 >> 16;
              i11 += (i21 - i11) * (i4 & 0xFFFF) >> 16;
            } else {
              i11 = this.m_texture[(i4 >> 16) * this.TEX_WIDTH + (i3 >> 16)] & 0xFF;
            } 
            int i12 = i5 & 0xFF0000;
            int i13 = i6 >> 8 & 0xFF00;
            int i14 = i7 >> 16;
            int i15 = this.m_pixels[n];
            int i16 = i15 & 0xFF0000;
            int i17 = i15 & 0xFF00;
            i15 &= 0xFF;
            this.m_pixels[n] = 0xFF000000 | i16 + ((i12 - i16) * i11 >> 8) & 0xFF0000 | i17 + ((i13 - i17) * i11 >> 8) & 0xFF00 | i15 + ((i14 - i15) * i11 >> 8) & 0xFF;
          } 
        } catch (Exception exception) {}
        i1++;
        if (!bool) {
          i3 += this.iuadd;
          i4 += this.ivadd;
        } 
        i5 += this.iradd;
        i6 += this.igadd;
        i7 += this.ibadd;
        f13 += this.izadd;
        n++;
      } 
      i++;
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.uleft += this.uleftadd;
      this.vleft += this.vleftadd;
      this.rleft += this.rleftadd;
      this.gleft += this.gleftadd;
      this.bleft += this.bleftadd;
      this.zleft += this.zleftadd;
    } 
  }
  
  private void drawsegment_gouraud_texture8_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    int i = paramInt1;
    int j = this.m_texture.length - this.TEX_WIDTH - 2;
    boolean bool = this.parent.hints[7];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int k = TEX_INTERP_POWER;
    int m = 1 << k;
    if (bool)
      if (precomputeAccurateTexturing()) {
        this.newax *= m;
        this.newbx *= m;
        this.newcx *= m;
        f3 = this.nearPlaneDepth;
        this.firstSegment = false;
      } else {
        bool = false;
      }  
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    float f7 = this.iuadd;
    float f8 = this.ivadd;
    float f9 = this.iradd;
    float f10 = this.igadd;
    float f11 = this.ibadd;
    float f12 = this.iaadd;
    while (paramInt1 < paramInt2) {
      int n = (int)(this.xleft + 0.5F);
      if (n < 0)
        n = 0; 
      int i1 = n;
      int i2 = (int)(this.xrght + 0.5F);
      if (i2 > this.SCREEN_WIDTH)
        i2 = this.SCREEN_WIDTH; 
      float f13 = n + 0.5F - this.xleft;
      int i3 = (int)(f7 * f13 + this.uleft);
      int i4 = (int)(f8 * f13 + this.vleft);
      int i5 = (int)(f9 * f13 + this.rleft);
      int i6 = (int)(f10 * f13 + this.gleft);
      int i7 = (int)(f11 * f13 + this.bleft);
      int i8 = (int)(f12 * f13 + this.aleft);
      float f14 = this.izadd * f13 + this.zleft;
      n += paramInt1;
      i2 += paramInt1;
      if (bool) {
        f1 = this.xmult * (i1 + 0.5F - this.SCREEN_WIDTH / 2.0F);
        f2 = this.ymult * (i + 0.5F - this.SCREEN_HEIGHT / 2.0F);
        f4 = f1 * this.ax + f2 * this.ay + f3 * this.az;
        f5 = f1 * this.bx + f2 * this.by + f3 * this.bz;
        f6 = f1 * this.cx + f2 * this.cy + f3 * this.cz;
      } 
      boolean bool1 = (((this.newcx > 0.0F) ? true : false) == ((f6 > 0.0F) ? true : false)) ? false : true;
      int i9 = 0;
      int i10 = 0;
      int i11 = 0;
      float f15 = 0.0F;
      float f16 = 0.0F;
      float f17 = 0.0F;
      float f18 = 0.0F;
      if (bool && bool1) {
        int i12 = (i2 - n - 1) % m;
        int i13 = m - i12;
        float f19 = i12 / m;
        float f20 = i13 / m;
        i9 = i13;
        float f21 = f4 - f20 * this.newax;
        float f22 = f5 - f20 * this.newbx;
        float f23 = f6 - f20 * this.newcx;
        float f24 = 65536.0F / f23;
        f17 = f21 * f24;
        f18 = f22 * f24;
        f4 += f19 * this.newax;
        f5 += f19 * this.newbx;
        f6 += f19 * this.newcx;
        f24 = 65536.0F / f6;
        f15 = f4 * f24;
        f16 = f5 * f24;
        i10 = (int)(f15 - f17) >> k;
        i11 = (int)(f16 - f18) >> k;
        i3 = (int)f17 + (i13 - 1) * i10;
        i4 = (int)f18 + (i13 - 1) * i11;
      } else {
        float f = 65536.0F / f6;
        f15 = f4 * f;
        f16 = f5 * f;
      } 
      while (n < i2) {
        if (bool) {
          if (i9 == m)
            i9 = 0; 
          if (i9 == 0) {
            f4 += this.newax;
            f5 += this.newbx;
            f6 += this.newcx;
            float f = 65536.0F / f6;
            f17 = f15;
            f18 = f16;
            f15 = f4 * f;
            f16 = f5 * f;
            i3 = (int)f17;
            i4 = (int)f18;
            i10 = (int)(f15 - f17) >> k;
            i11 = (int)(f16 - f18) >> k;
          } else {
            i3 += i10;
            i4 += i11;
          } 
          i9++;
        } 
        try {
          if (this.noDepthTest || f14 <= this.m_zbuffer[n]) {
            if (this.m_bilinear) {
              int i19 = (i4 >> 16) * this.TEX_WIDTH + (i3 >> 16);
              int i20 = i3 & 0xFFFF;
              i12 = this.m_texture[i19] & 0xFF;
              int i21 = this.m_texture[i19 + 1] & 0xFF;
              if (i19 < j)
                i19 += this.TEX_WIDTH; 
              int i22 = this.m_texture[i19] & 0xFF;
              int i23 = this.m_texture[i19 + 1] & 0xFF;
              i12 += (i21 - i12) * i20 >> 16;
              i22 += (i23 - i22) * i20 >> 16;
              i12 += (i22 - i12) * (i4 & 0xFFFF) >> 16;
            } else {
              i12 = this.m_texture[(i4 >> 16) * this.TEX_WIDTH + (i3 >> 16)] & 0xFF;
            } 
            int i12 = i12 * (i8 >> 16) >> 8;
            int i13 = i5 & 0xFF0000;
            int i14 = i6 >> 8 & 0xFF00;
            int i15 = i7 >> 16;
            int i16 = this.m_pixels[n];
            int i17 = i16 & 0xFF0000;
            int i18 = i16 & 0xFF00;
            i16 &= 0xFF;
            this.m_pixels[n] = 0xFF000000 | i17 + ((i13 - i17) * i12 >> 8) & 0xFF0000 | i18 + ((i14 - i18) * i12 >> 8) & 0xFF00 | i16 + ((i15 - i16) * i12 >> 8) & 0xFF;
          } 
        } catch (Exception exception) {}
        i1++;
        if (!bool) {
          i3 += this.iuadd;
          i4 += this.ivadd;
        } 
        i5 += this.iradd;
        i6 += this.igadd;
        i7 += this.ibadd;
        i8 += this.iaadd;
        f14 += this.izadd;
        n++;
      } 
      i++;
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.uleft += this.uleftadd;
      this.vleft += this.vleftadd;
      this.rleft += this.rleftadd;
      this.gleft += this.gleftadd;
      this.bleft += this.bleftadd;
      this.aleft += this.aleftadd;
      this.zleft += this.zleftadd;
    } 
  }
  
  private void drawsegment_gouraud_texture24(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    int i = paramInt1;
    int j = this.m_texture.length - this.TEX_WIDTH - 2;
    boolean bool = this.parent.hints[7];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int k = TEX_INTERP_POWER;
    int m = 1 << k;
    if (bool)
      if (precomputeAccurateTexturing()) {
        this.newax *= m;
        this.newbx *= m;
        this.newcx *= m;
        f3 = this.nearPlaneDepth;
        this.firstSegment = false;
      } else {
        bool = false;
      }  
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    float f7 = this.iuadd;
    float f8 = this.ivadd;
    float f9 = this.iradd;
    float f10 = this.igadd;
    float f11 = this.ibadd;
    while (paramInt1 < paramInt2) {
      int n = (int)(this.xleft + 0.5F);
      if (n < 0)
        n = 0; 
      int i1 = n;
      int i2 = (int)(this.xrght + 0.5F);
      if (i2 > this.SCREEN_WIDTH)
        i2 = this.SCREEN_WIDTH; 
      float f12 = n + 0.5F - this.xleft;
      int i3 = (int)(f7 * f12 + this.uleft);
      int i4 = (int)(f8 * f12 + this.vleft);
      int i5 = (int)(f9 * f12 + this.rleft);
      int i6 = (int)(f10 * f12 + this.gleft);
      int i7 = (int)(f11 * f12 + this.bleft);
      float f13 = this.izadd * f12 + this.zleft;
      n += paramInt1;
      i2 += paramInt1;
      if (bool) {
        f1 = this.xmult * (i1 + 0.5F - this.SCREEN_WIDTH / 2.0F);
        f2 = this.ymult * (i + 0.5F - this.SCREEN_HEIGHT / 2.0F);
        f4 = f1 * this.ax + f2 * this.ay + f3 * this.az;
        f5 = f1 * this.bx + f2 * this.by + f3 * this.bz;
        f6 = f1 * this.cx + f2 * this.cy + f3 * this.cz;
      } 
      boolean bool1 = (((this.newcx > 0.0F) ? true : false) == ((f6 > 0.0F) ? true : false)) ? false : true;
      int i8 = 0;
      int i9 = 0;
      int i10 = 0;
      float f14 = 0.0F;
      float f15 = 0.0F;
      float f16 = 0.0F;
      float f17 = 0.0F;
      if (bool && bool1) {
        int i11 = (i2 - n - 1) % m;
        int i12 = m - i11;
        float f18 = i11 / m;
        float f19 = i12 / m;
        i8 = i12;
        float f20 = f4 - f19 * this.newax;
        float f21 = f5 - f19 * this.newbx;
        float f22 = f6 - f19 * this.newcx;
        float f23 = 65536.0F / f22;
        f16 = f20 * f23;
        f17 = f21 * f23;
        f4 += f18 * this.newax;
        f5 += f18 * this.newbx;
        f6 += f18 * this.newcx;
        f23 = 65536.0F / f6;
        f14 = f4 * f23;
        f15 = f5 * f23;
        i9 = (int)(f14 - f16) >> k;
        i10 = (int)(f15 - f17) >> k;
        i3 = (int)f16 + (i12 - 1) * i9;
        i4 = (int)f17 + (i12 - 1) * i10;
      } else {
        float f = 65536.0F / f6;
        f14 = f4 * f;
        f15 = f5 * f;
      } 
      while (n < i2) {
        if (bool) {
          if (i8 == m)
            i8 = 0; 
          if (i8 == 0) {
            f4 += this.newax;
            f5 += this.newbx;
            f6 += this.newcx;
            float f = 65536.0F / f6;
            f16 = f14;
            f17 = f15;
            f14 = f4 * f;
            f15 = f5 * f;
            i3 = (int)f16;
            i4 = (int)f17;
            i9 = (int)(f14 - f16) >> k;
            i10 = (int)(f15 - f17) >> k;
          } else {
            i3 += i9;
            i4 += i10;
          } 
          i8++;
        } 
        try {
          if (this.noDepthTest || f13 <= this.m_zbuffer[n]) {
            int i11;
            int i12;
            int i13;
            this.m_zbuffer[n] = f13;
            if (this.m_bilinear) {
              int i17 = (i4 >> 16) * this.TEX_WIDTH + (i3 >> 16);
              int i18 = (i3 & 0xFFFF) >> 9;
              int i19 = (i4 & 0xFFFF) >> 9;
              int i20 = this.m_texture[i17];
              int i21 = this.m_texture[i17 + 1];
              if (i17 < j)
                i17 += this.TEX_WIDTH; 
              int i22 = this.m_texture[i17];
              int i23 = this.m_texture[i17 + 1];
              int i24 = i20 & 0xFF0000;
              int i25 = i22 & 0xFF0000;
              int i26 = i24 + (((i21 & 0xFF0000) - i24) * i18 >> 7);
              int i27 = i25 + (((i23 & 0xFF0000) - i25) * i18 >> 7);
              i11 = i26 + ((i27 - i26) * i19 >> 7);
              i24 = i20 & 0xFF00;
              i25 = i22 & 0xFF00;
              i26 = i24 + (((i21 & 0xFF00) - i24) * i18 >> 7);
              i27 = i25 + (((i23 & 0xFF00) - i25) * i18 >> 7);
              i12 = i26 + ((i27 - i26) * i19 >> 7);
              i24 = i20 & 0xFF;
              i25 = i22 & 0xFF;
              i26 = i24 + (((i21 & 0xFF) - i24) * i18 >> 7);
              i27 = i25 + (((i23 & 0xFF) - i25) * i18 >> 7);
              i13 = i26 + ((i27 - i26) * i19 >> 7);
            } else {
              i13 = this.m_texture[(i4 >> 16) * this.TEX_WIDTH + (i3 >> 16)];
              i11 = i13 & 0xFF0000;
              i12 = i13 & 0xFF00;
              i13 &= 0xFF;
            } 
            int i14 = i5 >> 16;
            int i15 = i6 >> 16;
            int i16 = i7 >> 16;
            this.m_pixels[n] = 0xFF000000 | (i11 * i14 & 0xFF000000 | i12 * i15 & 0xFF0000 | i13 * i16) >> 8;
          } 
        } catch (Exception exception) {}
        i1++;
        if (!bool) {
          i3 += this.iuadd;
          i4 += this.ivadd;
        } 
        i5 += this.iradd;
        i6 += this.igadd;
        i7 += this.ibadd;
        f13 += this.izadd;
        n++;
      } 
      i++;
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.uleft += this.uleftadd;
      this.vleft += this.vleftadd;
      this.rleft += this.rleftadd;
      this.gleft += this.gleftadd;
      this.bleft += this.bleftadd;
      this.zleft += this.zleftadd;
    } 
  }
  
  private void drawsegment_gouraud_texture24_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    int i = paramInt1;
    int j = this.m_texture.length - this.TEX_WIDTH - 2;
    boolean bool = this.parent.hints[7];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int k = TEX_INTERP_POWER;
    int m = 1 << k;
    if (bool)
      if (precomputeAccurateTexturing()) {
        this.newax *= m;
        this.newbx *= m;
        this.newcx *= m;
        f3 = this.nearPlaneDepth;
        this.firstSegment = false;
      } else {
        bool = false;
      }  
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    float f7 = this.iuadd;
    float f8 = this.ivadd;
    float f9 = this.iradd;
    float f10 = this.igadd;
    float f11 = this.ibadd;
    float f12 = this.iaadd;
    while (paramInt1 < paramInt2) {
      int n = (int)(this.xleft + 0.5F);
      if (n < 0)
        n = 0; 
      int i1 = n;
      int i2 = (int)(this.xrght + 0.5F);
      if (i2 > this.SCREEN_WIDTH)
        i2 = this.SCREEN_WIDTH; 
      float f13 = n + 0.5F - this.xleft;
      int i3 = (int)(f7 * f13 + this.uleft);
      int i4 = (int)(f8 * f13 + this.vleft);
      int i5 = (int)(f9 * f13 + this.rleft);
      int i6 = (int)(f10 * f13 + this.gleft);
      int i7 = (int)(f11 * f13 + this.bleft);
      int i8 = (int)(f12 * f13 + this.aleft);
      float f14 = this.izadd * f13 + this.zleft;
      n += paramInt1;
      i2 += paramInt1;
      if (bool) {
        f1 = this.xmult * (i1 + 0.5F - this.SCREEN_WIDTH / 2.0F);
        f2 = this.ymult * (i + 0.5F - this.SCREEN_HEIGHT / 2.0F);
        f4 = f1 * this.ax + f2 * this.ay + f3 * this.az;
        f5 = f1 * this.bx + f2 * this.by + f3 * this.bz;
        f6 = f1 * this.cx + f2 * this.cy + f3 * this.cz;
      } 
      boolean bool1 = (((this.newcx > 0.0F) ? true : false) == ((f6 > 0.0F) ? true : false)) ? false : true;
      int i9 = 0;
      int i10 = 0;
      int i11 = 0;
      float f15 = 0.0F;
      float f16 = 0.0F;
      float f17 = 0.0F;
      float f18 = 0.0F;
      if (bool && bool1) {
        int i12 = (i2 - n - 1) % m;
        int i13 = m - i12;
        float f19 = i12 / m;
        float f20 = i13 / m;
        i9 = i13;
        float f21 = f4 - f20 * this.newax;
        float f22 = f5 - f20 * this.newbx;
        float f23 = f6 - f20 * this.newcx;
        float f24 = 65536.0F / f23;
        f17 = f21 * f24;
        f18 = f22 * f24;
        f4 += f19 * this.newax;
        f5 += f19 * this.newbx;
        f6 += f19 * this.newcx;
        f24 = 65536.0F / f6;
        f15 = f4 * f24;
        f16 = f5 * f24;
        i10 = (int)(f15 - f17) >> k;
        i11 = (int)(f16 - f18) >> k;
        i3 = (int)f17 + (i13 - 1) * i10;
        i4 = (int)f18 + (i13 - 1) * i11;
      } else {
        float f = 65536.0F / f6;
        f15 = f4 * f;
        f16 = f5 * f;
      } 
      while (n < i2) {
        if (bool) {
          if (i9 == m)
            i9 = 0; 
          if (i9 == 0) {
            f4 += this.newax;
            f5 += this.newbx;
            f6 += this.newcx;
            float f = 65536.0F / f6;
            f17 = f15;
            f18 = f16;
            f15 = f4 * f;
            f16 = f5 * f;
            i3 = (int)f17;
            i4 = (int)f18;
            i10 = (int)(f15 - f17) >> k;
            i11 = (int)(f16 - f18) >> k;
          } else {
            i3 += i10;
            i4 += i11;
          } 
          i9++;
        } 
        try {
          if (this.noDepthTest || f14 <= this.m_zbuffer[n]) {
            int i12 = i8 >> 16;
            if (this.m_bilinear) {
              int i19 = (i4 >> 16) * this.TEX_WIDTH + (i3 >> 16);
              int i20 = (i3 & 0xFFFF) >> 9;
              int i21 = (i4 & 0xFFFF) >> 9;
              int i22 = this.m_texture[i19];
              int i23 = this.m_texture[i19 + 1];
              if (i19 < j)
                i19 += this.TEX_WIDTH; 
              int i24 = this.m_texture[i19];
              int i25 = this.m_texture[i19 + 1];
              int i26 = i22 & 0xFF0000;
              int i27 = i24 & 0xFF0000;
              int i28 = i26 + (((i23 & 0xFF0000) - i26) * i20 >> 7);
              int i29 = i27 + (((i25 & 0xFF0000) - i27) * i20 >> 7);
              i13 = i28 + ((i29 - i28) * i21 >> 7) >> 16;
              i26 = i22 & 0xFF00;
              i27 = i24 & 0xFF00;
              i28 = i26 + (((i23 & 0xFF00) - i26) * i20 >> 7);
              i29 = i27 + (((i25 & 0xFF00) - i27) * i20 >> 7);
              i14 = i28 + ((i29 - i28) * i21 >> 7) >> 8;
              i26 = i22 & 0xFF;
              i27 = i24 & 0xFF;
              i28 = i26 + (((i23 & 0xFF) - i26) * i20 >> 7);
              i29 = i27 + (((i25 & 0xFF) - i27) * i20 >> 7);
              i15 = i28 + ((i29 - i28) * i21 >> 7);
            } else {
              i15 = this.m_texture[(i4 >> 16) * this.TEX_WIDTH + (i3 >> 16)];
              i13 = (i15 & 0xFF0000) >> 16;
              i14 = (i15 & 0xFF00) >> 8;
              i15 &= 0xFF;
            } 
            int i13 = i13 * i5 >>> 8;
            int i14 = i14 * i6 >>> 16;
            int i15 = i15 * i7 >>> 24;
            int i16 = this.m_pixels[n];
            int i17 = i16 & 0xFF0000;
            int i18 = i16 & 0xFF00;
            i16 &= 0xFF;
            this.m_pixels[n] = 0xFF000000 | i17 + ((i13 - i17) * i12 >> 8) & 0xFF0000 | i18 + ((i14 - i18) * i12 >> 8) & 0xFF00 | i16 + ((i15 - i16) * i12 >> 8) & 0xFF;
          } 
        } catch (Exception exception) {}
        i1++;
        if (!bool) {
          i3 += this.iuadd;
          i4 += this.ivadd;
        } 
        i5 += this.iradd;
        i6 += this.igadd;
        i7 += this.ibadd;
        i8 += this.iaadd;
        f14 += this.izadd;
        n++;
      } 
      i++;
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.uleft += this.uleftadd;
      this.vleft += this.vleftadd;
      this.rleft += this.rleftadd;
      this.gleft += this.gleftadd;
      this.bleft += this.bleftadd;
      this.aleft += this.aleftadd;
      this.zleft += this.zleftadd;
    } 
  }
  
  private void drawsegment_gouraud_texture32(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    int i = paramInt1;
    int j = this.m_texture.length - this.TEX_WIDTH - 2;
    boolean bool = this.parent.hints[7];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int k = TEX_INTERP_POWER;
    int m = 1 << k;
    if (bool)
      if (precomputeAccurateTexturing()) {
        this.newax *= m;
        this.newbx *= m;
        this.newcx *= m;
        f3 = this.nearPlaneDepth;
        this.firstSegment = false;
      } else {
        bool = false;
      }  
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    float f7 = this.iuadd;
    float f8 = this.ivadd;
    float f9 = this.iradd;
    float f10 = this.igadd;
    float f11 = this.ibadd;
    while (paramInt1 < paramInt2) {
      int n = (int)(this.xleft + 0.5F);
      if (n < 0)
        n = 0; 
      int i1 = n;
      int i2 = (int)(this.xrght + 0.5F);
      if (i2 > this.SCREEN_WIDTH)
        i2 = this.SCREEN_WIDTH; 
      float f12 = n + 0.5F - this.xleft;
      int i3 = (int)(f7 * f12 + this.uleft);
      int i4 = (int)(f8 * f12 + this.vleft);
      int i5 = (int)(f9 * f12 + this.rleft);
      int i6 = (int)(f10 * f12 + this.gleft);
      int i7 = (int)(f11 * f12 + this.bleft);
      float f13 = this.izadd * f12 + this.zleft;
      n += paramInt1;
      i2 += paramInt1;
      if (bool) {
        f1 = this.xmult * (i1 + 0.5F - this.SCREEN_WIDTH / 2.0F);
        f2 = this.ymult * (i + 0.5F - this.SCREEN_HEIGHT / 2.0F);
        f4 = f1 * this.ax + f2 * this.ay + f3 * this.az;
        f5 = f1 * this.bx + f2 * this.by + f3 * this.bz;
        f6 = f1 * this.cx + f2 * this.cy + f3 * this.cz;
      } 
      boolean bool1 = (((this.newcx > 0.0F) ? true : false) == ((f6 > 0.0F) ? true : false)) ? false : true;
      int i8 = 0;
      int i9 = 0;
      int i10 = 0;
      float f14 = 0.0F;
      float f15 = 0.0F;
      float f16 = 0.0F;
      float f17 = 0.0F;
      if (bool && bool1) {
        int i11 = (i2 - n - 1) % m;
        int i12 = m - i11;
        float f18 = i11 / m;
        float f19 = i12 / m;
        i8 = i12;
        float f20 = f4 - f19 * this.newax;
        float f21 = f5 - f19 * this.newbx;
        float f22 = f6 - f19 * this.newcx;
        float f23 = 65536.0F / f22;
        f16 = f20 * f23;
        f17 = f21 * f23;
        f4 += f18 * this.newax;
        f5 += f18 * this.newbx;
        f6 += f18 * this.newcx;
        f23 = 65536.0F / f6;
        f14 = f4 * f23;
        f15 = f5 * f23;
        i9 = (int)(f14 - f16) >> k;
        i10 = (int)(f15 - f17) >> k;
        i3 = (int)f16 + (i12 - 1) * i9;
        i4 = (int)f17 + (i12 - 1) * i10;
      } else {
        float f = 65536.0F / f6;
        f14 = f4 * f;
        f15 = f5 * f;
      } 
      while (n < i2) {
        if (bool) {
          if (i8 == m)
            i8 = 0; 
          if (i8 == 0) {
            f4 += this.newax;
            f5 += this.newbx;
            f6 += this.newcx;
            float f = 65536.0F / f6;
            f16 = f14;
            f17 = f15;
            f14 = f4 * f;
            f15 = f5 * f;
            i3 = (int)f16;
            i4 = (int)f17;
            i9 = (int)(f14 - f16) >> k;
            i10 = (int)(f15 - f17) >> k;
          } else {
            i3 += i9;
            i4 += i10;
          } 
          i8++;
        } 
        try {
          if (this.noDepthTest || f13 <= this.m_zbuffer[n]) {
            int i14;
            if (this.m_bilinear) {
              int i18 = (i4 >> 16) * this.TEX_WIDTH + (i3 >> 16);
              int i19 = (i3 & 0xFFFF) >> 9;
              int i20 = (i4 & 0xFFFF) >> 9;
              int i21 = this.m_texture[i18];
              int i22 = this.m_texture[i18 + 1];
              if (i18 < j)
                i18 += this.TEX_WIDTH; 
              int i23 = this.m_texture[i18];
              int i24 = this.m_texture[i18 + 1];
              int i25 = i21 & 0xFF0000;
              int i26 = i23 & 0xFF0000;
              int i27 = i25 + (((i22 & 0xFF0000) - i25) * i19 >> 7);
              int i28 = i26 + (((i24 & 0xFF0000) - i26) * i19 >> 7);
              i11 = i27 + ((i28 - i27) * i20 >> 7) >> 16;
              i25 = i21 & 0xFF00;
              i26 = i23 & 0xFF00;
              i27 = i25 + (((i22 & 0xFF00) - i25) * i19 >> 7);
              i28 = i26 + (((i24 & 0xFF00) - i26) * i19 >> 7);
              i12 = i27 + ((i28 - i27) * i20 >> 7) >> 8;
              i25 = i21 & 0xFF;
              i26 = i23 & 0xFF;
              i27 = i25 + (((i22 & 0xFF) - i25) * i19 >> 7);
              i28 = i26 + (((i24 & 0xFF) - i26) * i19 >> 7);
              i13 = i27 + ((i28 - i27) * i20 >> 7);
              i21 >>>= 24;
              i23 >>>= 24;
              i27 = i21 + (((i22 >>> 24) - i21) * i19 >> 7);
              i28 = i23 + (((i24 >>> 24) - i23) * i19 >> 7);
              i14 = i27 + ((i28 - i27) * i20 >> 7);
            } else {
              i13 = this.m_texture[(i4 >> 16) * this.TEX_WIDTH + (i3 >> 16)];
              i14 = i13 >>> 24;
              i11 = (i13 & 0xFF0000) >> 16;
              i12 = (i13 & 0xFF00) >> 8;
              i13 &= 0xFF;
            } 
            int i11 = i11 * i5 >>> 8;
            int i12 = i12 * i6 >>> 16;
            int i13 = i13 * i7 >>> 24;
            int i15 = this.m_pixels[n];
            int i16 = i15 & 0xFF0000;
            int i17 = i15 & 0xFF00;
            i15 &= 0xFF;
            this.m_pixels[n] = 0xFF000000 | i16 + ((i11 - i16) * i14 >> 8) & 0xFF0000 | i17 + ((i12 - i17) * i14 >> 8) & 0xFF00 | i15 + ((i13 - i15) * i14 >> 8) & 0xFF;
          } 
        } catch (Exception exception) {}
        i1++;
        if (!bool) {
          i3 += this.iuadd;
          i4 += this.ivadd;
        } 
        i5 += this.iradd;
        i6 += this.igadd;
        i7 += this.ibadd;
        f13 += this.izadd;
        n++;
      } 
      i++;
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.uleft += this.uleftadd;
      this.vleft += this.vleftadd;
      this.rleft += this.rleftadd;
      this.gleft += this.gleftadd;
      this.bleft += this.bleftadd;
      this.zleft += this.zleftadd;
    } 
  }
  
  private void drawsegment_gouraud_texture32_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    int i = paramInt1;
    int j = this.m_texture.length - this.TEX_WIDTH - 2;
    boolean bool = this.parent.hints[7];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int k = TEX_INTERP_POWER;
    int m = 1 << k;
    if (bool)
      if (precomputeAccurateTexturing()) {
        this.newax *= m;
        this.newbx *= m;
        this.newcx *= m;
        f3 = this.nearPlaneDepth;
        this.firstSegment = false;
      } else {
        bool = false;
      }  
    paramInt1 *= this.SCREEN_WIDTH;
    paramInt2 *= this.SCREEN_WIDTH;
    float f7 = this.iuadd;
    float f8 = this.ivadd;
    float f9 = this.iradd;
    float f10 = this.igadd;
    float f11 = this.ibadd;
    float f12 = this.iaadd;
    while (paramInt1 < paramInt2) {
      int n = (int)(this.xleft + 0.5F);
      if (n < 0)
        n = 0; 
      int i1 = n;
      int i2 = (int)(this.xrght + 0.5F);
      if (i2 > this.SCREEN_WIDTH)
        i2 = this.SCREEN_WIDTH; 
      float f13 = n + 0.5F - this.xleft;
      int i3 = (int)(f7 * f13 + this.uleft);
      int i4 = (int)(f8 * f13 + this.vleft);
      int i5 = (int)(f9 * f13 + this.rleft);
      int i6 = (int)(f10 * f13 + this.gleft);
      int i7 = (int)(f11 * f13 + this.bleft);
      int i8 = (int)(f12 * f13 + this.aleft);
      float f14 = this.izadd * f13 + this.zleft;
      n += paramInt1;
      i2 += paramInt1;
      if (bool) {
        f1 = this.xmult * (i1 + 0.5F - this.SCREEN_WIDTH / 2.0F);
        f2 = this.ymult * (i + 0.5F - this.SCREEN_HEIGHT / 2.0F);
        f4 = f1 * this.ax + f2 * this.ay + f3 * this.az;
        f5 = f1 * this.bx + f2 * this.by + f3 * this.bz;
        f6 = f1 * this.cx + f2 * this.cy + f3 * this.cz;
      } 
      boolean bool1 = (((this.newcx > 0.0F) ? true : false) == ((f6 > 0.0F) ? true : false)) ? false : true;
      int i9 = 0;
      int i10 = 0;
      int i11 = 0;
      float f15 = 0.0F;
      float f16 = 0.0F;
      float f17 = 0.0F;
      float f18 = 0.0F;
      if (bool && bool1) {
        int i12 = (i2 - n - 1) % m;
        int i13 = m - i12;
        float f19 = i12 / m;
        float f20 = i13 / m;
        i9 = i13;
        float f21 = f4 - f20 * this.newax;
        float f22 = f5 - f20 * this.newbx;
        float f23 = f6 - f20 * this.newcx;
        float f24 = 65536.0F / f23;
        f17 = f21 * f24;
        f18 = f22 * f24;
        f4 += f19 * this.newax;
        f5 += f19 * this.newbx;
        f6 += f19 * this.newcx;
        f24 = 65536.0F / f6;
        f15 = f4 * f24;
        f16 = f5 * f24;
        i10 = (int)(f15 - f17) >> k;
        i11 = (int)(f16 - f18) >> k;
        i3 = (int)f17 + (i13 - 1) * i10;
        i4 = (int)f18 + (i13 - 1) * i11;
      } else {
        float f = 65536.0F / f6;
        f15 = f4 * f;
        f16 = f5 * f;
      } 
      while (n < i2) {
        if (bool) {
          if (i9 == m)
            i9 = 0; 
          if (i9 == 0) {
            f4 += this.newax;
            f5 += this.newbx;
            f6 += this.newcx;
            float f = 65536.0F / f6;
            f17 = f15;
            f18 = f16;
            f15 = f4 * f;
            f16 = f5 * f;
            i3 = (int)f17;
            i4 = (int)f18;
            i10 = (int)(f15 - f17) >> k;
            i11 = (int)(f16 - f18) >> k;
          } else {
            i3 += i10;
            i4 += i11;
          } 
          i9++;
        } 
        try {
          if (this.noDepthTest || f14 <= this.m_zbuffer[n]) {
            int i12 = i8 >> 16;
            if (this.m_bilinear) {
              int i19 = (i4 >> 16) * this.TEX_WIDTH + (i3 >> 16);
              int i20 = (i3 & 0xFFFF) >> 9;
              int i21 = (i4 & 0xFFFF) >> 9;
              int i22 = this.m_texture[i19];
              int i23 = this.m_texture[i19 + 1];
              if (i19 < j)
                i19 += this.TEX_WIDTH; 
              int i24 = this.m_texture[i19];
              int i25 = this.m_texture[i19 + 1];
              int i26 = i22 & 0xFF0000;
              int i27 = i24 & 0xFF0000;
              int i28 = i26 + (((i23 & 0xFF0000) - i26) * i20 >> 7);
              int i29 = i27 + (((i25 & 0xFF0000) - i27) * i20 >> 7);
              i13 = i28 + ((i29 - i28) * i21 >> 7) >> 16;
              i26 = i22 & 0xFF00;
              i27 = i24 & 0xFF00;
              i28 = i26 + (((i23 & 0xFF00) - i26) * i20 >> 7);
              i29 = i27 + (((i25 & 0xFF00) - i27) * i20 >> 7);
              i14 = i28 + ((i29 - i28) * i21 >> 7) >> 8;
              i26 = i22 & 0xFF;
              i27 = i24 & 0xFF;
              i28 = i26 + (((i23 & 0xFF) - i26) * i20 >> 7);
              i29 = i27 + (((i25 & 0xFF) - i27) * i20 >> 7);
              i15 = i28 + ((i29 - i28) * i21 >> 7);
              i22 >>>= 24;
              i24 >>>= 24;
              i28 = i22 + (((i23 >>> 24) - i22) * i20 >> 7);
              i29 = i24 + (((i25 >>> 24) - i24) * i20 >> 7);
              i12 = i12 * (i28 + ((i29 - i28) * i21 >> 7)) >> 8;
            } else {
              i15 = this.m_texture[(i4 >> 16) * this.TEX_WIDTH + (i3 >> 16)];
              i12 = i12 * (i15 >>> 24) >> 8;
              i13 = (i15 & 0xFF0000) >> 16;
              i14 = (i15 & 0xFF00) >> 8;
              i15 &= 0xFF;
            } 
            int i13 = i13 * i5 >>> 8;
            int i14 = i14 * i6 >>> 16;
            int i15 = i15 * i7 >>> 24;
            int i16 = this.m_pixels[n];
            int i17 = i16 & 0xFF0000;
            int i18 = i16 & 0xFF00;
            i16 &= 0xFF;
            this.m_pixels[n] = 0xFF000000 | i17 + ((i13 - i17) * i12 >> 8) & 0xFF0000 | i18 + ((i14 - i18) * i12 >> 8) & 0xFF00 | i16 + ((i15 - i16) * i12 >> 8) & 0xFF;
          } 
        } catch (Exception exception) {}
        i1++;
        if (!bool) {
          i3 += this.iuadd;
          i4 += this.ivadd;
        } 
        i5 += this.iradd;
        i6 += this.igadd;
        i7 += this.ibadd;
        i8 += this.iaadd;
        f14 += this.izadd;
        n++;
      } 
      i++;
      paramInt1 += this.SCREEN_WIDTH;
      this.xleft += paramFloat1;
      this.xrght += paramFloat2;
      this.uleft += this.uleftadd;
      this.vleft += this.vleftadd;
      this.rleft += this.rleftadd;
      this.gleft += this.gleftadd;
      this.bleft += this.bleftadd;
      this.aleft += this.aleftadd;
      this.zleft += this.zleftadd;
    } 
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PTriangle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */