package processing.core;

public interface PMatrix {
  void reset();
  
  PMatrix get();
  
  float[] get(float[] paramArrayOffloat);
  
  void set(PMatrix paramPMatrix);
  
  void set(float[] paramArrayOffloat);
  
  void set(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
  
  void set(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16);
  
  void translate(float paramFloat1, float paramFloat2);
  
  void translate(float paramFloat1, float paramFloat2, float paramFloat3);
  
  void rotate(float paramFloat);
  
  void rotateX(float paramFloat);
  
  void rotateY(float paramFloat);
  
  void rotateZ(float paramFloat);
  
  void rotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  
  void scale(float paramFloat);
  
  void scale(float paramFloat1, float paramFloat2);
  
  void scale(float paramFloat1, float paramFloat2, float paramFloat3);
  
  void shearX(float paramFloat);
  
  void shearY(float paramFloat);
  
  void apply(PMatrix paramPMatrix);
  
  void apply(PMatrix2D paramPMatrix2D);
  
  void apply(PMatrix3D paramPMatrix3D);
  
  void apply(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
  
  void apply(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16);
  
  void preApply(PMatrix2D paramPMatrix2D);
  
  void preApply(PMatrix3D paramPMatrix3D);
  
  void preApply(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
  
  void preApply(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16);
  
  PVector mult(PVector paramPVector1, PVector paramPVector2);
  
  float[] mult(float[] paramArrayOffloat1, float[] paramArrayOffloat2);
  
  void transpose();
  
  boolean invert();
  
  float determinant();
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PMatrix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */