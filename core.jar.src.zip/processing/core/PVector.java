package processing.core;

import java.io.Serializable;

public class PVector implements Serializable {
  private static final long serialVersionUID = -6717872085945400694L;
  
  public float x;
  
  public float y;
  
  public float z;
  
  protected transient float[] array;
  
  public PVector() {}
  
  public PVector(float paramFloat1, float paramFloat2, float paramFloat3) {
    this.x = paramFloat1;
    this.y = paramFloat2;
    this.z = paramFloat3;
  }
  
  public PVector(float paramFloat1, float paramFloat2) {
    this.x = paramFloat1;
    this.y = paramFloat2;
    this.z = 0.0F;
  }
  
  public void set(float paramFloat1, float paramFloat2, float paramFloat3) {
    this.x = paramFloat1;
    this.y = paramFloat2;
    this.z = paramFloat3;
  }
  
  public void set(PVector paramPVector) {
    this.x = paramPVector.x;
    this.y = paramPVector.y;
    this.z = paramPVector.z;
  }
  
  public void set(float[] paramArrayOffloat) {
    if (paramArrayOffloat.length >= 2) {
      this.x = paramArrayOffloat[0];
      this.y = paramArrayOffloat[1];
    } 
    if (paramArrayOffloat.length >= 3)
      this.z = paramArrayOffloat[2]; 
  }
  
  public PVector get() {
    return new PVector(this.x, this.y, this.z);
  }
  
  public float[] get(float[] paramArrayOffloat) {
    if (paramArrayOffloat == null)
      return new float[] { this.x, this.y, this.z }; 
    if (paramArrayOffloat.length >= 2) {
      paramArrayOffloat[0] = this.x;
      paramArrayOffloat[1] = this.y;
    } 
    if (paramArrayOffloat.length >= 3)
      paramArrayOffloat[2] = this.z; 
    return paramArrayOffloat;
  }
  
  public float mag() {
    return (float)Math.sqrt((this.x * this.x + this.y * this.y + this.z * this.z));
  }
  
  public void add(PVector paramPVector) {
    this.x += paramPVector.x;
    this.y += paramPVector.y;
    this.z += paramPVector.z;
  }
  
  public void add(float paramFloat1, float paramFloat2, float paramFloat3) {
    this.x += paramFloat1;
    this.y += paramFloat2;
    this.z += paramFloat3;
  }
  
  public static PVector add(PVector paramPVector1, PVector paramPVector2) {
    return add(paramPVector1, paramPVector2, (PVector)null);
  }
  
  public static PVector add(PVector paramPVector1, PVector paramPVector2, PVector paramPVector3) {
    if (paramPVector3 == null) {
      paramPVector3 = new PVector(paramPVector1.x + paramPVector2.x, paramPVector1.y + paramPVector2.y, paramPVector1.z + paramPVector2.z);
    } else {
      paramPVector3.set(paramPVector1.x + paramPVector2.x, paramPVector1.y + paramPVector2.y, paramPVector1.z + paramPVector2.z);
    } 
    return paramPVector3;
  }
  
  public void sub(PVector paramPVector) {
    this.x -= paramPVector.x;
    this.y -= paramPVector.y;
    this.z -= paramPVector.z;
  }
  
  public void sub(float paramFloat1, float paramFloat2, float paramFloat3) {
    this.x -= paramFloat1;
    this.y -= paramFloat2;
    this.z -= paramFloat3;
  }
  
  public static PVector sub(PVector paramPVector1, PVector paramPVector2) {
    return sub(paramPVector1, paramPVector2, (PVector)null);
  }
  
  public static PVector sub(PVector paramPVector1, PVector paramPVector2, PVector paramPVector3) {
    if (paramPVector3 == null) {
      paramPVector3 = new PVector(paramPVector1.x - paramPVector2.x, paramPVector1.y - paramPVector2.y, paramPVector1.z - paramPVector2.z);
    } else {
      paramPVector3.set(paramPVector1.x - paramPVector2.x, paramPVector1.y - paramPVector2.y, paramPVector1.z - paramPVector2.z);
    } 
    return paramPVector3;
  }
  
  public void mult(float paramFloat) {
    this.x *= paramFloat;
    this.y *= paramFloat;
    this.z *= paramFloat;
  }
  
  public static PVector mult(PVector paramPVector, float paramFloat) {
    return mult(paramPVector, paramFloat, (PVector)null);
  }
  
  public static PVector mult(PVector paramPVector1, float paramFloat, PVector paramPVector2) {
    if (paramPVector2 == null) {
      paramPVector2 = new PVector(paramPVector1.x * paramFloat, paramPVector1.y * paramFloat, paramPVector1.z * paramFloat);
    } else {
      paramPVector2.set(paramPVector1.x * paramFloat, paramPVector1.y * paramFloat, paramPVector1.z * paramFloat);
    } 
    return paramPVector2;
  }
  
  public void mult(PVector paramPVector) {
    this.x *= paramPVector.x;
    this.y *= paramPVector.y;
    this.z *= paramPVector.z;
  }
  
  public static PVector mult(PVector paramPVector1, PVector paramPVector2) {
    return mult(paramPVector1, paramPVector2, (PVector)null);
  }
  
  public static PVector mult(PVector paramPVector1, PVector paramPVector2, PVector paramPVector3) {
    if (paramPVector3 == null) {
      paramPVector3 = new PVector(paramPVector1.x * paramPVector2.x, paramPVector1.y * paramPVector2.y, paramPVector1.z * paramPVector2.z);
    } else {
      paramPVector3.set(paramPVector1.x * paramPVector2.x, paramPVector1.y * paramPVector2.y, paramPVector1.z * paramPVector2.z);
    } 
    return paramPVector3;
  }
  
  public void div(float paramFloat) {
    this.x /= paramFloat;
    this.y /= paramFloat;
    this.z /= paramFloat;
  }
  
  public static PVector div(PVector paramPVector, float paramFloat) {
    return div(paramPVector, paramFloat, (PVector)null);
  }
  
  public static PVector div(PVector paramPVector1, float paramFloat, PVector paramPVector2) {
    if (paramPVector2 == null) {
      paramPVector2 = new PVector(paramPVector1.x / paramFloat, paramPVector1.y / paramFloat, paramPVector1.z / paramFloat);
    } else {
      paramPVector2.set(paramPVector1.x / paramFloat, paramPVector1.y / paramFloat, paramPVector1.z / paramFloat);
    } 
    return paramPVector2;
  }
  
  public void div(PVector paramPVector) {
    this.x /= paramPVector.x;
    this.y /= paramPVector.y;
    this.z /= paramPVector.z;
  }
  
  public static PVector div(PVector paramPVector1, PVector paramPVector2) {
    return div(paramPVector1, paramPVector2, (PVector)null);
  }
  
  public static PVector div(PVector paramPVector1, PVector paramPVector2, PVector paramPVector3) {
    if (paramPVector3 == null) {
      paramPVector3 = new PVector(paramPVector1.x / paramPVector2.x, paramPVector1.y / paramPVector2.y, paramPVector1.z / paramPVector2.z);
    } else {
      paramPVector3.set(paramPVector1.x / paramPVector2.x, paramPVector1.y / paramPVector2.y, paramPVector1.z / paramPVector2.z);
    } 
    return paramPVector3;
  }
  
  public float dist(PVector paramPVector) {
    float f1 = this.x - paramPVector.x;
    float f2 = this.y - paramPVector.y;
    float f3 = this.z - paramPVector.z;
    return (float)Math.sqrt((f1 * f1 + f2 * f2 + f3 * f3));
  }
  
  public static float dist(PVector paramPVector1, PVector paramPVector2) {
    float f1 = paramPVector1.x - paramPVector2.x;
    float f2 = paramPVector1.y - paramPVector2.y;
    float f3 = paramPVector1.z - paramPVector2.z;
    return (float)Math.sqrt((f1 * f1 + f2 * f2 + f3 * f3));
  }
  
  public float dot(PVector paramPVector) {
    return this.x * paramPVector.x + this.y * paramPVector.y + this.z * paramPVector.z;
  }
  
  public float dot(float paramFloat1, float paramFloat2, float paramFloat3) {
    return this.x * paramFloat1 + this.y * paramFloat2 + this.z * paramFloat3;
  }
  
  public static float dot(PVector paramPVector1, PVector paramPVector2) {
    return paramPVector1.x * paramPVector2.x + paramPVector1.y * paramPVector2.y + paramPVector1.z * paramPVector2.z;
  }
  
  public PVector cross(PVector paramPVector) {
    return cross(paramPVector, null);
  }
  
  public PVector cross(PVector paramPVector1, PVector paramPVector2) {
    float f1 = this.y * paramPVector1.z - paramPVector1.y * this.z;
    float f2 = this.z * paramPVector1.x - paramPVector1.z * this.x;
    float f3 = this.x * paramPVector1.y - paramPVector1.x * this.y;
    if (paramPVector2 == null) {
      paramPVector2 = new PVector(f1, f2, f3);
    } else {
      paramPVector2.set(f1, f2, f3);
    } 
    return paramPVector2;
  }
  
  public static PVector cross(PVector paramPVector1, PVector paramPVector2, PVector paramPVector3) {
    float f1 = paramPVector1.y * paramPVector2.z - paramPVector2.y * paramPVector1.z;
    float f2 = paramPVector1.z * paramPVector2.x - paramPVector2.z * paramPVector1.x;
    float f3 = paramPVector1.x * paramPVector2.y - paramPVector2.x * paramPVector1.y;
    if (paramPVector3 == null) {
      paramPVector3 = new PVector(f1, f2, f3);
    } else {
      paramPVector3.set(f1, f2, f3);
    } 
    return paramPVector3;
  }
  
  public void normalize() {
    float f = mag();
    if (f != 0.0F && f != 1.0F)
      div(f); 
  }
  
  public PVector normalize(PVector paramPVector) {
    if (paramPVector == null)
      paramPVector = new PVector(); 
    float f = mag();
    if (f > 0.0F) {
      paramPVector.set(this.x / f, this.y / f, this.z / f);
    } else {
      paramPVector.set(this.x, this.y, this.z);
    } 
    return paramPVector;
  }
  
  public void limit(float paramFloat) {
    if (mag() > paramFloat) {
      normalize();
      mult(paramFloat);
    } 
  }
  
  public void scaleTo(float paramFloat) {
    normalize();
    mult(paramFloat);
  }
  
  public PVector scaleTo(PVector paramPVector, float paramFloat) {
    paramPVector = normalize(paramPVector);
    paramPVector.mult(paramFloat);
    return paramPVector;
  }
  
  public float heading2D() {
    float f = (float)Math.atan2(-this.y, this.x);
    return -1.0F * f;
  }
  
  public void rotate(float paramFloat) {
    float f = this.x;
    this.x = this.x * PApplet.cos(paramFloat) - this.y * PApplet.sin(paramFloat);
    this.y = f * PApplet.sin(paramFloat) + this.y * PApplet.cos(paramFloat);
  }
  
  public static float angleBetween(PVector paramPVector1, PVector paramPVector2) {
    double d1 = (paramPVector1.x * paramPVector2.x + paramPVector1.y * paramPVector2.y + paramPVector1.z * paramPVector2.z);
    double d2 = Math.sqrt((paramPVector1.x * paramPVector1.x + paramPVector1.y * paramPVector1.y + paramPVector1.z * paramPVector1.z));
    double d3 = Math.sqrt((paramPVector2.x * paramPVector2.x + paramPVector2.y * paramPVector2.y + paramPVector2.z * paramPVector2.z));
    double d4 = d1 / d2 * d3;
    return (d4 <= -1.0D) ? 3.1415927F : ((d4 >= 1.0D) ? 0.0F : (float)Math.acos(d4));
  }
  
  public String toString() {
    return "[ " + this.x + ", " + this.y + ", " + this.z + " ]";
  }
  
  public float[] array() {
    if (this.array == null)
      this.array = new float[3]; 
    this.array[0] = this.x;
    this.array[1] = this.y;
    this.array[2] = this.z;
    return this.array;
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof PVector))
      return false; 
    PVector pVector = (PVector)paramObject;
    return (this.x == pVector.x && this.y == pVector.y && this.z == pVector.z);
  }
  
  public int hashCode() {
    null = 1;
    null = 31 * null + Float.floatToIntBits(this.x);
    null = 31 * null + Float.floatToIntBits(this.y);
    return 31 * null + Float.floatToIntBits(this.z);
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PVector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */