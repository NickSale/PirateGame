package processing.core;

import java.awt.Paint;
import java.awt.PaintContext;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.ColorModel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.util.HashMap;
import processing.xml.XMLElement;

public class PShapeSVG extends PShape {
  XMLElement element;
  
  float opacity;
  
  float strokeOpacity;
  
  float fillOpacity;
  
  Gradient strokeGradient;
  
  Paint strokeGradientPaint;
  
  String strokeName;
  
  Gradient fillGradient;
  
  Paint fillGradientPaint;
  
  String fillName;
  
  public PShapeSVG(PApplet paramPApplet, String paramString) {
    this(new XMLElement(paramPApplet, paramString));
  }
  
  public PShapeSVG(XMLElement paramXMLElement) {
    this((PShapeSVG)null, paramXMLElement, true);
    if (!paramXMLElement.getName().equals("svg"))
      throw new RuntimeException("root is not <svg>, it's <" + paramXMLElement.getName() + ">"); 
    String str1 = paramXMLElement.getString("viewBox");
    if (str1 != null) {
      int[] arrayOfInt = PApplet.parseInt(PApplet.splitTokens(str1));
      this.width = arrayOfInt[2];
      this.height = arrayOfInt[3];
    } 
    String str2 = paramXMLElement.getString("width");
    String str3 = paramXMLElement.getString("height");
    if (str2 != null) {
      this.width = parseUnitSize(str2);
      this.height = parseUnitSize(str3);
    } else if (this.width == 0.0F || this.height == 0.0F) {
      PGraphics.showWarning("The width and/or height is not readable in the <svg> tag of this file.");
      this.width = 1.0F;
      this.height = 1.0F;
    } 
  }
  
  public PShapeSVG(PShapeSVG paramPShapeSVG, XMLElement paramXMLElement, boolean paramBoolean) {
    this.parent = paramPShapeSVG;
    if (paramPShapeSVG == null) {
      this.stroke = false;
      this.strokeColor = -16777216;
      this.strokeWeight = 1.0F;
      this.strokeCap = 1;
      this.strokeJoin = 8;
      this.strokeGradient = null;
      this.strokeGradientPaint = null;
      this.strokeName = null;
      this.fill = true;
      this.fillColor = -16777216;
      this.fillGradient = null;
      this.fillGradientPaint = null;
      this.fillName = null;
      this.strokeOpacity = 1.0F;
      this.fillOpacity = 1.0F;
      this.opacity = 1.0F;
    } else {
      this.stroke = paramPShapeSVG.stroke;
      this.strokeColor = paramPShapeSVG.strokeColor;
      this.strokeWeight = paramPShapeSVG.strokeWeight;
      this.strokeCap = paramPShapeSVG.strokeCap;
      this.strokeJoin = paramPShapeSVG.strokeJoin;
      this.strokeGradient = paramPShapeSVG.strokeGradient;
      this.strokeGradientPaint = paramPShapeSVG.strokeGradientPaint;
      this.strokeName = paramPShapeSVG.strokeName;
      this.fill = paramPShapeSVG.fill;
      this.fillColor = paramPShapeSVG.fillColor;
      this.fillGradient = paramPShapeSVG.fillGradient;
      this.fillGradientPaint = paramPShapeSVG.fillGradientPaint;
      this.fillName = paramPShapeSVG.fillName;
      this.opacity = paramPShapeSVG.opacity;
    } 
    this.element = paramXMLElement;
    this.name = paramXMLElement.getString("id");
    if (this.name != null)
      while (true) {
        String[] arrayOfString = PApplet.match(this.name, "_x([A-Za-z0-9]{2})_");
        if (arrayOfString == null)
          break; 
        char c = (char)PApplet.unhex(arrayOfString[1]);
        this.name = this.name.replace(arrayOfString[0], "" + c);
      }  
    String str1 = paramXMLElement.getString("display", "inline");
    this.visible = !str1.equals("none");
    String str2 = paramXMLElement.getString("transform");
    if (str2 != null)
      this.matrix = parseTransform(str2); 
    if (paramBoolean) {
      parseColors(paramXMLElement);
      parseChildren(paramXMLElement);
    } 
  }
  
  protected void parseChildren(XMLElement paramXMLElement) {
    XMLElement[] arrayOfXMLElement = paramXMLElement.getChildren();
    this.children = new PShape[arrayOfXMLElement.length];
    this.childCount = 0;
    for (XMLElement xMLElement : arrayOfXMLElement) {
      PShape pShape = parseChild(xMLElement);
      if (pShape != null)
        addChild(pShape); 
    } 
    this.children = (PShape[])PApplet.subset(this.children, 0, this.childCount);
  }
  
  protected PShape parseChild(XMLElement paramXMLElement) {
    String str = paramXMLElement.getName();
    PShapeSVG pShapeSVG = null;
    if (str.equals("g")) {
      pShapeSVG = new PShapeSVG(this, paramXMLElement, true);
    } else if (str.equals("defs")) {
      pShapeSVG = new PShapeSVG(this, paramXMLElement, true);
    } else if (str.equals("line")) {
      pShapeSVG = new PShapeSVG(this, paramXMLElement, true);
      pShapeSVG.parseLine();
    } else if (str.equals("circle")) {
      pShapeSVG = new PShapeSVG(this, paramXMLElement, true);
      pShapeSVG.parseEllipse(true);
    } else if (str.equals("ellipse")) {
      pShapeSVG = new PShapeSVG(this, paramXMLElement, true);
      pShapeSVG.parseEllipse(false);
    } else if (str.equals("rect")) {
      pShapeSVG = new PShapeSVG(this, paramXMLElement, true);
      pShapeSVG.parseRect();
    } else if (str.equals("polygon")) {
      pShapeSVG = new PShapeSVG(this, paramXMLElement, true);
      pShapeSVG.parsePoly(true);
    } else if (str.equals("polyline")) {
      pShapeSVG = new PShapeSVG(this, paramXMLElement, true);
      pShapeSVG.parsePoly(false);
    } else if (str.equals("path")) {
      pShapeSVG = new PShapeSVG(this, paramXMLElement, true);
      pShapeSVG.parsePath();
    } else {
      if (str.equals("radialGradient"))
        return new RadialGradient(this, paramXMLElement); 
      if (str.equals("linearGradient"))
        return new LinearGradient(this, paramXMLElement); 
      if (str.equals("font"))
        return new Font(this, paramXMLElement); 
      if (str.equals("metadata"))
        return null; 
      if (str.equals("text")) {
        PGraphics.showWarning("Text and fonts in SVG files are not currently supported, convert text to outlines instead.");
      } else if (str.equals("filter")) {
        PGraphics.showWarning("Filters are not supported.");
      } else if (str.equals("mask")) {
        PGraphics.showWarning("Masks are not supported.");
      } else if (str.equals("pattern")) {
        PGraphics.showWarning("Patterns are not supported.");
      } else if (!str.equals("stop") && !str.equals("sodipodi:namedview")) {
        PGraphics.showWarning("Ignoring <" + str + "> tag.");
      } 
    } 
    return pShapeSVG;
  }
  
  protected void parseLine() {
    this.primitive = 4;
    this.family = 1;
    this.params = new float[] { getFloatWithUnit(this.element, "x1"), getFloatWithUnit(this.element, "y1"), getFloatWithUnit(this.element, "x2"), getFloatWithUnit(this.element, "y2") };
  }
  
  protected void parseEllipse(boolean paramBoolean) {
    float f1;
    float f2;
    this.primitive = 31;
    this.family = 1;
    this.params = new float[4];
    this.params[0] = getFloatWithUnit(this.element, "cx");
    this.params[1] = getFloatWithUnit(this.element, "cy");
    if (paramBoolean) {
      f1 = f2 = getFloatWithUnit(this.element, "r");
    } else {
      f1 = getFloatWithUnit(this.element, "rx");
      f2 = getFloatWithUnit(this.element, "ry");
    } 
    this.params[0] = this.params[0] - f1;
    this.params[1] = this.params[1] - f2;
    this.params[2] = f1 * 2.0F;
    this.params[3] = f2 * 2.0F;
  }
  
  protected void parseRect() {
    this.primitive = 30;
    this.family = 1;
    this.params = new float[] { getFloatWithUnit(this.element, "x"), getFloatWithUnit(this.element, "y"), getFloatWithUnit(this.element, "width"), getFloatWithUnit(this.element, "height") };
  }
  
  protected void parsePoly(boolean paramBoolean) {
    this.family = 2;
    this.close = paramBoolean;
    String str = this.element.getString("points");
    if (str != null) {
      String[] arrayOfString = PApplet.splitTokens(str);
      this.vertexCount = arrayOfString.length;
      this.vertices = new float[this.vertexCount][2];
      for (byte b = 0; b < this.vertexCount; b++) {
        String[] arrayOfString1 = PApplet.split(arrayOfString[b], ',');
        this.vertices[b][0] = Float.valueOf(arrayOfString1[0]).floatValue();
        this.vertices[b][1] = Float.valueOf(arrayOfString1[1]).floatValue();
      } 
    } 
  }
  
  protected void parsePath() {
    this.family = 2;
    this.primitive = 0;
    String str = this.element.getString("d");
    if (str == null || PApplet.trim(str).length() == 0)
      return; 
    char[] arrayOfChar = str.toCharArray();
    StringBuffer stringBuffer = new StringBuffer();
    boolean bool1 = false;
    for (byte b1 = 0; b1 < arrayOfChar.length; b1++) {
      char c1 = arrayOfChar[b1];
      boolean bool = false;
      if (c1 == 'M' || c1 == 'm' || c1 == 'L' || c1 == 'l' || c1 == 'H' || c1 == 'h' || c1 == 'V' || c1 == 'v' || c1 == 'C' || c1 == 'c' || c1 == 'S' || c1 == 's' || c1 == 'Q' || c1 == 'q' || c1 == 'T' || c1 == 't' || c1 == 'Z' || c1 == 'z' || c1 == ',') {
        bool = true;
        if (b1 != 0)
          stringBuffer.append("|"); 
      } 
      if (c1 == 'Z' || c1 == 'z')
        bool = false; 
      if (c1 == '-' && !bool1 && (b1 == 0 || arrayOfChar[b1 - 1] != 'e'))
        stringBuffer.append("|"); 
      if (c1 != ',')
        stringBuffer.append(c1); 
      if (bool && c1 != ',' && c1 != '-')
        stringBuffer.append("|"); 
      bool1 = bool;
    } 
    String[] arrayOfString = PApplet.splitTokens(stringBuffer.toString(), "| \t\n\r\f ");
    this.vertices = new float[arrayOfString.length][2];
    this.vertexCodes = new int[arrayOfString.length];
    float f1 = 0.0F;
    float f2 = 0.0F;
    byte b2 = 0;
    char c = Character.MIN_VALUE;
    boolean bool2 = false;
    while (b2 < arrayOfString.length) {
      float f3;
      float f4;
      float f5;
      float f6;
      float f7;
      float f8;
      float f9;
      float f10;
      char c1 = arrayOfString[b2].charAt(0);
      if (((c1 >= '0' && c1 <= '9') || c1 == '-') && c) {
        c1 = c;
        b2--;
      } else {
        c = c1;
      } 
      switch (c1) {
        case 'M':
          f1 = PApplet.parseFloat(arrayOfString[b2 + 1]);
          f2 = PApplet.parseFloat(arrayOfString[b2 + 2]);
          parsePathMoveto(f1, f2);
          c = 'L';
          b2 += 3;
          continue;
        case 'm':
          f1 += PApplet.parseFloat(arrayOfString[b2 + 1]);
          f2 += PApplet.parseFloat(arrayOfString[b2 + 2]);
          parsePathMoveto(f1, f2);
          c = 'l';
          b2 += 3;
          continue;
        case 'L':
          f1 = PApplet.parseFloat(arrayOfString[b2 + 1]);
          f2 = PApplet.parseFloat(arrayOfString[b2 + 2]);
          parsePathLineto(f1, f2);
          b2 += 3;
          continue;
        case 'l':
          f1 += PApplet.parseFloat(arrayOfString[b2 + 1]);
          f2 += PApplet.parseFloat(arrayOfString[b2 + 2]);
          parsePathLineto(f1, f2);
          b2 += 3;
          continue;
        case 'H':
          f1 = PApplet.parseFloat(arrayOfString[b2 + 1]);
          parsePathLineto(f1, f2);
          b2 += 2;
          continue;
        case 'h':
          f1 += PApplet.parseFloat(arrayOfString[b2 + 1]);
          parsePathLineto(f1, f2);
          b2 += 2;
          continue;
        case 'V':
          f2 = PApplet.parseFloat(arrayOfString[b2 + 1]);
          parsePathLineto(f1, f2);
          b2 += 2;
          continue;
        case 'v':
          f2 += PApplet.parseFloat(arrayOfString[b2 + 1]);
          parsePathLineto(f1, f2);
          b2 += 2;
          continue;
        case 'C':
          f5 = PApplet.parseFloat(arrayOfString[b2 + 1]);
          f6 = PApplet.parseFloat(arrayOfString[b2 + 2]);
          f7 = PApplet.parseFloat(arrayOfString[b2 + 3]);
          f8 = PApplet.parseFloat(arrayOfString[b2 + 4]);
          f9 = PApplet.parseFloat(arrayOfString[b2 + 5]);
          f10 = PApplet.parseFloat(arrayOfString[b2 + 6]);
          parsePathCurveto(f5, f6, f7, f8, f9, f10);
          f1 = f9;
          f2 = f10;
          b2 += 7;
          bool2 = true;
          continue;
        case 'c':
          f5 = f1 + PApplet.parseFloat(arrayOfString[b2 + 1]);
          f6 = f2 + PApplet.parseFloat(arrayOfString[b2 + 2]);
          f7 = f1 + PApplet.parseFloat(arrayOfString[b2 + 3]);
          f8 = f2 + PApplet.parseFloat(arrayOfString[b2 + 4]);
          f9 = f1 + PApplet.parseFloat(arrayOfString[b2 + 5]);
          f10 = f2 + PApplet.parseFloat(arrayOfString[b2 + 6]);
          parsePathCurveto(f5, f6, f7, f8, f9, f10);
          f1 = f9;
          f2 = f10;
          b2 += 7;
          bool2 = true;
          continue;
        case 'S':
          if (!bool2) {
            f3 = f1;
            f4 = f2;
          } else {
            f5 = this.vertices[this.vertexCount - 2][0];
            f6 = this.vertices[this.vertexCount - 2][1];
            f7 = this.vertices[this.vertexCount - 1][0];
            f8 = this.vertices[this.vertexCount - 1][1];
            f3 = f7 + f7 - f5;
            f4 = f8 + f8 - f6;
          } 
          f5 = PApplet.parseFloat(arrayOfString[b2 + 1]);
          f6 = PApplet.parseFloat(arrayOfString[b2 + 2]);
          f7 = PApplet.parseFloat(arrayOfString[b2 + 3]);
          f8 = PApplet.parseFloat(arrayOfString[b2 + 4]);
          parsePathCurveto(f3, f4, f5, f6, f7, f8);
          f1 = f7;
          f2 = f8;
          b2 += 5;
          bool2 = true;
          continue;
        case 's':
          if (!bool2) {
            f3 = f1;
            f4 = f2;
          } else {
            f5 = this.vertices[this.vertexCount - 2][0];
            f6 = this.vertices[this.vertexCount - 2][1];
            f7 = this.vertices[this.vertexCount - 1][0];
            f8 = this.vertices[this.vertexCount - 1][1];
            f3 = f7 + f7 - f5;
            f4 = f8 + f8 - f6;
          } 
          f5 = f1 + PApplet.parseFloat(arrayOfString[b2 + 1]);
          f6 = f2 + PApplet.parseFloat(arrayOfString[b2 + 2]);
          f7 = f1 + PApplet.parseFloat(arrayOfString[b2 + 3]);
          f8 = f2 + PApplet.parseFloat(arrayOfString[b2 + 4]);
          parsePathCurveto(f3, f4, f5, f6, f7, f8);
          f1 = f7;
          f2 = f8;
          b2 += 5;
          bool2 = true;
          continue;
        case 'Q':
          f3 = PApplet.parseFloat(arrayOfString[b2 + 1]);
          f4 = PApplet.parseFloat(arrayOfString[b2 + 2]);
          f5 = PApplet.parseFloat(arrayOfString[b2 + 3]);
          f6 = PApplet.parseFloat(arrayOfString[b2 + 4]);
          parsePathQuadto(f3, f4, f5, f6);
          f1 = f5;
          f2 = f6;
          b2 += 5;
          bool2 = true;
          continue;
        case 'q':
          f3 = f1 + PApplet.parseFloat(arrayOfString[b2 + 1]);
          f4 = f2 + PApplet.parseFloat(arrayOfString[b2 + 2]);
          f5 = f1 + PApplet.parseFloat(arrayOfString[b2 + 3]);
          f6 = f2 + PApplet.parseFloat(arrayOfString[b2 + 4]);
          parsePathQuadto(f3, f4, f5, f6);
          f1 = f5;
          f2 = f6;
          b2 += 5;
          bool2 = true;
          continue;
        case 'T':
          if (!bool2) {
            f3 = f1;
            f4 = f2;
          } else {
            f5 = this.vertices[this.vertexCount - 2][0];
            f6 = this.vertices[this.vertexCount - 2][1];
            f7 = this.vertices[this.vertexCount - 1][0];
            f8 = this.vertices[this.vertexCount - 1][1];
            f3 = f7 + f7 - f5;
            f4 = f8 + f8 - f6;
          } 
          f5 = PApplet.parseFloat(arrayOfString[b2 + 1]);
          f6 = PApplet.parseFloat(arrayOfString[b2 + 2]);
          parsePathQuadto(f3, f4, f5, f6);
          f1 = f5;
          f2 = f6;
          b2 += 3;
          bool2 = true;
          continue;
        case 't':
          if (!bool2) {
            f3 = f1;
            f4 = f2;
          } else {
            f5 = this.vertices[this.vertexCount - 2][0];
            f6 = this.vertices[this.vertexCount - 2][1];
            f7 = this.vertices[this.vertexCount - 1][0];
            f8 = this.vertices[this.vertexCount - 1][1];
            f3 = f7 + f7 - f5;
            f4 = f8 + f8 - f6;
          } 
          f5 = f1 + PApplet.parseFloat(arrayOfString[b2 + 1]);
          f6 = f2 + PApplet.parseFloat(arrayOfString[b2 + 2]);
          parsePathQuadto(f3, f4, f5, f6);
          f1 = f5;
          f2 = f6;
          b2 += 3;
          bool2 = true;
          continue;
        case 'Z':
        case 'z':
          this.close = true;
          b2++;
          continue;
      } 
      String str1 = PApplet.join(PApplet.subset(arrayOfString, 0, b2), ",");
      String str2 = PApplet.join(PApplet.subset(arrayOfString, b2), ",");
      System.err.println("parsed: " + str1);
      System.err.println("unparsed: " + str2);
      if (arrayOfString[b2].equals("a") || arrayOfString[b2].equals("A")) {
        String str3 = "Sorry, elliptical arc support for SVG files is not yet implemented (See issue #130 for updates)";
        throw new RuntimeException(str3);
      } 
      throw new RuntimeException("shape command not handled: " + arrayOfString[b2]);
    } 
  }
  
  private void parsePathVertex(float paramFloat1, float paramFloat2) {
    if (this.vertexCount == this.vertices.length) {
      float[][] arrayOfFloat = new float[this.vertexCount << 1][2];
      System.arraycopy(this.vertices, 0, arrayOfFloat, 0, this.vertexCount);
      this.vertices = arrayOfFloat;
    } 
    this.vertices[this.vertexCount][0] = paramFloat1;
    this.vertices[this.vertexCount][1] = paramFloat2;
    this.vertexCount++;
  }
  
  private void parsePathCode(int paramInt) {
    if (this.vertexCodeCount == this.vertexCodes.length)
      this.vertexCodes = PApplet.expand(this.vertexCodes); 
    this.vertexCodes[this.vertexCodeCount++] = paramInt;
  }
  
  private void parsePathMoveto(float paramFloat1, float paramFloat2) {
    if (this.vertexCount > 0)
      parsePathCode(4); 
    parsePathCode(0);
    parsePathVertex(paramFloat1, paramFloat2);
  }
  
  private void parsePathLineto(float paramFloat1, float paramFloat2) {
    parsePathCode(0);
    parsePathVertex(paramFloat1, paramFloat2);
  }
  
  private void parsePathCurveto(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    parsePathCode(1);
    parsePathVertex(paramFloat1, paramFloat2);
    parsePathVertex(paramFloat3, paramFloat4);
    parsePathVertex(paramFloat5, paramFloat6);
  }
  
  private void parsePathQuadto(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    parsePathCode(2);
    parsePathVertex(paramFloat1, paramFloat2);
    parsePathVertex(paramFloat3, paramFloat4);
  }
  
  protected static PMatrix2D parseTransform(String paramString) {
    paramString = paramString.trim();
    PMatrix2D pMatrix2D = null;
    int i = 0;
    int j = -1;
    while ((j = paramString.indexOf(')', i)) != -1) {
      PMatrix2D pMatrix2D1 = parseSingleTransform(paramString.substring(i, j + 1));
      if (pMatrix2D == null) {
        pMatrix2D = pMatrix2D1;
      } else {
        pMatrix2D.apply(pMatrix2D1);
      } 
      i = j + 1;
    } 
    return pMatrix2D;
  }
  
  protected static PMatrix2D parseSingleTransform(String paramString) {
    String[] arrayOfString = PApplet.match(paramString, "[,\\s]*(\\w+)\\((.*)\\)");
    if (arrayOfString == null) {
      System.err.println("Could not parse transform " + paramString);
      return null;
    } 
    float[] arrayOfFloat = PApplet.parseFloat(PApplet.splitTokens(arrayOfString[2], ", "));
    if (arrayOfString[1].equals("matrix"))
      return new PMatrix2D(arrayOfFloat[0], arrayOfFloat[2], arrayOfFloat[4], arrayOfFloat[1], arrayOfFloat[3], arrayOfFloat[5]); 
    if (arrayOfString[1].equals("translate")) {
      float f1 = arrayOfFloat[0];
      float f2 = (arrayOfFloat.length == 2) ? arrayOfFloat[1] : arrayOfFloat[0];
      return new PMatrix2D(1.0F, 0.0F, f1, 0.0F, 1.0F, f2);
    } 
    if (arrayOfString[1].equals("scale")) {
      float f1 = arrayOfFloat[0];
      float f2 = (arrayOfFloat.length == 2) ? arrayOfFloat[1] : arrayOfFloat[0];
      return new PMatrix2D(f1, 0.0F, 0.0F, 0.0F, f2, 0.0F);
    } 
    if (arrayOfString[1].equals("rotate")) {
      float f = arrayOfFloat[0];
      if (arrayOfFloat.length == 1) {
        float f1 = PApplet.cos(f);
        float f2 = PApplet.sin(f);
        return new PMatrix2D(f1, -f2, 0.0F, f2, f1, 0.0F);
      } 
      if (arrayOfFloat.length == 3) {
        PMatrix2D pMatrix2D = new PMatrix2D(0.0F, 1.0F, arrayOfFloat[1], 1.0F, 0.0F, arrayOfFloat[2]);
        pMatrix2D.rotate(arrayOfFloat[0]);
        pMatrix2D.translate(-arrayOfFloat[1], -arrayOfFloat[2]);
        return pMatrix2D;
      } 
    } else {
      if (arrayOfString[1].equals("skewX"))
        return new PMatrix2D(1.0F, 0.0F, 1.0F, PApplet.tan(arrayOfFloat[0]), 0.0F, 0.0F); 
      if (arrayOfString[1].equals("skewY"))
        return new PMatrix2D(1.0F, 0.0F, 1.0F, 0.0F, PApplet.tan(arrayOfFloat[0]), 0.0F); 
    } 
    return null;
  }
  
  protected void parseColors(XMLElement paramXMLElement) {
    if (paramXMLElement.hasAttribute("opacity")) {
      String str = paramXMLElement.getString("opacity");
      setOpacity(str);
    } 
    if (paramXMLElement.hasAttribute("stroke")) {
      String str = paramXMLElement.getString("stroke");
      setColor(str, false);
    } 
    if (paramXMLElement.hasAttribute("stroke-opacity")) {
      String str = paramXMLElement.getString("stroke-opacity");
      setStrokeOpacity(str);
    } 
    if (paramXMLElement.hasAttribute("stroke-width")) {
      String str = paramXMLElement.getString("stroke-width");
      setStrokeWeight(str);
    } 
    if (paramXMLElement.hasAttribute("stroke-linejoin")) {
      String str = paramXMLElement.getString("stroke-linejoin");
      setStrokeJoin(str);
    } 
    if (paramXMLElement.hasAttribute("stroke-linecap")) {
      String str = paramXMLElement.getString("stroke-linecap");
      setStrokeCap(str);
    } 
    if (paramXMLElement.hasAttribute("fill")) {
      String str = paramXMLElement.getString("fill");
      setColor(str, true);
    } 
    if (paramXMLElement.hasAttribute("fill-opacity")) {
      String str = paramXMLElement.getString("fill-opacity");
      setFillOpacity(str);
    } 
    if (paramXMLElement.hasAttribute("style")) {
      String str = paramXMLElement.getString("style");
      String[] arrayOfString = PApplet.splitTokens(str, ";");
      for (byte b = 0; b < arrayOfString.length; b++) {
        String[] arrayOfString1 = PApplet.splitTokens(arrayOfString[b], ":");
        arrayOfString1[0] = PApplet.trim(arrayOfString1[0]);
        if (arrayOfString1[0].equals("fill")) {
          setColor(arrayOfString1[1], true);
        } else if (arrayOfString1[0].equals("fill-opacity")) {
          setFillOpacity(arrayOfString1[1]);
        } else if (arrayOfString1[0].equals("stroke")) {
          setColor(arrayOfString1[1], false);
        } else if (arrayOfString1[0].equals("stroke-width")) {
          setStrokeWeight(arrayOfString1[1]);
        } else if (arrayOfString1[0].equals("stroke-linecap")) {
          setStrokeCap(arrayOfString1[1]);
        } else if (arrayOfString1[0].equals("stroke-linejoin")) {
          setStrokeJoin(arrayOfString1[1]);
        } else if (arrayOfString1[0].equals("stroke-opacity")) {
          setStrokeOpacity(arrayOfString1[1]);
        } else if (arrayOfString1[0].equals("opacity")) {
          setOpacity(arrayOfString1[1]);
        } 
      } 
    } 
  }
  
  void setOpacity(String paramString) {
    this.opacity = PApplet.parseFloat(paramString);
    this.strokeColor = (int)(this.opacity * 255.0F) << 24 | this.strokeColor & 0xFFFFFF;
    this.fillColor = (int)(this.opacity * 255.0F) << 24 | this.fillColor & 0xFFFFFF;
  }
  
  void setStrokeWeight(String paramString) {
    this.strokeWeight = parseUnitSize(paramString);
  }
  
  void setStrokeOpacity(String paramString) {
    this.strokeOpacity = PApplet.parseFloat(paramString);
    this.strokeColor = (int)(this.strokeOpacity * 255.0F) << 24 | this.strokeColor & 0xFFFFFF;
  }
  
  void setStrokeJoin(String paramString) {
    if (!paramString.equals("inherit"))
      if (paramString.equals("miter")) {
        this.strokeJoin = 8;
      } else if (paramString.equals("round")) {
        this.strokeJoin = 2;
      } else if (paramString.equals("bevel")) {
        this.strokeJoin = 32;
      }  
  }
  
  void setStrokeCap(String paramString) {
    if (!paramString.equals("inherit"))
      if (paramString.equals("butt")) {
        this.strokeCap = 1;
      } else if (paramString.equals("round")) {
        this.strokeCap = 2;
      } else if (paramString.equals("square")) {
        this.strokeCap = 4;
      }  
  }
  
  void setFillOpacity(String paramString) {
    this.fillOpacity = PApplet.parseFloat(paramString);
    this.fillColor = (int)(this.fillOpacity * 255.0F) << 24 | this.fillColor & 0xFFFFFF;
  }
  
  void setColor(String paramString, boolean paramBoolean) {
    int i = this.fillColor & 0xFF000000;
    boolean bool = true;
    int j = 0;
    String str = "";
    Gradient gradient = null;
    Paint paint = null;
    if (paramString.equals("none")) {
      bool = false;
    } else if (paramString.equals("black")) {
      j = i;
    } else if (paramString.equals("white")) {
      j = i | 0xFFFFFF;
    } else if (paramString.startsWith("#")) {
      if (paramString.length() == 4)
        paramString = paramString.replaceAll("^#(.)(.)(.)$", "#$1$1$2$2$3$3"); 
      j = i | Integer.parseInt(paramString.substring(1), 16) & 0xFFFFFF;
    } else if (paramString.startsWith("rgb")) {
      j = i | parseRGB(paramString);
    } else if (paramString.startsWith("url(#")) {
      str = paramString.substring(5, paramString.length() - 1);
      PShape pShape = findChild(str);
      if (pShape instanceof Gradient) {
        gradient = (Gradient)pShape;
        paint = calcGradientPaint(gradient);
      } else {
        System.err.println("url " + str + " refers to unexpected data: " + pShape);
      } 
    } 
    if (paramBoolean) {
      this.fill = bool;
      this.fillColor = j;
      this.fillName = str;
      this.fillGradient = gradient;
      this.fillGradientPaint = paint;
    } else {
      this.stroke = bool;
      this.strokeColor = j;
      this.strokeName = str;
      this.strokeGradient = gradient;
      this.strokeGradientPaint = paint;
    } 
  }
  
  protected static int parseRGB(String paramString) {
    int i = paramString.indexOf('(') + 1;
    int j = paramString.indexOf(')');
    String str = paramString.substring(i, j);
    int[] arrayOfInt = PApplet.parseInt(PApplet.splitTokens(str, ", "));
    return arrayOfInt[0] << 16 | arrayOfInt[1] << 8 | arrayOfInt[2];
  }
  
  protected static HashMap<String, String> parseStyleAttributes(String paramString) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    String[] arrayOfString = paramString.split(";");
    for (byte b = 0; b < arrayOfString.length; b++) {
      String[] arrayOfString1 = arrayOfString[b].split(":");
      hashMap.put(arrayOfString1[0], arrayOfString1[1]);
    } 
    return (HashMap)hashMap;
  }
  
  protected static float getFloatWithUnit(XMLElement paramXMLElement, String paramString) {
    String str = paramXMLElement.getString(paramString);
    return (str == null) ? 0.0F : parseUnitSize(str);
  }
  
  protected static float parseUnitSize(String paramString) {
    int i = paramString.length() - 2;
    return paramString.endsWith("pt") ? (PApplet.parseFloat(paramString.substring(0, i)) * 1.25F) : (paramString.endsWith("pc") ? (PApplet.parseFloat(paramString.substring(0, i)) * 15.0F) : (paramString.endsWith("mm") ? (PApplet.parseFloat(paramString.substring(0, i)) * 3.543307F) : (paramString.endsWith("cm") ? (PApplet.parseFloat(paramString.substring(0, i)) * 35.43307F) : (paramString.endsWith("in") ? (PApplet.parseFloat(paramString.substring(0, i)) * 90.0F) : (paramString.endsWith("px") ? PApplet.parseFloat(paramString.substring(0, i)) : PApplet.parseFloat(paramString))))));
  }
  
  protected Paint calcGradientPaint(Gradient paramGradient) {
    if (paramGradient instanceof LinearGradient) {
      LinearGradient linearGradient = (LinearGradient)paramGradient;
      return new LinearGradientPaint(linearGradient.x1, linearGradient.y1, linearGradient.x2, linearGradient.y2, linearGradient.offset, linearGradient.color, linearGradient.count, this.opacity);
    } 
    if (paramGradient instanceof RadialGradient) {
      RadialGradient radialGradient = (RadialGradient)paramGradient;
      return new RadialGradientPaint(radialGradient.cx, radialGradient.cy, radialGradient.r, radialGradient.offset, radialGradient.color, radialGradient.count, this.opacity);
    } 
    return null;
  }
  
  protected void styles(PGraphics paramPGraphics) {
    super.styles(paramPGraphics);
    if (paramPGraphics instanceof PGraphicsJava2D) {
      PGraphicsJava2D pGraphicsJava2D = (PGraphicsJava2D)paramPGraphics;
      if (this.strokeGradient != null) {
        pGraphicsJava2D.strokeGradient = true;
        pGraphicsJava2D.strokeGradientObject = this.strokeGradientPaint;
      } 
      if (this.fillGradient != null) {
        pGraphicsJava2D.fillGradient = true;
        pGraphicsJava2D.fillGradientObject = this.fillGradientPaint;
      } 
    } 
  }
  
  public PShape getChild(String paramString) {
    PShape pShape = super.getChild(paramString);
    if (pShape == null)
      pShape = super.getChild(paramString.replace(' ', '_')); 
    if (pShape != null) {
      pShape.width = this.width;
      pShape.height = this.height;
    } 
    return pShape;
  }
  
  public void print() {
    PApplet.println(this.element.toString());
  }
  
  public class FontGlyph extends PShapeSVG {
    public String name;
    
    char unicode;
    
    int horizAdvX;
    
    public FontGlyph(PShapeSVG param1PShapeSVG1, XMLElement param1XMLElement, PShapeSVG.Font param1Font) {
      super(param1PShapeSVG1, param1XMLElement, true);
      parsePath();
      this.name = param1XMLElement.getString("glyph-name");
      String str = param1XMLElement.getString("unicode");
      this.unicode = Character.MIN_VALUE;
      if (str != null)
        if (str.length() == 1) {
          this.unicode = str.charAt(0);
        } else {
          System.err.println("unicode for " + this.name + " is more than one char: " + str);
        }  
      if (param1XMLElement.hasAttribute("horiz-adv-x")) {
        this.horizAdvX = param1XMLElement.getInt("horiz-adv-x");
      } else {
        this.horizAdvX = param1Font.horizAdvX;
      } 
    }
    
    protected boolean isLegit() {
      return (this.vertexCount != 0);
    }
  }
  
  class FontFace extends PShapeSVG {
    int horizOriginX;
    
    int horizOriginY;
    
    int vertOriginX;
    
    int vertOriginY;
    
    int vertAdvY;
    
    String fontFamily;
    
    int fontWeight;
    
    String fontStretch;
    
    int unitsPerEm;
    
    int[] panose1;
    
    int ascent;
    
    int descent;
    
    int[] bbox;
    
    int underlineThickness;
    
    int underlinePosition;
    
    public FontFace(PShapeSVG param1PShapeSVG1, XMLElement param1XMLElement) {
      super(param1PShapeSVG1, param1XMLElement, true);
      this.unitsPerEm = param1XMLElement.getInt("units-per-em", 1000);
    }
    
    protected void drawShape() {}
  }
  
  public class Font extends PShapeSVG {
    public PShapeSVG.FontFace face;
    
    public HashMap<String, PShapeSVG.FontGlyph> namedGlyphs;
    
    public HashMap<Character, PShapeSVG.FontGlyph> unicodeGlyphs;
    
    public int glyphCount;
    
    public PShapeSVG.FontGlyph[] glyphs;
    
    public PShapeSVG.FontGlyph missingGlyph;
    
    int horizAdvX;
    
    public Font(PShapeSVG param1PShapeSVG1, XMLElement param1XMLElement) {
      super(param1PShapeSVG1, param1XMLElement, false);
      XMLElement[] arrayOfXMLElement = param1XMLElement.getChildren();
      this.horizAdvX = param1XMLElement.getInt("horiz-adv-x", 0);
      this.namedGlyphs = new HashMap<String, PShapeSVG.FontGlyph>();
      this.unicodeGlyphs = new HashMap<Character, PShapeSVG.FontGlyph>();
      this.glyphCount = 0;
      this.glyphs = new PShapeSVG.FontGlyph[arrayOfXMLElement.length];
      for (byte b = 0; b < arrayOfXMLElement.length; b++) {
        String str = arrayOfXMLElement[b].getName();
        XMLElement xMLElement = arrayOfXMLElement[b];
        if (str.equals("glyph")) {
          PShapeSVG.FontGlyph fontGlyph = new PShapeSVG.FontGlyph(this, xMLElement, this);
          if (fontGlyph.isLegit()) {
            if (fontGlyph.name != null)
              this.namedGlyphs.put(fontGlyph.name, fontGlyph); 
            if (fontGlyph.unicode != '\000')
              this.unicodeGlyphs.put(new Character(fontGlyph.unicode), fontGlyph); 
          } 
          this.glyphs[this.glyphCount++] = fontGlyph;
        } else if (str.equals("missing-glyph")) {
          this.missingGlyph = new PShapeSVG.FontGlyph(this, xMLElement, this);
        } else if (str.equals("font-face")) {
          this.face = new PShapeSVG.FontFace(this, xMLElement);
        } else {
          System.err.println("Ignoring " + str + " inside <font>");
        } 
      } 
    }
    
    protected void drawShape() {}
    
    public void drawString(PGraphics param1PGraphics, String param1String, float param1Float1, float param1Float2, float param1Float3) {
      param1PGraphics.pushMatrix();
      float f = param1Float3 / this.face.unitsPerEm;
      param1PGraphics.translate(param1Float1, param1Float2);
      param1PGraphics.scale(f, -f);
      char[] arrayOfChar = param1String.toCharArray();
      for (byte b = 0; b < arrayOfChar.length; b++) {
        PShapeSVG.FontGlyph fontGlyph = this.unicodeGlyphs.get(new Character(arrayOfChar[b]));
        if (fontGlyph != null) {
          fontGlyph.draw(param1PGraphics);
          param1PGraphics.translate(fontGlyph.horizAdvX, 0.0F);
        } else {
          System.err.println("'" + arrayOfChar[b] + "' not available.");
        } 
      } 
      param1PGraphics.popMatrix();
    }
    
    public void drawChar(PGraphics param1PGraphics, char param1Char, float param1Float1, float param1Float2, float param1Float3) {
      param1PGraphics.pushMatrix();
      float f = param1Float3 / this.face.unitsPerEm;
      param1PGraphics.translate(param1Float1, param1Float2);
      param1PGraphics.scale(f, -f);
      PShapeSVG.FontGlyph fontGlyph = this.unicodeGlyphs.get(new Character(param1Char));
      if (fontGlyph != null)
        param1PGraphics.shape(fontGlyph); 
      param1PGraphics.popMatrix();
    }
    
    public float textWidth(String param1String, float param1Float) {
      float f = 0.0F;
      char[] arrayOfChar = param1String.toCharArray();
      for (byte b = 0; b < arrayOfChar.length; b++) {
        PShapeSVG.FontGlyph fontGlyph = this.unicodeGlyphs.get(new Character(arrayOfChar[b]));
        if (fontGlyph != null)
          f += fontGlyph.horizAdvX / this.face.unitsPerEm; 
      } 
      return f * param1Float;
    }
  }
  
  class RadialGradientPaint implements Paint {
    float cx;
    
    float cy;
    
    float radius;
    
    float[] offset;
    
    int[] color;
    
    int count;
    
    float opacity;
    
    public RadialGradientPaint(float param1Float1, float param1Float2, float param1Float3, float[] param1ArrayOffloat, int[] param1ArrayOfint, int param1Int, float param1Float4) {
      this.cx = param1Float1;
      this.cy = param1Float2;
      this.radius = param1Float3;
      this.offset = param1ArrayOffloat;
      this.color = param1ArrayOfint;
      this.count = param1Int;
      this.opacity = param1Float4;
    }
    
    public PaintContext createContext(ColorModel param1ColorModel, Rectangle param1Rectangle, Rectangle2D param1Rectangle2D, AffineTransform param1AffineTransform, RenderingHints param1RenderingHints) {
      return new RadialGradientContext();
    }
    
    public int getTransparency() {
      return 3;
    }
    
    public class RadialGradientContext implements PaintContext {
      int ACCURACY = 5;
      
      public void dispose() {}
      
      public ColorModel getColorModel() {
        return ColorModel.getRGBdefault();
      }
      
      public Raster getRaster(int param2Int1, int param2Int2, int param2Int3, int param2Int4) {
        WritableRaster writableRaster = getColorModel().createCompatibleWritableRaster(param2Int3, param2Int4);
        int i = (int)PShapeSVG.RadialGradientPaint.this.radius * this.ACCURACY;
        int[][] arrayOfInt = new int[i][4];
        int j = 0;
        for (byte b1 = 1; b1 < PShapeSVG.RadialGradientPaint.this.count; b1++) {
          int k = PShapeSVG.RadialGradientPaint.this.color[b1 - 1];
          int m = PShapeSVG.RadialGradientPaint.this.color[b1];
          int n = (int)(PShapeSVG.RadialGradientPaint.this.offset[b1] * (i - 1));
          for (int i1 = j; i1 <= n; i1++) {
            float f = PApplet.norm(i1, j, n);
            arrayOfInt[i1][0] = (int)PApplet.lerp((k >> 16 & 0xFF), (m >> 16 & 0xFF), f);
            arrayOfInt[i1][1] = (int)PApplet.lerp((k >> 8 & 0xFF), (m >> 8 & 0xFF), f);
            arrayOfInt[i1][2] = (int)PApplet.lerp((k & 0xFF), (m & 0xFF), f);
            arrayOfInt[i1][3] = (int)(PApplet.lerp((k >> 24 & 0xFF), (m >> 24 & 0xFF), f) * PShapeSVG.RadialGradientPaint.this.opacity);
          } 
          j = n;
        } 
        int[] arrayOfInt1 = new int[param2Int3 * param2Int4 * 4];
        byte b2 = 0;
        for (byte b3 = 0; b3 < param2Int4; b3++) {
          for (byte b = 0; b < param2Int3; b++) {
            float f = PApplet.dist(PShapeSVG.RadialGradientPaint.this.cx, PShapeSVG.RadialGradientPaint.this.cy, (param2Int1 + b), (param2Int2 + b3));
            int k = PApplet.min((int)(f * this.ACCURACY), arrayOfInt.length - 1);
            arrayOfInt1[b2++] = arrayOfInt[k][0];
            arrayOfInt1[b2++] = arrayOfInt[k][1];
            arrayOfInt1[b2++] = arrayOfInt[k][2];
            arrayOfInt1[b2++] = arrayOfInt[k][3];
          } 
        } 
        writableRaster.setPixels(0, 0, param2Int3, param2Int4, arrayOfInt1);
        return writableRaster;
      }
    }
  }
  
  class LinearGradientPaint implements Paint {
    float x1;
    
    float y1;
    
    float x2;
    
    float y2;
    
    float[] offset;
    
    int[] color;
    
    int count;
    
    float opacity;
    
    public LinearGradientPaint(float param1Float1, float param1Float2, float param1Float3, float param1Float4, float[] param1ArrayOffloat, int[] param1ArrayOfint, int param1Int, float param1Float5) {
      this.x1 = param1Float1;
      this.y1 = param1Float2;
      this.x2 = param1Float3;
      this.y2 = param1Float4;
      this.offset = param1ArrayOffloat;
      this.color = param1ArrayOfint;
      this.count = param1Int;
      this.opacity = param1Float5;
    }
    
    public PaintContext createContext(ColorModel param1ColorModel, Rectangle param1Rectangle, Rectangle2D param1Rectangle2D, AffineTransform param1AffineTransform, RenderingHints param1RenderingHints) {
      Point2D point2D1 = param1AffineTransform.transform(new Point2D.Float(this.x1, this.y1), null);
      Point2D point2D2 = param1AffineTransform.transform(new Point2D.Float(this.x2, this.y2), null);
      return new LinearGradientContext((float)point2D1.getX(), (float)point2D1.getY(), (float)point2D2.getX(), (float)point2D2.getY());
    }
    
    public int getTransparency() {
      return 3;
    }
    
    public class LinearGradientContext implements PaintContext {
      int ACCURACY = 2;
      
      float tx1;
      
      float ty1;
      
      float tx2;
      
      float ty2;
      
      public LinearGradientContext(float param2Float1, float param2Float2, float param2Float3, float param2Float4) {
        this.tx1 = param2Float1;
        this.ty1 = param2Float2;
        this.tx2 = param2Float3;
        this.ty2 = param2Float4;
      }
      
      public void dispose() {}
      
      public ColorModel getColorModel() {
        return ColorModel.getRGBdefault();
      }
      
      public Raster getRaster(int param2Int1, int param2Int2, int param2Int3, int param2Int4) {
        WritableRaster writableRaster = getColorModel().createCompatibleWritableRaster(param2Int3, param2Int4);
        int[] arrayOfInt = new int[param2Int3 * param2Int4 * 4];
        float f1 = this.tx2 - this.tx1;
        float f2 = this.ty2 - this.ty1;
        float f3 = (float)Math.sqrt((f1 * f1 + f2 * f2));
        if (f3 != 0.0F) {
          f1 /= f3;
          f2 /= f3;
        } 
        int i = (int)PApplet.dist(this.tx1, this.ty1, this.tx2, this.ty2) * this.ACCURACY;
        if (i <= 0) {
          byte b1 = 0;
          for (byte b2 = 0; b2 < param2Int4; b2++) {
            for (byte b = 0; b < param2Int3; b++) {
              arrayOfInt[b1++] = 0;
              arrayOfInt[b1++] = 0;
              arrayOfInt[b1++] = 0;
              arrayOfInt[b1++] = 255;
            } 
          } 
        } else {
          int[][] arrayOfInt1 = new int[i][4];
          int j = 0;
          byte b1;
          for (b1 = 1; b1 < PShapeSVG.LinearGradientPaint.this.count; b1++) {
            int k = PShapeSVG.LinearGradientPaint.this.color[b1 - 1];
            int m = PShapeSVG.LinearGradientPaint.this.color[b1];
            int n = (int)(PShapeSVG.LinearGradientPaint.this.offset[b1] * (i - 1));
            for (int i1 = j; i1 <= n; i1++) {
              float f = PApplet.norm(i1, j, n);
              arrayOfInt1[i1][0] = (int)PApplet.lerp((k >> 16 & 0xFF), (m >> 16 & 0xFF), f);
              arrayOfInt1[i1][1] = (int)PApplet.lerp((k >> 8 & 0xFF), (m >> 8 & 0xFF), f);
              arrayOfInt1[i1][2] = (int)PApplet.lerp((k & 0xFF), (m & 0xFF), f);
              arrayOfInt1[i1][3] = (int)(PApplet.lerp((k >> 24 & 0xFF), (m >> 24 & 0xFF), f) * PShapeSVG.LinearGradientPaint.this.opacity);
            } 
            j = n;
          } 
          b1 = 0;
          for (byte b2 = 0; b2 < param2Int4; b2++) {
            for (byte b = 0; b < param2Int3; b++) {
              float f4 = (param2Int1 + b) - this.tx1;
              float f5 = (param2Int2 + b2) - this.ty1;
              int k = (int)((f4 * f1 + f5 * f2) * this.ACCURACY);
              if (k < 0)
                k = 0; 
              if (k > arrayOfInt1.length - 1)
                k = arrayOfInt1.length - 1; 
              arrayOfInt[b1++] = arrayOfInt1[k][0];
              arrayOfInt[b1++] = arrayOfInt1[k][1];
              arrayOfInt[b1++] = arrayOfInt1[k][2];
              arrayOfInt[b1++] = arrayOfInt1[k][3];
            } 
          } 
        } 
        writableRaster.setPixels(0, 0, param2Int3, param2Int4, arrayOfInt);
        return writableRaster;
      }
    }
  }
  
  class RadialGradient extends Gradient {
    float cx;
    
    float cy;
    
    float r;
    
    public RadialGradient(PShapeSVG param1PShapeSVG1, XMLElement param1XMLElement) {
      super(param1XMLElement);
      this.cx = getFloatWithUnit(param1XMLElement, "cx");
      this.cy = getFloatWithUnit(param1XMLElement, "cy");
      this.r = getFloatWithUnit(param1XMLElement, "r");
      String str = param1XMLElement.getString("gradientTransform");
      if (str != null) {
        float[] arrayOfFloat = parseTransform(str).get(null);
        this.transform = new AffineTransform(arrayOfFloat[0], arrayOfFloat[3], arrayOfFloat[1], arrayOfFloat[4], arrayOfFloat[2], arrayOfFloat[5]);
        Point2D point2D1 = this.transform.transform(new Point2D.Float(this.cx, this.cy), null);
        Point2D point2D2 = this.transform.transform(new Point2D.Float(this.cx + this.r, this.cy), null);
        this.cx = (float)point2D1.getX();
        this.cy = (float)point2D1.getY();
        this.r = (float)(point2D2.getX() - point2D1.getX());
      } 
    }
  }
  
  class LinearGradient extends Gradient {
    float x1;
    
    float y1;
    
    float x2;
    
    float y2;
    
    public LinearGradient(PShapeSVG param1PShapeSVG1, XMLElement param1XMLElement) {
      super(param1XMLElement);
      this.x1 = getFloatWithUnit(param1XMLElement, "x1");
      this.y1 = getFloatWithUnit(param1XMLElement, "y1");
      this.x2 = getFloatWithUnit(param1XMLElement, "x2");
      this.y2 = getFloatWithUnit(param1XMLElement, "y2");
      String str = param1XMLElement.getString("gradientTransform");
      if (str != null) {
        float[] arrayOfFloat = parseTransform(str).get(null);
        this.transform = new AffineTransform(arrayOfFloat[0], arrayOfFloat[3], arrayOfFloat[1], arrayOfFloat[4], arrayOfFloat[2], arrayOfFloat[5]);
        Point2D point2D1 = this.transform.transform(new Point2D.Float(this.x1, this.y1), null);
        Point2D point2D2 = this.transform.transform(new Point2D.Float(this.x2, this.y2), null);
        this.x1 = (float)point2D1.getX();
        this.y1 = (float)point2D1.getY();
        this.x2 = (float)point2D2.getX();
        this.y2 = (float)point2D2.getY();
      } 
    }
  }
  
  static class Gradient extends PShapeSVG {
    AffineTransform transform;
    
    float[] offset;
    
    int[] color;
    
    int count;
    
    public Gradient(PShapeSVG param1PShapeSVG, XMLElement param1XMLElement) {
      super(param1PShapeSVG, param1XMLElement, true);
      XMLElement[] arrayOfXMLElement = param1XMLElement.getChildren();
      this.offset = new float[arrayOfXMLElement.length];
      this.color = new int[arrayOfXMLElement.length];
      for (byte b = 0; b < arrayOfXMLElement.length; b++) {
        XMLElement xMLElement = arrayOfXMLElement[b];
        String str = xMLElement.getName();
        if (str.equals("stop")) {
          String str1 = xMLElement.getString("offset");
          float f = 1.0F;
          if (str1.endsWith("%")) {
            f = 100.0F;
            str1 = str1.substring(0, str1.length() - 1);
          } 
          this.offset[this.count] = PApplet.parseFloat(str1) / f;
          String str2 = xMLElement.getString("style");
          HashMap<String, String> hashMap = parseStyleAttributes(str2);
          String str3 = hashMap.get("stop-color");
          if (str3 == null)
            str3 = "#000000"; 
          String str4 = hashMap.get("stop-opacity");
          if (str4 == null)
            str4 = "1"; 
          int i = (int)(PApplet.parseFloat(str4) * 255.0F);
          this.color[this.count] = i << 24 | Integer.parseInt(str3.substring(1), 16);
          this.count++;
        } 
      } 
      this.offset = PApplet.subset(this.offset, 0, this.count);
      this.color = PApplet.subset(this.color, 0, this.count);
    }
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\core\PShapeSVG.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */