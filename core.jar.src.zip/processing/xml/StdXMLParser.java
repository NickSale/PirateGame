package processing.xml;

import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;

public class StdXMLParser {
  private StdXMLBuilder builder = null;
  
  private StdXMLReader reader = null;
  
  private XMLEntityResolver entityResolver = new XMLEntityResolver();
  
  private XMLValidator validator = null;
  
  protected void finalize() throws Throwable {
    this.builder = null;
    this.reader = null;
    this.entityResolver = null;
    this.validator = null;
    super.finalize();
  }
  
  public void setBuilder(StdXMLBuilder paramStdXMLBuilder) {
    this.builder = paramStdXMLBuilder;
  }
  
  public StdXMLBuilder getBuilder() {
    return this.builder;
  }
  
  public void setValidator(XMLValidator paramXMLValidator) {
    this.validator = paramXMLValidator;
  }
  
  public XMLValidator getValidator() {
    return this.validator;
  }
  
  public void setResolver(XMLEntityResolver paramXMLEntityResolver) {
    this.entityResolver = paramXMLEntityResolver;
  }
  
  public XMLEntityResolver getResolver() {
    return this.entityResolver;
  }
  
  public void setReader(StdXMLReader paramStdXMLReader) {
    this.reader = paramStdXMLReader;
  }
  
  public StdXMLReader getReader() {
    return this.reader;
  }
  
  public Object parse() throws XMLException {
    try {
      this.builder.startBuilding(this.reader.getSystemID(), this.reader.getLineNr());
      scanData();
      return this.builder.getResult();
    } catch (XMLException xMLException) {
      throw xMLException;
    } catch (Exception exception) {
      throw new XMLException(exception);
    } 
  }
  
  protected void scanData() throws Exception {
    while (!this.reader.atEOF() && this.builder.getResult() == null) {
      String str = XMLUtil.read(this.reader, '&');
      char c = str.charAt(0);
      if (c == '&') {
        XMLUtil.processEntity(str, this.reader, this.entityResolver);
        continue;
      } 
      switch (c) {
        case '<':
          scanSomeTag(false, null, new Properties());
          continue;
        case '\t':
        case '\n':
        case '\r':
        case ' ':
          continue;
      } 
      XMLUtil.errorInvalidInput(this.reader.getSystemID(), this.reader.getLineNr(), "`" + c + "' (0x" + Integer.toHexString(c) + ')');
    } 
  }
  
  protected void scanSomeTag(boolean paramBoolean, String paramString, Properties paramProperties) throws Exception {
    String str = XMLUtil.read(this.reader, '&');
    char c = str.charAt(0);
    if (c == '&')
      XMLUtil.errorUnexpectedEntity(this.reader.getSystemID(), this.reader.getLineNr(), str); 
    switch (c) {
      case '?':
        processPI();
        return;
      case '!':
        processSpecialTag(paramBoolean);
        return;
    } 
    this.reader.unread(c);
    processElement(paramString, paramProperties);
  }
  
  protected void processPI() throws Exception {
    XMLUtil.skipWhitespace(this.reader, null);
    String str = XMLUtil.scanIdentifier(this.reader);
    XMLUtil.skipWhitespace(this.reader, null);
    PIReader pIReader = new PIReader(this.reader);
    if (!str.equalsIgnoreCase("xml"))
      this.builder.newProcessingInstruction(str, pIReader); 
    pIReader.close();
  }
  
  protected void processSpecialTag(boolean paramBoolean) throws Exception {
    String str = XMLUtil.read(this.reader, '&');
    char c = str.charAt(0);
    if (c == '&')
      XMLUtil.errorUnexpectedEntity(this.reader.getSystemID(), this.reader.getLineNr(), str); 
    switch (c) {
      case '[':
        if (paramBoolean) {
          processCDATA();
        } else {
          XMLUtil.errorUnexpectedCDATA(this.reader.getSystemID(), this.reader.getLineNr());
        } 
        return;
      case 'D':
        processDocType();
        return;
      case '-':
        XMLUtil.skipComment(this.reader);
        return;
    } 
  }
  
  protected void processCDATA() throws Exception {
    if (!XMLUtil.checkLiteral(this.reader, "CDATA["))
      XMLUtil.errorExpectedInput(this.reader.getSystemID(), this.reader.getLineNr(), "<![[CDATA["); 
    this.validator.PCDataAdded(this.reader.getSystemID(), this.reader.getLineNr());
    CDATAReader cDATAReader = new CDATAReader(this.reader);
    this.builder.addPCData(cDATAReader, this.reader.getSystemID(), this.reader.getLineNr());
    cDATAReader.close();
  }
  
  protected void processDocType() throws Exception {
    if (!XMLUtil.checkLiteral(this.reader, "OCTYPE")) {
      XMLUtil.errorExpectedInput(this.reader.getSystemID(), this.reader.getLineNr(), "<!DOCTYPE");
      return;
    } 
    XMLUtil.skipWhitespace(this.reader, null);
    String str = null;
    StringBuffer stringBuffer = new StringBuffer();
    XMLUtil.scanIdentifier(this.reader);
    XMLUtil.skipWhitespace(this.reader, null);
    char c = this.reader.read();
    if (c == 'P') {
      str = XMLUtil.scanPublicID(stringBuffer, this.reader);
      XMLUtil.skipWhitespace(this.reader, null);
      c = this.reader.read();
    } else if (c == 'S') {
      str = XMLUtil.scanSystemID(this.reader);
      XMLUtil.skipWhitespace(this.reader, null);
      c = this.reader.read();
    } 
    if (c == '[') {
      this.validator.parseDTD(stringBuffer.toString(), this.reader, this.entityResolver, false);
      XMLUtil.skipWhitespace(this.reader, null);
      c = this.reader.read();
    } 
    if (c != '>')
      XMLUtil.errorExpectedInput(this.reader.getSystemID(), this.reader.getLineNr(), "`>'"); 
  }
  
  protected void processElement(String paramString, Properties paramProperties) throws Exception {
    char c;
    String str1 = XMLUtil.scanIdentifier(this.reader);
    String str2 = str1;
    XMLUtil.skipWhitespace(this.reader, null);
    String str3 = null;
    int i = str2.indexOf(':');
    if (i > 0) {
      str3 = str2.substring(0, i);
      str2 = str2.substring(i + 1);
    } 
    Vector<String> vector1 = new Vector();
    Vector<String> vector2 = new Vector();
    Vector<String> vector3 = new Vector();
    this.validator.elementStarted(str1, this.reader.getSystemID(), this.reader.getLineNr());
    while (true) {
      c = this.reader.read();
      if (c == '/' || c == '>')
        break; 
      this.reader.unread(c);
      processAttribute(vector1, vector2, vector3);
      XMLUtil.skipWhitespace(this.reader, null);
    } 
    Properties properties = new Properties();
    this.validator.elementAttributesProcessed(str1, properties, this.reader.getSystemID(), this.reader.getLineNr());
    Enumeration<String> enumeration = properties.keys();
    while (enumeration.hasMoreElements()) {
      String str4 = enumeration.nextElement();
      String str5 = properties.getProperty(str4);
      vector1.addElement(str4);
      vector2.addElement(str5);
      vector3.addElement("CDATA");
    } 
    if (str3 == null) {
      this.builder.startElement(str2, str3, paramString, this.reader.getSystemID(), this.reader.getLineNr());
    } else {
      this.builder.startElement(str2, str3, paramProperties.getProperty(str3), this.reader.getSystemID(), this.reader.getLineNr());
    } 
    for (byte b = 0; b < vector1.size(); b++) {
      String str4 = vector1.elementAt(b);
      String str5 = vector2.elementAt(b);
      String str6 = vector3.elementAt(b);
      i = str4.indexOf(':');
      if (i > 0) {
        String str = str4.substring(0, i);
        str4 = str4.substring(i + 1);
        this.builder.addAttribute(str4, str, paramProperties.getProperty(str), str5, str6);
      } else {
        this.builder.addAttribute(str4, null, null, str5, str6);
      } 
    } 
    if (str3 == null) {
      this.builder.elementAttributesProcessed(str2, str3, paramString);
    } else {
      this.builder.elementAttributesProcessed(str2, str3, paramProperties.getProperty(str3));
    } 
    if (c == '/') {
      if (this.reader.read() != '>')
        XMLUtil.errorExpectedInput(this.reader.getSystemID(), this.reader.getLineNr(), "`>'"); 
      this.validator.elementEnded(str2, this.reader.getSystemID(), this.reader.getLineNr());
      if (str3 == null) {
        this.builder.endElement(str2, str3, paramString);
      } else {
        this.builder.endElement(str2, str3, paramProperties.getProperty(str3));
      } 
      return;
    } 
    StringBuffer stringBuffer = new StringBuffer(16);
    while (true) {
      String str;
      stringBuffer.setLength(0);
      while (true) {
        XMLUtil.skipWhitespace(this.reader, stringBuffer);
        str = XMLUtil.read(this.reader, '&');
        if (str.charAt(0) == '&' && str.charAt(1) != '#') {
          XMLUtil.processEntity(str, this.reader, this.entityResolver);
          continue;
        } 
        break;
      } 
      if (str.charAt(0) == '<') {
        str = XMLUtil.read(this.reader, false);
        if (str.charAt(0) == '/') {
          XMLUtil.skipWhitespace(this.reader, null);
          str = XMLUtil.scanIdentifier(this.reader);
          if (!str.equals(str1))
            XMLUtil.errorWrongClosingTag(this.reader.getSystemID(), this.reader.getLineNr(), str2, str); 
          XMLUtil.skipWhitespace(this.reader, null);
          if (this.reader.read() != '>')
            XMLUtil.errorClosingTagNotEmpty(this.reader.getSystemID(), this.reader.getLineNr()); 
          this.validator.elementEnded(str1, this.reader.getSystemID(), this.reader.getLineNr());
          if (str3 == null) {
            this.builder.endElement(str2, str3, paramString);
            break;
          } 
          this.builder.endElement(str2, str3, paramProperties.getProperty(str3));
          break;
        } 
        this.reader.unread(str.charAt(0));
        scanSomeTag(true, paramString, (Properties)paramProperties.clone());
        continue;
      } 
      if (str.charAt(0) == '&') {
        c = XMLUtil.processCharLiteral(str);
        stringBuffer.append(c);
      } else {
        this.reader.unread(str.charAt(0));
      } 
      this.validator.PCDataAdded(this.reader.getSystemID(), this.reader.getLineNr());
      ContentReader contentReader = new ContentReader(this.reader, this.entityResolver, stringBuffer.toString());
      this.builder.addPCData(contentReader, this.reader.getSystemID(), this.reader.getLineNr());
      contentReader.close();
    } 
  }
  
  protected void processAttribute(Vector<String> paramVector1, Vector<String> paramVector2, Vector<String> paramVector3) throws Exception {
    String str1 = XMLUtil.scanIdentifier(this.reader);
    XMLUtil.skipWhitespace(this.reader, null);
    if (!XMLUtil.read(this.reader, '&').equals("="))
      XMLUtil.errorExpectedInput(this.reader.getSystemID(), this.reader.getLineNr(), "`='"); 
    XMLUtil.skipWhitespace(this.reader, null);
    String str2 = XMLUtil.scanString(this.reader, '&', this.entityResolver);
    paramVector1.addElement(str1);
    paramVector2.addElement(str2);
    paramVector3.addElement("CDATA");
    this.validator.attributeAdded(str1, str2, this.reader.getSystemID(), this.reader.getLineNr());
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\xml\StdXMLParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */