package processing.xml;

import java.io.IOException;
import java.io.Reader;

class CDATAReader extends Reader {
  private StdXMLReader reader;
  
  private char savedChar;
  
  private boolean atEndOfData;
  
  CDATAReader(StdXMLReader paramStdXMLReader) {
    this.reader = paramStdXMLReader;
    this.savedChar = Character.MIN_VALUE;
    this.atEndOfData = false;
  }
  
  protected void finalize() throws Throwable {
    this.reader = null;
    super.finalize();
  }
  
  public int read(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException {
    byte b = 0;
    if (this.atEndOfData)
      return -1; 
    if (paramInt1 + paramInt2 > paramArrayOfchar.length)
      paramInt2 = paramArrayOfchar.length - paramInt1; 
    while (b < paramInt2) {
      char c = this.savedChar;
      if (c == '\000') {
        c = this.reader.read();
      } else {
        this.savedChar = Character.MIN_VALUE;
      } 
      if (c == ']') {
        char c1 = this.reader.read();
        if (c1 == ']') {
          char c2 = this.reader.read();
          if (c2 == '>') {
            this.atEndOfData = true;
            break;
          } 
          this.savedChar = c1;
          this.reader.unread(c2);
        } else {
          this.reader.unread(c1);
        } 
      } 
      paramArrayOfchar[b] = c;
      b++;
    } 
    if (b == 0)
      b = -1; 
    return b;
  }
  
  public void close() throws IOException {
    while (!this.atEndOfData) {
      char c = this.savedChar;
      if (c == '\000') {
        c = this.reader.read();
      } else {
        this.savedChar = Character.MIN_VALUE;
      } 
      if (c == ']') {
        char c1 = this.reader.read();
        if (c1 == ']') {
          char c2 = this.reader.read();
          if (c2 == '>')
            break; 
          this.savedChar = c1;
          this.reader.unread(c2);
          continue;
        } 
        this.reader.unread(c1);
      } 
    } 
    this.atEndOfData = true;
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\xml\CDATAReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */