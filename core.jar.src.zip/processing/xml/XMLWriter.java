package processing.xml;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Writer;

public class XMLWriter {
  static final int INDENT = 2;
  
  static final String HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
  
  private PrintWriter writer;
  
  public XMLWriter(Writer paramWriter) {
    if (paramWriter instanceof PrintWriter) {
      this.writer = (PrintWriter)paramWriter;
    } else {
      this.writer = new PrintWriter(paramWriter);
    } 
  }
  
  public XMLWriter(OutputStream paramOutputStream) {
    this.writer = new PrintWriter(paramOutputStream);
  }
  
  protected void finalize() throws Throwable {
    this.writer = null;
    super.finalize();
  }
  
  public void write(XMLElement paramXMLElement) throws IOException {
    write(paramXMLElement, false, 0, 2, true);
  }
  
  public void write(XMLElement paramXMLElement, boolean paramBoolean) throws IOException {
    write(paramXMLElement, paramBoolean, 0, 2, true);
  }
  
  public void write(XMLElement paramXMLElement, boolean paramBoolean, int paramInt) throws IOException {
    write(paramXMLElement, paramBoolean, paramInt, 2, true);
  }
  
  public void write(XMLElement paramXMLElement, boolean paramBoolean1, int paramInt1, int paramInt2, boolean paramBoolean2) throws IOException {
    if (paramBoolean1)
      for (byte b = 0; b < paramInt1; b++)
        this.writer.print(' ');  
    if (paramXMLElement.getLocalName() == null) {
      if (paramXMLElement.getContent() != null)
        if (paramBoolean1) {
          writeEncoded(paramXMLElement.getContent().trim());
          this.writer.println();
        } else {
          writeEncoded(paramXMLElement.getContent());
        }  
    } else {
      this.writer.print('<');
      this.writer.print(paramXMLElement.getName());
      for (String str1 : paramXMLElement.listAttributes()) {
        String str2 = paramXMLElement.getString(str1, null);
        this.writer.print(" " + str1 + "=\"");
        writeEncoded(str2);
        this.writer.print('"');
      } 
      if (paramXMLElement.getContent() != null && paramXMLElement.getContent().length() > 0) {
        this.writer.print('>');
        writeEncoded(paramXMLElement.getContent());
        this.writer.print("</" + paramXMLElement.getName() + '>');
        if (paramBoolean1)
          this.writer.println(); 
      } else if (paramXMLElement.hasChildren() || !paramBoolean2) {
        this.writer.print('>');
        if (paramBoolean1)
          this.writer.println(); 
        int i = paramXMLElement.getChildCount();
        byte b;
        for (b = 0; b < i; b++) {
          XMLElement xMLElement = paramXMLElement.getChild(b);
          write(xMLElement, paramBoolean1, paramInt1 + paramInt2, paramInt2, paramBoolean2);
        } 
        if (paramBoolean1)
          for (b = 0; b < paramInt1; b++)
            this.writer.print(' ');  
        this.writer.print("</" + paramXMLElement.getName() + ">");
        if (paramBoolean1)
          this.writer.println(); 
      } else {
        this.writer.print("/>");
        if (paramBoolean1)
          this.writer.println(); 
      } 
    } 
    this.writer.flush();
  }
  
  private void writeEncoded(String paramString) {
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      switch (c) {
        case '\n':
          this.writer.print(c);
          break;
        case '<':
          this.writer.print("&lt;");
          break;
        case '>':
          this.writer.print("&gt;");
          break;
        case '&':
          this.writer.print("&amp;");
          break;
        case '\'':
          this.writer.print("&apos;");
          break;
        case '"':
          this.writer.print("&quot;");
          break;
        default:
          if (c < ' ' || c > '~') {
            this.writer.print("&#x");
            this.writer.print(Integer.toString(c, 16));
            this.writer.print(';');
            break;
          } 
          this.writer.print(c);
          break;
      } 
    } 
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\xml\XMLWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */