package processing.xml;

import java.io.IOException;
import java.io.Reader;
import java.util.Stack;

public class StdXMLBuilder {
  private Stack<XMLElement> stack;
  
  private XMLElement root;
  
  private XMLElement parent;
  
  public StdXMLBuilder() {
    this(new XMLElement());
    this.stack = null;
    this.root = null;
  }
  
  public StdXMLBuilder(XMLElement paramXMLElement) {
    this.parent = paramXMLElement;
  }
  
  protected void finalize() throws Throwable {
    this.root = null;
    this.stack.clear();
    this.stack = null;
    super.finalize();
  }
  
  public void startBuilding(String paramString, int paramInt) {
    this.stack = new Stack<XMLElement>();
    this.root = null;
  }
  
  public void newProcessingInstruction(String paramString, Reader paramReader) {}
  
  public void startElement(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt) {
    String str = paramString1;
    if (paramString2 != null)
      str = paramString2 + ':' + paramString1; 
    if (this.stack.empty()) {
      this.parent.init(str, paramString3, paramString4, paramInt);
      this.stack.push(this.parent);
      this.root = this.parent;
    } else {
      XMLElement xMLElement1 = this.stack.peek();
      XMLElement xMLElement2 = new XMLElement(str, paramString3, paramString4, paramInt);
      xMLElement1.addChild(xMLElement2);
      this.stack.push(xMLElement2);
    } 
  }
  
  public void elementAttributesProcessed(String paramString1, String paramString2, String paramString3) {}
  
  public void endElement(String paramString1, String paramString2, String paramString3) {
    XMLElement xMLElement = this.stack.pop();
    if (xMLElement.getChildCount() == 1) {
      XMLElement xMLElement1 = xMLElement.getChild(0);
      if (xMLElement1.getLocalName() == null) {
        xMLElement.setContent(xMLElement1.getContent());
        xMLElement.removeChild(0);
      } 
    } 
  }
  
  public void addAttribute(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) throws Exception {
    String str = paramString1;
    if (paramString2 != null)
      str = paramString2 + ':' + paramString1; 
    XMLElement xMLElement = this.stack.peek();
    if (xMLElement.hasAttribute(str))
      throw new XMLParseException(xMLElement.getSystemID(), xMLElement.getLine(), "Duplicate attribute: " + paramString1); 
    xMLElement.setString(str, paramString4);
  }
  
  public void addPCData(Reader paramReader, String paramString, int paramInt) {
    int i = 2048;
    int j = 0;
    StringBuffer stringBuffer = new StringBuffer(i);
    char[] arrayOfChar = new char[i];
    while (true) {
      int k;
      if (j >= i) {
        i *= 2;
        stringBuffer.ensureCapacity(i);
      } 
      try {
        k = paramReader.read(arrayOfChar);
      } catch (IOException iOException) {
        break;
      } 
      if (k < 0)
        break; 
      stringBuffer.append(arrayOfChar, 0, k);
      j += k;
    } 
    XMLElement xMLElement = new XMLElement(null, null, paramString, paramInt);
    xMLElement.setContent(stringBuffer.toString());
    if (!this.stack.empty()) {
      XMLElement xMLElement1 = this.stack.peek();
      xMLElement1.addChild(xMLElement);
    } 
  }
  
  public Object getResult() {
    return this.root;
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\xml\StdXMLBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */