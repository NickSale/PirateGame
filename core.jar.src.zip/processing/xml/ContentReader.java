package processing.xml;

import java.io.IOException;
import java.io.Reader;

class ContentReader extends Reader {
  private StdXMLReader reader;
  
  private String buffer;
  
  private int bufferIndex;
  
  private XMLEntityResolver resolver;
  
  ContentReader(StdXMLReader paramStdXMLReader, XMLEntityResolver paramXMLEntityResolver, String paramString) {
    this.reader = paramStdXMLReader;
    this.resolver = paramXMLEntityResolver;
    this.buffer = paramString;
    this.bufferIndex = 0;
  }
  
  protected void finalize() throws Throwable {
    this.reader = null;
    this.resolver = null;
    this.buffer = null;
    super.finalize();
  }
  
  public int read(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException {
    try {
      byte b = 0;
      int i = this.buffer.length();
      if (paramInt1 + paramInt2 > paramArrayOfchar.length)
        paramInt2 = paramArrayOfchar.length - paramInt1; 
      while (b < paramInt2) {
        char c;
        String str = "";
        if (this.bufferIndex >= i) {
          str = XMLUtil.read(this.reader, '&');
          c = str.charAt(0);
        } else {
          c = this.buffer.charAt(this.bufferIndex);
          this.bufferIndex++;
          paramArrayOfchar[b] = c;
          b++;
          continue;
        } 
        if (c == '<') {
          this.reader.unread(c);
          break;
        } 
        if (c == '&' && str.length() > 1)
          if (str.charAt(1) == '#') {
            c = XMLUtil.processCharLiteral(str);
          } else {
            XMLUtil.processEntity(str, this.reader, this.resolver);
            continue;
          }  
        paramArrayOfchar[b] = c;
        b++;
      } 
      if (b == 0)
        b = -1; 
      return b;
    } catch (XMLParseException xMLParseException) {
      throw new IOException(xMLParseException.getMessage());
    } 
  }
  
  public void close() throws IOException {
    try {
      int i = this.buffer.length();
      while (true) {
        char c;
        String str = "";
        if (this.bufferIndex >= i) {
          str = XMLUtil.read(this.reader, '&');
          c = str.charAt(0);
        } else {
          c = this.buffer.charAt(this.bufferIndex);
          this.bufferIndex++;
          continue;
        } 
        if (c == '<') {
          this.reader.unread(c);
          break;
        } 
        if (c == '&' && str.length() > 1 && str.charAt(1) != '#')
          XMLUtil.processEntity(str, this.reader, this.resolver); 
      } 
    } catch (XMLParseException xMLParseException) {
      throw new IOException(xMLParseException.getMessage());
    } 
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\xml\ContentReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */