package processing.xml;

import java.io.StringReader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Stack;

public class XMLValidator {
  protected XMLEntityResolver parameterEntityResolver = new XMLEntityResolver();
  
  protected Hashtable<String, Properties> attributeDefaultValues = new Hashtable<String, Properties>();
  
  protected Stack<Properties> currentElements = new Stack<Properties>();
  
  protected void finalize() throws Throwable {
    this.parameterEntityResolver = null;
    this.attributeDefaultValues.clear();
    this.attributeDefaultValues = null;
    this.currentElements.clear();
    this.currentElements = null;
    super.finalize();
  }
  
  public void setParameterEntityResolver(XMLEntityResolver paramXMLEntityResolver) {
    this.parameterEntityResolver = paramXMLEntityResolver;
  }
  
  public XMLEntityResolver getParameterEntityResolver() {
    return this.parameterEntityResolver;
  }
  
  public void parseDTD(String paramString, StdXMLReader paramStdXMLReader, XMLEntityResolver paramXMLEntityResolver, boolean paramBoolean) throws Exception {
    XMLUtil.skipWhitespace(paramStdXMLReader, null);
    int i = paramStdXMLReader.getStreamLevel();
    while (true) {
      String str = XMLUtil.read(paramStdXMLReader, '%');
      char c = str.charAt(0);
      if (c == '%') {
        XMLUtil.processEntity(str, paramStdXMLReader, this.parameterEntityResolver);
        continue;
      } 
      if (c == '<') {
        processElement(paramStdXMLReader, paramXMLEntityResolver);
      } else {
        if (c == ']')
          return; 
        XMLUtil.errorInvalidInput(paramStdXMLReader.getSystemID(), paramStdXMLReader.getLineNr(), str);
      } 
      while (true) {
        c = paramStdXMLReader.read();
        if (paramBoolean && paramStdXMLReader.getStreamLevel() < i) {
          paramStdXMLReader.unread(c);
          return;
        } 
        if (c != ' ' && c != '\t' && c != '\n' && c != '\r')
          paramStdXMLReader.unread(c); 
      } 
      break;
    } 
  }
  
  protected void processElement(StdXMLReader paramStdXMLReader, XMLEntityResolver paramXMLEntityResolver) throws Exception {
    String str = XMLUtil.read(paramStdXMLReader, '%');
    char c = str.charAt(0);
    if (c != '!') {
      XMLUtil.skipTag(paramStdXMLReader);
      return;
    } 
    str = XMLUtil.read(paramStdXMLReader, '%');
    c = str.charAt(0);
    switch (c) {
      case '-':
        XMLUtil.skipComment(paramStdXMLReader);
        return;
      case '[':
        processConditionalSection(paramStdXMLReader, paramXMLEntityResolver);
        return;
      case 'E':
        processEntity(paramStdXMLReader, paramXMLEntityResolver);
        return;
      case 'A':
        processAttList(paramStdXMLReader, paramXMLEntityResolver);
        return;
    } 
    XMLUtil.skipTag(paramStdXMLReader);
  }
  
  protected void processConditionalSection(StdXMLReader paramStdXMLReader, XMLEntityResolver paramXMLEntityResolver) throws Exception {
    XMLUtil.skipWhitespace(paramStdXMLReader, null);
    String str = XMLUtil.read(paramStdXMLReader, '%');
    char c = str.charAt(0);
    if (c != 'I') {
      XMLUtil.skipTag(paramStdXMLReader);
      return;
    } 
    str = XMLUtil.read(paramStdXMLReader, '%');
    c = str.charAt(0);
    switch (c) {
      case 'G':
        processIgnoreSection(paramStdXMLReader, paramXMLEntityResolver);
        return;
      case 'N':
        break;
      default:
        XMLUtil.skipTag(paramStdXMLReader);
        return;
    } 
    if (!XMLUtil.checkLiteral(paramStdXMLReader, "CLUDE")) {
      XMLUtil.skipTag(paramStdXMLReader);
      return;
    } 
    XMLUtil.skipWhitespace(paramStdXMLReader, null);
    str = XMLUtil.read(paramStdXMLReader, '%');
    c = str.charAt(0);
    if (c != '[') {
      XMLUtil.skipTag(paramStdXMLReader);
      return;
    } 
    CDATAReader cDATAReader = new CDATAReader(paramStdXMLReader);
    StringBuffer stringBuffer = new StringBuffer(1024);
    while (true) {
      int i = cDATAReader.read();
      if (i < 0) {
        cDATAReader.close();
        paramStdXMLReader.startNewStream(new StringReader(stringBuffer.toString()));
        return;
      } 
      stringBuffer.append((char)i);
    } 
  }
  
  protected void processIgnoreSection(StdXMLReader paramStdXMLReader, XMLEntityResolver paramXMLEntityResolver) throws Exception {
    if (!XMLUtil.checkLiteral(paramStdXMLReader, "NORE")) {
      XMLUtil.skipTag(paramStdXMLReader);
      return;
    } 
    XMLUtil.skipWhitespace(paramStdXMLReader, null);
    String str = XMLUtil.read(paramStdXMLReader, '%');
    char c = str.charAt(0);
    if (c != '[') {
      XMLUtil.skipTag(paramStdXMLReader);
      return;
    } 
    CDATAReader cDATAReader = new CDATAReader(paramStdXMLReader);
    cDATAReader.close();
  }
  
  protected void processAttList(StdXMLReader paramStdXMLReader, XMLEntityResolver paramXMLEntityResolver) throws Exception {
    if (!XMLUtil.checkLiteral(paramStdXMLReader, "TTLIST")) {
      XMLUtil.skipTag(paramStdXMLReader);
      return;
    } 
    XMLUtil.skipWhitespace(paramStdXMLReader, null);
    String str1 = XMLUtil.read(paramStdXMLReader, '%');
    char c;
    for (c = str1.charAt(0); c == '%'; c = str1.charAt(0)) {
      XMLUtil.processEntity(str1, paramStdXMLReader, this.parameterEntityResolver);
      str1 = XMLUtil.read(paramStdXMLReader, '%');
    } 
    paramStdXMLReader.unread(c);
    String str2 = XMLUtil.scanIdentifier(paramStdXMLReader);
    XMLUtil.skipWhitespace(paramStdXMLReader, null);
    str1 = XMLUtil.read(paramStdXMLReader, '%');
    for (c = str1.charAt(0); c == '%'; c = str1.charAt(0)) {
      XMLUtil.processEntity(str1, paramStdXMLReader, this.parameterEntityResolver);
      str1 = XMLUtil.read(paramStdXMLReader, '%');
    } 
    Properties properties = new Properties();
    while (c != '>') {
      paramStdXMLReader.unread(c);
      String str3 = XMLUtil.scanIdentifier(paramStdXMLReader);
      XMLUtil.skipWhitespace(paramStdXMLReader, null);
      str1 = XMLUtil.read(paramStdXMLReader, '%');
      for (c = str1.charAt(0); c == '%'; c = str1.charAt(0)) {
        XMLUtil.processEntity(str1, paramStdXMLReader, this.parameterEntityResolver);
        str1 = XMLUtil.read(paramStdXMLReader, '%');
      } 
      if (c == '(') {
        while (c != ')') {
          str1 = XMLUtil.read(paramStdXMLReader, '%');
          for (c = str1.charAt(0); c == '%'; c = str1.charAt(0)) {
            XMLUtil.processEntity(str1, paramStdXMLReader, this.parameterEntityResolver);
            str1 = XMLUtil.read(paramStdXMLReader, '%');
          } 
        } 
      } else {
        paramStdXMLReader.unread(c);
        XMLUtil.scanIdentifier(paramStdXMLReader);
      } 
      XMLUtil.skipWhitespace(paramStdXMLReader, null);
      str1 = XMLUtil.read(paramStdXMLReader, '%');
      for (c = str1.charAt(0); c == '%'; c = str1.charAt(0)) {
        XMLUtil.processEntity(str1, paramStdXMLReader, this.parameterEntityResolver);
        str1 = XMLUtil.read(paramStdXMLReader, '%');
      } 
      if (c == '#') {
        str1 = XMLUtil.scanIdentifier(paramStdXMLReader);
        XMLUtil.skipWhitespace(paramStdXMLReader, null);
        if (!str1.equals("FIXED")) {
          XMLUtil.skipWhitespace(paramStdXMLReader, null);
          str1 = XMLUtil.read(paramStdXMLReader, '%');
          for (c = str1.charAt(0); c == '%'; c = str1.charAt(0)) {
            XMLUtil.processEntity(str1, paramStdXMLReader, this.parameterEntityResolver);
            str1 = XMLUtil.read(paramStdXMLReader, '%');
          } 
          continue;
        } 
      } else {
        paramStdXMLReader.unread(c);
      } 
      String str4 = XMLUtil.scanString(paramStdXMLReader, '%', this.parameterEntityResolver);
      properties.put(str3, str4);
      XMLUtil.skipWhitespace(paramStdXMLReader, null);
      str1 = XMLUtil.read(paramStdXMLReader, '%');
      for (c = str1.charAt(0); c == '%'; c = str1.charAt(0)) {
        XMLUtil.processEntity(str1, paramStdXMLReader, this.parameterEntityResolver);
        str1 = XMLUtil.read(paramStdXMLReader, '%');
      } 
    } 
    if (!properties.isEmpty())
      this.attributeDefaultValues.put(str2, properties); 
  }
  
  protected void processEntity(StdXMLReader paramStdXMLReader, XMLEntityResolver paramXMLEntityResolver) throws Exception {
    String str4;
    if (!XMLUtil.checkLiteral(paramStdXMLReader, "NTITY")) {
      XMLUtil.skipTag(paramStdXMLReader);
      return;
    } 
    XMLUtil.skipWhitespace(paramStdXMLReader, null);
    char c = XMLUtil.readChar(paramStdXMLReader, false);
    if (c == '%') {
      XMLUtil.skipWhitespace(paramStdXMLReader, null);
      paramXMLEntityResolver = this.parameterEntityResolver;
    } else {
      paramStdXMLReader.unread(c);
    } 
    String str1 = XMLUtil.scanIdentifier(paramStdXMLReader);
    XMLUtil.skipWhitespace(paramStdXMLReader, null);
    c = XMLUtil.readChar(paramStdXMLReader, '%');
    String str2 = null;
    String str3 = null;
    switch (c) {
      case 'P':
        if (!XMLUtil.checkLiteral(paramStdXMLReader, "UBLIC")) {
          XMLUtil.skipTag(paramStdXMLReader);
          return;
        } 
        XMLUtil.skipWhitespace(paramStdXMLReader, null);
        str3 = XMLUtil.scanString(paramStdXMLReader, '%', this.parameterEntityResolver);
        XMLUtil.skipWhitespace(paramStdXMLReader, null);
        str2 = XMLUtil.scanString(paramStdXMLReader, '%', this.parameterEntityResolver);
        XMLUtil.skipWhitespace(paramStdXMLReader, null);
        XMLUtil.readChar(paramStdXMLReader, '%');
        break;
      case 'S':
        if (!XMLUtil.checkLiteral(paramStdXMLReader, "YSTEM")) {
          XMLUtil.skipTag(paramStdXMLReader);
          return;
        } 
        XMLUtil.skipWhitespace(paramStdXMLReader, null);
        str2 = XMLUtil.scanString(paramStdXMLReader, '%', this.parameterEntityResolver);
        XMLUtil.skipWhitespace(paramStdXMLReader, null);
        XMLUtil.readChar(paramStdXMLReader, '%');
        break;
      case '"':
      case '\'':
        paramStdXMLReader.unread(c);
        str4 = XMLUtil.scanString(paramStdXMLReader, '%', this.parameterEntityResolver);
        paramXMLEntityResolver.addInternalEntity(str1, str4);
        XMLUtil.skipWhitespace(paramStdXMLReader, null);
        XMLUtil.readChar(paramStdXMLReader, '%');
        break;
      default:
        XMLUtil.skipTag(paramStdXMLReader);
        break;
    } 
    if (str2 != null)
      paramXMLEntityResolver.addExternalEntity(str1, str3, str2); 
  }
  
  public void elementStarted(String paramString1, String paramString2, int paramInt) {
    Properties properties = this.attributeDefaultValues.get(paramString1);
    if (properties == null) {
      properties = new Properties();
    } else {
      properties = (Properties)properties.clone();
    } 
    this.currentElements.push(properties);
  }
  
  public void elementEnded(String paramString1, String paramString2, int paramInt) {}
  
  public void elementAttributesProcessed(String paramString1, Properties paramProperties, String paramString2, int paramInt) {
    Properties properties = this.currentElements.pop();
    Enumeration<String> enumeration = properties.keys();
    while (enumeration.hasMoreElements()) {
      String str = enumeration.nextElement();
      paramProperties.put(str, properties.get(str));
    } 
  }
  
  public void attributeAdded(String paramString1, String paramString2, String paramString3, int paramInt) {
    Properties properties = this.currentElements.peek();
    if (properties.containsKey(paramString1))
      properties.remove(paramString1); 
  }
  
  public void PCDataAdded(String paramString, int paramInt) {}
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\xml\XMLValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */