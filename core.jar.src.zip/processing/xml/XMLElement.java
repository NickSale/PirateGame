package processing.xml;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringReader;
import java.util.Enumeration;
import java.util.Vector;
import processing.core.PApplet;

public class XMLElement implements Serializable {
  public static final int NO_LINE = -1;
  
  private PApplet sketch;
  
  private XMLElement parent;
  
  private Vector<XMLAttribute> attributes = new Vector<XMLAttribute>();
  
  private Vector<XMLElement> children = new Vector<XMLElement>(8);
  
  private String name;
  
  private String fullName;
  
  private String namespace;
  
  private String content;
  
  private String systemID;
  
  private int line;
  
  public XMLElement() {
    this(null, null, null, -1);
  }
  
  public XMLElement(String paramString) {
    this(paramString, null, null, -1);
  }
  
  public XMLElement(String paramString1, String paramString2, String paramString3, int paramInt) {
    this.fullName = paramString1;
    if (paramString2 == null) {
      this.name = paramString1;
    } else {
      int i = paramString1.indexOf(':');
      if (i >= 0) {
        this.name = paramString1.substring(i + 1);
      } else {
        this.name = paramString1;
      } 
    } 
    this.namespace = paramString2;
    this.content = null;
    this.line = paramInt;
    this.systemID = paramString3;
    this.parent = null;
  }
  
  public XMLElement(PApplet paramPApplet, String paramString) {
    this();
    this.sketch = paramPApplet;
    init(paramPApplet.createReader(paramString));
  }
  
  public XMLElement(Reader paramReader) {
    this();
    init(paramReader);
  }
  
  public static XMLElement parse(String paramString) {
    return parse(new StringReader(paramString));
  }
  
  public static XMLElement parse(Reader paramReader) {
    try {
      StdXMLParser stdXMLParser = new StdXMLParser();
      stdXMLParser.setBuilder(new StdXMLBuilder());
      stdXMLParser.setValidator(new XMLValidator());
      stdXMLParser.setReader(new StdXMLReader(paramReader));
      return (XMLElement)stdXMLParser.parse();
    } catch (XMLException xMLException) {
      xMLException.printStackTrace();
      return null;
    } 
  }
  
  protected void init(String paramString1, String paramString2, String paramString3, int paramInt) {
    this.fullName = paramString1;
    if (paramString2 == null) {
      this.name = paramString1;
    } else {
      int i = paramString1.indexOf(':');
      if (i >= 0) {
        this.name = paramString1.substring(i + 1);
      } else {
        this.name = paramString1;
      } 
    } 
    this.namespace = paramString2;
    this.line = paramInt;
    this.systemID = paramString3;
  }
  
  protected void init(Reader paramReader) {
    try {
      StdXMLParser stdXMLParser = new StdXMLParser();
      stdXMLParser.setBuilder(new StdXMLBuilder(this));
      stdXMLParser.setValidator(new XMLValidator());
      stdXMLParser.setReader(new StdXMLReader(paramReader));
      stdXMLParser.parse();
    } catch (XMLException xMLException) {
      xMLException.printStackTrace();
    } 
  }
  
  protected void finalize() throws Throwable {
    this.attributes.clear();
    this.attributes = null;
    this.children = null;
    this.fullName = null;
    this.name = null;
    this.namespace = null;
    this.content = null;
    this.systemID = null;
    this.parent = null;
    super.finalize();
  }
  
  public XMLElement getParent() {
    return this.parent;
  }
  
  public String getName() {
    return this.fullName;
  }
  
  public String getLocalName() {
    return this.name;
  }
  
  public String getNamespace() {
    return this.namespace;
  }
  
  public void setName(String paramString) {
    this.name = paramString;
    this.fullName = paramString;
    this.namespace = null;
  }
  
  public void setName(String paramString1, String paramString2) {
    int i = paramString1.indexOf(':');
    if (paramString2 == null || i < 0) {
      this.name = paramString1;
    } else {
      this.name = paramString1.substring(i + 1);
    } 
    this.fullName = paramString1;
    this.namespace = paramString2;
  }
  
  public void addChild(XMLElement paramXMLElement) {
    if (paramXMLElement == null)
      throw new IllegalArgumentException("child must not be null"); 
    if (paramXMLElement.getLocalName() == null && !this.children.isEmpty()) {
      XMLElement xMLElement = this.children.lastElement();
      if (xMLElement.getLocalName() == null) {
        xMLElement.setContent(xMLElement.getContent() + paramXMLElement.getContent());
        return;
      } 
    } 
    paramXMLElement.parent = this;
    this.children.addElement(paramXMLElement);
  }
  
  public void insertChild(XMLElement paramXMLElement, int paramInt) {
    if (paramXMLElement == null)
      throw new IllegalArgumentException("child must not be null"); 
    if (paramXMLElement.getLocalName() == null && !this.children.isEmpty()) {
      XMLElement xMLElement = this.children.lastElement();
      if (xMLElement.getLocalName() == null) {
        xMLElement.setContent(xMLElement.getContent() + paramXMLElement.getContent());
        return;
      } 
    } 
    paramXMLElement.parent = this;
    this.children.insertElementAt(paramXMLElement, paramInt);
  }
  
  public void removeChild(XMLElement paramXMLElement) {
    if (paramXMLElement == null)
      throw new IllegalArgumentException("child must not be null"); 
    this.children.removeElement(paramXMLElement);
  }
  
  public void removeChild(int paramInt) {
    this.children.removeElementAt(paramInt);
  }
  
  public boolean isLeaf() {
    return this.children.isEmpty();
  }
  
  public boolean hasChildren() {
    return !this.children.isEmpty();
  }
  
  public int getChildCount() {
    return this.children.size();
  }
  
  public String[] listChildren() {
    int i = getChildCount();
    String[] arrayOfString = new String[i];
    for (byte b = 0; b < i; b++)
      arrayOfString[b] = getChild(b).getName(); 
    return arrayOfString;
  }
  
  public XMLElement[] getChildren() {
    int i = getChildCount();
    XMLElement[] arrayOfXMLElement = new XMLElement[i];
    this.children.copyInto((Object[])arrayOfXMLElement);
    return arrayOfXMLElement;
  }
  
  public XMLElement getChild(int paramInt) {
    return this.children.elementAt(paramInt);
  }
  
  public XMLElement getChild(String paramString) {
    if (paramString.indexOf('/') != -1)
      return getChildRecursive(PApplet.split(paramString, '/'), 0); 
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      XMLElement xMLElement = getChild(b);
      String str = xMLElement.getName();
      if (str != null && str.equals(paramString))
        return xMLElement; 
    } 
    return null;
  }
  
  protected XMLElement getChildRecursive(String[] paramArrayOfString, int paramInt) {
    if (Character.isDigit(paramArrayOfString[paramInt].charAt(0))) {
      XMLElement xMLElement = getChild(Integer.parseInt(paramArrayOfString[paramInt]));
      return (paramInt == paramArrayOfString.length - 1) ? xMLElement : xMLElement.getChildRecursive(paramArrayOfString, paramInt + 1);
    } 
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      XMLElement xMLElement = getChild(b);
      String str = xMLElement.getName();
      if (str != null && str.equals(paramArrayOfString[paramInt]))
        return (paramInt == paramArrayOfString.length - 1) ? xMLElement : xMLElement.getChildRecursive(paramArrayOfString, paramInt + 1); 
    } 
    return null;
  }
  
  public XMLElement[] getChildren(String paramString) {
    if (paramString.indexOf('/') != -1)
      return getChildrenRecursive(PApplet.split(paramString, '/'), 0); 
    if (Character.isDigit(paramString.charAt(0)))
      return new XMLElement[] { getChild(Integer.parseInt(paramString)) }; 
    int i = getChildCount();
    XMLElement[] arrayOfXMLElement = new XMLElement[i];
    byte b1 = 0;
    for (byte b2 = 0; b2 < i; b2++) {
      XMLElement xMLElement = getChild(b2);
      String str = xMLElement.getName();
      if (str != null && str.equals(paramString))
        arrayOfXMLElement[b1++] = xMLElement; 
    } 
    return (XMLElement[])PApplet.subset(arrayOfXMLElement, 0, b1);
  }
  
  protected XMLElement[] getChildrenRecursive(String[] paramArrayOfString, int paramInt) {
    if (paramInt == paramArrayOfString.length - 1)
      return getChildren(paramArrayOfString[paramInt]); 
    XMLElement[] arrayOfXMLElement1 = getChildren(paramArrayOfString[paramInt]);
    XMLElement[] arrayOfXMLElement2 = new XMLElement[0];
    for (byte b = 0; b < arrayOfXMLElement1.length; b++) {
      XMLElement[] arrayOfXMLElement = arrayOfXMLElement1[b].getChildrenRecursive(paramArrayOfString, paramInt + 1);
      arrayOfXMLElement2 = (XMLElement[])PApplet.concat(arrayOfXMLElement2, arrayOfXMLElement);
    } 
    return arrayOfXMLElement2;
  }
  
  private XMLAttribute findAttribute(String paramString) {
    Enumeration<XMLAttribute> enumeration = this.attributes.elements();
    while (enumeration.hasMoreElements()) {
      XMLAttribute xMLAttribute = enumeration.nextElement();
      if (xMLAttribute.getName().equals(paramString))
        return xMLAttribute; 
    } 
    return null;
  }
  
  public int getAttributeCount() {
    return this.attributes.size();
  }
  
  public String[] listAttributes() {
    String[] arrayOfString = new String[this.attributes.size()];
    for (byte b = 0; b < this.attributes.size(); b++)
      arrayOfString[b] = ((XMLAttribute)this.attributes.get(b)).getName(); 
    return arrayOfString;
  }
  
  public String getStringAttribute(String paramString) {
    return getString(paramString);
  }
  
  public String getStringAttribute(String paramString1, String paramString2) {
    return getString(paramString1, paramString2);
  }
  
  public String getString(String paramString) {
    return getString(paramString, null);
  }
  
  public String getString(String paramString1, String paramString2) {
    XMLAttribute xMLAttribute = findAttribute(paramString1);
    return (xMLAttribute == null) ? paramString2 : xMLAttribute.getValue();
  }
  
  public boolean getBoolean(String paramString) {
    return getBoolean(paramString, false);
  }
  
  public boolean getBoolean(String paramString, boolean paramBoolean) {
    String str = getString(paramString);
    return (str == null) ? paramBoolean : ((str.equals("1") || str.toLowerCase().equals("true")));
  }
  
  public int getIntAttribute(String paramString) {
    return getInt(paramString, 0);
  }
  
  public int getIntAttribute(String paramString, int paramInt) {
    return getInt(paramString, paramInt);
  }
  
  public int getInt(String paramString) {
    return getInt(paramString, 0);
  }
  
  public int getInt(String paramString, int paramInt) {
    String str = getString(paramString);
    return (str == null) ? paramInt : PApplet.parseInt(str, paramInt);
  }
  
  public float getFloatAttribute(String paramString) {
    return getFloat(paramString, 0.0F);
  }
  
  public float getFloatAttribute(String paramString, float paramFloat) {
    return getFloat(paramString, 0.0F);
  }
  
  public float getFloat(String paramString) {
    return getFloat(paramString, 0.0F);
  }
  
  public float getFloat(String paramString, float paramFloat) {
    String str = getString(paramString);
    return (str == null) ? paramFloat : PApplet.parseFloat(str, paramFloat);
  }
  
  public double getDouble(String paramString) {
    return getDouble(paramString, 0.0D);
  }
  
  public double getDouble(String paramString, double paramDouble) {
    String str = getString(paramString);
    return (str == null) ? paramDouble : Double.parseDouble(str);
  }
  
  public void setString(String paramString1, String paramString2) {
    XMLAttribute xMLAttribute = findAttribute(paramString1);
    if (xMLAttribute == null) {
      xMLAttribute = new XMLAttribute(paramString1, paramString1, null, paramString2, "CDATA");
      this.attributes.addElement(xMLAttribute);
    } else {
      xMLAttribute.setValue(paramString2);
    } 
  }
  
  public void setBoolean(String paramString, boolean paramBoolean) {
    setString(paramString, String.valueOf(paramBoolean));
  }
  
  public void setInt(String paramString, int paramInt) {
    setString(paramString, String.valueOf(paramInt));
  }
  
  public void setFloat(String paramString, float paramFloat) {
    setString(paramString, String.valueOf(paramFloat));
  }
  
  public void setDouble(String paramString, double paramDouble) {
    setString(paramString, String.valueOf(paramDouble));
  }
  
  public void remove(String paramString) {
    for (byte b = 0; b < this.attributes.size(); b++) {
      XMLAttribute xMLAttribute = this.attributes.elementAt(b);
      if (xMLAttribute.getName().equals(paramString)) {
        this.attributes.removeElementAt(b);
        return;
      } 
    } 
  }
  
  public boolean hasAttribute(String paramString) {
    return (findAttribute(paramString) != null);
  }
  
  public String getSystemID() {
    return this.systemID;
  }
  
  public int getLine() {
    return this.line;
  }
  
  public String getContent() {
    return this.content;
  }
  
  public void setContent(String paramString) {
    this.content = paramString;
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof XMLElement))
      return false; 
    XMLElement xMLElement = (XMLElement)paramObject;
    if (!this.name.equals(xMLElement.getLocalName()))
      return false; 
    if (this.attributes.size() != xMLElement.getAttributeCount())
      return false; 
    Enumeration<XMLAttribute> enumeration = this.attributes.elements();
    while (enumeration.hasMoreElements()) {
      XMLAttribute xMLAttribute = enumeration.nextElement();
      if (!xMLElement.hasAttribute(xMLAttribute.getName()))
        return false; 
      String str = xMLElement.getString(xMLAttribute.getName(), null);
      if (!xMLAttribute.getValue().equals(str))
        return false; 
    } 
    if (this.children.size() != xMLElement.getChildCount())
      return false; 
    for (byte b = 0; b < this.children.size(); b++) {
      XMLElement xMLElement1 = getChild(b);
      XMLElement xMLElement2 = xMLElement.getChild(b);
      if (!xMLElement1.equals(xMLElement2))
        return false; 
    } 
    return true;
  }
  
  public String toString() {
    return toString(true);
  }
  
  public String toString(boolean paramBoolean) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(byteArrayOutputStream);
    XMLWriter xMLWriter = new XMLWriter(outputStreamWriter);
    try {
      xMLWriter.write(this, paramBoolean);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    return byteArrayOutputStream.toString();
  }
  
  private PApplet findSketch() {
    return (this.sketch != null) ? this.sketch : ((this.parent != null) ? this.parent.findSketch() : null);
  }
  
  public boolean save(String paramString) {
    if (this.sketch == null)
      this.sketch = findSketch(); 
    if (this.sketch == null) {
      System.err.println("save() can only be used on elements loaded by a sketch");
      throw new RuntimeException("no sketch found, use write(PrintWriter) instead.");
    } 
    return write(this.sketch.createWriter(paramString));
  }
  
  public boolean write(PrintWriter paramPrintWriter) {
    paramPrintWriter.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    XMLWriter xMLWriter = new XMLWriter(paramPrintWriter);
    try {
      xMLWriter.write(this, true);
      paramPrintWriter.flush();
      return true;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return false;
    } 
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\xml\XMLElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */