package processing.xml;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.PushbackInputStream;
import java.io.PushbackReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Stack;

public class StdXMLReader {
  private Stack<StackedReader> readers;
  
  private StackedReader currentReader;
  
  public static StdXMLReader stringReader(String paramString) {
    return new StdXMLReader(new StringReader(paramString));
  }
  
  public static StdXMLReader fileReader(String paramString) throws FileNotFoundException, IOException {
    StdXMLReader stdXMLReader = new StdXMLReader(new FileInputStream(paramString));
    stdXMLReader.setSystemID(paramString);
    for (byte b = 0; b < stdXMLReader.readers.size(); b++) {
      StackedReader stackedReader = stdXMLReader.readers.elementAt(b);
      stackedReader.systemId = stdXMLReader.currentReader.systemId;
    } 
    return stdXMLReader;
  }
  
  public StdXMLReader(String paramString1, String paramString2) throws MalformedURLException, FileNotFoundException, IOException {
    URL uRL = null;
    try {
      uRL = new URL(paramString2);
    } catch (MalformedURLException malformedURLException) {
      paramString2 = "file:" + paramString2;
      try {
        uRL = new URL(paramString2);
      } catch (MalformedURLException malformedURLException1) {
        throw malformedURLException;
      } 
    } 
    this.currentReader = new StackedReader();
    this.readers = new Stack<StackedReader>();
    Reader reader = openStream(paramString1, uRL.toString());
    this.currentReader.lineReader = new LineNumberReader(reader);
    this.currentReader.pbReader = new PushbackReader(this.currentReader.lineReader, 2);
  }
  
  public StdXMLReader(Reader paramReader) {
    this.currentReader = new StackedReader();
    this.readers = new Stack<StackedReader>();
    this.currentReader.lineReader = new LineNumberReader(paramReader);
    this.currentReader.pbReader = new PushbackReader(this.currentReader.lineReader, 2);
    this.currentReader.publicId = "";
    try {
      this.currentReader.systemId = new URL("file:.");
    } catch (MalformedURLException malformedURLException) {}
  }
  
  protected void finalize() throws Throwable {
    this.currentReader.lineReader = null;
    this.currentReader.pbReader = null;
    this.currentReader.systemId = null;
    this.currentReader.publicId = null;
    this.currentReader = null;
    this.readers.clear();
    super.finalize();
  }
  
  protected String getEncoding(String paramString) {
    if (!paramString.startsWith("<?xml"))
      return null; 
    for (int i = 5; i < paramString.length(); i = j + 1) {
      StringBuffer stringBuffer = new StringBuffer();
      while (i < paramString.length() && paramString.charAt(i) <= ' ')
        i++; 
      while (i < paramString.length() && paramString.charAt(i) >= 'a' && paramString.charAt(i) <= 'z') {
        stringBuffer.append(paramString.charAt(i));
        i++;
      } 
      while (i < paramString.length() && paramString.charAt(i) <= ' ')
        i++; 
      if (i >= paramString.length() || paramString.charAt(i) != '=')
        break; 
      while (i < paramString.length() && paramString.charAt(i) != '\'' && paramString.charAt(i) != '"')
        i++; 
      if (i >= paramString.length())
        break; 
      char c = paramString.charAt(i);
      int j = paramString.indexOf(c, ++i);
      if (j < 0)
        break; 
      if (stringBuffer.toString().equals("encoding"))
        return paramString.substring(i, j); 
    } 
    return null;
  }
  
  protected Reader stream2reader(InputStream paramInputStream, StringBuffer paramStringBuffer) throws IOException {
    byte b;
    String str;
    PushbackInputStream pushbackInputStream = new PushbackInputStream(paramInputStream);
    int i = pushbackInputStream.read();
    switch (i) {
      case 0:
      case 254:
      case 255:
        pushbackInputStream.unread(i);
        return new InputStreamReader(pushbackInputStream, "UTF-16");
      case 239:
        for (b = 0; b < 2; b++)
          pushbackInputStream.read(); 
        return new InputStreamReader(pushbackInputStream, "UTF-8");
      case 60:
        i = pushbackInputStream.read();
        paramStringBuffer.append('<');
        while (i > 0 && i != 62) {
          paramStringBuffer.append((char)i);
          i = pushbackInputStream.read();
        } 
        if (i > 0)
          paramStringBuffer.append((char)i); 
        str = getEncoding(paramStringBuffer.toString());
        if (str == null)
          return new InputStreamReader(pushbackInputStream, "UTF-8"); 
        paramStringBuffer.setLength(0);
        try {
          return new InputStreamReader(pushbackInputStream, str);
        } catch (UnsupportedEncodingException unsupportedEncodingException) {
          return new InputStreamReader(pushbackInputStream, "UTF-8");
        } 
    } 
    paramStringBuffer.append((char)i);
    return new InputStreamReader(pushbackInputStream, "UTF-8");
  }
  
  public StdXMLReader(InputStream paramInputStream) throws IOException {
    StringBuffer stringBuffer = new StringBuffer();
    Reader reader = stream2reader(paramInputStream, stringBuffer);
    this.currentReader = new StackedReader();
    this.readers = new Stack<StackedReader>();
    this.currentReader.lineReader = new LineNumberReader(reader);
    this.currentReader.pbReader = new PushbackReader(this.currentReader.lineReader, 2);
    this.currentReader.publicId = "";
    try {
      this.currentReader.systemId = new URL("file:.");
    } catch (MalformedURLException malformedURLException) {}
    startNewStream(new StringReader(stringBuffer.toString()));
  }
  
  public char read() throws IOException {
    int i;
    for (i = this.currentReader.pbReader.read(); i < 0; i = this.currentReader.pbReader.read()) {
      if (this.readers.empty())
        throw new IOException("Unexpected EOF"); 
      this.currentReader.pbReader.close();
      this.currentReader = this.readers.pop();
    } 
    return (char)i;
  }
  
  public boolean atEOFOfCurrentStream() throws IOException {
    int i = this.currentReader.pbReader.read();
    if (i < 0)
      return true; 
    this.currentReader.pbReader.unread(i);
    return false;
  }
  
  public boolean atEOF() throws IOException {
    int i;
    for (i = this.currentReader.pbReader.read(); i < 0; i = this.currentReader.pbReader.read()) {
      if (this.readers.empty())
        return true; 
      this.currentReader.pbReader.close();
      this.currentReader = this.readers.pop();
    } 
    this.currentReader.pbReader.unread(i);
    return false;
  }
  
  public void unread(char paramChar) throws IOException {
    this.currentReader.pbReader.unread(paramChar);
  }
  
  public Reader openStream(String paramString1, String paramString2) throws MalformedURLException, FileNotFoundException, IOException {
    URL uRL = new URL(this.currentReader.systemId, paramString2);
    if (uRL.getRef() != null) {
      String str1 = uRL.getRef();
      if (uRL.getFile().length() > 0) {
        uRL = new URL(uRL.getProtocol(), uRL.getHost(), uRL.getPort(), uRL.getFile());
        uRL = new URL("jar:" + uRL + '!' + str1);
      } else {
        uRL = StdXMLReader.class.getResource(str1);
      } 
    } 
    this.currentReader.publicId = paramString1;
    this.currentReader.systemId = uRL;
    StringBuffer stringBuffer = new StringBuffer();
    Reader reader = stream2reader(uRL.openStream(), stringBuffer);
    if (stringBuffer.length() == 0)
      return reader; 
    String str = stringBuffer.toString();
    PushbackReader pushbackReader = new PushbackReader(reader, str.length());
    for (int i = str.length() - 1; i >= 0; i--)
      pushbackReader.unread(str.charAt(i)); 
    return pushbackReader;
  }
  
  public void startNewStream(Reader paramReader) {
    startNewStream(paramReader, false);
  }
  
  public void startNewStream(Reader paramReader, boolean paramBoolean) {
    StackedReader stackedReader = this.currentReader;
    this.readers.push(this.currentReader);
    this.currentReader = new StackedReader();
    if (paramBoolean) {
      this.currentReader.lineReader = null;
      this.currentReader.pbReader = new PushbackReader(paramReader, 2);
    } else {
      this.currentReader.lineReader = new LineNumberReader(paramReader);
      this.currentReader.pbReader = new PushbackReader(this.currentReader.lineReader, 2);
    } 
    this.currentReader.systemId = stackedReader.systemId;
    this.currentReader.publicId = stackedReader.publicId;
  }
  
  public int getStreamLevel() {
    return this.readers.size();
  }
  
  public int getLineNr() {
    if (this.currentReader.lineReader == null) {
      StackedReader stackedReader = this.readers.peek();
      return (stackedReader.lineReader == null) ? 0 : (stackedReader.lineReader.getLineNumber() + 1);
    } 
    return this.currentReader.lineReader.getLineNumber() + 1;
  }
  
  public void setSystemID(String paramString) throws MalformedURLException {
    this.currentReader.systemId = new URL(this.currentReader.systemId, paramString);
  }
  
  public void setPublicID(String paramString) {
    this.currentReader.publicId = paramString;
  }
  
  public String getSystemID() {
    return this.currentReader.systemId.toString();
  }
  
  public String getPublicID() {
    return this.currentReader.publicId;
  }
  
  private class StackedReader {
    PushbackReader pbReader;
    
    LineNumberReader lineReader;
    
    URL systemId;
    
    String publicId;
    
    private StackedReader() {}
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\xml\StdXMLReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */