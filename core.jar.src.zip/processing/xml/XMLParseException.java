package processing.xml;

public class XMLParseException extends XMLException {
  public XMLParseException(String paramString) {
    super(paramString);
  }
  
  public XMLParseException(String paramString1, int paramInt, String paramString2) {
    super(paramString1, paramInt, null, paramString2, true);
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\xml\XMLParseException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */