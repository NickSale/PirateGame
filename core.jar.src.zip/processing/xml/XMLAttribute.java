package processing.xml;

class XMLAttribute {
  private String name;
  
  private String localName;
  
  private String namespace;
  
  private String value;
  
  private String type;
  
  XMLAttribute(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    this.name = paramString1;
    this.localName = paramString2;
    this.namespace = paramString3;
    this.value = paramString4;
    this.type = paramString5;
  }
  
  String getName() {
    return this.name;
  }
  
  String getLocalName() {
    return this.localName;
  }
  
  String getNamespace() {
    return this.namespace;
  }
  
  String getValue() {
    return this.value;
  }
  
  void setValue(String paramString) {
    this.value = paramString;
  }
  
  String getType() {
    return this.type;
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\xml\XMLAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */