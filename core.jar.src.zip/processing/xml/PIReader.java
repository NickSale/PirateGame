package processing.xml;

import java.io.IOException;
import java.io.Reader;

class PIReader extends Reader {
  private StdXMLReader reader;
  
  private boolean atEndOfData;
  
  PIReader(StdXMLReader paramStdXMLReader) {
    this.reader = paramStdXMLReader;
    this.atEndOfData = false;
  }
  
  protected void finalize() throws Throwable {
    this.reader = null;
    super.finalize();
  }
  
  public int read(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException {
    if (this.atEndOfData)
      return -1; 
    byte b = 0;
    if (paramInt1 + paramInt2 > paramArrayOfchar.length)
      paramInt2 = paramArrayOfchar.length - paramInt1; 
    while (b < paramInt2) {
      char c = this.reader.read();
      if (c == '?') {
        char c1 = this.reader.read();
        if (c1 == '>') {
          this.atEndOfData = true;
          break;
        } 
        this.reader.unread(c1);
      } 
      paramArrayOfchar[b] = c;
      b++;
    } 
    if (b == 0)
      b = -1; 
    return b;
  }
  
  public void close() throws IOException {
    while (!this.atEndOfData) {
      char c = this.reader.read();
      if (c == '?') {
        char c1 = this.reader.read();
        if (c1 == '>')
          this.atEndOfData = true; 
      } 
    } 
  }
}


/* Location:              C:\Users\nicho\Downloads\PirateGame.zip!\lib\core.jar!\processing\xml\PIReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */